# CyberTrace Compliance Engine — Platform Specification

**Document type:** Engineering & Product Definition
**Audience:** Internal — Systems Security Engineering, ISSO/ISSM, Program Security
**Status:** Draft for review — v3

---

## 1. Problem Statement

### 1.1 Failure Modes

1. **Artifact divergence.** The SP and SCTM are maintained as separate documents. They drift. Reconciling them before delivery is manual, expensive, and never fully trusted.
2. **Evidence archaeology.** Proof lives in SharePoint, Lucid, Confluence, ticketing, and email. Nobody knows which artifact proves which control, whether it is current, or who owns it.
3. **No reuse across systems and variants.** Subsystems are shared across products and programs, but implementations are re-authored each time.
4. **Untracked work.** "Go find the evidence for AC-2" is assigned verbally. Aging, blockers, and reviewer state are invisible until a delivery date slips.
5. **Unmanaged change.** A component swap, a published CVE, or an overlay revision perturbs the package in ways that are *predictable in kind but untracked in practice*. The blast radius is recomputed by hand, from memory, every time — and the parts nobody remembered stay stale until an assessor finds them.

Failure mode 5 is the largest and the least addressed by existing tooling.

### 1.2 The Package Is a Living Object

The SP and SCTM are not authored once. They are perturbed continuously by a small set of recurring event types, and the work is keeping them consistent as the system moves through its authorization lifecycle. Six recurring triggers are documented in §4.

Three consequences drive the architecture:

- **Implementation status is not monotonic.** A published CVE knocks controls from Implemented back to Partially Implemented. Status must be a versioned, reversible state with full history — not a checkbox that only advances.
- **The evidence bar changes with authorization state.** At IATT, "Planned" with an accepted risk is legitimate. At full ATO, the same control needs evidence-backed implementation. The same record is compliant in one state and a gap in the next. Readiness must be evaluated *against a target state*, not absolutely.
- **Change impact is computable.** Every trigger type has a known propagation pattern. The platform should compute the blast radius, not ask the SSE to remember it.

### 1.3 The SCTM Is a Contract Deliverable

The SCTM is a spreadsheet delivered to the customer proving every required control is accounted for: what the control requires, how the system implements it (or plans to, or why it does not apply), the implementation status, and what evidence supports the claim.

- **Format is customer-dictated.** They supply a template or request columns beyond baseline. Export to *their* format.
- **Custom columns are typed data, not notes.** A customer-requested column must be queryable, assignable, and reportable.
- **A program has multiple systems.** Each gets its own SCTM, often against one shared template, with a program rollup.
- **SSE discretion is a feature.** How an implementation is described is engineering judgment. Support and standardize it; do not automate it away.

### 1.4 Explicit Non-Goals

- **Not a vulnerability or STIG scanner.** Scan results are one evidence input. Scan-first optimizes the minority of controls that automate.
- **Not a document repository.** Evidence stays in its system of record; the platform holds references, metadata, and validity state.
- **Not an authorship replacement.** The tool eliminates rekeying, reconciliation, and forgotten downstream edits — not engineering judgment.

---

## 2. Framework Model

### 2.1 Derivation Chain

```
Security Standard  +  System Categorization  +  Overlays  +  Program Tailoring
        │                      │                    │                │
        ▼                      ▼                    ▼                ▼
   Control catalog      C-I-A impact levels    Add / modify /    Remove N/A,
   (800-53 master)      (L/M/H per axis)       raise floors      add environment-
        │                      │                    │            specific
        └──────────────────────┴────────────────────┴────────────────┘
                                    │
                                    ▼
                          TAILORED CONTROL SET
                                    │
                     ┌──────────────┴──────────────┐
                     ▼                             ▼
              SCTM (customer format)          SP (narrative)
```

Every stage is individually inspectable and reversible. "Why is SC-8(1) in this baseline" must be one click.

### 2.2 Standards Layer

**NIST SP 800-53** is the master catalog for federal systems — the canonical source of control text, enhancements, and parameters.

**CNSSI 1253** applies to national security systems. All NSS are federal systems, so 1253 builds on the 800-53 catalog rather than replacing it. The material difference is the **selection algorithm**:

| | Impact model | Selection logic |
|---|---|---|
| **NIST 800-53B** | Single-axis; one level via FIPS 199 high-water mark | Control selected if the single level meets its threshold |
| **CNSSI 1253** | Three-axis; C, I, A rated independently | Control selected if **any** axis meets that control's threshold for that axis. Pulls in ~120 controls beyond the civilian Moderate baseline |

**This is the most consequential schema decision in the platform.** Impact is stored as a triple everywhere; applicability is stored per axis. A single-axis model cannot be retrofitted — it propagates through baseline resolution, every SCTM, every tailoring rationale, and every inheritance calculation.

### 2.3 Control Applicability Model

```
control_axis_applicability
├── catalog_version
├── control_id            (to enhancement depth, e.g. AC-2(3))
├── axis                  C | I | A
├── min_level             L | M | H | NOT_SELECTED
└── axis_parameter_values (where the axis drives a differing parameter)
```

```
selected(control, system) =
    ANY axis IN {C, I, A} WHERE
        system.categorization[axis] >= control.min_level[axis]
```

**Selection provenance is mandatory** — store *which axis or axes* drove selection. "SC-8 is in solely because Confidentiality is Moderate" is the exact conversation that occurs when an AO reconsiders a categorization, and the platform must answer it instantly.

### 2.4 Concurrent Catalog Revisions

Catalog revisions are not adopted uniformly. Adoption is slow and inconsistent, and customers sometimes request an older revision deliberately — space programs have requested Rev 4 for schedule reasons, accepting the security tradeoff.

Requirements:

- **Multiple catalog revisions live simultaneously.** Program A on Rev 4 and Program B on Rev 5 is a normal steady state, not a migration window.
- **Systems pin to a revision.** Migration is an explicit, scheduled change event (§4, Trigger 4), never a silent global update.
- **Cross-revision crosswalk is curated, not computed.** The Rev 4 → Rev 5 mapping is imperfect — controls were renumbered, merged, split, and withdrawn. Store the crosswalk as reviewable data with confidence levels and a human-review queue for ambiguous mappings. Treating it as a clean automated join will silently corrupt reuse across programs on different revisions.
- **Component implementations declare their revision.** Reusing a Rev 5 component statement on a Rev 4 system requires an explicit mapped-and-reviewed step.

### 2.5 Categorization

Each axis rated Low / Moderate / High independently. **M-M-L** = moderate impact for confidentiality and integrity compromise, low for availability loss.

| Field | Notes |
|---|---|
| `proposed_c/i/a` | SSE-proposed levels |
| `rationale_c/i/a` | Per-axis justification, required |
| `applied_floors[]` | Overlay-driven minimums with source overlay recorded |
| `effective_c/i/a` | Computed: `max(proposed, all applicable floors)` per axis |
| `approval_state` | Proposed / Under review / **AO-approved** / Superseded |
| `approving_ao`, `approval_date` | |
| `version`, `superseded_by` | Recategorization is a versioned event, never an edit |

**The AO has final say.** Proposed and approved are distinct states. Baselines may be computed from a proposed categorization for planning, but any exported SCTM states plainly which it rests on.

**Overlay floors are computed and attributed.** JSIG triggers a minimum M-L-L; the floor applies automatically when the overlay attaches, the raise is visible with its source, and the SSE cannot propose below it.

### 2.6 Overlays

Overlays apply on top of the selected baseline as ordered, composable modifiers: **add** controls, **remove** controls (with rationale), **set or tighten parameters**, **raise categorization floors**, **attach supplemental guidance**.

In scope: JSIG, Classified Information, Space Platform, Cross Domain, Privacy, Intel, plus program-specific and locally authored overlays.

Overlays stack; order is explicit and stored. Parameter conflicts are **surfaced, not silently resolved** — two overlays setting the same parameter differently blocks until a human decides, and the decision is recorded. Overlays never mutate the catalog; they resolve at read time.

### 2.7 Program Tailoring

Removes controls that are not applicable; adds controls the environment demands. Every action requires a rationale.

**Removals are suppressed, not deleted.** The control stays in the record with status Not Applicable and its rationale, and it still appears in the SCTM. A control silently missing reads as an oversight; a control marked N/A with justification reads as engineering. *(Template-level toggle if a customer expects a shorter matrix.)*

---

## 3. Authorization Lifecycle

Authorization state is a first-class system attribute, because **it determines the evidence bar**.

```
[Pre-authorization] ──► [IATT] ──► [ATO] ──► [Reauthorization] ──► [ATO']
                                     │                              
                                     └──► [Decommission]
```

| State | Control set | Acceptable status | Evidence bar |
|---|---|---|---|
| **Pre-authorization** | Draft baseline | Planned dominant | Design intent; forward-looking narratives |
| **IATT** | Scoped-down set, accepted risks | Planned acceptable with approved risk acceptance | Partial; interim mitigations documented |
| **ATO** | Complete baseline | Implemented / N/A / Inherited; Planned only with approved POA&M | Evidence-backed for every control |
| **Reauthorization** | Re-derived against current baseline | As ATO | Current evidence; expired artifacts fail |
| **Dev → Production** | Production environment set | As ATO for production boundary | Production-environment evidence, not dev |

**Requirements:**

- **Target-state readiness.** Every readiness view is evaluated against a *target* state, not absolutely. The IATT → ATO gap report is a distinct, high-value artifact: every control acceptable at IATT that will not be acceptable at ATO, plus every open POA&M requiring resolution or approved risk acceptance before transition.
- **Narrative mode shift.** The SP moves from forward-looking plans to evidence-backed implementation statements. Flag narratives still written in future tense when the target state is ATO — this is a real and repeated finding.
- **State transitions are change events** and run through the §4 engine like any other.

---

## 4. Change Event Model

The core abstraction. Every perturbation of the package is a typed **change event** with a computable blast radius.

```
[Change Event Intake] ──► [Classify Trigger Type] ──► [Compute Blast Radius]
                                                              │
                                                              ▼
                            [Generate Task Set] ──► [Author / Collect / Review]
                                                              │
                                                              ▼
                            [Regenerate Artifacts] ──► [Package Consistent]
```

A change event stays **open until every derived task closes**. Package consistency is a state the platform asserts, not a hope.

### 4.1 Trigger Taxonomy

**Trigger 1 — Authorization boundary change**
*Component added, removed, or replaced: new GSE in a configuration, a hardware part swapped to a different vendor, a software module added to the mission computer.*

| Impact | Auto-computable |
|---|---|
| SP boundary section requires update | Yes — flag section, generate task |
| New component needs implementation narratives | Yes — from component library if known; task if new |
| **NVM subsection** required if component has non-volatile memory | Yes — component attribute rule (§6.6) |
| SCTM reflects controls now implemented differently or newly applicable | Partially — controls touched by the component's declared implementations; SSE reviews the residual |

**Trigger 2 — Vulnerability / POA&M lifecycle**
*CVE published against a fielded component, scan finding returned, POA&M milestone comes due. Continuous and ongoing after IATT or ATO.*

| Impact | Auto-computable |
|---|---|
| Implementation status regresses on affected controls (typically **RA-5, SI-2, CM-6**) | Yes — status regression with history preserved |
| POA&M entry created or updated in the SP | Yes |
| Risk assessment section update documenting exposure and interim mitigations | Task-generated; narrative is SSE judgment |
| Authorization posture impact if severe | Flagged for ISSM/AO decision — never auto-decided |

This trigger makes **status regression** and **POA&M as a first-class lifecycle object** non-optional. It also means the platform must accept inbound CVE and scan feeds mapped to components, not just to systems — a CVE on a shared component should surface across every system that composes it.

**Trigger 3 — Authorization milestone transition**
*IATT → ATO, ATO renewal, dev → production.*

| Impact | Auto-computable |
|---|---|
| Scoped-down set with accepted risks → complete implementation evidence for every baseline control | Yes — target-state gap report (§3) |
| All open IATT POA&Ms need resolution or approved risk acceptance | Yes — filtered POA&M queue |
| SP shifts from forward-looking plans to evidence-backed statements | Partially — flag future-tense narratives for rewrite |

**Trigger 4 — Baseline or overlay update**
*Customer or authorizing body issues updated overlay parameters; NIST revises 800-53; CNSS updates 1253; AO adds program-specific requirements. Rare, but high blast radius.*

| Impact | Auto-computable |
|---|---|
| Control set re-derived against updated baseline | Yes |
| New controls added | Yes — with tasks |
| Removed controls need tailoring-out justification | Yes — flagged; rationale is SSE work |
| Existing controls may get new parameter values | Yes — diff parameters, flag narratives citing old values |
| Corresponding SP sections reflect updated requirements | Task-generated per affected section |

Because revisions are adopted inconsistently, this trigger runs **per program, not globally**. Rev 4 → Rev 5 migration uses the curated crosswalk (§2.4) with a human-review queue.

**Trigger 5 — Configuration divergence across variants**
*Umbrella case: configurations fork from a shared baseline into distinct variants — different hardware, environments, or threat exposures. Triggers 1 and 6 often live underneath this.*

| Impact | Auto-computable |
|---|---|
| SP boundary definitions delineate shared vs divergent implementations | Yes — inheritance provenance already carries this |
| SCTM needs per-configuration tracking | Yes — three delivery modes below |
| Configuration-specific components need own narratives and NVM subsections | Yes — component attribute rules |

**Three SCTM delivery modes required**, selectable per program because customers differ:
1. **Separate SCTMs** — one file per configuration
2. **Separate tabs** — one workbook, one tab per configuration
3. **Per-configuration columns** — one matrix, status columns per configuration

All three render from the same records. This is the concrete output of the delta model — plus the **delta package**: the subset showing exactly what differs from an approved parent, which is the reciprocity argument.

**Trigger 6 — Security-relevant capability change**
*A new capability with security implications: cryptographic subsystem, classified data handling path, new communication interface, COMSEC-controlled device. Introduces new security functions, data flows, or compliance requirements that did not previously exist — not a simple component swap. Examples: GPS receiver requiring key loading, encrypted comm link, new test or maintenance interface handling sensitive data, a device that changes the system's CCI status.*

| Impact | Auto-computable |
|---|---|
| New or revised narratives, particularly **SC-12, SC-13, SC-28, AU-10** | Control set flagged; narratives are SSE work |
| SP architecture sections, data flow diagrams, key management sections, CCI handling procedures | Yes — flag sections by capability type |
| **New supporting documents required** — CONOPS, key handling plan, sanitization plan | Yes — capability-driven document requirements (§6.7) |
| SP must reference, incorporate, and align with those documents | Reference tracked; alignment flagged for review |

This trigger is why supporting documents need their own register with dependency and alignment tracking. A key handling plan that exists but is not referenced by the SP is a finding; one referenced but stale is a worse one.

### 4.2 Cross-Cutting Requirements

- **Every event is typed at intake.** Free-text "misc update" is available but reports as untyped and unclassified in the audit trail.
- **Blast radius is proposed, then confirmed.** The engine computes affected controls, SP sections, evidence, and supporting documents; the SSE reviews and can add or remove scope with rationale. Never silent auto-edit of delivered content.
- **Events nest.** Trigger 5 commonly contains Triggers 1 and 6. Parent/child event relationships with rolled-up closure state.
- **Events close explicitly.** A change event is Open, In Progress, Pending Review, or Closed. Open events on a system are visible on every readiness view and on the program rollup.
- **Shared-component events fan out.** A CVE or boundary change on a shared component generates child events on every consuming system — subject to program segregation rules (§13, Q5).

---

## 5. Core Architectural Decisions

| ID | Decision |
|---|---|
| **AD-1** | The SP and SCTM are projections of one table. Exactly one editable record per (system, control). No output artifact is ever hand-edited. |
| **AD-2** | Impact is a triple; applicability is per axis. Non-negotiable and undeferrable. |
| **AD-3** | Evidence is federated, not stored. Link integrity and staleness are first-class features. |
| **AD-4** | Control implementations attach to components, not only systems. |
| **AD-5** | A variant is a delta, not a copy. |
| **AD-6** | Program is a first-class level above system. |
| **AD-7** | **The change event is the unit of work.** Not the control, not the document. Controls and documents are what events touch. |
| **AD-8** | **Implementation status is versioned and reversible**, with full history. Status regression is a normal transition, not an error state. |
| **AD-9** | **Readiness is evaluated against a target authorization state**, never absolutely. |
| **AD-10** | OSCAL as the internal object model, with a documented local extension for three-axis applicability and selection provenance. Do not distort categorization to fit stock OSCAL. |

---

## 6. Data Model

### 6.1 Hierarchy

```
PROGRAM
├── customer, deliverables, SCTM template(s), classification guidance
├── catalog revision pin, program-level common controls, tailoring decisions
│
├── SYSTEM A ── categorization ── auth state ── profile ── SCTM
├── SYSTEM B ── categorization ── auth state ── profile ── SCTM
└── SYSTEM C ── categorization ── auth state ── profile ── SCTM
    └── VARIANT C-2 ── delta only ── SCTM (+ delta package)

COMPONENT LIBRARY (cross-program, separately governed)
└── components with attributes, reusable implementations, revision tags
```

Two systems in one program can legitimately have different control sets — each carries its own categorization and authorization state.

### 6.2 Core Entities

| Entity | Purpose |
|---|---|
| `catalog` | Immutable 800-53 catalog version. Multiple live concurrently. |
| `catalog_crosswalk` | Curated cross-revision mapping with confidence and review state. |
| `control_axis_applicability` | Per-control, per-axis thresholds and parameters. |
| `overlay` | Ordered add / remove / set-parameter / raise-floor / guidance operations. |
| `program` | Customer, deliverables, templates, classification guidance, revision pin, common controls. |
| `system` | Authorization boundary within a program. |
| `authorization_state` | Versioned lifecycle state with effective dates and target state. |
| `categorization` | Versioned C-I-A triple with rationale, floors, AO approval state. |
| `profile` | Resolved effective control set. Immutable once locked. |
| `system_variant` | System whose parent is another system; deltas only. |
| `component` | Reusable subsystem, product, service, or hardware element, **with typed attributes**. |
| `component_implementation` | Control implementation owned by a component, tagged to a catalog revision. |
| `control_implementation` | **Single source of truth.** One per (system, control). |
| `implementation_status_history` | Append-only status transitions with cause and change event linkage. |
| **`change_event`** | Typed perturbation with blast radius, task set, and closure state. |
| `poam_item` | First-class lifecycle object with milestones, dates, and risk acceptance. |
| `risk_acceptance` | Approved acceptance with authority, scope, expiry. |
| `supporting_document` | CONOPS, key handling plan, sanitization plan, etc., with SP reference tracking. |
| `sctm_template` | Customer columns, ordering, vocabularies, formatting, delivery mode. |
| `custom_field` | Program-scoped typed field rendering as a customer column. |
| `evidence_artifact` | Pointer to proof in an external system of record. |
| `narrative_block` | Reusable approved implementation language. |
| `sp_section` | Addressable SP section for impact flagging and change tracking. |
| `assessment_procedure` / `assessment_result` | Test procedure and outcome. |
| `task` | Assigned work, normally parented to a change event. |
| `tailoring_action` | Auditable record of every add, remove, parameter change, or override. |

### 6.3 `control_implementation` — Field Set

**Requirement side (derived, read-only):** `control_id` to enhancement depth · `control_title`, `control_text`, `supplemental_guidance` (from pinned catalog version) · `selection_provenance` (which axes, which overlays) · resolved `parameter_values` · `applicable_overlays[]`

**Implementation side (authored):** `responsibility` (system-specific / inherited / hybrid / CCP / not applicable) · `inheritance_source` · `implementation_status` · `planned_completion_date` (required if Planned) · `na_rationale` (required if N/A) · `implementation_narrative` · `hybrid_delta` · `tailoring_rationale`

**Traceability:** `evidence_links[]` · `supporting_document_links[]` · `assessment_procedure_id` · `latest_assessment_result_id` · `open_poam_items[]`

**Lifecycle:** `status_history[]` · `open_change_events[]` · `last_reviewed_date` · `narrative_tense_flag`

**Workflow:** `owner` · `due_date` · `review_state` · `custom_field_values{}` · `classification_marking` · computed `provenance`

### 6.4 Implementation Status

`Implemented` · `Partially Implemented` · `Planned` · `Not Applicable` · `Alternate Implementation` · `Inherited`

**Status is versioned and bidirectional.** Every transition records timestamp, actor, cause, and the change event that drove it. A CVE moving a control from Implemented to Partially Implemented is a normal transition with full history — and when the POA&M closes, the prior evidence and narrative are recoverable rather than rewritten from scratch.

**Acceptability is state-dependent.** `Planned` is acceptable at IATT with an approved risk acceptance and a gap at ATO. The platform evaluates status against the target authorization state, never against a fixed rule.

### 6.5 Inheritance Resolution

```
1. Variant-level override
2. System-specific implementation
3. Component-provided implementation
4. Parent system inheritance          (for variants)
5. Program-level common control provider
6. Enterprise common control provider
7. UNSATISFIED → task + candidate POA&M item
```

Every resolved cell displays its provenance. Overriding inherited values requires rationale and writes a `tailoring_action`. Silent inheritance produces SCTMs that collapse under assessor questioning.

### 6.6 Component Attributes → Required Documentation

Components carry typed attributes that **automatically generate documentation requirements** when composed into a system. This is the generalization of the NVM rule.

| Attribute | Generated requirement |
|---|---|
| `has_nvm` | NVM subsection in the SP; sanitization procedure |
| `is_cryptographic` | Key management section; SC-12 / SC-13 narratives |
| `is_cci` | CCI handling procedures; accountability documentation |
| `handles_classified_data` | Data flow diagram update; SC-28 narrative |
| `external_interface` | Boundary diagram update; SC-7 narrative; interface control documentation |
| `requires_key_loading` | Key handling plan reference |

The rule table is data, not code — SSEs extend it as new attribute classes emerge. When a component with an attribute is added to a system, the requirements instantiate as tasks on the triggering change event.

### 6.7 Supporting Documents

Distinct from evidence artifacts. Evidence *proves* a control; a supporting document is a **companion deliverable the SP must reference, incorporate, and align with** — CONOPS, key handling plan, sanitization plan.

`document_type` · `uri` / system of record · `owner` · `version`, `approval_state` · `required_by` (capability, component attribute, or control) · `referenced_by_sp_sections[]` · `alignment_state` (aligned / needs review / divergent) · `last_alignment_check` · `classification_marking`

Two distinct failure states, both tracked: **required but missing**, and **referenced but stale**. When a change event touches a capability, its supporting documents flag for alignment review.

### 6.8 POA&M

| Field | Notes |
|---|---|
| `affected_controls[]` | Usually RA-5, SI-2, CM-6, plus capability-specific |
| `source` | CVE, scan finding, assessment finding, self-identified |
| `affected_components[]` | Enables fan-out across systems sharing a component |
| `milestones[]` | Each with owner, due date, completion state |
| `interim_mitigations` | Narrative; feeds the SP risk assessment section |
| `risk_acceptance_id` | If accepted rather than remediated |
| `authorization_impact` | ISSM/AO-flagged; never auto-decided |
| `state`, `originating_change_event` | |

Milestone due dates generate change events (Trigger 2). Open POA&Ms feed the IATT → ATO gap report (Trigger 3).

### 6.9 Evidence Artifact

`source_system` · `uri` / `external_id` · `artifact_type` · `title` · `owner` · `collected_date` · `validity_window` · `scope` · `version_stamp` · `link_state` · `last_verified` · `classification_marking` · `environment` (dev / test / production)

**Staleness:** past validity window, source modified after `collected_date`, or link unreachable past threshold. Stale evidence degrades readiness and tasks its owner.

**Scope enforcement:** cross-system reuse outside declared scope is blocked or flagged. The `environment` field matters at dev → production transition — dev evidence does not satisfy a production authorization.

### 6.10 Narrative Block Library

Approved reusable language, parameterized by system, component, and configuration values. Scoped to component, program, or enterprise, with ownership and approval state. **Editing a block never silently rewrites delivered SCTMs** — it flags every consuming implementation for review as a change event.

---

## 7. Operational Workflows

### 7.1 Initial Package Build

```
[Catalog & Overlay Ingest] ──► [Program Setup] ──► [System Definition & Composition]
                                                              │
                                                              ▼
                                              [Categorization & AO Approval]
                                                              │
                                                              ▼
                                              [Baseline Derivation & Tailoring]
                                                              │
                                                              ▼
                                              [Implementation Authoring]
                                                              │
                                                              ▼
                                              [Evidence Linking & Tasking]
                                                              │
                                                              ▼
                                              [Review & SCTM/SP Generation]
```

**Catalog & Overlay Ingest.** Import 800-53 catalogs and 1253 axis applicability tables. Multiple revisions live concurrently. Diff on import; report per-system impact before commit.

**Program Setup.** Customer, deliverables, SCTM template(s) and delivery mode, custom fields, classification guidance, catalog revision pin, program-level common controls.

**System Definition & Composition.** Define the boundary; compose from the component library. Component attributes instantiate documentation requirements immediately. Coverage appears before authoring begins.

**Categorization & AO Approval.** SSE proposes C, I, A with per-axis rationale. Overlay floors apply automatically and visibly. Moves to AO review; approval state carries into every downstream artifact.

**Baseline Derivation & Tailoring.** Three-axis selection, ordered overlays, conflict resolution, program tailoring. Every control shows why it is present. Removals become N/A with rationale and stay in the SCTM. Profile locks and snapshots on approval.

**Implementation Authoring.** Author or confirm statements for controls not satisfied by inheritance. Inherited text is read-only with provenance; overriding is explicit. Narrative library available.

**Evidence Linking & Tasking.** Link evidence; where absent, create tasks with owners and dates. This step is where delivery schedules are won or lost.

**Review & Generation.** Author → ISSO → ISSE → ISSM. Generate SCTM in the customer's exact template and delivery mode, plus SP, POA&M, and evidence index — all renders of the same records, marked, timestamped, hash-stamped, citing profile version and categorization approval state.

### 7.2 The Change Loop *(steady state — where most of the work lives)*

```
        [Change Event Intake: typed trigger]
                      │
                      ▼
        [Blast Radius Computed & Confirmed]
                      │
       ┌──────────────┼──────────────┬──────────────┐
       ▼              ▼              ▼              ▼
  [Controls to    [SP sections   [Evidence to   [Supporting
   re-author]      to update]     re-collect]    docs to align]
       │              │              │              │
       └──────────────┴──────┬───────┴──────────────┘
                             ▼
                  [Tasks assigned & tracked]
                             ▼
                  [Review chain]
                             ▼
                  [Artifacts regenerated]
                             ▼
                  [Event closed — package consistent]
```

Open change events are visible on every system readiness view and the program rollup. A system with open events is not a system with a current package.

### 7.3 Continuous Monitoring

Background: evidence link reachability and source modification timestamps · validity window expiry · catalog revision changes affecting pinned programs · POA&M milestone due dates · authorization expiry approaching reauthorization · supporting document version drift.

Each finding generates a typed change event or a task on an existing one. Nothing surfaces as a notification that can be dismissed without a record.

---

## 8. Module Specifications

### Module A — Catalog & Standards Manager
800-53 import with schema validation · CNSSI 1253 three-axis applicability tables · concurrent revision support with per-program pinning · **curated cross-revision crosswalk with confidence levels and human-review queue** · overlay authoring · ordered stacking with conflict surfacing · version diffing with per-system impact.

### Module B — Program Workspace
Program definition, customer, deliverables · SCTM template and delivery-mode management · custom field definitions · catalog revision pin · program-level common controls · cross-system rollup: readiness by target state, evidence currency, open change events, open POA&Ms, delivery dates.

### Module C — Categorization Manager
Per-axis proposal with mandatory rationale · automatic overlay floor application with attribution · AO approval workflow · versioned recategorization · **impact preview** before committing an axis change.

### Module D — Baseline Derivation & Tailoring Studio
Three-axis selection with per-control axis provenance · ordered overlay application · parameter conflict resolution · tailoring with mandatory rationale · N/A suppression rather than deletion · coverage projection from composed components · profile lock with approval gate · effective profile export.

### Module E — Component Library
Reusable component definitions **with typed attributes** · attribute-driven documentation requirement rules (editable as data) · component-owned implementations tagged to catalog revision · **reverse impact query required before any edit** · component versioning · CVE and finding fan-out to consuming systems · separately governed cross-program tier.

### Module F — Change Impact Engine ⭐
The differentiating module.

- Typed change event intake covering all six triggers plus untyped fallback
- **Blast radius computation** per trigger type: affected controls, SP sections, evidence, supporting documents, downstream systems
- Proposed-then-confirmed workflow — SSE reviews scope, adds or removes with rationale, never silent auto-edit
- Automatic task generation with suggested owners from prior assignment history
- Nested parent/child events with rolled-up closure
- Event closure gating: package asserted consistent only when all derived tasks close
- Inbound feeds: CVE and scan findings mapped to components, POA&M milestone dates, catalog revision publication, authorization expiry

### Module G — Authorization Lifecycle Manager
Versioned state with effective dates · target-state selection · **state-specific evidence bar evaluation** · IATT → ATO gap report · future-tense narrative detection · risk acceptance register with authority, scope, and expiry · reauthorization countdown.

### Module H — POA&M Manager
First-class POA&M lifecycle with milestones and owners · status regression driven into affected control implementations with history · interim mitigation narratives feeding the SP risk assessment section · component-level fan-out across systems · risk acceptance linkage · authorization impact flagged to ISSM/AO, never auto-decided.

### Module I — Implementation Workspace
Primary authoring surface.

| Column | Content |
|---|---|
| Control | ID, title, text, and **why it is in this baseline** (axis + overlay provenance) |
| Responsibility | System-specific / inherited / hybrid / CCP / N/A |
| Provenance | Full inheritance resolution chain |
| Implementation | Narrative — editable, or read-only if inherited |
| Status | Current status, history, and **acceptability against target state** |
| Evidence | Linked artifacts with currency indicators |
| Open items | Change events and POA&Ms touching this control |
| Custom | Program-defined template columns |
| Owner / Due | Assignment and aging |

Filterable by family, status, responsibility, owner, evidence currency, selecting axis, overlay-modified, open event, and target-state gap.

### Module J — SCTM Template Engine
Import or define customer column layouts · map platform fields to customer headers · typed custom fields with vocabularies · **three delivery modes** (separate SCTMs / separate tabs / per-configuration columns) selectable per program · exact-format XLSX export preserving headers, ordering, and styling · **customer markup re-import** mapping assessor comments back to source records · template versioning.

### Module K — Evidence Registry
SharePoint, Lucid, Confluence, ticketing, repository connectors with URL fallback · scheduled link health checks · validity windows and staleness detection · scope and environment declarations with enforcement · reverse lookup · orphan reporting.

### Module L — Supporting Document Register
Capability-driven and attribute-driven document requirements · SP reference tracking · alignment state with review workflow · missing-vs-stale distinction · version and approval tracking.

### Module M — Task & Workflow Engine
Assignment against controls, evidence, supporting documents, or POA&M items · normally parented to change events · owner, due date, blocker, escalation · aging and per-owner queues · review chain author → ISSO → ISSE → ISSM · full audit log.

### Module N — Artifact Generation
SCTM in customer format and delivery mode · SP with change-tracked sections · POA&M · evidence index · supporting document index · variant delta package · IATT → ATO gap report. All outputs marked, timestamped, hash-stamped, citing profile version, catalog revision, categorization approval state, and authorization state. Hand-editing structurally prevented.

### Module O — Technical Check Connector *(Phase 4)*
STIG/SCAP results populate evidence records and generate Trigger 2 events on findings. Published CCI-to-control mappings have historically lagged catalog revisions; treat the crosswalk as curation requiring review.

---

## 9. Deployment & Handling Constraints

| Constraint | Requirement |
|---|---|
| Network isolation | Fully functional with no outbound connectivity. No phone-home, no external webhooks. |
| Offline updates | Catalog, overlay, and CVE feed updates as signed offline bundles. |
| Classification marking | Every record marked; artifacts carry banner and portion markings; aggregates at highest constituent level. |
| Program segregation | No cross-program visibility via any query path, including search, reverse lookup, and the shared component library. |
| Audit | Immutable log of all record changes, approvals, categorization decisions, status transitions, and exports. |

---

## 10. Feature Matrix

| ID | Module | Requirement | Acceptance Metric |
|---|---|---|---|
| FT-CAT-01 | Standards Manager | 800-53 catalog import | Addressable to `XX-N(n)(a)` depth |
| FT-CAT-02 | Standards Manager | Three-axis applicability | Every control carries independent C, I, A thresholds |
| FT-CAT-03 | Standards Manager | Concurrent revisions | Programs on Rev 4 and Rev 5 operate simultaneously without interference |
| FT-CAT-04 | Standards Manager | Curated crosswalk | Cross-revision mappings carry confidence; ambiguous ones queue for review |
| FT-CAT-05 | Standards Manager | Overlay conflict detection | Conflicting parameters block pending explicit resolution |
| FT-CAZ-01 | Categorization | Independent C-I-A storage | Triple stored end to end; no high-water-mark collapse |
| FT-CAZ-02 | Categorization | Automatic overlay floors | Overlay attach applies its minimum with visible attribution |
| FT-CAZ-03 | Categorization | AO approval state | Every export states AO-approved vs provisional |
| FT-CAZ-04 | Categorization | Recategorization impact | Axis change produces full baseline diff before commit |
| FT-SEL-01 | Tailoring Studio | Three-axis selection | Control selected if any axis meets its threshold |
| FT-SEL-02 | Tailoring Studio | Selection provenance | Every control shows which axis and overlay put it in the baseline |
| FT-SEL-03 | Tailoring Studio | N/A suppression | Tailored-out controls remain in the SCTM as N/A with rationale |
| FT-SEL-04 | Tailoring Studio | Baseline lock | Locked profile immutable; every SCTM cites its version |
| FT-CHG-01 | Change Impact Engine | Typed intake | All six triggers classifiable; untyped events report as unclassified |
| FT-CHG-02 | Change Impact Engine | Blast radius computation | Each trigger type computes affected controls, SP sections, evidence, and documents |
| FT-CHG-03 | Change Impact Engine | Confirm before apply | No delivered content edits without SSE scope confirmation |
| FT-CHG-04 | Change Impact Engine | Event closure gating | Package reports consistent only when all derived tasks close |
| FT-CHG-05 | Change Impact Engine | Nested events | Parent/child relationships with rolled-up closure state |
| FT-CHG-06 | Change Impact Engine | Component fan-out | A component-level finding generates child events on every consuming system |
| FT-LFC-01 | Lifecycle Manager | State-specific evidence bar | Same record evaluates differently against IATT vs ATO targets |
| FT-LFC-02 | Lifecycle Manager | Transition gap report | IATT → ATO report lists every control and POA&M blocking transition |
| FT-LFC-03 | Lifecycle Manager | Narrative tense detection | Future-tense narratives flagged when target state is ATO |
| FT-LFC-04 | Lifecycle Manager | Environment scoping | Dev-environment evidence does not satisfy production authorization |
| FT-STS-01 | Implementation Workspace | Reversible status | Status regression preserves prior narrative and evidence for recovery |
| FT-STS-02 | Implementation Workspace | Status history | Every transition records timestamp, actor, cause, and driving change event |
| FT-PAM-01 | POA&M Manager | First-class lifecycle | Milestones with owners and dates; due dates generate change events |
| FT-PAM-02 | POA&M Manager | Status propagation | Opening a POA&M regresses affected control status automatically |
| FT-PAM-03 | POA&M Manager | Authorization impact | Posture-affecting findings flag to ISSM/AO; never auto-decided |
| FT-CMP-01 | Component Library | Reusable implementations | Statement authored once appears in every composing system with provenance |
| FT-CMP-02 | Component Library | Reverse impact query | Component edit surfaces all affected systems before save |
| FT-CMP-03 | Component Library | Attribute rules | `has_nvm` and peers auto-generate documentation requirements as tasks |
| FT-SUP-01 | Supporting Documents | Requirement generation | Capability changes instantiate required document tasks |
| FT-SUP-02 | Supporting Documents | Alignment tracking | Distinguishes required-but-missing from referenced-but-stale |
| FT-SCT-01 | Template Engine | Customer format export | Exports in the customer's exact columns, order, and headers |
| FT-SCT-02 | Template Engine | Delivery modes | Separate SCTMs, tabs, and per-configuration columns all render from one dataset |
| FT-SCT-03 | Template Engine | Typed custom fields | Customer columns are queryable, assignable data |
| FT-SCT-04 | Template Engine | Markup re-import | Customer comments on a returned SCTM map back to source records |
| FT-IMP-01 | Implementation Workspace | Single source of truth | SP and SCTM from the same records; discrepancy count structurally zero |
| FT-IMP-02 | Implementation Workspace | Visible provenance | Every inherited value shows its full resolution chain |
| FT-IMP-03 | Implementation Workspace | Override discipline | Overriding inherited values requires rationale and writes a tailoring action |
| FT-IMP-04 | Implementation Workspace | Narrative library | Block edits flag consumers for review, never silent rewrite |
| FT-EVD-01 | Evidence Registry | Federated references | Evidence resolves to its system of record; no primary copies stored |
| FT-EVD-02 | Evidence Registry | Link health | Unreachable links detected on schedule and routed to owners |
| FT-EVD-03 | Evidence Registry | Scope enforcement | Out-of-scope cross-system reuse blocked or flagged |
| FT-VAR-01 | Variant Engine | Delta-based derivation | Variant stores only deltas; unchanged controls resolve by inheritance |
| FT-VAR-02 | Variant Engine | Impact computation | Declared delta computes affected controls and invalidated evidence |
| FT-VAR-03 | Artifact Generation | Delta package | Exports the SCTM subset differing from the approved parent |
| FT-WFL-01 | Task Engine | Assignment and aging | Any gap assignable with owner, due date, escalation |
| FT-WFL-02 | Task Engine | Review chain | Approval states enforced with immutable audit trail |
| FT-GEN-01 | Artifact Generation | No hand-editing | Exports marked, timestamped, hash-stamped, regenerable |
| FT-DEP-01 | Platform | Isolated-network operation | Full functionality with no outbound connectivity |
| FT-DEP-02 | Platform | Marking propagation | Aggregates marked at highest constituent level |
| FT-DEP-03 | Platform | Program segregation | No cross-program visibility via any query path |

---

## 11. Success Metrics

| Metric | Direction |
|---|---|
| **Time from change event intake to package consistency** | Down — headline metric |
| Time to first draft SCTM for a new system in an existing program | Down |
| Time to first draft SCTM for a variant of an approved system | Down |
| **Change events closed without a downstream item missed** | Up toward 100% |
| Median open change event age | Down |
| Systems with zero open change events at delivery | Up |
| Inheritance reuse rate | Up |
| SP/SCTM discrepancy count | Structurally zero |
| Rework cycles after customer SCTM review | Down |
| Time to produce an IATT → ATO gap report | Minutes, not weeks |
| % of controls with linked, current evidence | Up |
| Median evidence age | Down |
| Required-but-missing supporting documents | Zero at delivery |
| Referenced-but-stale supporting documents | Zero at delivery |
| Controls with no assigned owner | Zero |
| Controls with no recorded selection provenance | Zero |

---

## 12. Phasing

**Phase 1 — Single source of truth.** Catalog and 1253 axis ingest, concurrent revisions, program and system definition, categorization with floors and AO state, three-axis derivation, tailoring, implementation authoring, SCTM template engine with delivery modes, SCTM and SP generation. *Kills artifact divergence and manual SCTM assembly.*

**Phase 2 — Evidence, work, and lifecycle.** Evidence registry with SharePoint and Lucid connectors, link health, task engine, review chain, narrative library, authorization state with target-state readiness, POA&M manager, supporting document register. *Kills evidence archaeology and untracked work; makes the IATT → ATO transition a report instead of a project.*

**Phase 3 — Change impact and reuse.** Change Impact Engine across all six triggers, component library with attribute rules, variant derivation, delta packages, component fan-out, continuous monitoring. *Kills unmanaged change and re-authoring. Highest-value phase; Phases 1–2 exist to make it possible.*

**Phase 4 — Automated checks.** STIG/SCAP connector feeding evidence and generating Trigger 2 events. Valuable only once 1–3 are in production.

**Sequencing note.** Change Impact is the differentiator but cannot be built first — blast radius computation requires the data model from Phase 1 and the evidence and lifecycle layers from Phase 2. Building it early produces a workflow engine that computes impact against records nobody trusts.

---

## 13. Open Questions

1. **Authorization path per program.** DoD RMF via eMASS, DCSA under DAAPM, or SAP under JSIG? Does not change the 800-53 baseline but determines whether an eMASS export is mandatory and what artifact conventions apply. JSIG's presence in the overlay set implies at least some SAP work — design markings and segregation accordingly.

2. **CVE and finding feed.** What is the authoritative inbound source for Trigger 2 — a scanning platform, a manual ISSO intake, or a vendor advisory feed? On isolated networks this arrives as an offline bundle, which constrains freshness. Also: what maps a CVE to a component in the library? That join is the difference between fan-out working and not.

3. **Categorization authority workflow.** Does the AO interact with the platform directly, or does an ISSM record the decision on their behalf? Determines whether approval is a workflow state or an attested record.

4. **Component ownership.** Who owns and approves a shared component's implementations, given that an edit fans out across programs? Needs a named role before Phase 3.

5. **Cross-program component sharing vs segregation.** Segregation says programs cannot see each other's data; reuse and CVE fan-out say components should be shared. Proposed resolution: a separately governed, non-program-scoped component tier with its own access model, where fan-out notifies the consuming program's ISSO without exposing the originating program. Confirm with program security before building.

6. **Custom field governance.** Who defines new customer template columns — program lead or a central owner? Uncontrolled proliferation fragments cross-program reporting within a year.

7. **Catalog revision policy.** When 800-53 or 1253 revises, what is the default for pinned programs — migrate at reauthorization, migrate on customer direction, or indefinite pinning? Also: what is the review standard for accepting a crosswalk mapping as authoritative?

8. **Connector priority.** Confirm SharePoint and Lucid for Phase 2; identify the third.

9. **Highest classification handled.** Determines deployment topology and whether one instance can serve all programs.
