// Attest — shared session store (business logic only; no styling)
(function () {
  if (window.__attest) return;

  // Product-line universe: Kestrel parent (authorized) + two variants (delta-based),
  // plus standalone systems. Kestrel-M carries the working narrative.
  var PROGRAMS = [
    { id: "kestrel", code: "PRG-011", name: "Kestrel TUAS", service: "U.S. Army", platform: "Group 4 tactical UAS",
      kind: "parent", ato: "ATO 14 Mar 2026", profileVer: "Profile P-3 · locked",
      triad: "M-M-H", il: "IL5", controls: 612, tailored: 612, implemented: 604, partial: 8, planned: 0,
      reqs: 148, reqAllocated: 148, reqGap: 0, phase: "Sustainment", health: "on-track", swatch: "var(--swatch-amber)", updated: "27 Jul",
      sctmRev: "Rev G", spRev: "Rev G", due: "Reauth Mar 2029", cdrl: "A012 / A014", owner: "M. Okonjo", assessor: "AFLCMC/HNCP", evCur: 96 },
    { id: "kestrel-m", code: "PRG-014", name: "Kestrel-M TUAS", service: "U.S. Navy", platform: "Shipboard Group 4 UAS",
      kind: "variant", parentId: "kestrel", parentName: "Kestrel TUAS", deltas: 8, reuse: 93,
      triad: "M-M-H", il: "IL5", controls: 612, tailored: 612, implemented: 471, partial: 96, planned: 45,
      reqs: 148, reqAllocated: 141, reqGap: 7, phase: "Assessment", health: "at-risk", swatch: "var(--swatch-green)", updated: "29 Jul",
      sctmRev: "Rev C", spRev: "Rev B", due: "14 Sep 2026", cdrl: "A012 / A014", owner: "M. Okonjo", assessor: "NAVWAR 5.0", evCur: 71 },
    { id: "kestrel-x", code: "PRG-047", name: "Kestrel-X TUAS", service: "FMS · export", platform: "Export Group 4 UAS",
      kind: "variant", parentId: "kestrel", parentName: "Kestrel TUAS", deltas: 3, reuse: 84,
      triad: "M-L-M", il: "IL4", controls: 541, tailored: 541, implemented: 38, partial: 9, planned: 494,
      reqs: 92, reqAllocated: 61, reqGap: 31, phase: "Planning", health: "on-track", swatch: "var(--swatch-teal)", updated: "25 Jul",
      sctmRev: "Rev A", spRev: "—", due: "Q2 FY27", cdrl: "A012", owner: "S. Whitfield", assessor: "TBD", evCur: 22 },
    { id: "halcyon", code: "PRG-021", name: "Halcyon ASW Suite", service: "U.S. Navy", platform: "Shipboard mission system",
      kind: "system",
      triad: "M-H-H", il: "IL6", controls: 688, tailored: 688, implemented: 402, partial: 174, planned: 112,
      reqs: 206, reqAllocated: 178, reqGap: 28, phase: "EMD", health: "at-risk", swatch: "var(--swatch-blue)", updated: "28 Jul",
      sctmRev: "Rev F", spRev: "Rev E", due: "02 Nov 2026", cdrl: "B003", owner: "K. Reyes", assessor: "NAVWAR 5.0", evCur: 78 },
    { id: "vantage", code: "PRG-007", name: "Vantage GEO Payload", service: "U.S. Space Force", platform: "GEO hosted payload",
      kind: "system",
      triad: "H-H-M", il: "IL6", controls: 741, tailored: 741, implemented: 655, partial: 61, planned: 25,
      reqs: 174, reqAllocated: 174, reqGap: 0, phase: "Production", health: "on-track", swatch: "var(--swatch-violet)", updated: "27 Jul",
      sctmRev: "Rev H", spRev: "Rev H", due: "30 Aug 2026", cdrl: "C101 / C104", owner: "D. Vasquez", assessor: "SSC/SZG", evCur: 91 },
    { id: "corvid", code: "PRG-033", name: "Corvid ECU/FCC", service: "U.S. Air Force", platform: "Airborne flight controls",
      kind: "system",
      triad: "M-M-H", il: "IL5", controls: 574, tailored: 574, implemented: 318, partial: 141, planned: 115,
      reqs: 121, reqAllocated: 96, reqGap: 25, phase: "TMRR", health: "off-track", swatch: "var(--swatch-sky)", updated: "29 Jul",
      sctmRev: "Rev B", spRev: "Rev A", due: "19 Dec 2026", cdrl: "A008", owner: "S. Whitfield", assessor: "AFLCMC/EZ", evCur: 64 },
    { id: "packhorse", code: "PRG-045", name: "Packhorse Edge Kit", service: "U.S. Marine Corps", platform: "Tactical edge compute",
      kind: "system",
      triad: "M-M-M", il: "IL4", controls: 498, tailored: 498, implemented: 466, partial: 22, planned: 10,
      reqs: 96, reqAllocated: 94, reqGap: 2, phase: "Production", health: "on-track", swatch: "var(--swatch-vermilion)", updated: "24 Jul",
      sctmRev: "Rev D", spRev: "Rev D", due: "07 Oct 2026", cdrl: "D021", owner: "J. Park", assessor: "MCSC PfM IA", evCur: 88 }
  ];

  // Variant deltas — a variant stores only what differs from its parent (AD-4).
  var VARIANTS = {
    "kestrel-m": {
      parent: "kestrel", affected: 41, inherited: 571, reusePct: 93,
      deltas: [
        { id: "D-01", title: "Crypto module — KGV-72M replaced by KI-700", chg: "CHG-118", controls: ["SC-12", "SC-13", "SC-28", "IA-7"], evidence: "2 artifacts stale · bench report to re-collect", state: "In review", tone: "warn" },
        { id: "D-02", title: "Primary link — LOS C-band replaced by SATCOM", controls: ["SC-8(1)", "AC-17", "AC-4"], evidence: "KM-SIL-CRYPTO-TR-014 out of declared scope", state: "Impact computed", tone: "warn" },
        { id: "D-03", title: "Shipboard power and EMI enclosure", controls: ["PE-9", "PE-11"], evidence: "One-line diagram collected 24 Jul", state: "Evidence linked", tone: "ok" },
        { id: "D-04", title: "GCS hosted in ship operations center", controls: ["PE-2", "PE-3", "PE-6"], evidence: "Inherited from ship enclave — attestation current", state: "Inheritance claimed", tone: "ok" },
        { id: "D-05", title: "Two-node GCS — no third failover site", controls: ["CP-7"], evidence: "Parameter change · tailoring action TA-032", state: "Tailoring recorded", tone: "ok" },
        { id: "D-06", title: "Depot maintenance performed afloat", controls: ["MA-2", "IA-5", "IA-5(1)"], evidence: "Procedure KM-PRO-0044 in draft · FND-0209", state: "Authoring", tone: "warn" },
        { id: "D-07", title: "Training equipment removed from boundary", controls: ["14 controls → N/A"], evidence: "Tailoring action TA-029 with rationale", state: "Tailoring recorded", tone: "ok" },
        { id: "D-08", title: "Salt-fog hardened air vehicle enclosure", controls: ["CM-8"], evidence: "Configuration item update only", state: "No control impact", tone: "ok" }
      ]
    },
    "kestrel-x": {
      parent: "kestrel", affected: 62, inherited: 479, reusePct: 84,
      deltas: [
        { id: "D-01", title: "Releasable crypto suite replaces Type 1 module", controls: ["SC-12", "SC-13", "IA-7"], evidence: "Export ruling pending", state: "Authoring", tone: "warn" },
        { id: "D-02", title: "Cross-domain guard removed from boundary", controls: ["AC-4", "SC-7(10)"], evidence: "Tailoring action TA-101", state: "Tailoring recorded", tone: "ok" },
        { id: "D-03", title: "Categorization lowered to M-L-M · IL4", controls: ["Baseline re-resolved"], evidence: "71 controls drop from the effective set", state: "Impact computed", tone: "ok" }
      ]
    }
  };

  // ---- Baseline derivation ---------------------------------------------------
  // 800-53 Rev 5 is the catalog. FIPS 199 picks ONE overall impact level; CNSSI 1253
  // rates C, I and A independently for national security systems. Overlays apply on
  // top of whichever basis is used, then the program tailors (inherit / N-A / add).
  var LV = { L: 0, M: 1, H: 2 };
  var LEVEL_NAME = { L: "Low", M: "Moderate", H: "High" };
  var FIPS_BASE = { L: 149, M: 287, H: 370 };
  var AXIS_BASE = { common: 113, c: { L: 62, M: 110, H: 149 }, i: { L: 55, M: 98, H: 133 }, a: { L: 47, M: 86, H: 112 } };

  var OVERLAY_DEFS = [
    { key: "jsig", name: "JSIG", src: "DoD SAP · JSIG Rev 4", effect: "special access program handling", add: 64, rem: 0, floor: { c: "M", i: "L", a: "L" } },
    { key: "classified", name: "Classified information", src: "CNSSI 1253 App. F", effect: "classified data at rest and in transit", add: 52, rem: 0 },
    { key: "space", name: "Space platform", src: "CNSSI 1253 App. F / SPARTA v1.7", effect: "on-orbit segment and TT&C countermeasures", add: 41, rem: 3 },
    { key: "cds", name: "Cross-domain solution", src: "NCDSMO", effect: "guard, filter and transfer requirements", add: 37, rem: 0 },
    { key: "do326", name: "DO-326A / ED-202A", src: "RTCA", effect: "airworthiness security process", add: 34, rem: 0 },
    { key: "privacy", name: "Privacy", src: "800-53 Rev 5 privacy baseline", effect: "PII processing controls", add: 33, rem: 0 },
    { key: "intel", name: "Intelligence", src: "ICD 503", effect: "IC handling and dissemination", add: 28, rem: 0 },
    { key: "ics", name: "ATT&CK for ICS v14", src: "MITRE", effect: "embedded and bus mitigations", add: 26, rem: 0 },
    { key: "iec", name: "IEC 62443-4-2", src: "IEC", effect: "component requirements for industrial devices", add: 23, rem: 0 },
    { key: "cmmc", name: "800-171 R3 / CMMC L2", src: "DoD CIO", effect: "contractor handling of CUI", add: 12, rem: 0 }
  ];

  var FAMILY_DEFS = [
    { key: "AC", name: "Access control", catalog: 147, share: 0.115, axis: "c" },
    { key: "AT", name: "Awareness and training", catalog: 24, share: 0.02, axis: "i" },
    { key: "AU", name: "Audit and accountability", catalog: 82, share: 0.062, axis: "i" },
    { key: "CA", name: "Assessment, authorization and monitoring", catalog: 58, share: 0.04, axis: "i" },
    { key: "CM", name: "Configuration management", catalog: 78, share: 0.07, axis: "i" },
    { key: "CP", name: "Contingency planning", catalog: 62, share: 0.05, axis: "a" },
    { key: "IA", name: "Identification and authentication", catalog: 96, share: 0.08, axis: "c" },
    { key: "IR", name: "Incident response", catalog: 56, share: 0.04, axis: "a" },
    { key: "MA", name: "Maintenance", catalog: 42, share: 0.03, axis: "a", inherit: "depot maintenance authority" },
    { key: "MP", name: "Media protection", catalog: 34, share: 0.03, axis: "c" },
    { key: "PE", name: "Physical and environmental protection", catalog: 68, share: 0.05, axis: "a", inherit: "operating base facility plan" },
    { key: "PL", name: "Planning", catalog: 32, share: 0.02, axis: "i" },
    { key: "PM", name: "Program management", catalog: 36, share: 0.02, axis: "i" },
    { key: "PS", name: "Personnel security", catalog: 38, share: 0.02, axis: "c", inherit: "government security office" },
    { key: "PT", name: "PII processing and transparency", catalog: 26, share: 0.015, axis: "c" },
    { key: "RA", name: "Risk assessment", catalog: 44, share: 0.04, axis: "i" },
    { key: "SA", name: "System and services acquisition", catalog: 96, share: 0.06, axis: "i" },
    { key: "SC", name: "System and communications protection", catalog: 162, share: 0.11, axis: "c" },
    { key: "SI", name: "System and information integrity", catalog: 138, share: 0.1, axis: "i" },
    { key: "SR", name: "Supply chain risk management", catalog: 44, share: 0.035, axis: "i" }
  ];

  // SCTM columns. req = the standard's baseline format — cannot be dropped.
  var COL_DEFS = [
    { key: "id", label: "Control ID", src: "800-53 Rev 5", req: 1 },
    { key: "title", label: "Control title", src: "800-53 Rev 5", req: 1 },
    { key: "text", label: "Control text", src: "800-53 Rev 5", req: 1 },
    { key: "family", label: "Family", src: "800-53 Rev 5" },
    { key: "origin", label: "Control origin", src: "Baseline, overlay or tailoring", req: 1 },
    { key: "cci", label: "CCI", src: "DoD CCI list" },
    { key: "param", label: "Assignment / selection values", src: "Tailored parameters" },
    { key: "impl", label: "Implementation statement", src: "SSE-authored", req: 1 },
    { key: "status", label: "Implementation status", src: "SSE-authored", req: 1 },
    { key: "resp", label: "Responsible entity", src: "System, inherited or shared" },
    { key: "evidence", label: "Supporting artifacts", src: "Evidence registry", req: 1 },
    { key: "req", label: "Driving requirement", src: "Requirements register" },
    { key: "sys", label: "System", src: "Program systems" },
    { key: "aostatus", label: "AO determination", src: "Assessment results" },
    { key: "notes", label: "SSE notes", src: "Internal — not delivered" }
  ];

  var DIFF_POOL = ["CP-2(3)", "CP-7", "CP-7(1)", "CP-9(2)", "CP-10(4)", "AU-4(1)", "AU-5(2)", "AU-9(3)", "SC-5(2)", "SC-7(10)",
    "SC-12(3)", "SC-16(1)", "SC-24", "SI-4(12)", "SI-7(9)", "SI-13(4)", "IA-5(13)", "IA-7", "AC-4(8)", "AC-17(9)",
    "MA-3(3)", "PE-11(1)", "PE-13(4)", "RA-5(5)", "SR-5(2)", "SR-9(1)", "CM-3(6)", "CM-7(9)", "IR-4(6)", "MP-6(3)"];

  function pick(n, seed) {
    var out = [];
    for (var i = 0; i < n && i < 6; i++) out.push(DIFF_POOL[(seed + i * 7) % DIFF_POOL.length]);
    return out;
  }

  // Overlays can raise categorisation as a floor (JSIG forces at least M-L-L).
  function effTriad(sys) {
    var t = { c: sys.triad.c, i: sys.triad.i, a: sys.triad.a }, fips = sys.fips, raised = null;
    OVERLAY_DEFS.forEach(function (o) {
      if (!sys.overlays || !sys.overlays[o.key] || !o.floor) return;
      ["c", "i", "a"].forEach(function (k) { if (LV[t[k]] < LV[o.floor[k]]) { t[k] = o.floor[k]; raised = o.name; } });
      var hi = o.floor.c;
      ["i", "a"].forEach(function (k) { if (LV[o.floor[k]] > LV[hi]) hi = o.floor[k]; });
      if (LV[fips] < LV[hi]) { fips = hi; raised = o.name; }
    });
    return { t: t, fips: fips, raised: raised };
  }

  var SHARE_SUM = FAMILY_DEFS.reduce(function (a, f) { return a + f.share; }, 0);

  function baseline(sys) {
    var et = effTriad(sys);
    var base = sys.basis === "fips" ? FIPS_BASE[et.fips]
      : AXIS_BASE.common + AXIS_BASE.c[et.t.c] + AXIS_BASE.i[et.t.i] + AXIS_BASE.a[et.t.a];
    var fam = {};
    FAMILY_DEFS.forEach(function (f) { fam[f.key] = Math.round((base * f.share) / SHARE_SUM); });
    var on = OVERLAY_DEFS.filter(function (o) { return sys.overlays && sys.overlays[o.key]; });
    var added = 0, ovRem = 0;
    on.forEach(function (o) { added += o.add; ovRem += o.rem; });
    var inhFams = FAMILY_DEFS.filter(function (f) { return f.inherit && sys.families && !sys.families[f.key]; });
    var inherited = inhFams.reduce(function (a, f) { return a + fam[f.key]; }, 0);
    var unique = sys.unique || 0;
    return {
      base: base, fam: fam, triad: et.t, fips: et.fips, raisedBy: et.raised, overlaysOn: on,
      added: added, ovRemoved: ovRem, inherited: inherited, inheritedFams: inhFams, unique: unique,
      label: sys.basis === "fips" ? "FIPS 199 " + LEVEL_NAME[et.fips] : et.t.c + "-" + et.t.i + "-" + et.t.a,
      total: base + added - ovRem - inherited + unique
    };
  }

  // Grouped diff — every change to a system's basis, categorisation, overlays or
  // inheritance is shown as controls added and removed before it is committed.
  // Each group is measured by applying that one change to a working copy and
  // taking the real movement in the total, so the groups always reconcile:
  // sum(added) − sum(removed) === after.total − before.total.
  function diffBaseline(a, b) {
    var A = baseline(a), B = baseline(b);
    var work = JSON.parse(JSON.stringify(a)), prev = A.total;
    var groups = [], addN = 0, remN = 0, seed = 3;
    function step(reason, mutate) {
      mutate(work);
      var now = baseline(work).total, d = now - prev;
      prev = now;
      if (!d) return;
      var n = Math.abs(d), dir = d > 0 ? "add" : "remove";
      groups.push({ dir: dir, reason: reason, n: n, ids: pick(n, seed) });
      seed += 11;
      if (dir === "add") addN += n; else remN += n;
    }
    if (a.basis !== b.basis || a.fips !== b.fips || A.label !== B.label) {
      step(a.basis !== b.basis
        ? (b.basis === "fips" ? "Basis changed to NIST 800-53 · FIPS 199 " + LEVEL_NAME[B.fips] : "Basis changed to CNSSI 1253 · " + B.label)
        : "Categorisation " + A.label + " → " + B.label,
      function (w) { w.basis = b.basis; w.fips = b.fips; w.triad = { c: b.triad.c, i: b.triad.i, a: b.triad.a }; });
    }
    OVERLAY_DEFS.forEach(function (o) {
      var was = !!(a.overlays && a.overlays[o.key]), now = !!(b.overlays && b.overlays[o.key]);
      if (was === now) return;
      step((now ? "Overlay applied · " : "Overlay removed · ") + o.name, function (w) { w.overlays[o.key] = now ? 1 : 0; });
    });
    FAMILY_DEFS.forEach(function (f) {
      if (!f.inherit) return;
      var was = !!(a.families && a.families[f.key]), now = !!(b.families && b.families[f.key]);
      if (was === now) return;
      step(now ? f.key + " implemented by this system" : f.key + " inherited from the " + f.inherit,
        function (w) { w.families[f.key] = now ? 1 : 0; });
    });
    if ((a.unique || 0) !== (b.unique || 0)) {
      step("Program-unique controls", function (w) { w.unique = b.unique || 0; });
    }
    return { groups: groups, addN: addN, remN: remN, before: A, after: B };
  }

  // Systems evaluated under a program. Each carries its own categorisation,
  // overlays, tailoring and SCTM; the program view is the roll-up.
  var SYSTEMS = {
    "kestrel-m": [
      { id: "SYS-01", name: "Air vehicle segment", boundary: "Mission computer, flight control computer, payload bus, datalink terminal",
        basis: "1253", fips: "M", triad: { c: "M", i: "M", a: "H" }, il: "IL5",
        overlays: { do326: 1, ics: 1, classified: 1 }, families: { PE: 1, MA: 1, PS: 1 }, unique: 6,
        owner: "D. Iqbal", sctmRev: "Rev C", implemented: 372, status: "Assessment" },
      { id: "SYS-02", name: "Ground control station", boundary: "Shipboard GCS, operator consoles, mission planning server",
        basis: "1253", fips: "M", triad: { c: "M", i: "M", a: "H" }, il: "IL5",
        overlays: { classified: 1, cds: 1, cmmc: 1 }, families: { PE: 0, MA: 1, PS: 0 }, unique: 4,
        owner: "T. Bell", sctmRev: "Rev C", implemented: 401, status: "Assessment" },
      { id: "SYS-03", name: "Depot support environment", boundary: "Afloat maintenance laptops, load devices, spares tracking",
        basis: "fips", fips: "M", triad: { c: "M", i: "L", a: "L" }, il: "IL4",
        overlays: { cmmc: 1 }, families: { PE: 0, MA: 0, PS: 0 }, unique: 1,
        owner: "L. Chun", sctmRev: "Rev A", implemented: 176, status: "Implementation" }
    ],
    kestrel: [
      { id: "SYS-01", name: "Air vehicle segment", boundary: "Mission computer, FCC, payload bus, LOS datalink",
        basis: "1253", fips: "M", triad: { c: "M", i: "M", a: "H" }, il: "IL5",
        overlays: { do326: 1, ics: 1, classified: 1 }, families: { PE: 1, MA: 1, PS: 1 }, unique: 6,
        owner: "D. Iqbal", sctmRev: "Rev G", implemented: 545, status: "Authorized" },
      { id: "SYS-02", name: "Ground control station", boundary: "Transportable GCS shelter, operator consoles",
        basis: "1253", fips: "M", triad: { c: "M", i: "M", a: "H" }, il: "IL5",
        overlays: { classified: 1, cmmc: 1 }, families: { PE: 0, MA: 1, PS: 0 }, unique: 3,
        owner: "T. Bell", sctmRev: "Rev G", implemented: 456, status: "Authorized" }
    ],
    halcyon: [
      { id: "SYS-01", name: "Sonar processing suite", boundary: "Acoustic processors, classification servers, operator displays",
        basis: "1253", fips: "H", triad: { c: "M", i: "H", a: "H" }, il: "IL6",
        overlays: { classified: 1, intel: 1, cds: 1 }, families: { PE: 0, MA: 1, PS: 0 }, unique: 9,
        owner: "K. Reyes", sctmRev: "Rev F", implemented: 402, status: "Assessment" },
      { id: "SYS-02", name: "Trainer and lab environment", boundary: "Shore-based SIL, stimulator, recorded mission library",
        basis: "fips", fips: "M", triad: { c: "M", i: "M", a: "L" }, il: "IL5",
        overlays: { classified: 1 }, families: { PE: 0, MA: 0, PS: 0 }, unique: 0,
        owner: "R. Osei", sctmRev: "Rev C", implemented: 214, status: "Implementation" }
    ],
    vantage: [
      { id: "SYS-01", name: "Hosted payload", boundary: "Payload processor, crypto unit, TT&C interface",
        basis: "1253", fips: "H", triad: { c: "H", i: "H", a: "M" }, il: "IL6",
        overlays: { space: 1, classified: 1, intel: 1 }, families: { PE: 0, MA: 0, PS: 0 }, unique: 11,
        owner: "D. Vasquez", sctmRev: "Rev H", implemented: 655, status: "Authorized" }
    ]
  };

  function fallbackSystems(p) {
    var tri = (p.triad || "M-M-M").split("-");
    var s = { id: "SYS-01", name: p.name + " system", boundary: p.platform, basis: "1253", fips: tri[0],
      triad: { c: tri[0], i: tri[1], a: tri[2] }, il: p.il, overlays: { classified: 1 },
      families: { PE: 1, MA: 1, PS: 1 }, unique: 0, owner: p.owner, sctmRev: p.sctmRev,
      implemented: p.implemented, status: p.phase };
    s.unique = Math.max(0, p.controls - baseline(s).total);
    return [s];
  }

  // Distinct controls across a program's systems. Systems in one program overlap
  // heavily, so the roll-up is the largest baseline plus a share of the rest.
  function rollup(list) {
    var t = list.map(function (s) { return baseline(s).total; });
    var mx = t.reduce(function (a, n) { return Math.max(a, n); }, 0);
    var sum = t.reduce(function (a, n) { return a + n; }, 0);
    return t.length > 1 ? mx + Math.round(0.18 * (sum - mx)) : sum;
  }

  // Seeded programs are reconciled with their systems so every view reports the
  // same total — the program number is derived, never typed.
  Object.keys(SYSTEMS).forEach(function (pid) {
    var p = PROGRAMS.find(function (x) { return x.id === pid; });
    if (!p) return;
    var total = rollup(SYSTEMS[pid]), f = total / p.controls;
    p.implemented = Math.round(p.implemented * f);
    p.partial = Math.round(p.partial * f);
    p.planned = Math.max(0, total - p.implemented - p.partial);
    p.controls = total; p.tailored = total;
  });

  // My work — the SSE action spine. Every actionable item across views lands here.
  var WORK = [
    { id: "W-01", kind: "change", ref: "CHG-118", title: "Review crypto substitution — KI-700 replaces KGV-72M", note: "Delta D-01 · SC-12, SC-13, IA-7 stale · SP §4.3 quotes a retired key length", due: "01 Aug", owner: "M. Okonjo", pri: "P1", lane: "todo", go: "impact" },
    { id: "W-02", kind: "finding", ref: "FND-0209", title: "Document initial authenticator distribution for depot accounts", note: "Responds to RFI-014 · procedure KM-PRO-0044 in draft", due: "05 Aug", owner: "M. Okonjo", pri: "P1", lane: "progress", go: "finding" },
    { id: "W-03", kind: "req", ref: "SRS-3.4.9", title: "Allocate zeroize requirement to a control", note: "1 of 7 unallocated — delivers as an unverifiable SCTM line", due: "08 Aug", owner: "M. Okonjo", pri: "P2", lane: "todo", go: "reqwb" },
    { id: "W-04", kind: "control", ref: "SC-13", title: "Re-assess cryptographic protection after CHG-118 lands", note: "43 controls in CSA 03 blocked on the same evidence", due: "14 Aug", owner: "D. Iqbal", pri: "P1", lane: "blocked", blockedBy: "CHG-118 evidence", go: "control" },
    { id: "W-05", kind: "finding", ref: "FND-0188", title: "Verify radio firmware fix in the lab", note: "CAT I · maintenance-mode auth bypass · ECP-2231", due: "15 Aug", owner: "D. Iqbal", pri: "P1", lane: "progress", go: "finding" },
    { id: "W-06", kind: "scan", ref: "KM-SCAP-0742", title: "Promote 14 new SCAP results to the POA&M", note: "RHEL 8 V1R14 · dedupe against FND-0204 first", due: "06 Aug", owner: "L. Chun", pri: "P2", lane: "todo", go: "scans" },
    { id: "W-07", kind: "risk", ref: "RSK-03", title: "Configure audit storage alerting on the GCS collector", note: "Closes FND-0226 · moves AP-03 to mitigated", due: "07 Aug", owner: "T. Bell", pri: "P2", lane: "progress", go: "survive" },
    { id: "W-08", kind: "review", ref: "RFI-014", title: "Answer assessor RFI on depot authenticators", note: "Waiting on KM-PRO-0044 approval", due: "05 Aug", owner: "M. Okonjo", pri: "P2", lane: "blocked", blockedBy: "W-02", go: "reviews" },
    { id: "W-09", kind: "doc", ref: "SP §4.3", title: "Rewrite key management section for the KI-700", note: "Block held stale by CHG-118", due: "12 Aug", owner: "M. Okonjo", pri: "P2", lane: "todo", go: "sp" },
    { id: "W-10", kind: "finding", ref: "FND-0223", title: "Rebuild container base image for CVE-2026-31882", note: "KEV-listed · four ground services redeploy", due: "31 Jul", owner: "L. Chun", pri: "P1", lane: "progress", go: "finding" },
    { id: "W-11", kind: "risk", ref: "RSK-11", title: "Retest three-node GCS failover", note: "August exercise window · replaces KM-TP-0301", due: "05 Sep", owner: "R. Osei", pri: "P3", lane: "todo", go: "survive" },
    { id: "W-12", kind: "change", ref: "CHG-120", title: "Review SI-7(9) scope addition from ICSA-26-189-02", note: "Advisory pulls boot integrity into the baseline", due: "04 Aug", owner: "M. Okonjo", pri: "P2", lane: "todo", go: "impact" },
    { id: "W-13", kind: "control", ref: "IA-5", title: "Close depot authenticator determinations", note: "Three failed statements clear when KM-PRO-0044 signs", due: "12 Aug", owner: "T. Bell", pri: "P2", lane: "blocked", blockedBy: "W-02", go: "control" },
    { id: "W-14", kind: "doc", ref: "CSE Annex", title: "Regenerate CSE annex after MBCRA updates", note: "Two attributes changed state this week", due: "20 Aug", owner: "M. Okonjo", pri: "P3", lane: "done", go: "survive" },
    { id: "W-15", kind: "evidence", ref: "EV-03", title: "Re-collect crypto bench evidence for the SATCOM link", note: "Parent report KM-SIL-CRYPTO-TR-014 is out of scope for Kestrel-M · delta D-02", due: "18 Aug", owner: "D. Iqbal", pri: "P2", lane: "todo", go: "evidence" },
    { id: "W-16", kind: "evidence", ref: "EV-07", title: "Repoint moved physical security SOP link", note: "SharePoint reorg moved the file · 2 controls degrade while broken", due: "08 Aug", owner: "T. Bell", pri: "P3", lane: "todo", go: "evidence" }
  ];

  var state = {
    view: "portfolio",
    rail: "programs",
    programId: "kestrel-m",
    // system scope — the nav below the switcher. "all" is the program roll-up.
    systemId: "all",
    // tab strip state, keyed by surface. A tab is a subject; a view mode is a projection.
    tabs: { evidence: "registry", protect: "protection", reviews: "reviews", home: "systems", setup: "template", reqs: "allocated", poam: "open", assess: "tests", authz: "current", inbox: "assigned", impact: "open" },
    sctmMode: "impl",
    // on-demand detail sheet — one open at a time, keyed by view
    sheetView: null,
    // record sheet — half-screen preview of an associated record; stack enables back
    recordSheet: null,
    recordStack: [],
    // my work hub
    workMode: "queue",
    workOwner: "mine",
    workStatus: {},
    // survivability risk register
    riskSel: "RSK-09",
    riskFilter: "all",
    // compliance matrix
    matrixFam: "IA",
    matrixOnlyFail: false,
    // portfolio table
    portScope: "all",
    // requirements register
    reqSel: "SRS-3.4.9",
    reqFilter: "all",
    reqPanel: 1,
    reqTab: "overview",
    // SCTM / implementation workspace
    sctmSel: "SC-13",
    sctmEdits: {},
    sctmEditing: null,
    sctmDrawer: { "SC-13": 1 },
    panelOpen: true,
    controlsOpen: false,
    sctmTab: "trace",
    layout: "grid",
    groupBy: "family",
    density: "standard",
    cols: { req: 1, sys: 1, status: 1, ev: 1, sp: 1, owner: 1 },
    filters: { status: null, owner: null, noEvidence: false, staleOnly: false },
    filterMenu: null,
    // evidence registry
    evSel: "EV-03",
    evFilter: "all",
    evPanel: 1,
    evVerifying: null,
    evVerified: {},
    evTasks: {},
    evJustified: {},
    // variant derivation
    varSel: "D-01",
    // change control
    queue: { "CHG-118": "open", "CHG-119": "open", "CHG-120": "open" },
    openChange: "CHG-118",
    // staleness keyed by control id / SP block id
    stale: { "SC-12": 1, "SC-13": 1, "IA-7": 1, "sp-b3": 1, "sp-b4": 1, "sp-b6": 1 },
    notif: 4,
    toast: null,
    // baseline builder overlays
    overlays: { cnssi: true, sparta: false, attack: true, ics: true, cmmc: false, do326: true, iec: false, csa: true, cdrl: true },
    triad: { c: "M", i: "M", a: "H" },
    // program detail editing (inline on program home) + system categorisation draft
    progEditing: null,
    sysDraft: null,
    sysDraftTab: "cat",
    // new-program wizard
    wizard: {
      step: 1,
      name: "",
      code: "PRG-052",
      service: "U.S. Army",
      office: "PEO Aviation",
      platform: "Rotary-wing mission computer",
      owner: "M. Okonjo",
      assessor: "AFLCMC/HNCP",
      cdrl: "A012 / A014",
      sysSel: "S1",
      systems: [
        { id: "S1", name: "Air vehicle segment", boundary: "Mission computer, flight controls, datalink terminal",
          basis: "1253", fips: "M", triad: { c: "M", i: "M", a: "H" }, il: "IL5",
          overlays: { do326: 1, ics: 1 }, families: { PE: 1, MA: 1, PS: 1 }, unique: 0, owner: "M. Okonjo" }
      ],
      sctmShape: "per-system",
      cols: { id: 1, title: 1, text: 1, family: 1, origin: 1, cci: 1, param: 0, impl: 1, status: 1, resp: 1, evidence: 1, req: 1, sys: 0, aostatus: 0, notes: 0 },
      customCols: [{ key: "cc1", label: "Contract reference", src: "Customer request · CDRL A012 §3.4" }],
      template: 0,
      docs: { a012: 1, a014: 1, sow: 1, icd: 0 },
      parsed: false,
      parsing: false
    },
    // systems
    wbs: { "1.0": 1, "1.1": 1, "1.1.5": 1, "1.1.4": 0, "1.1.1": 0, "1.1.2": 0, "1.1.3": 0, "1.1.6": 0, "1.2": 0, "1.3": 0, "1.4": 0 },
    wbsSel: "1.1.5.3",
    wbsFilter: null,
    wbsEdits: {},
    wbsCtlOff: {},
    wbsRenaming: false,
    wbsPanel: 0,
    wbsAdded: [],
    // parts catalog
    partsOpen: { "CAT-100": 1 },
    partsSel: "CAT-100",
    partsFilter: null,
    partsAdded: {},
    partsPanel: 0,
    // SP editor
    spBlock: null,
    slashOpen: false,
    spSection: "4.3",
    // library
    libFamily: "SC",
    libCatalog: "",
    libCatOpen: 1,
    libGroups: { "800-53:SC": 1, "cci:IA-5(1)": 1 },
    libGroupBy: "native",
    libCols: { levels: 1, map: 1, programs: 1, bp: 1 },
    libDensity: "standard",
    libOnlyOverlay: false,
    libOnlyBp: false,
    // sources
    syncing: null,
    srcSel: null,
    // assessment
    assessSel: "SC-13",
    assessFilter: "all",
    // findings and POA&M
    poamSel: "FND-0204",
    poamFilter: "all",
    // scans, STIGs, SBOM
    intake: { map: 1, dedupe: 1, supersede: 1, autopoam: 0 },
    scanTab: "scans",
    scanPromoted: 0,
    scanBench: null,
    scanRule: null,
    // control workbench
    ctlSel: "IA-5(1)",
    ctlTab: "record",
    ctlFrom: "baseline",
    ctlDone: {},
    // finding workbench
    fndSel: "FND-0204",
    fndFrom: "poam",
    fndDone: {},
    // requirement workbench
    reqWbSel: "SRS-3.4.9",
    reqWbFrom: "reqs",
    reqWbDone: {},
    reqWbAlloc: {},
    // evidence workbench
    evWbFrom: "evidence",
    evWbDone: {},
    // ingestion pipeline
    srcTab: "catalogs",
    srcDiff: null,
    // authorization
    authzStep: "assess",
    fwOff: {},
    // program protection
    protSel: "CPI-001",
    protFilter: null,
    // cyber survivability
    csaSel: "csa06",
    threadSel: "maint",
    // reviews and sign-off
    threadsResolved: {},
    rfiClosed: {},
    spSigned: 0,
    // deliverable packages
    pkgSel: "cdrl"
  };

  var subs = new Set();
  function emit() { subs.forEach(function (f) { f(); }); }

  var VIEW_RAIL = { portfolio: "programs", newprog: "programs", home: "programs", reqs: "programs",
    baseline: "programs", control: "programs", finding: "programs", reqwb: "programs", sctm: "programs", sp: "programs",
    evidence: "programs", evwb: "programs", variant: "programs", delta: "programs",
    impact: "programs", inbox: "programs", systems: "systems", parts: "parts", library: "library", sources: "sources",
    assess: "programs", poam: "programs", scans: "programs", authz: "programs", reporting: "programs", matrix: "programs",
    protect: "programs", survive: "programs", reviews: "programs", deliver: "programs", setup: "programs" };

  // Legacy view ids kept alive: the old documentation view routes to the evidence registry.
  // Retired surfaces keep working as links — each resolves to the host that absorbed it.
  var VIEW_ALIAS = {
    docs: "evidence",
    matrix: { view: "sctm", mode: "cross" },
    reqs: { view: "sctm", mode: "reqs" },
    baseline: { view: "sctm", mode: "baseline" },
    rollup: "home",
    scans: { view: "evidence", tab: "scans" },
    stigs: { view: "evidence", tab: "stigs" },
    sbom: { view: "evidence", tab: "sbom" },
    survive: { view: "protect", tab: "survivability" },
    deliver: { view: "reviews", tab: "packages" }
  };

  function clearOverlays() { state.recordSheet = null; state.recordStack = []; }

  var api = {
    state: state,
    programs: PROGRAMS,
    variants: VARIANTS,
    sub: function (f) { subs.add(f); return function () { subs.delete(f); }; },
    set: function (patch) { Object.assign(state, patch); emit(); },
    prog: function () { return PROGRAMS.find(function (p) { return p.id === state.programId; }) || PROGRAMS[0]; },
    progById: function (id) { return PROGRAMS.find(function (p) { return p.id === id; }); },
    variantOf: function (id) { return VARIANTS[id || state.programId]; },
    go: function (view) {
      var a = VIEW_ALIAS[view];
      if (a && typeof a === "object") { if (a.tab) api.pageTab(a.view, a.tab); if (a.mode) state.sctmMode = a.mode; view = a.view; }
      else if (a) view = a;
      state.view = view; state.sheetView = null; clearOverlays(); state.rail = VIEW_RAIL[view] || state.rail; emit();
    },
    // one tab model for the Evidence surface — both halves of the strip render this
    EV_TABS: [
      { id: "registry", label: "Registry", count: 14 },
      { id: "scans", label: "Vulnerability scans", count: 7 },
      { id: "stigs", label: "STIG and SRG checklists", count: 12 },
      { id: "sbom", label: "SBOM and advisories", count: 2417 }
    ],
    // The SCTM is the program's workbook. Everything that decides what is in it — the
    // categorisation and overlays that resolve the control set, and the customer
    // requirements that add to it — is a tab of that one surface, not its own page.
    SCTM_TABS: [
      { id: "impl", label: "Controls" },
      { id: "reqs", label: "Requirements" },
      { id: "baseline", label: "Baseline" },
      { id: "cross", label: "Cross-config" }
    ],
    sctmTabs: function () {
      var sc = api.scope(), p = api.prog(), m = state.sctmMode || "impl";
      var counts = { impl: String(sc.total), reqs: String(p.reqs), baseline: sc.triad, cross: api.systems().length + " sys" };
      return api.SCTM_TABS.map(function (t) {
        return { id: t.id, label: t.label, count: counts[t.id],
          fg: t.id === m ? "var(--n-900)" : "var(--n-600)",
          bar: t.id === m ? "inset 0 -2px 0 var(--cortex-500)" : "none" };
      });
    },
    // one authoritative name per surface — cross-links read from here, never from a local copy
    SURFACE: { portfolio: "Programs", home: "Overview", setup: "Program settings", reporting: "Reporting",
      inbox: "My work", impact: "Changes", baseline: "SCTM · Baseline", reqs: "SCTM · Requirements",
      sctm: "SCTM", matrix: "SCTM · Cross-config", evidence: "Evidence", scans: "Evidence · STIG and SRG checklists",
      sp: "Security plan", assess: "Assessment", poam: "POA&M", authz: "Authorization",
      reviews: "Reviews and packages", deliver: "Reviews and packages · Packages",
      protect: "Protection and survivability", survive: "Protection and survivability · Cyber survivability",
      variant: "Derivation and deltas", delta: "Delta package",
      control: "Control workbench", finding: "Finding workbench", reqwb: "Requirement workbench", evwb: "Evidence workbench",
      systems: "Systems", parts: "Parts", library: "Library", sources: "Sources" },
    surfaceName: function (v) { return api.SURFACE[v] || v; },
    setTab: function (view, id) { state.tabs[view] = id; emit(); },
    // a tab is a subject of the page it sits on — the host decides what the id means
    pageTab: function (host, id) {
      if (host === "sctm") state.sctmMode = id;
      else if (host === "evidence") { state.tabs.evidence = id; if (id !== "registry") state.scanTab = id; }
      else state.tabs[host] = id;
      emit();
    },
    tab: function (view, dflt) { return state.tabs[view] || dflt; },
    setSctmMode: function (m) { state.sctmMode = m; emit(); },
    // system scope. "all" reads as the program roll-up; a system id scopes every count below it.
    setSystem: function (id) { state.systemId = id; if (state.view === "home") state.tabs.home = "systems"; emit(); },
    sys: function () { return state.systemId === "all" ? null : api.sysById(state.systemId); },
    scopeLabel: function () { var s = api.sys(); return s ? s.id + " · " + s.name : "All systems"; },
    // counts for the current scope — a system when one is picked, the program roll-up otherwise
    scope: function () {
      var p = api.prog(), s = api.sys();
      if (!s) return { total: p.controls, implemented: p.implemented, partial: p.partial, planned: p.planned, rev: p.sctmRev, label: "All systems", owner: p.owner, il: p.il, triad: p.triad };
      var b = baseline(s), impl = Math.min(s.implemented, b.total), part = Math.round((b.total - impl) * 0.62);
      return { total: b.total, implemented: impl, partial: part, planned: Math.max(0, b.total - impl - part), rev: s.sctmRev, label: s.name, owner: s.owner, il: s.il, triad: b.triad.c + "-" + b.triad.i + "-" + b.triad.a };
    },
    // reusable detail-sheet pattern: opens on row selection, closes on X / Esc / scrim click
    openSheet: function (view, patch) { if (patch) Object.assign(state, patch); state.sheetView = view; emit(); },
    closeSheet: function () { if (state.sheetView) { state.sheetView = null; emit(); } },
    // record sheet — half-screen overlay preview of an associated record; keeps the user on the page.
    // Opening another record from inside a sheet stacks it; back pops the stack.
    openRecord: function (type, id, extra) { if (state.recordSheet) state.recordStack.push(state.recordSheet); state.recordSheet = { type: type, id: id, extra: extra || null }; emit(); },
    recordBack: function () { state.recordSheet = state.recordStack.pop() || null; emit(); },
    closeRecord: function () { if (state.recordSheet || state.recordStack.length) { clearOverlays(); emit(); } },
    work: WORK,
    workLane: function (it) { return state.workStatus[it.id] || it.lane; },
    workMove: function (id, lane) {
      state.workStatus[id] = lane; emit();
      if (lane === "done") api.toast({ tone: "success", title: id + " marked done", desc: "Downstream items unblock automatically when their dependency closes." });
    },
    goRail: function (rail) {
      clearOverlays();
      state.rail = rail;
      state.view = rail === "systems" ? "systems" : rail === "parts" ? "parts" : rail === "library" ? "library" : rail === "sources" ? "sources" : "portfolio";
      emit();
    },
    selectProgram: function (id) { state.programId = id; clearOverlays(); state.view = "home"; state.rail = "programs"; emit(); },
    isStale: function (id) { return !!state.stale[id]; },
    toggleOverlay: function (k) { state.overlays[k] = !state.overlays[k]; emit(); },
    setTriad: function (k, v) { state.triad[k] = v; emit(); },
    toggleIntake: function (k) { state.intake[k] = state.intake[k] ? 0 : 1; emit(); },
    toggleWbs: function (k) { state.wbs[k] = state.wbs[k] ? 0 : 1; emit(); },
    setWbsFilter: function (f) {
      state.wbsFilter = state.wbsFilter === f ? null : f;
      state.view = "systems"; state.rail = "systems"; emit();
    },
    editWbs: function (id, key, val) {
      var e = state.wbsEdits[id] || (state.wbsEdits[id] = {});
      e[key] = val; emit();
    },
    toggleWbsCtl: function (id, ctl) {
      var k = id + "|" + ctl;
      state.wbsCtlOff[k] = state.wbsCtlOff[k] ? 0 : 1; emit();
    },
    openPart: function (id) { state.partsSel = id; state.partsPanel = 1; clearOverlays(); state.view = "parts"; state.rail = "parts"; emit(); },
    openWbs: function (id) {
      var seg = id.split(".");
      while (seg.length > 1) { seg.pop(); state.wbs[seg.length === 1 ? seg[0] + ".0" : seg.join(".")] = 1; }
      state.wbsSel = id; state.wbsPanel = 1; state.wbsFilter = null;
      clearOverlays(); state.view = "systems"; state.rail = "systems"; emit();
    },
    setLibCatalog: function (id) { state.libCatalog = id; state.view = "library"; state.rail = "library"; emit(); },
    toggleLibGroup: function (k) { state.libGroups[k] = state.libGroups[k] ? 0 : 1; emit(); },
    toggleLibCol: function (k) { state.libCols[k] = state.libCols[k] ? 0 : 1; emit(); },
    selectSource: function (name) { state.srcSel = name; state.view = "sources"; state.rail = "sources"; emit(); },
    openControl: function (id, tab) { if (id) state.ctlSel = id; if (tab) state.ctlTab = tab === "chain" ? "record" : tab; if (state.view !== "control") state.ctlFrom = state.view; clearOverlays(); state.view = "control"; state.rail = "programs"; emit(); },
    openRule: function (bench, rule) { state.scanBench = bench; state.scanRule = rule || null; state.scanTab = "stigs"; state.tabs.evidence = "stigs"; clearOverlays(); state.view = "evidence"; state.rail = "programs"; emit(); },
    ctlWork: function (k) { state.ctlDone[k] = state.ctlDone[k] ? 0 : 1; emit(); },
    openFinding: function (id) { if (id) state.fndSel = id; if (state.view !== "finding") state.fndFrom = state.view; clearOverlays(); state.view = "finding"; state.rail = "programs"; emit(); },
    fndWork: function (k) { state.fndDone[k] = state.fndDone[k] ? 0 : 1; emit(); },
    openReqWb: function (id) { if (id) state.reqWbSel = id; if (state.view !== "reqwb") state.reqWbFrom = state.view; clearOverlays(); state.view = "reqwb"; state.rail = "programs"; emit(); },
    reqWork: function (k) { state.reqWbDone[k] = state.reqWbDone[k] ? 0 : 1; emit(); },
    openEvWb: function (id) { if (id) state.evSel = id; if (state.view !== "evwb") state.evWbFrom = state.view; clearOverlays(); state.view = "evwb"; state.rail = "programs"; emit(); },
    evWork: function (k) { state.evWbDone[k] = state.evWbDone[k] ? 0 : 1; emit(); },
    toggleCol: function (k) { state.cols[k] = state.cols[k] ? 0 : 1; emit(); },
    editSctm: function (id, key, val) {
      var e = state.sctmEdits[id] || (state.sctmEdits[id] = {});
      e[key] = val; emit();
    },
    setSctmEditing: function (k) { state.sctmEditing = k; emit(); },
    toggleSctmDrawer: function (id) { state.sctmDrawer[id] = state.sctmDrawer[id] ? 0 : 1; emit(); },
    setFilter: function (k, v) { state.filters[k] = v; state.filterMenu = null; emit(); },
    clearFilters: function () { state.filters = { status: null, owner: null, noEvidence: false, staleOnly: false }; emit(); },
    selectReq: function (id) { state.reqSel = id; emit(); },
    // evidence registry
    openEvidence: function (id) { if (id) { state.evSel = id; state.evPanel = 1; } clearOverlays(); state.view = "evidence"; state.rail = "programs"; emit(); },
    selectEvidence: function (id) { state.evSel = id; state.evPanel = 1; emit(); },
    evVerify: function (id, outcome) {
      state.evVerifying = id; emit();
      setTimeout(function () {
        state.evVerifying = null;
        state.evVerified[id] = "just now";
        emit();
        api.toast(outcome === "moved"
          ? { tone: "default", title: "Link still broken", desc: id + " returns 404 — the file moved. Repoint the reference or task the owner." }
          : outcome === "stale"
            ? { tone: "default", title: "Link reachable · content changed", desc: "Source was modified after collection. " + id + " stays flagged stale." }
            : { tone: "success", title: "Link verified", desc: id + " is reachable and the version stamp matches the record." });
      }, 1100);
    },
    evTask: function (id, label) {
      state.evTasks[id] = 1; emit();
      api.toast({ tone: "success", title: "Task created", desc: label + " Routed to the artifact owner with a 10-day due date." });
    },
    evJustify: function (id) {
      state.evJustified[id] = 1; emit();
      api.toast({ tone: "default", title: "Reuse justification recorded", desc: "Tailoring action TA-041 written — the delta package will disclose it to the assessor." });
    },
    // derivation model, exposed so every view computes the same baseline
    OVERLAY_DEFS: OVERLAY_DEFS,
    FAMILY_DEFS: FAMILY_DEFS,
    COL_DEFS: COL_DEFS,
    LEVEL_NAME: LEVEL_NAME,
    baseline: baseline,
    diffBaseline: diffBaseline,
    systems: function (pid) {
      var id = pid || state.programId;
      if (!SYSTEMS[id]) SYSTEMS[id] = fallbackSystems(api.progById(id) || PROGRAMS[0]);
      return SYSTEMS[id];
    },
    sysById: function (sid, pid) {
      return api.systems(pid).find(function (s) { return s.id === sid; });
    },
    // program details — edited in place on the program header and facts panel
    setProgEditing: function (field) { state.progEditing = field; emit(); },
    editProg: function (field, val) {
      var p = api.prog();
      p[field] = val;
      state.progEditing = null;
      emit();
    },
    // system categorisation — every change is previewed as a control diff first
    openSysDraft: function (sid) {
      var s = api.sysById(sid);
      if (!s) return;
      state.sysDraft = { sid: sid, base: s, draft: JSON.parse(JSON.stringify(s)) };
      state.sysDraftTab = "cat";
      emit();
    },
    sysDraftSet: function (patch) { if (state.sysDraft) { Object.assign(state.sysDraft.draft, patch); emit(); } },
    sysDraftTriad: function (k, v) { if (state.sysDraft) { state.sysDraft.draft.triad[k] = v; emit(); } },
    sysDraftOverlay: function (k) {
      if (!state.sysDraft) return;
      var o = state.sysDraft.draft.overlays;
      o[k] = o[k] ? 0 : 1; emit();
    },
    sysDraftFamily: function (k) {
      if (!state.sysDraft) return;
      var f = state.sysDraft.draft.families;
      f[k] = f[k] ? 0 : 1; emit();
    },
    sysDraftTab: function (t) { state.sysDraftTab = t; emit(); },
    commitSysDraft: function () {
      var d = state.sysDraft;
      if (!d) return;
      var diff = diffBaseline(d.base, d.draft);
      Object.assign(d.base, d.draft);
      state.sysDraft = null;
      var p = api.prog();
      p.controls = rollup(api.systems());
      p.tailored = p.controls;
      p.planned = Math.max(0, p.controls - p.implemented - p.partial);
      emit();
      api.toast({ tone: "success", title: d.base.name + " re-baselined",
        desc: diff.addN + " controls added, " + diff.remN + " removed. SCTM rows drafted and each change written to the tailoring annex." });
    },
    cancelSysDraft: function () { state.sysDraft = null; emit(); },
    // wizard
    wiz: function (patch) { Object.assign(state.wizard, patch); emit(); },
    wizStep: function (n) { state.wizard.step = Math.max(1, Math.min(5, n)); emit(); },
    wizSys: function () {
      var w = state.wizard;
      return w.systems.find(function (s) { return s.id === w.sysSel; }) || w.systems[0];
    },
    wizSelSystem: function (id) { state.wizard.sysSel = id; emit(); },
    wizAddSystem: function () {
      var w = state.wizard, n = w.systems.length + 1, id = "S" + n;
      w.systems.push({ id: id, name: "", boundary: "", basis: "1253", fips: "M", triad: { c: "M", i: "M", a: "M" },
        il: "IL5", overlays: {}, families: { PE: 1, MA: 1, PS: 1 }, unique: 0, owner: w.owner });
      w.sysSel = id; emit();
    },
    wizDelSystem: function (id) {
      var w = state.wizard;
      if (w.systems.length < 2) { api.toast({ tone: "warning", title: "A program needs at least one system", desc: "The SCTM is written against a system boundary, so one has to exist." }); return; }
      w.systems = w.systems.filter(function (s) { return s.id !== id; });
      if (w.sysSel === id) w.sysSel = w.systems[0].id;
      emit();
    },
    wizSysSet: function (patch) { Object.assign(api.wizSys(), patch); emit(); },
    wizTriad: function (k, v) { api.wizSys().triad[k] = v; emit(); },
    wizOverlay: function (k) { var s = api.wizSys(); s.overlays[k] = s.overlays[k] ? 0 : 1; emit(); },
    wizFamily: function (k) { var s = api.wizSys(); s.families[k] = s.families[k] ? 0 : 1; emit(); },
    wizCol: function (k) {
      var d = COL_DEFS.find(function (c) { return c.key === k; });
      if (d && d.req) { api.toast({ tone: "warning", title: d.label + " is part of the baseline format", desc: "NIST 800-53 and CNSSI 1253 require it, so it cannot be dropped from the deliverable." }); return; }
      state.wizard.cols[k] = state.wizard.cols[k] ? 0 : 1; emit();
    },
    wizAddCol: function () {
      var w = state.wizard;
      w.customCols.push({ key: "cc" + (w.customCols.length + 1), label: "", src: "Customer request" });
      emit();
    },
    wizSetCol: function (key, label) {
      var c = state.wizard.customCols.find(function (x) { return x.key === key; });
      if (c) { c.label = label; emit(); }
    },
    wizDelCol: function (key) {
      state.wizard.customCols = state.wizard.customCols.filter(function (x) { return x.key !== key; });
      emit();
    },
    wizTemplate: function () {
      state.wizard.template = state.wizard.template ? 0 : 1;
      emit();
      if (state.wizard.template) api.toast({ tone: "ai", title: "Customer template read", desc: "14 of 16 columns matched the baseline format. 2 unmatched columns were added as custom columns." });
    },
    wizDoc: function (k) { state.wizard.docs[k] = state.wizard.docs[k] ? 0 : 1; state.wizard.parsed = false; emit(); },
    wizParse: function () {
      state.wizard.parsing = true; emit();
      setTimeout(function () {
        state.wizard.parsing = false; state.wizard.parsed = true; emit();
        api.toast({ tone: "ai", title: "163 security requirements extracted", desc: "Cerebro allocated 149 to catalog controls. 8 need a local control, 6 are unallocated." });
      }, 1500);
    },
    createProgram: function (summary) {
      var w = state.wizard;
      var id = "prg-" + (w.code || "PRG-052").toLowerCase();
      var hi = { c: "L", i: "L", a: "L" };
      w.systems.forEach(function (s) {
        var b = baseline(s);
        ["c", "i", "a"].forEach(function (k) { if (LV[b.triad[k]] > LV[hi[k]]) hi[k] = b.triad[k]; });
      });
      SYSTEMS[id] = w.systems.map(function (s, i) {
        return Object.assign(JSON.parse(JSON.stringify(s)), {
          id: "SYS-0" + (i + 1), name: s.name || "System " + (i + 1),
          sctmRev: "Rev A", implemented: 0, status: "Implementation", owner: s.owner || w.owner
        });
      });
      PROGRAMS.push({
        id: id, code: w.code, name: w.name || "Untitled program", service: w.service, platform: w.platform,
        kind: "system", office: w.office,
        triad: hi.c + "-" + hi.i + "-" + hi.a, il: w.systems[0].il,
        controls: summary.total, tailored: summary.total, implemented: 0, partial: 0, planned: summary.total,
        reqs: summary.reqs, reqAllocated: summary.allocated, reqGap: summary.gap,
        phase: "TMRR", health: "on-track", swatch: "var(--swatch-magenta)", updated: "1 Aug", evCur: 0,
        sctmRev: "Rev A", spRev: "Rev A", due: "TBD", cdrl: w.cdrl, owner: w.owner, assessor: w.assessor
      });
      state.programId = id; state.view = "home"; state.rail = "programs"; emit();
      api.toast({ tone: "success", title: (w.name || "Program") + " created",
        desc: w.systems.length + " systems registered · SCTM Rev A drafted with " + summary.total + " distinct controls and " + summary.reqs + " requirements traced." });
    },
    toast: function (t) {
      state.toast = t; emit();
      clearTimeout(api._tt);
      api._tt = setTimeout(function () { state.toast = null; emit(); }, 4200);
    },
    // Accepting CHG-118 clears crypto-module staleness across SCTM + SP
    accept: function (id) {
      state.queue[id] = "accepted";
      if (id === "CHG-118") { delete state.stale["SC-12"]; delete state.stale["SC-13"]; delete state.stale["IA-7"]; delete state.stale["sp-b3"]; delete state.stale["sp-b4"]; delete state.stale["sp-b6"]; }
      state.notif = Math.max(0, state.notif - 1);
      api.toast({ tone: "success", title: id + " accepted", desc: "SCTM Rev C and Security plan §4.3 updated. 3 controls cleared." });
    },
    reject: function (id) {
      state.queue[id] = "rejected";
      state.notif = Math.max(0, state.notif - 1);
      api.toast({ tone: "default", title: id + " rejected", desc: "Source owner notified in Confluence thread." });
    },
    openChange: function (id) { state.openChange = id; clearOverlays(); state.view = "impact"; state.rail = "programs"; emit(); },
    sync: function (name) {
      state.syncing = name; emit();
      setTimeout(function () { state.syncing = null; api.toast({ tone: "success", title: name + " synced", desc: "No new upstream changes since 07:12." }); }, 1400);
    }
  };

  window.__attest = api;
})();
