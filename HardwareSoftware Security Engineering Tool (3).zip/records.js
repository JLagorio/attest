// Attest — shared full-depth record data for quick-view sheets (mirrors the workbench registries)
(function () {
  if (window.__attestRecords) return;

  var NAMES = {
    "SC-12": "Cryptographic key establishment and management", "SC-13": "Cryptographic protection", "SC-28": "Protection of information at rest", "SC-28(1)": "Cryptographic protection of information at rest",
    "IA-7": "Cryptographic module authentication", "IA-5": "Authenticator management", "IA-5(1)": "Authenticator management — password-based authentication", "IA-3": "Device identification and authentication", "IA-3(1)": "Cryptographic bidirectional authentication",
    "AC-17": "Remote access", "AC-17(9)": "Disconnect or disable access", "AC-4": "Information flow enforcement", "AC-6": "Least privilege", "AC-2": "Account management", "AC-2(3)": "Disable accounts",
    "PE-9": "Power equipment and cabling", "PE-11": "Emergency power", "PE-2": "Physical access authorizations", "PE-3": "Physical access control", "PE-6": "Monitoring physical access",
    "CP-7": "Alternate processing site", "MA-2": "Controlled maintenance", "MP-6": "Media sanitization", "PS-4": "Personnel termination",
    "CM-2": "Baseline configuration", "CM-5": "Access restrictions for change", "CM-6": "Configuration settings", "CM-8": "System component inventory", "CM-14": "Signed components",
    "SI-2": "Flaw remediation", "SI-4": "System monitoring", "SI-6": "Security and privacy function verification", "SI-7": "Software, firmware, and information integrity", "SI-7(9)": "Verify boot process", "SI-10": "Information input validation",
    "RA-5": "Vulnerability monitoring and scanning", "CA-3": "Information exchange", "SC-7": "Boundary protection", "SC-7(21)": "Isolation of system components", "SC-8(1)": "Transmission confidentiality — cryptographic protection", "SC-5(2)": "Capacity, bandwidth, and redundancy",
    "IR-4": "Incident handling", "IR-8": "Incident response plan", "AU-6": "Audit record review, analysis, and reporting", "AU-11": "Audit record retention", "AU-3": "Content of audit records",
    "SR-11": "Component authenticity", "SR-4(3)": "Provenance — validate as genuine and not altered", "SR-11(2)": "Component authenticity — configuration control", "SA-11(2)": "Threat modeling and vulnerability analysis", "KM-SR-01": "Tamper-initiated zeroisation (program-unique)"
  };
  var FAM = { AC: "Access control", AU: "Audit and accountability", CA: "Assessment and authorization", CM: "Configuration management", CP: "Contingency planning", IA: "Identification and authentication", IR: "Incident response", KM: "Program-unique", MA: "Maintenance", MP: "Media protection", PE: "Physical and environmental protection", PS: "Personnel security", RA: "Risk assessment", SA: "Acquisition", SC: "System and communications protection", SI: "System and information integrity", SR: "Supply chain risk management" };

  var provVariant = function (ta) {
    return [
      { level: "Variant override", src: ta, state: "eff" },
      { level: "System-specific", src: "Kestrel-M Rev C — superseded by the override", state: "sup" },
      { level: "Component-provided", src: "CM-140 crypto module — supplies link-crypto boilerplate", state: "pre" },
      { level: "Parent system", src: "Kestrel TUAS Rev G", state: "sup" },
      { level: "Common control provider", src: "None claimed", state: "none" }
    ];
  };
  var provSystem = function (note) {
    return [
      { level: "Variant override", src: "None declared", state: "none" },
      { level: "System-specific", src: note || "Kestrel-M Rev C", state: "eff" },
      { level: "Component-provided", src: "None", state: "none" },
      { level: "Parent system", src: "Kestrel TUAS Rev G — superseded at authoring", state: "sup" },
      { level: "Common control provider", src: "None claimed", state: "none" }
    ];
  };
  var provParent = function () {
    return [
      { level: "Variant override", src: "None declared", state: "none" },
      { level: "System-specific", src: "None authored — nothing to author", state: "none" },
      { level: "Component-provided", src: "None", state: "none" },
      { level: "Parent system", src: "Kestrel TUAS Rev G · assessed 14 Mar 2026", state: "eff" },
      { level: "Common control provider", src: "None claimed", state: "none" }
    ];
  };

  // ---- Controls (full workbench depth) ----
  var CTL = {
    "SC-13": {
      family: FAM.SC, baselines: "L M H", status: ["Implemented", "success"],
      statement: "Determine the cryptographic uses and implement the types of cryptography required for each specified use in accordance with applicable laws and standards.",
      params: [{ name: "Cryptography on datalinks", base: "organization-defined types", val: "NSA-approved Type 1" }, { name: "Minimum key length", base: "organization-defined", val: "256-bit" }],
      rec: { resp: "System-specific — variant override", review: "Held for CHG-118", owner: "M. Okonjo", due: "14 Aug",
        narrative: "Communications security for the air vehicle is provided by the KGV-72M in-line network encryptor installed in WBS 1.1.5.3. All command-and-control traffic on the LOS C-band link is encrypted end to end at 128-bit strength, with keys rotated every 30 days under two-person control. Data at rest on the mission recorder uses the same module's storage partition.",
        renders: "Renders into SP §4.3 (3 blocks) and SCTM Rev C row 388." },
      prov: provVariant("TA-035 · delta D-01 — KI-700 replaces KGV-72M"),
      trace: { reqs: [{ id: "SRS-3.2.4", t: "Encrypt all C2 traffic in transit", meta: "CDRL A012 · allocated" }, { id: "SRS-3.2.7", t: "Zeroize keys on tamper or loss of custody", meta: "allocated · verify by test" }],
        sp: [{ t: "§4.3 Cryptographic protection", meta: "3 blocks · 2 held stale" }],
        parts: [{ wbs: "1.1.5.3", t: "Encryption/decryption modules — CM-140 (KI-700 pending)", meta: "CHG-118 in review", tone: "warn" }] },
      ev: ["EV-01", "EV-03", "EV-05"], checks: null, fnds: [],
      hist: [
        { when: "27 Jul 2026", what: "CHG-118 raised — KI-700 replaces the KGV-72M; statement and 2 SP blocks flagged stale", who: "Change control" },
        { when: "24 Jul 2026", what: "Tailoring action TA-035 recorded with rationale under delta D-01", who: "M. Okonjo" },
        { when: "12 May 2026", what: "Statement revised for SCTM Rev C", who: "M. Okonjo" },
        { when: "14 Mar 2026", what: "Derived from parent Kestrel Rev G; override declared at derivation", who: "Provenance" }
      ],
      work: [
        { t: "Re-assess cryptographic protection after CHG-118 lands", tag: "Assess", who: "D. Iqbal", due: "14 Aug" },
        { t: "Rewrite SP §4.3 key management blocks for the KI-700", tag: "Document", who: "M. Okonjo", due: "12 Aug" },
        { t: "Re-collect bench evidence on the SATCOM configuration", tag: "Evidence", who: "D. Iqbal", due: "18 Aug" }
      ]
    },
    "SC-12": {
      family: FAM.SC, baselines: "L M H", status: ["Implemented", "success"],
      statement: "Establish and manage cryptographic keys when cryptography is employed within the system in accordance with organization-defined requirements for key generation, distribution, storage, access, and destruction.",
      params: [{ name: "Key rotation interval", base: "organization-defined", val: "30 days" }, { name: "Key custody", base: "organization-defined", val: "two-person control" }],
      rec: { resp: "System-specific — variant override", review: "Held for CHG-118", owner: "M. Okonjo", due: "14 Aug",
        narrative: "Key establishment and management for the datalink crypto module follows key management plan KM-PL-0021 — 30-day rotation under two-person control, keys loaded by the crypto office keyloader, zeroize on tamper wired through the tamper loop in WBS 1.1.5.4.",
        renders: "Renders into SP §4.3 (2 blocks) and SCTM Rev C row 384." },
      prov: provVariant("TA-035 · delta D-01 — KI-700 replaces KGV-72M"),
      trace: { reqs: [{ id: "SRS-3.2.7", t: "Zeroize keys on tamper or loss of custody", meta: "allocated · verify by test" }, { id: "SRS-3.4.9", t: "Crypto module authentication before operational mode", meta: "CDRL A012 · allocated" }],
        sp: [{ t: "§4.3 Cryptographic protection", meta: "2 blocks · 1 held stale" }],
        parts: [{ wbs: "1.1.5.3", t: "Encryption/decryption modules — CM-140 (KI-700 pending)", meta: "CHG-118 in review", tone: "warn" }, { wbs: "1.1.5.4", t: "Tamper loop", meta: "in sync", tone: "n" }] },
      ev: ["EV-01", "EV-03", "EV-05"], checks: null, fnds: [],
      hist: [
        { when: "27 Jul 2026", what: "CHG-118 raised — key management blocks held stale pending the KI-700 rewrite", who: "Change control" },
        { when: "24 Jul 2026", what: "Tailoring action TA-035 recorded under delta D-01", who: "M. Okonjo" },
        { when: "14 Mar 2026", what: "Derived from parent Kestrel Rev G; override declared at derivation", who: "Provenance" }
      ],
      work: [{ t: "Rewrite the key management narrative for the KI-700 fill procedure", tag: "Document", who: "M. Okonjo", due: "12 Aug" }]
    },
    "IA-7": {
      family: FAM.IA, baselines: "L M H", status: ["Implemented", "success"],
      statement: "Implement mechanisms for authentication to a cryptographic module that meet the requirements of applicable laws, executive orders, directives, policies, and standards for such authentication.",
      params: [{ name: "Authentication point", base: "organization-defined", val: "power-on, before operational mode" }],
      rec: { resp: "System-specific — variant override", review: "Held for CHG-118", owner: "M. Okonjo", due: "14 Aug",
        narrative: "The crypto module authenticates to the mission computer by challenge-response during power-on, before the operational-mode discrete is asserted — the mechanism requirement SRS-3.4.9 tightens beyond the catalog text. Verified by SIL timing run KM-TP-0412.",
        renders: "Renders into SP §4.3 (1 block) and SCTM Rev C row 214." },
      prov: provVariant("TA-035 · delta D-01 — KI-700 replaces KGV-72M"),
      trace: { reqs: [{ id: "SRS-3.4.9", t: "Crypto module authentication before operational mode", meta: "CDRL A012 · allocated" }],
        sp: [{ t: "§4.3 Cryptographic protection", meta: "1 block · held stale" }],
        parts: [{ wbs: "1.1.5.3", t: "Encryption/decryption modules — CM-140 (KI-700 pending)", meta: "CHG-118 in review", tone: "warn" }] },
      ev: ["EV-01", "EV-03"], checks: null, fnds: [],
      hist: [
        { when: "27 Jul 2026", what: "CHG-118 raised — statement quotes the retired module; re-verify KM-TP-0412 after acceptance", who: "Change control" },
        { when: "14 Mar 2026", what: "Derived from parent Kestrel Rev G; override declared at derivation", who: "Provenance" }
      ],
      work: [{ t: "Re-run KM-TP-0412 against the KI-700 in the SIL", tag: "Validate", who: "M. Okonjo", due: "08 Aug" }]
    },
    "IA-5(1)": {
      family: FAM.IA, baselines: "L M H", status: ["2 CCIs failing", "warn"],
      statement: "For password-based authentication: maintain a list of commonly-used, expected, or compromised passwords; enforce composition and complexity rules; require changed characters on update; and protect passwords in storage and transmission.",
      params: [
        { name: "Minimum password length", base: "organization-defined", val: "15 characters" },
        { name: "Character classes required", base: "organization-defined complexity", val: "all four classes" },
        { name: "Changed characters on update", base: "organization-defined number", val: "8 characters" },
        { name: "Maximum lifetime", base: "organization-defined frequency", val: "60 days" }
      ],
      rec: { resp: "System-specific — variant override", review: "ISSO review", owner: "M. Okonjo", due: "15 Aug",
        narrative: "Passwords on the mission computer and GCS partitions are enforced by the pwquality policy at the CNSSI values — minlen 15, difok 8, all four classes, 60-day lifetime. Afloat depot accounts receive initial authenticators under procedure KM-PRO-0044 (draft, delta D-06); those accounts stay disabled until it signs.",
        renders: "Renders into SP §5.2 (2 blocks) and SCTM Rev C row 214." },
      prov: provVariant("TA-039 · delta D-06 — depot maintenance afloat"),
      trace: { reqs: [{ id: "SRS-4.1.2", t: "Password policy per CNSSI 1253 values", meta: "CDRL A012 · allocated" }],
        sp: [{ t: "§5.2 Authenticator management", meta: "2 blocks · current" }],
        parts: [{ wbs: "1.1.5.2", t: "Mission computer partition — RHEL 8 image v14", meta: "in sync", tone: "n" }] },
      ev: ["EV-04", "EV-09"],
      checks: { cciMeta: "8 CCIs · DISA CCI list 2024-02", ccis: [
        { id: "CCI-000192", def: "Enforces password complexity by the minimum number of upper case characters used.", status: "met", rules: [["RHEL 8 STIG", "RHEL-08-020110", 1], ["Windows Server 2022 STIG", "WN22-AC-000080", 1]] },
        { id: "CCI-000195", def: "Requires the minimum number of characters changed when new passwords are created.", status: "failing", rules: [["RHEL 8 STIG", "RHEL-08-020170", 0]] },
        { id: "CCI-000205", def: "Enforces minimum password length.", status: "failing", rules: [["RHEL 8 STIG", "RHEL-08-020230", 0], ["Windows Server 2022 STIG", "WN22-AC-000070", 0]] },
        { id: "CCI-000200", def: "Prohibits password reuse for the organization-defined number of generations.", status: "met", rules: [["RHEL 8 STIG", "RHEL-08-020220", 1], ["Windows Server 2022 STIG", "WN22-AC-000040", 1]] },
        { id: "CCI-000196", def: "Stores only cryptographically-protected passwords.", status: "met", rules: [["RHEL 8 STIG", "RHEL-08-010110", 1]] }
      ] },
      fnds: [{ id: "FND-0204", t: "difok not enforced on mission computers" }, { id: "FND-0198", t: "minlen below CNSSI value" }],
      hist: [
        { when: "25 Jul 2026", what: "Tailoring action TA-039 recorded — afloat depot authenticator handling under delta D-06", who: "M. Okonjo" },
        { when: "12 Jul 2026", what: "Benchmark V1R14 refresh surfaced two failing CCIs", who: "SCAP import" },
        { when: "04 Apr 2026", what: "CNSSI 1253 value set applied by profile P-3", who: "Tailoring studio" },
        { when: "14 Mar 2026", what: "Derived from parent Kestrel Rev G", who: "Provenance" }
      ],
      work: [
        { t: "Issue pwquality values (difok 8, minlen 15) to flight software team", tag: "Guidance", who: "M. Okonjo", due: "05 Aug" },
        { t: "Raise minlen 12 → 15 in the RHEL baseline image", tag: "Fix", who: "Platform team", due: "12 Aug" },
        { t: "Reconcile Windows GPO minimum length 14 → 15", tag: "Fix", who: "MP admin", due: "05 Aug" },
        { t: "Re-run RHEL benchmark and attach the checklist", tag: "Validate", who: "M. Okonjo", due: "15 Aug" }
      ]
    },
    "IA-5": {
      family: FAM.IA, baselines: "L M H", status: ["3 statements failing", "warn"],
      statement: "Manage system authenticators by verifying the identity of the receiving individual before issuance, establishing initial authenticator content, and changing or refreshing authenticators per organization-defined periods.",
      params: [{ name: "Initial authenticator distribution", base: "organization-defined process", val: "per KM-PRO-0044 (draft)" }],
      rec: { resp: "System-specific — variant override", review: "Blocked on KM-PRO-0044", owner: "T. Bell", due: "12 Aug",
        narrative: "Authenticator lifecycle on the ground segment rides the enterprise IdAM feed. Afloat depot accounts created under delta D-06 stay disabled until the initial-distribution procedure KM-PRO-0044 signs — three failed determinations clear on that signature.",
        renders: "Renders into SP §5.2 (1 block) and SCTM Rev C row 210." },
      prov: provVariant("TA-039 · delta D-06 — depot maintenance afloat"),
      trace: { reqs: [], sp: [{ t: "§5.2 Authenticator management", meta: "1 block · draft annex" }], parts: [{ wbs: "1.1.5", t: "Air vehicle partition — depot accounts", meta: "accounts disabled pending procedure", tone: "warn" }] },
      ev: ["EV-04"], checks: null,
      fnds: [{ id: "FND-0209", t: "Initial authenticator distribution undocumented for depot accounts" }],
      hist: [
        { when: "28 Jul 2026", what: "KM-PRO-0044 draft 4 routed for ISSO approval — responds to RFI-014", who: "T. Bell" },
        { when: "08 Jul 2026", what: "FND-0209 opened from assessor RFI-014", who: "Assessment" },
        { when: "14 Mar 2026", what: "Derived from parent Kestrel Rev G", who: "Provenance" }
      ],
      work: [
        { t: "Route KM-PRO-0044 draft 4 for ISSO approval", tag: "Approve", who: "T. Bell", due: "05 Aug" },
        { t: "Close the three failed determinations when it signs", tag: "Assess", who: "T. Bell", due: "12 Aug" }
      ]
    },
    "SC-8(1)": {
      family: FAM.SC, baselines: "M H", status: ["CAT I open", "danger"],
      statement: "Implement cryptographic mechanisms to prevent unauthorized disclosure of, and detect changes to, information during transmission.",
      params: [{ name: "Cryptographic mechanisms", base: "organization-defined", val: "NSA Type 1 on datalinks" }, { name: "Ground segment transport", base: "organization-defined", val: "FIPS 140-3 · TLS 1.3" }],
      rec: { resp: "Hybrid — system + CM-140 component", review: "In rework", owner: "K. Reyes", due: "09 Aug",
        narrative: "Command and telemetry on the primary link are protected end to end by the link encryptor at NSA-approved settings; ground transport uses FIPS 140-3 validated TLS 1.3. Statement rewrite in progress under delta D-02 — the SATCOM path replaces the LOS C-band chain this text still describes.",
        renders: "Renders into SP §4.6 and SCTM Rev C row 392." },
      prov: provVariant("TA-036 · delta D-02 — SATCOM primary link"),
      trace: { reqs: [{ id: "SRS-3.2.4", t: "Encrypt all C2 traffic in transit", meta: "CDRL A012 · allocated" }],
        sp: [{ t: "§4.6 Transmission protection", meta: "1 block · stale" }],
        parts: [{ wbs: "1.1.5.3", t: "Encryption/decryption modules — CM-140", meta: "CHG-118 in review", tone: "warn" }] },
      ev: ["EV-03"],
      checks: { cciMeta: "2 CCIs · DISA CCI list 2024-02", ccis: [
        { id: "CCI-002418", def: "Protects the confidentiality and integrity of transmitted information.", status: "failing", rules: [["RHEL 8 STIG", "RHEL-08-010294", 0], ["Cisco IOS-XE Router NDM STIG", "CISC-ND-001200", 1]] },
        { id: "CCI-002421", def: "Implements cryptographic mechanisms during transmission unless otherwise protected.", status: "failing", rules: [["RHEL 8 STIG", "RHEL-08-010294", 0]] }
      ] },
      fnds: [{ id: "FND-0211", t: "Legacy ciphers on GCS uplink (CAT I)" }],
      hist: [
        { when: "24 Jul 2026", what: "Tailoring action TA-036 recorded under delta D-02 — SATCOM transport", who: "M. Okonjo" },
        { when: "02 Jul 2026", what: "CAT I FND-0211 opened from benchmark result", who: "SCAP import" },
        { when: "14 Mar 2026", what: "Derived from parent Kestrel Rev G", who: "Provenance" }
      ],
      work: [
        { t: "Drop legacy cipher suites from the GCS uplink crypto policy", tag: "Fix", who: "Ground SW team", due: "02 Aug" },
        { t: "Attach the Type 1 keyloader cert artifact from crypto office", tag: "Evidence", who: "K. Reyes", due: "09 Aug" }
      ]
    },
    "CM-6": {
      family: FAM.CM, baselines: "L M H", status: ["41 rules open", "warn"],
      statement: "Establish and document configuration settings that reflect the most restrictive mode consistent with operational requirements, and identify, document, and approve any deviations.",
      params: [{ name: "Configuration checklists", base: "organization-defined", val: "DISA STIGs and SRGs" }, { name: "Deviation approval", base: "organization-defined", val: "ISSM + chief engineer" }],
      rec: { resp: "System-specific", review: "Current", owner: "L. Chun", due: "22 Aug",
        narrative: "Configuration settings derive from the DISA STIG set named by profile P-3. Deviations required by the operational flight program are documented in the deviation annex Rev B with ISSM and chief engineer approval; everything else is enforced by the Ansible baseline at build time.",
        renders: "Renders into SP §6.1 and SCTM Rev C row 097." },
      prov: provSystem("Kestrel-M Rev C — statement authored for this system"),
      trace: { reqs: [], sp: [{ t: "§6.1 Configuration management", meta: "2 blocks · current" }],
        parts: [{ wbs: "1.1.5.2", t: "Mission computer partition", meta: "34 rules open", tone: "warn" }, { wbs: "1.2.1", t: "GCS operator consoles", meta: "7 rules open", tone: "warn" }] },
      ev: ["EV-09", "EV-14"],
      checks: { cciMeta: "1 CCI · nearly every technical rule fans in here", ccis: [
        { id: "CCI-000366", def: "Configures the information system in accordance with established configuration settings. 1,847 rules across 12 benchmarks on this program.", status: "failing", rules: [["RHEL 8 STIG", "RHEL-08-010671", 0], ["RHEL 8 STIG", "RHEL-08-040284", 0], ["Windows Server 2022 STIG", "WN22-SO-000110", 0]] }
      ] },
      fnds: [{ id: "FND-0187", t: "34 RHEL settings drifted after V1R14" }, { id: "FND-0204", t: "34 open CAT II STIG items on the mission computer" }],
      hist: [
        { when: "12 Jul 2026", what: "Benchmark refresh to V1R14 — 34 new open rules, 19 dispatched to deviation review", who: "SCAP import" },
        { when: "03 Jun 2026", what: "Deviation annex Rev B approved", who: "ISSM" },
        { when: "14 Mar 2026", what: "Derived from parent Kestrel Rev G", who: "Provenance" }
      ],
      work: [
        { t: "Dispatch the 19 OFP-conflicting settings to deviation review", tag: "Guidance", who: "M. Okonjo", due: "07 Aug" },
        { t: "Patch the remaining 22 true drifts via Ansible baseline", tag: "Fix", who: "Platform team", due: "14 Aug" }
      ]
    },
    "AC-2": {
      family: FAM.AC, baselines: "L M H", status: ["1 CCI unmet", "warn"],
      statement: "Define allowed account types, assign account managers, establish criteria for membership, and create, enable, modify, disable, and remove accounts in accordance with policy.",
      params: [{ name: "Disable inactive accounts after", base: "organization-defined period", val: "30 days" }, { name: "Remove temporary accounts after", base: "organization-defined period", val: "72 hours" }],
      rec: { resp: "System-specific", review: "Decision pending", owner: "M. Okonjo", due: "08 Aug",
        narrative: "Account lifecycle on the ground segment is automated through the enterprise IdAM feed. The air vehicle partition cannot reach that feed in flight configuration; account changes there follow a manual two-person procedure with 72-hour review, documented as a compensating measure.",
        renders: "Renders into SP §3.2 and SCTM Rev C row 002." },
      prov: provSystem("Kestrel-M Rev C — compensating measure pending ISSM acceptance"),
      trace: { reqs: [{ id: "SRS-4.2.1", t: "Central account management for all ground assets", meta: "CDRL A012 · allocated" }],
        sp: [{ t: "§3.2 Account management", meta: "1 block · compensating measure draft" }],
        parts: [{ wbs: "1.1.4", t: "Air vehicle avionics partition", meta: "no IdAM path in flight", tone: "warn" }] },
      ev: ["EV-10"],
      checks: { cciMeta: "4 CCIs · DISA CCI list 2024-02", ccis: [
        { id: "CCI-000015", def: "Employs automated mechanisms to support the management of system accounts.", status: "failing", rules: [["RHEL 8 STIG", "RHEL-08-020270", 0]] },
        { id: "CCI-000016", def: "Removes temporary accounts within the organization-defined period.", status: "met", rules: [["RHEL 8 STIG", "RHEL-08-020000", 1]] },
        { id: "CCI-000017", def: "Disables inactive accounts within the organization-defined period.", status: "met", rules: [["RHEL 8 STIG", "RHEL-08-020260", 1], ["Windows Server 2022 STIG", "WN22-AC-000010", 1]] }
      ] },
      fnds: [{ id: "FND-0176", t: "Manual account lifecycle on air vehicle" }],
      hist: [
        { when: "22 Jul 2026", what: "Halcyon precedent (PRG-021) cited for the compensating-measure pattern", who: "M. Okonjo" },
        { when: "12 May 2026", what: "Statement revised for SCTM Rev C", who: "S. Whitfield" },
        { when: "14 Mar 2026", what: "Derived from parent Kestrel Rev G", who: "Provenance" }
      ],
      work: [
        { t: "Decide: local exception or IdAM bridge for the air vehicle partition", tag: "Guidance", who: "M. Okonjo", due: "08 Aug" },
        { t: "Document the manual procedure as a compensating measure in SP §3.2", tag: "Document", who: "S. Whitfield", due: "11 Aug" }
      ]
    },
    "IA-3": {
      family: FAM.IA, baselines: "M H", status: ["CAT I open", "danger"],
      statement: "Uniquely identify and authenticate organization-defined devices and/or types of devices before establishing a connection.",
      params: [{ name: "Devices requiring authentication", base: "organization-defined", val: "all datalink terminals" }],
      rec: { resp: "System-specific", review: "In rework", owner: "D. Iqbal", due: "15 Aug",
        narrative: "Datalink association requires cryptographic device authentication on the primary waveform. The maintenance-mode bypass demonstrated under red team event AA-2 is procedurally contained and is being removed by radio firmware change ECP-2231.",
        renders: "Renders into SP §6.4 and SCTM Rev C row 156." },
      prov: provSystem("Kestrel-M Rev C — statement authored for this system"),
      trace: { reqs: [{ id: "SRS-6.2", t: "Reject unauthorised association attempts without loss of link", meta: "CDRL A012 · allocated" }],
        sp: [{ t: "§6.4 Datalink authentication", meta: "1 block · rework queued" }],
        parts: [{ wbs: "1.2.1", t: "GCS radio segment", meta: "maintenance-mode bypass", tone: "warn" }] },
      ev: [], checks: null,
      fnds: [{ id: "FND-0188", t: "Datalink authentication bypass in maintenance mode (CAT I)" }],
      hist: [
        { when: "08 Jul 2026", what: "Procedural restriction issued — maintenance mode disabled outside the shielded bay", who: "D. Iqbal" },
        { when: "02 Jul 2026", what: "FND-0188 opened from red team demonstration AA-2", who: "Adversarial assessment" },
        { when: "14 Mar 2026", what: "Derived from parent Kestrel Rev G", who: "Provenance" }
      ],
      work: [
        { t: "Verify ECP-2231 firmware removes the maintenance-mode command path", tag: "Fix", who: "Radio vendor", due: "15 Aug" },
        { t: "Schedule red team regression under the AA-2 scope", tag: "Validate", who: "D. Iqbal", due: "26 Sep" }
      ]
    },
    "SI-2": {
      family: FAM.SI, baselines: "L M H", status: ["KEV clock running", "warn"],
      statement: "Identify, report, and correct system flaws; test software and firmware updates before installation; and install security-relevant updates within an organization-defined period.",
      params: [{ name: "Remediation window (KEV-listed)", base: "organization-defined period", val: "21 days" }],
      rec: { resp: "System-specific", review: "Current", owner: "L. Chun", due: "07 Aug",
        narrative: "Flaw remediation on ground software rides the container pipeline — SBOM matching against the KEV catalog gates every image promotion. Air vehicle software follows the OFP block cycle with flaws dispositioned by the CCB.",
        renders: "Renders into SP §9.1 and SCTM Rev C row 310." },
      prov: provSystem("Kestrel-M Rev C — statement authored for this system"),
      trace: { reqs: [], sp: [{ t: "§9.1 Flaw remediation", meta: "1 block · current" }],
        parts: [{ wbs: "1.2.4", t: "Ground software services", meta: "3 services on vulnerable base image", tone: "warn" }] },
      ev: ["EV-09"], checks: null,
      fnds: [{ id: "FND-0223", t: "CVE-2026-31882 in the ground software base image" }],
      hist: [
        { when: "27 Jul 2026", what: "SBOM match flagged CVE-2026-31882 — FND-0223 opened, 21-day KEV clock started 19 Jul", who: "SBOM pipeline" },
        { when: "14 Mar 2026", what: "Derived from parent Kestrel Rev G", who: "Provenance" }
      ],
      work: [
        { t: "Rebuild the container base image with the patched layer", tag: "Fix", who: "Platform team", due: "31 Jul" },
        { t: "Redeploy the three affected services and rescan", tag: "Validate", who: "L. Chun", due: "07 Aug" }
      ]
    },
    "SI-7(9)": {
      family: FAM.SI, baselines: "H", status: ["Planned", "n"],
      statement: "Verify the integrity of the boot process of organization-defined system components.",
      params: [{ name: "Components requiring boot verification", base: "organization-defined", val: "mission computer P-cards" }],
      rec: { resp: "System-specific", review: "Added by advisory", owner: "S. Whitfield", due: "18 Nov",
        narrative: "Boot process verification requires the P3 processor card refresh under ECP-2240 — the fielded P2 card has no root of trust. Interim: signed OFP loads with a two-person integrity check at depot, documented in SP §4.4.",
        renders: "Renders into SP §4.4 and SCTM Rev C row 402." },
      prov: provSystem("Kestrel-M Rev C — added by advisory ICSA-26-189-02"),
      trace: { reqs: [{ id: "SRS-4.2.7", t: "Signed flight software loads verified by the bootloader", meta: "CDRL A012 · allocated" }],
        sp: [{ t: "§4.4 Software integrity", meta: "1 block · placeholder" }],
        parts: [{ wbs: "1.1.4.3", t: "Flight control computer", meta: "P2 card — no root of trust", tone: "warn" }] },
      ev: ["EV-14"], checks: null,
      fnds: [{ id: "FND-0198", t: "Boot integrity verification not implemented" }],
      hist: [
        { when: "28 Jul 2026", what: "CHG-119 queued — advisory ICSA-26-189-02 pulls this control into the baseline", who: "Advisory feed" },
        { when: "09 Jul 2026", what: "FND-0198 opened — P2 card has no measured-boot capability", who: "Assessment" }
      ],
      work: [
        { t: "Assign an owner and statement before Rev D", tag: "Document", who: "S. Whitfield", due: "12 Aug" },
        { t: "Verify measured boot on the P3 first article", tag: "Validate", who: "Platform team", due: "10 Oct" }
      ]
    }
  };

  // ---- Requirements (full workbench depth) ----
  var REQ = {
    "SRS-3.2.4": { text: "The system shall encrypt all command-and-control traffic in transit between the ground segment and the air vehicle.", rel: "invokes", status: "Implemented", tone: "ok", verify: "Test", source: "CDRL A012 §3.2.4", flowed: "12 Mar 2026", owner: "M. Okonjo",
      controls: [{ id: "SC-13", title: NAMES["SC-13"], src: "800-53 Rev 5 · CNSSI 1253 C=M", action: "Modified by tailoring" }, { id: "SC-8(1)", title: NAMES["SC-8(1)"], src: "800-53 Rev 5", action: "Catalog as written" }],
      wbs: "1.1.5.3", wbsName: "Encryption/decryption modules — CM-140", statement: "All C2 traffic on the primary link is encrypted end to end by the in-line network encryptor; ground transport uses FIPS 140-3 validated TLS 1.3.",
      evidence: ["KM-TP-0412", "KM-AR-0088"], procs: [["KM-TP-0412", "Link encryption end-to-end test — SIL run", "12 Jul", "stale"], ["KM-AR-0088", "Crypto architecture analysis", "03 Jun", "pass"]],
      vNote: "The SIL run predates the SATCOM substitution under delta D-02 — expect a re-run request against the new link chain.",
      sctm: "2 rows", sp: "§4.3", assessorNote: "Test-verified with evidence predating the link change — re-verification likely." },
    "SRS-3.2.7": { text: "The system shall zeroize cryptographic keys on tamper detection or loss of custody.", rel: "invokes", status: "Implemented", tone: "ok", verify: "Test", source: "CDRL A012 §3.2.7", flowed: "12 Mar 2026", owner: "R. Osei",
      controls: [{ id: "SC-12", title: NAMES["SC-12"], src: "800-53 Rev 5 · CNSSI 1253 C=M", action: "Catalog as written" }, { id: "KM-SR-01", title: "Tamper-initiated zeroisation", src: "Program-unique · no 800-53 equivalent at this granularity", action: "Program-unique" }],
      wbs: "1.1.5.4", wbsName: "Tamper loop", statement: "Tamper switches drive the crypto module zeroise line directly; the mission computer is not in the path. Bench measured 1.8 s against the 5 s bound.",
      evidence: ["KM-TP-0401"], procs: [["KM-TP-0401", "Tamper-to-zeroize timing — bench", "19 Jun", "pass"]],
      vNote: "Bench result carries 3.2 s of margin; re-run only if the tamper loop hardware changes.",
      sctm: "2 rows", sp: "§4.6", assessorNote: "Clean test evidence with margin — no action expected." },
    "SRS-3.4.9": { text: "The cryptographic module shall authenticate to the mission computer before the air vehicle enters operational mode.", rel: "constrains", status: "Re-verify after CHG-118", tone: "warn", verify: "Test", source: "CDRL A012 §3.4.9", flowed: "12 Mar 2026", owner: "M. Okonjo",
      controls: [{ id: "IA-7", title: NAMES["IA-7"], src: "800-53 Rev 5 · customer clause tightens it", action: "Modified by tailoring" }, { id: "SC-12", title: NAMES["SC-12"], src: "800-53 Rev 5 · CNSSI 1253 C=M", action: "Catalog as written" }],
      wbs: "1.1.5.3", wbsName: "Crypto module", statement: "KI-700 performs challenge-response with the mission computer during power-on before the operational mode discrete is asserted.",
      evidence: ["KM-TP-0412", "KM-AR-0088"], procs: [["KM-TP-0412", "Power-on authentication timing — SIL run", "12 Jul", "stale"], ["KM-AR-0088", "Challenge-response protocol analysis", "03 Jun", "pass"]],
      vNote: "CHG-118 swaps the KGV-72M for a KI-700 — the SIL run predates the swap, so the timing result no longer describes the fielded module.",
      sctm: "2 rows", sp: "§4.3", assessorNote: "Test-verified but evidence predates the module swap — expect a re-run request." },
    "SRS-4.1.2": { text: "Password policy on all computing assets shall enforce the CNSSI 1253 value set.", rel: "constrains", status: "Partial", tone: "warn", verify: "Test", source: "CDRL A012 §4.1.2", flowed: "12 Mar 2026", owner: "M. Okonjo",
      controls: [{ id: "IA-5(1)", title: NAMES["IA-5(1)"], src: "800-53 Rev 5 · CNSSI values replace org-defined", action: "Modified by tailoring" }],
      wbs: "1.1.5.2", wbsName: "Mission computer partition — RHEL 8 image v14", statement: "pwquality enforces minlen 15, difok 8, all four classes, 60-day lifetime. Two CCIs failing until the baseline image is rebuilt.",
      evidence: ["KM-SCAP-0742"], procs: [["KM-SCAP-0742", "RHEL 8 SCAP benchmark — V1R14", "12 Jul", "fail"]],
      vNote: "Two CCIs fail on the fielded image; the Ansible rebuild staged for 12 Aug closes both, then rescan.",
      sctm: "1 row", sp: "§5.2", assessorNote: "Partial — benchmark evidence shows the exact failing values, which helps the story." },
    "SRS-4.2.1": { text: "Account management for all ground assets shall be centralized through the enterprise identity service.", rel: "invokes", status: "Partial", tone: "warn", verify: "Demonstration", source: "CDRL A012 §4.2.1", flowed: "12 Mar 2026", owner: "M. Okonjo",
      controls: [{ id: "AC-2", title: NAMES["AC-2"], src: "800-53 Rev 5", action: "Catalog as written" }],
      wbs: "1.2.4", wbsName: "Identity service", statement: "Ground segment lifecycle is automated through the IdAM feed; the air vehicle partition follows a manual two-person compensating procedure with 72-hour review.",
      evidence: ["INT-0722"], procs: [["KM-DM-0066", "IdAM lifecycle demonstration", "22 Jul", "pass"]],
      vNote: "The ground half demonstrates cleanly; the air vehicle compensating measure needs ISSM acceptance before it counts.",
      sctm: "1 row", sp: "§3.2", assessorNote: "Partial — hinges on the compensating measure being accepted (Halcyon precedent applies)." },
    "SRS-6.2": { text: "The data link shall detect and reject unauthorised association attempts without loss of the authorised link.", rel: "invokes", status: "Partial", tone: "warn", verify: "Test", source: "CDRL A012 §6.2", flowed: "12 Mar 2026", owner: "R. Osei",
      controls: [{ id: "IA-3(1)", title: NAMES["IA-3(1)"], src: "ATT&CK M1035 overlay", action: "Added by overlay" }, { id: "SC-7(21)", title: NAMES["SC-7(21)"], src: "ATT&CK ICS T0842 overlay", action: "Added by overlay" }],
      wbs: "1.1.2.1", wbsName: "C-band data link", statement: "Pre-association challenge on the C-band waveform; rejected attempts are logged and do not interrupt the established session.",
      evidence: ["KM-TP-0344"], procs: [["KM-TP-0344", "Unauthorised association rejection — range test", "28 May", "pass"]],
      vNote: "Passing on the C-band waveform; delta D-02's SATCOM path will need its own run.",
      sctm: "2 rows", sp: "§6.4", assessorNote: "Both controls came from threat overlays — the requirement is what makes them verifiable." },
    "SRS-4.2.7": { text: "Flight control software loads shall be digitally signed and verified by the bootloader before execution.", rel: "invokes", status: "Planned", tone: "warn", verify: "Test", source: "CDRL A012 §4.2.7", flowed: "12 Mar 2026", owner: "S. Whitfield",
      controls: [{ id: "CM-14", title: NAMES["CM-14"], src: "DO-326A SEC-INT-02 overlay", action: "Added by overlay" }, { id: "SI-7(9)", title: NAMES["SI-7(9)"], src: "Advisory ICSA-26-189-02 · pending baseline apply", action: "Added by overlay" }],
      wbs: "1.1.4.3", wbsName: "Flight control computer", statement: "",
      evidence: [], procs: [],
      vNote: "Nothing to verify until an implementation statement exists — the bootloader check is hardware-blocked on the P3 refresh (FND-0198).",
      sctm: "2 rows", sp: "§4.4", assessorNote: "Two planned rows with no statement — reads as unstarted despite the signing half being done." }
  };
  var REL = {
    invokes: { label: "Invokes", color: "var(--cortex-600)", explain: "The customer cites this control area directly — the catalog text governs and one statement answers both." },
    constrains: { label: "Constrains", color: "var(--warn-600)", explain: "The customer is stricter than the catalog parameter; the tailoring annex records the clause as the reason." },
    unique: { label: "Program-unique", color: "var(--ent-component)", explain: "Nothing in 800-53 or the overlays covers this — a local control keeps it verifiable." },
    open: { label: "Unallocated", color: "var(--danger-600)", explain: "No control allocated — no implementation, no evidence, no SCTM row an assessor can verify." }
  };

  // ---- Evidence (registry depth + work + AI) ----
  var EVR = {
    "EV-01": { name: "Key management plan", xid: "KM-PL-0021", type: "Policy", icon: "file-text", source: "SharePoint", uri: "/deliverables/KM-PL-0021", owner: "M. Okonjo", collected: "02 Jun 2026", validity: "To 02 Jun 2027", version: "Modified 12 Jul 2026", link: "reachable", verified: "29 Jul 07:12", controls: ["SC-12", "SC-13", "SC-28", "IA-7"], scope: "Kestrel family", scopeNote: "Covers the parent and both variants.",
      flag: { kind: "stale", tone: "warn", icon: "history", title: "Stale — source changed after collection", body: "The plan was modified 12 Jul, after the 02 Jun collection, and still cites the retired KGV-72M key length. CHG-118 supersedes it; the four supported controls degrade until re-collected." },
      work: [{ t: "Re-collect the plan after CHG-118 lands", tag: "Evidence", who: "M. Okonjo", due: "12 Aug" }, { t: "Confirm the new key length citation against SP §4.3", tag: "Validate", who: "M. Okonjo", due: "12 Aug" }],
      ai: { body: "Accepting CHG-118 queues this re-collection automatically — the same action that clears SC-12, SC-13, and IA-7. Re-collecting before acceptance would just go stale again.", src: "From CHG-118 · 4 supported controls" } },
    "EV-02": { name: "Authorization boundary diagram v14", xid: "LCD-88213", type: "Diagram", icon: "workflow", source: "Lucid", uri: "lucid.app/KM-boundary-v14", owner: "D. Reyes", collected: "14 Jul 2026", validity: "Until source changes", version: "v14 · matches record", link: "reachable", verified: "29 Jul 07:12", controls: ["CA-3", "SC-7", "AC-4"], scope: "Kestrel family", scopeNote: "Boundary common to parent and variants; ship hosting shown as an annex.", flag: null, work: [],
      ai: { body: "Verified current. The nightly sweep re-checks the link and compares the version stamp — you will be flagged if v15 appears.", src: "Nightly sweep · 29 Jul 07:12" } },
    "EV-03": { name: "Crypto bench test report", xid: "KM-SIL-CRYPTO-TR-014", type: "Test result", icon: "file-check-2", source: "SharePoint", uri: "/test-reports/TR-014.pdf", owner: "D. Iqbal", collected: "19 Jun 2026", validity: "To 19 Jun 2028", version: "Rev — · unchanged", link: "reachable", verified: "29 Jul 07:12", controls: ["SC-12", "SC-13", "IA-7"], scope: "Kestrel (parent) only", scopeTone: "danger", scopeNote: "Declared scope: LOS C-band bench configuration on the parent. Delta D-02 moves Kestrel-M to SATCOM — outside this artifact's coverage.",
      flag: { kind: "scope", tone: "danger", icon: "shield-alert", title: "Out of scope for Kestrel-M — reuse blocked", body: "Scope enforcement stopped this variant from resting on parent evidence that does not cover it. Re-collect on the SATCOM configuration, or record an explicit reuse justification the delta package will disclose." },
      work: [{ t: "Re-collect bench evidence on the SATCOM configuration", tag: "Evidence", who: "D. Iqbal", due: "18 Aug" }, { t: "Decide: re-collect or justify reuse under TA-041", tag: "Decide", who: "M. Okonjo", due: "08 Aug" }],
      ai: { body: "The bench re-collection is the long pole to the 14 Sep assessment window — the SIL is booked out 10 working days. Schedule it this week or take the justification path.", src: "From delta D-02 · W-15 · SIL calendar" } },
    "EV-04": { name: "Depot authenticator procedure", xid: "KM-PRO-0044", type: "Procedure", icon: "file-text", source: "Confluence", uri: "/spaces/KM/procedures/0044", owner: "T. Bell", collected: "Draft — not yet", validity: "Unchecked — draft", version: "Draft 4 · 28 Jul", link: "reachable", verified: "29 Jul 07:12", controls: ["IA-5", "IA-5(1)"], scope: "Kestrel-M only", scopeNote: "Written for afloat depot maintenance (delta D-06). Closes FND-0209 and RFI-014 when approved.", flag: null,
      work: [{ t: "Route draft 4 for ISSO approval", tag: "Approve", who: "T. Bell", due: "05 Aug" }, { t: "Attach the approval record and close FND-0209", tag: "Evidence", who: "M. Okonjo", due: "05 Aug" }],
      ai: { body: "Three failed IA-5 determinations, FND-0209, and RFI-014 all clear on the same signature. This document is the single blocker for that chain.", src: "From FND-0209 · RFI-014 · IA-5" } },
    "EV-05": { name: "ECP-2214 crypto obsolescence record", xid: "KM-4821", type: "Change record", icon: "circle-dot", source: "Jira", uri: "jira/KM-4821", owner: "CCB", collected: "28 Jul 2026", validity: "Until source changes", version: "Status: in review", link: "reachable", verified: "29 Jul 07:12", controls: ["SC-12", "SC-13"], scope: "Kestrel family", scopeNote: "Documents the KI-700 substitution decision behind CHG-118.", flag: null, work: [],
      ai: { body: "This record is the engineering rationale the assessor will ask for when CHG-118's rewrites land. Nothing to do — it rides the CCB workflow.", src: "From CHG-118 · CCB queue" } },
    "EV-06": { name: "Ground software signing pipeline", xid: "gitlab #6621", type: "Config export", icon: "git-branch", source: "GitLab", uri: "ground-software/pipelines/6621", owner: "L. Chun", collected: "29 Jul 2026", validity: "Rolling — re-pulled on push", version: "Pipeline #6621 · green", link: "reachable", verified: "29 Jul 07:20", controls: ["SI-7", "CM-14"], scope: "Kestrel-M only", scopeNote: "Variant build chain; the parent pins pipeline #5940.", flag: null, work: [],
      ai: { body: "Rolling evidence — every push re-pulls the pipeline definition, so this reference cannot silently age. The strongest kind of artifact in the registry.", src: "GitLab webhook · pipeline #6621" } },
    "EV-07": { name: "Physical security SOP", xid: "PS-SOP-114", type: "Procedure", icon: "file-text", source: "SharePoint", uri: "/site-security/PS-SOP-114 (404)", owner: "Site security", collected: "03 Mar 2026", validity: "To 03 Mar 2027", version: "Unknown — link broken", link: "moved", verified: "22 Jul 06:40", controls: ["PE-2", "PE-3"], scope: "Kestrel family", scopeNote: "Ground segment physical security at the operating site.",
      flag: { kind: "link", tone: "warn", icon: "unlink", title: "Link broken since 22 Jul — file moved", body: "The SharePoint reorg moved the deliverables library. A dead link discovered during assessment is the same failure as no evidence — PE-2 and PE-3 read as unsupported until repointed." },
      work: [{ t: "Repoint the reference to the moved file", tag: "Fix", who: "T. Bell", due: "08 Aug" }],
      ai: { body: "Same reorg likely moved other site-security files — the sweep found only this one because only this one is indexed. Worth asking site security for the new library root.", src: "Nightly sweep · 22 Jul" } },
    "EV-08": { name: "Incident response plan Rev C", xid: "IRP-2026-C", type: "Plan", icon: "file-text", source: "Confluence", uri: "/spaces/KM/irp (403)", owner: "R. Osei", collected: "11 Apr 2026", validity: "To 11 Apr 2027", version: "Unknown — no access", link: "denied", verified: "26 Jul 06:40", controls: ["IR-4", "IR-8"], scope: "Kestrel family", scopeNote: "Shared response plan; variant annex covers afloat operations.",
      flag: { kind: "link", tone: "danger", icon: "lock", title: "Permission denied since 26 Jul", body: "Space permissions changed and the registry's service account lost read access. Content currency cannot be re-verified until access is restored." },
      work: [{ t: "Restore registry read access to the IRP space", tag: "Access", who: "R. Osei", due: "06 Aug" }],
      ai: { body: "The plan itself has not changed state — only the registry's visibility of it. Restore access before the assessment window so currency checks resume.", src: "Registry sweep · 26 Jul" } },
    "EV-09": { name: "RHEL 8 SCAP results", xid: "KM-SCAP-0742", type: "Scan output", icon: "scan-search", source: "ACAS", uri: "acas/exports/0742", owner: "L. Chun", collected: "12 Jul 2026", validity: "30-day window · expires 11 Aug", version: "V1R14 benchmark", link: "reachable", verified: "29 Jul 07:12", controls: ["CM-6", "SI-2", "RA-5"], scope: "Kestrel-M only", scopeNote: "Scan results populate the registry like any other artifact.",
      flag: { kind: "expiry", tone: "warn", icon: "timer", title: "Ages out 11 Aug", body: "Scan evidence carries a 30-day validity window. Schedule the August run or the 14 supported determinations degrade to stale." },
      work: [{ t: "Schedule the August SCAP run", tag: "Validate", who: "L. Chun", due: "06 Aug" }],
      ai: { body: "Run it after the build 4.2 hardening script applies (18 Aug target) and the same scan both refreshes this window and closes FND-0204's rescan milestone.", src: "From FND-0204 · Ansible baseline" } },
    "EV-10": { name: "AO staff interview record", xid: "INT-0722", type: "Interview", icon: "mic", source: "File share", uri: "\\\\km-fs01\\assessments\\INT-0722", owner: "M. Okonjo", collected: "22 Jul 2026", validity: "Until superseded", version: "—", link: "unchecked", verified: "Never — no API", controls: ["AC-2", "AC-6"], scope: "Kestrel-M only", scopeNote: "Account management practices for the afloat detachment.", flag: null, work: [],
      ai: { body: "File-share references cannot be auto-verified — no API. Consider moving the record into SharePoint so the sweep can watch it.", src: "Registry connector coverage" } },
    "EV-11": { name: "SOW clause 3.4 — sanitization and zeroize", xid: "SOW-3.4", type: "Contract clause", icon: "file-badge", source: "Jama", uri: "jama/SOW/3.4", owner: "Contracts", collected: "09 Feb 2026", validity: "Until contract mod", version: "Mod 02", link: "reachable", verified: "29 Jul 07:12", controls: ["MP-6"], scope: "Kestrel-M only", scopeNote: "Drives requirement SRS-3.4.9.", flag: null, work: [],
      ai: { body: "Contract-source evidence — it changes only on a mod, and Jama pushes those. Nothing to watch here.", src: "Jama webhook · Mod 02" } },
    "EV-12": { name: "Enterprise SOC monitoring MOU", xid: "MOU-SOC-11", type: "Memo", icon: "landmark", source: "SharePoint", uri: "/enterprise/mou-soc-11", owner: "Enterprise SOC", collected: "03 Apr 2026", validity: "To 03 Apr 2027", version: "Signed · current", link: "reachable", verified: "29 Jul 07:12", controls: ["AU-6", "IR-4", "SI-4"], scope: "Enterprise — all programs", scopeNote: "Common control provider evidence; inherited rather than re-proven per system.", flag: null, work: [],
      ai: { body: "Provider-level evidence — every program in the portfolio cites this one MOU. If it lapses the degradation fans out portfolio-wide, so the SOC owns renewal.", src: "Common control provider · 6 programs" } },
    "EV-13": { name: "Shipboard power and EMI one-line", xid: "LCD-90417", type: "Diagram", icon: "workflow", source: "Lucid", uri: "lucid.app/KM-ship-power", owner: "D. Reyes", collected: "24 Jul 2026", validity: "Until source changes", version: "v2 · matches record", link: "reachable", verified: "29 Jul 07:12", controls: ["PE-9", "PE-11"], scope: "Kestrel-M only", scopeNote: "Collected for delta D-03 — first variant-native artifact.", flag: null, work: [],
      ai: { body: "Collected against delta D-03 and scoped variant-only from day one — the pattern every variant-native artifact should follow.", src: "From delta D-03" } },
    "EV-14": { name: "FCC bootloader CI 4.2.1 baseline", xid: "TC-CI-421", type: "Config export", icon: "boxes", source: "TeamCenter", uri: "teamcenter/ci/4.2.1", owner: "Config mgmt", collected: "17 Jul 2026", validity: "Until source changes", version: "Unknown — connector down", link: "unreachable", verified: "28 Jul 06:40", controls: ["CM-2", "CM-8", "SI-7(9)"], scope: "Kestrel family", scopeNote: "Item master record for the flight control computer bootloader.",
      flag: { kind: "auth", tone: "danger", icon: "cable", title: "Connector auth expired 28 Jul", body: "The TeamCenter service credential lapsed, so the registry cannot reach the item master. Renew it in Sources; the artifact itself has not changed state." },
      work: [{ t: "Renew the TeamCenter credential in Sources", tag: "Access", who: "Config mgmt", due: "04 Aug" }],
      ai: { body: "Three controls read as unverifiable while the connector is down, and the same credential feeds the parts catalog sync. One renewal fixes both.", src: "Sources · TeamCenter connector" } }
  };

  // ---- Findings (full workbench depth) ----
  var FND = {
    "FND-0188": { title: "Datalink authentication bypass in maintenance mode", cat: "CAT I", ctl: "IA-3", wbs: "1.2.1", wbsName: "GCS radio segment", found: "02 Jul 2026", source: "Adversarial assessment", srcMeta: "CVPA event AA-2 · red team", owner: "D. Iqbal", due: "15 Aug",
      weakness: "Placing the GCS radio in maintenance mode accepts unauthenticated command frames from a co-located transmitter. Demonstrated twice by the red team under CVPA event AA-2.",
      assetMeta: "2 of 3 fielded radios affected",
      assets: [["GCS radio A — forward site", "KM-GCS-R01", 1, "maintenance mode reachable"], ["GCS radio B — forward site", "KM-GCS-R02", 1, "maintenance mode reachable"], ["Trainer radio — schoolhouse", "KM-TRN-R01", 2, "not a fielded configuration"]],
      plan: "Interim: maintenance mode is procedurally disabled outside the shielded bay and removed from the fielded configuration. Permanent fix is a radio firmware change, on contract under ECP-2231.",
      miles: [["Procedural restriction issued to operators", "08 Jul — complete", "done"], ["Radio firmware change verified in the lab", "15 Aug", "next"], ["Regression and re-test with the red team", "26 Sep", "future"]],
      evMeta: "2 of 3 artifacts attached", ev: [["AA-2-RPT", "Red team demonstration report", 1], ["KM-OPS-0031", "Procedural restriction — operator directive", 1], ["ECP-2231-TR", "Radio firmware change — lab test report", 0]],
      close: { sctm: "Row 156 · IA-3", sctmSub: "partially implemented → implemented", sar: "AA-2 result", sarSub: "other than satisfied → satisfied", ato: "CAT I count", atoSub: "4 → 3 in the decision brief" },
      work: [{ t: "Verify ECP-2231 firmware removes the maintenance-mode command path", tag: "Fix", who: "Radio vendor", due: "15 Aug" }, { t: "Attach the lab test report to this finding", tag: "Evidence", who: "D. Iqbal", due: "15 Aug" }, { t: "Schedule red team regression under the AA-2 scope", tag: "Validate", who: "D. Iqbal", due: "26 Sep" }] },
    "FND-0204": { title: "34 open CAT II STIG items on the mission computer", cat: "CAT II", ctl: "CM-6", wbs: "1.1.5.2", wbsName: "Mission computer partition", found: "29 Jul 2026", source: "SCAP import", srcMeta: "RHEL 8 STIG V1R14 · SCAP import", owner: "L. Chun", due: "22 Aug",
      weakness: "RHEL 8 STIG benchmark V1R14 applied to the mission computer partition returns 34 open CAT II items, 19 of which are settings the OFP intentionally overrides at boot.",
      assetMeta: "4 of 6 nodes affected",
      assets: [["Mission computer nodes 01–04", "KM-MC-01…04", 1, "34 open CAT II each"], ["Mission computer node 05", "KM-MC-05", 0, "hardening script piloted"], ["Mission computer node 06", "KM-MC-06", 0, "hardening script piloted"]],
      plan: "Nineteen items close with the build 4.2 hardening script. Fifteen OFP-dependent settings need an approved deviation with compensating controls; the deviation package is drafted and awaiting ISSM concurrence.",
      miles: [["Deviation package drafted", "18 Jul — complete", "done"], ["ISSM concurrence on 15 deviations", "05 Aug", "next"], ["Build 4.2 hardening script applied and rescanned", "22 Aug", "future"]],
      evMeta: "1 of 3 artifacts attached", ev: [["KM-DEV-0012", "Deviation package — 15 OFP-dependent settings", 1], ["BLD-4.2-LOG", "Hardening script run log", 0], ["SCAP-0822", "Post-fix rescan checklist", 0]],
      close: { sctm: "Row 097 · CM-6", sctmSub: "3 deviations recorded in the annex", sar: "CM-6 result", sarSub: "OTS → satisfied with conditions", ato: "POA&M export", atoSub: "34 lines collapse to 1 annex entry" },
      work: [{ t: "Route the 15 OFP-dependent settings to deviation review", tag: "Guidance", who: "M. Okonjo", due: "05 Aug" }, { t: "Apply the build 4.2 hardening script to nodes 01–04", tag: "Fix", who: "Platform team", due: "18 Aug" }, { t: "Rescan and attach the checklist", tag: "Validate", who: "L. Chun", due: "22 Aug" }] },
    "FND-0223": { title: "CVE-2026-31882 in the ground software base image", cat: "CAT II", ctl: "SI-2", wbs: "1.2.4", wbsName: "Ground software services", found: "27 Jul 2026", source: "SBOM match", srcMeta: "KEV catalog · CVE-2026-31882", owner: "L. Chun", due: "07 Aug",
      weakness: "SBOM matching flagged a known exploited vulnerability in the container base image used by four ground software services. In the KEV catalog since 19 Jul, which starts the remediation clock.",
      assetMeta: "3 of 4 services affected",
      assets: [["Auth service", "gcs-auth", 1, "base image layer 3"], ["Telemetry ingest", "gcs-telem", 1, "base image layer 3"], ["Mission planner", "gcs-plan", 1, "base image layer 3"], ["Archive service", "gcs-arch", 0, "already on the patched image"]],
      plan: "Base image rebuild is in the pipeline; the three affected services redeploy with the patched layer. No operational workaround needed — none of them are reachable from the datalink.",
      miles: [["Patched base image built", "31 Jul", "next"], ["Three services redeployed and rescanned", "07 Aug", "future"]],
      evMeta: "1 of 2 artifacts attached", ev: [["SBOM-0727", "SBOM match report with KEV reference", 1], ["IMG-3.9.2", "Patched image digest and provenance attestation", 0]],
      close: { sctm: "Row 310 · SI-2", sctmSub: "remediation objective met", sar: "SI-2 result", sarSub: "no change — closed inside the window", ato: "KEV exposure", atoSub: "cleared from the weekly brief" },
      work: [{ t: "Rebuild the base image with the patched layer", tag: "Fix", who: "Platform team", due: "31 Jul" }, { t: "Redeploy auth, telemetry, and planner services", tag: "Fix", who: "L. Chun", due: "05 Aug" }, { t: "Rescan and attach the image digest", tag: "Validate", who: "L. Chun", due: "07 Aug" }] },
    "FND-0198": { title: "Boot integrity verification not implemented on the mission computer", cat: "CAT II", ctl: "SI-7(9)", wbs: "1.1.5.2", wbsName: "Mission computer partition", found: "09 Jul 2026", source: "Advisory ICSA-26-189-02", srcMeta: "advisory-driven control addition", owner: "S. Whitfield", due: "18 Nov",
      weakness: "The mission computer does not verify the boot process, and the current P2 processor card has no measured-boot capability. Advisory ICSA-26-189-02 targets exactly this bootloader update path.",
      assetMeta: "6 of 6 nodes affected",
      assets: [["Mission computer P2 cards", "KM-MC-01…06", 1, "no root of trust in hardware"]],
      plan: "Requires the P3 processor card refresh, on contract under ECP-2240. Interim: signed OFP loads with a two-person integrity check at depot, documented in the security plan.",
      miles: [["Interim two-person load procedure approved", "22 Jul — complete", "done"], ["P3 card refresh first article delivered", "26 Sep", "next"], ["Boot integrity verified and control assessed", "18 Nov", "future"]],
      evMeta: "2 of 3 artifacts attached", ev: [["KM-PRO-0051", "Interim two-person load procedure", 1], ["ECP-2240", "P3 processor refresh — contract mod", 1], ["BOOT-ATT", "Boot attestation log from the P3 first article", 0]],
      close: { sctm: "Row 402 · SI-7(9)", sctmSub: "planned → implemented", sar: "Advisory response", sarSub: "documented for the AO", ato: "Hardware condition", atoSub: "tracked to the P3 refresh" },
      work: [{ t: "Confirm the P3 first-article delivery holds the September window", tag: "Decide", who: "S. Whitfield", due: "15 Aug" }, { t: "Verify measured boot on the first article and capture the attestation log", tag: "Validate", who: "Platform team", due: "10 Oct" }] },
    "FND-0211": { title: "Legacy ciphers on the GCS uplink", cat: "CAT I", ctl: "SC-8(1)", wbs: "1.2.1", wbsName: "GCS uplink nodes", found: "24 Jul 2026", source: "SCAP import", srcMeta: "RHEL-08-010294 · GCS enclave", owner: "Ground SW team", due: "05 Aug",
      weakness: "The TLS crypto policy on two GCS uplink nodes still permits legacy cipher suites, exposing the command uplink to protocol downgrade.",
      assetMeta: "2 of 4 uplink nodes affected",
      assets: [["Uplink node 1", "KM-UPL-01", 1, "pre-April crypto policy"], ["Uplink node 2", "KM-UPL-02", 1, "pre-April crypto policy"], ["Uplink nodes 3–4", "KM-UPL-03/04", 0, "policy current"]],
      plan: "Drop legacy suites from the uplink crypto policy and re-baseline the two stale nodes. The Type 1 keyloader certificate from the crypto office closes the evidence gap.",
      miles: [["Crypto policy diff approved", "30 Jul — complete", "done"], ["Policy pushed to both nodes", "02 Aug", "next"], ["Rescan and attach the checklist", "05 Aug", "future"]],
      evMeta: "1 of 2 artifacts attached", ev: [["POL-DIFF", "Crypto policy diff", 1], ["KL-CERT", "Type 1 keyloader certificate", 0]],
      close: { sctm: "Row 388 · SC-8(1)", sctmSub: "partially implemented → implemented", sar: "SC-8(1) result", sarSub: "clears the only CAT I on this control", ato: "CAT I count", atoSub: "4 → 3 in the decision brief" },
      work: [{ t: "Push the approved crypto policy to both uplink nodes", tag: "Fix", who: "Ground SW team", due: "02 Aug" }, { t: "Rescan RHEL-08-010294 and attach the checklist", tag: "Validate", who: "L. Chun", due: "05 Aug" }, { t: "Attach the Type 1 keyloader certificate", tag: "Evidence", who: "K. Reyes", due: "09 Aug" }] },
    "FND-0187": { title: "34 RHEL settings drifted after the V1R14 refresh", cat: "CAT II", ctl: "CM-6", wbs: "1.1.5.2", wbsName: "Mission computer partition", found: "12 Jul 2026", source: "SCAP import", srcMeta: "V1R14 benchmark refresh", owner: "Platform team", due: "14 Aug",
      weakness: "The V1R14 benchmark refresh changed 34 expected values; the fielded image still reflects V1R13. True drift, distinct from the OFP-dependent settings tracked under FND-0204.",
      assetMeta: "6 of 6 nodes affected",
      assets: [["Mission computer nodes", "KM-MC-01…06", 1, "image predates V1R14"]],
      plan: "The 22 true drifts are staged in the Ansible baseline; 12 settings overlap the FND-0204 deviation package and close with it.",
      miles: [["Drift analysis complete", "18 Jul — complete", "done"], ["Ansible baseline applied", "14 Aug", "next"], ["Rescan confirms zero drift", "20 Aug", "future"]],
      evMeta: "1 of 2 artifacts attached", ev: [["ANS-DIFF", "Ansible baseline diff against V1R14", 1], ["SCAP-0820", "Post-apply rescan", 0]],
      close: { sctm: "Row 097 · CM-6", sctmSub: "drift cleared from the row", sar: "CM-6 result", sarSub: "rule count 41 → 19 open", ato: "No change", atoSub: "CAT II tracked in POA&M" },
      work: [{ t: "Apply the staged Ansible baseline to all six nodes", tag: "Fix", who: "Platform team", due: "14 Aug" }, { t: "Rescan and attach the checklist", tag: "Validate", who: "L. Chun", due: "20 Aug" }] },
    "FND-0176": { title: "Manual account lifecycle on the air vehicle partition", cat: "CAT II", ctl: "AC-2", wbs: "1.1.5", wbsName: "Air vehicle partition", found: "19 Jun 2026", source: "Assessment", srcMeta: "800-53A AC-2 procedure", owner: "M. Okonjo", due: "11 Aug",
      weakness: "Account management on the air vehicle partition is manual — the partition cannot reach the central IdAM feed in flight configuration, so CCI-000015 has no automated mechanism.",
      assetMeta: "1 of 1 partition affected",
      assets: [["Air vehicle partition", "KM-AV-01", 1, "no IdAM path in flight configuration"]],
      plan: "Compensating manual procedure with 72-hour review, following the pattern the assessor accepted on Halcyon. An IdAM bridge is deferred to Rev D as a design change.",
      miles: [["Manual procedure drafted", "28 Jul — complete", "done"], ["ISSM accepts the compensating measure", "08 Aug", "next"], ["SP §3.2 documents the measure", "11 Aug", "future"]],
      evMeta: "2 of 3 artifacts attached", ev: [["KM-PRO-0048", "Manual account procedure", 1], ["IdAM-ICD", "IdAM interface control document", 1], ["COMP-0032", "Compensating-control writeup for SP §3.2", 0]],
      close: { sctm: "Row 002 · AC-2", sctmSub: "compensating measure recorded", sar: "AC-2 result", sarSub: "satisfied with conditions", ato: "Compensating measure", atoSub: "recorded in the SP annex" },
      work: [{ t: "Decide: local exception or IdAM bridge for the air vehicle", tag: "Decide", who: "M. Okonjo", due: "08 Aug" }, { t: "Write the compensating measure into SP §3.2", tag: "Document", who: "S. Whitfield", due: "11 Aug" }] },
    "FND-0209": { title: "Initial authenticator distribution undocumented for depot accounts", cat: "CAT II", ctl: "IA-5", wbs: "1.1.5", wbsName: "Air vehicle partition", found: "08 Jul 2026", source: "Assessor RFI-014", srcMeta: "RFI-014 · assessment prep", owner: "M. Okonjo", due: "05 Aug",
      weakness: "No documented procedure covers initial authenticator distribution for afloat depot accounts created under delta D-06. Three IA-5 determinations fail on this gap.",
      assetMeta: "1 account class affected",
      assets: [["Afloat depot accounts", "KM-AV-01 · depot", 1, "disabled pending procedure"]],
      plan: "Procedure KM-PRO-0044 is in draft 4; the three failed determinations on IA-5 clear when it signs, and RFI-014 closes with it.",
      miles: [["Procedure drafted", "28 Jul — complete", "done"], ["ISSO approval", "05 Aug", "next"], ["RFI-014 answered and determinations cleared", "05 Aug", "future"]],
      evMeta: "2 of 2 artifacts attached", ev: [["KM-PRO-0044", "Depot authenticator procedure (draft)", 1], ["RFI-014", "Assessor request for information", 1]],
      close: { sctm: "Row 210 · IA-5", sctmSub: "3 failed statements clear", sar: "IA-5 result", sarSub: "OTS → satisfied", ato: "RFI queue", atoSub: "RFI-014 closes with it" },
      work: [{ t: "Route KM-PRO-0044 draft 4 for ISSO approval", tag: "Approve", who: "T. Bell", due: "05 Aug" }, { t: "Answer RFI-014 with the signed procedure", tag: "Document", who: "M. Okonjo", due: "05 Aug" }] }
  };

  // ---- Configuration items ----
  var PART = {
    "1.1.5.3": { name: "Encryption/decryption modules — CM-140", kind: "Sub-assembly · crypto", note: "CHG-118 in review — KI-700 replaces KGV-72M", tone: "warn", src: "TeamCenter item master", qty: "2 per air vehicle", owner: "K. Reyes",
      desc: "In-line network encryptor for the C2 datalink plus the mission recorder storage partition. The KI-700 substitution (ECP-2214) drives delta D-01 and holds SC-12, SC-13, and IA-7 stale until accepted.",
      ctls: ["SC-12", "SC-13", "IA-7", "SC-8(1)"], reqs: [{ id: "SRS-3.2.4", t: "Encrypt all C2 traffic in transit" }, { id: "SRS-3.4.9", t: "Crypto module authentication before operational mode" }], chg: "CHG-118",
      hist: [{ when: "27 Jul 2026", what: "CHG-118 raised from the Cameo model — KI-700 replaces KGV-72M", who: "Model sync" }, { when: "19 Jun 2026", what: "Bench report TR-014 collected against the LOS configuration", who: "D. Iqbal" }] },
    "1.1.5.2": { name: "Mission computer partition — RHEL 8 image v14", kind: "Computing partition", note: "34 STIG rules open", tone: "warn", src: "TeamCenter item master", qty: "6 nodes", owner: "L. Chun",
      desc: "Six mission computer nodes on the hardened RHEL 8 image. The image predates the April CNSSI value set — the root cause behind the open IA-5(1) CCIs and the V1R14 drift.",
      ctls: ["CM-6", "IA-5(1)", "SI-2", "SI-7(9)"], reqs: [{ id: "SRS-4.1.2", t: "Password policy per CNSSI 1253 values" }], chg: "",
      hist: [{ when: "12 Jul 2026", what: "V1R14 benchmark refresh — 34 new open rules on the fielded image", who: "SCAP import" }, { when: "04 Apr 2026", what: "CNSSI value set applied by profile P-3; image rebuild deferred", who: "Tailoring studio" }] },
    "1.1.5.4": { name: "Tamper loop", kind: "Sub-assembly · security", note: "In sync", tone: "n", src: "TeamCenter item master", qty: "1 per air vehicle", owner: "R. Osei",
      desc: "Tamper switches drive the crypto module zeroise line directly; the mission computer is not in the path. Bench measured 1.8 s against the 5 s requirement.",
      ctls: ["KM-SR-01", "SC-12"], reqs: [{ id: "SRS-3.2.7", t: "Zeroize keys on tamper or loss of custody" }], chg: "",
      hist: [{ when: "19 Jun 2026", what: "Tamper-to-zeroize timing verified at 1.8 s on the bench", who: "Test" }] },
    "1.2.1": { name: "GCS radio segment / uplink nodes", kind: "Ground segment", note: "2 nodes on stale crypto policy", tone: "warn", src: "TeamCenter item master", qty: "4 uplink nodes · 3 radios", owner: "D. Iqbal",
      desc: "Ground control station radios and uplink nodes. Carries the AA-2 maintenance-mode finding (FND-0188) and the legacy-cipher CAT I (FND-0211).",
      ctls: ["IA-3", "SC-8(1)"], reqs: [{ id: "SRS-6.2", t: "Reject unauthorised association attempts" }], chg: "",
      hist: [{ when: "24 Jul 2026", what: "FND-0211 opened — legacy ciphers on two uplink nodes", who: "SCAP import" }, { when: "02 Jul 2026", what: "FND-0188 opened from red team event AA-2", who: "Adversarial assessment" }] },
    "1.1.4": { name: "Air vehicle avionics partition", kind: "Computing partition", note: "No IdAM path in flight", tone: "warn", src: "TeamCenter item master", qty: "1 per air vehicle", owner: "S. Whitfield",
      desc: "Flight-critical avionics partition. Cannot reach the enterprise IdAM feed in flight configuration — account lifecycle is manual under a compensating procedure.",
      ctls: ["AC-2"], reqs: [{ id: "SRS-4.2.1", t: "Central account management for all ground assets" }], chg: "",
      hist: [{ when: "19 Jun 2026", what: "FND-0176 opened — manual account lifecycle", who: "Assessment" }] },
    "1.2.4": { name: "Identity service / ground software services", kind: "Ground segment", note: "3 services on vulnerable base image", tone: "warn", src: "GitLab · TeamCenter", qty: "4 containerized services", owner: "L. Chun",
      desc: "Ground identity and supporting services in the container platform. Three services redeploy with the patched base image under FND-0223.",
      ctls: ["AC-2", "SI-2"], reqs: [{ id: "SRS-3.9.1", t: "24-hour credential revocation" }], chg: "",
      hist: [{ when: "27 Jul 2026", what: "FND-0223 opened — KEV CVE in the base image", who: "SBOM pipeline" }] },
    "1.1.4.3": { name: "Flight control computer", kind: "Sub-assembly · avionics", note: "P2 card — no root of trust", tone: "warn", src: "TeamCenter item master", qty: "2 per air vehicle", owner: "S. Whitfield",
      desc: "Flight control computer on the P2 processor card. Signed OFP loads work today; bootloader verification is hardware-blocked until the P3 refresh under ECP-2240.",
      ctls: ["CM-14", "SI-7(9)", "CM-2", "CM-8"], reqs: [{ id: "SRS-4.2.7", t: "Signed flight software loads verified by the bootloader" }], chg: "CHG-119",
      hist: [{ when: "09 Jul 2026", what: "FND-0198 opened — no measured-boot capability on the P2 card", who: "Assessment" }] }
  };

  // ---- Security plan sections ----
  var SPS = {
    "§4.3": { title: "Cryptographic protection", rev: "Security plan Rev B", owner: "M. Okonjo", ctls: ["SC-12", "SC-13", "IA-7"],
      blocks: [["Key management approach", "stale", "Cites the retired KGV-72M 128-bit key length — rewrite queued on CHG-118 acceptance."], ["Datalink encryption", "stale", "Describes the LOS C-band chain; delta D-02 moves the primary link to SATCOM."], ["Data at rest on the mission recorder", "current", "Storage partition text unaffected by the module swap."]] },
    "§4.6": { title: "Transmission protection", rev: "Security plan Rev B", owner: "K. Reyes", ctls: ["SC-8(1)"],
      blocks: [["Primary link transmission protection", "stale", "Statement rewrite in progress under delta D-02 — SATCOM replaces the LOS chain."]] },
    "§5.2": { title: "Authenticator management", rev: "Security plan Rev B", owner: "M. Okonjo", ctls: ["IA-5", "IA-5(1)"],
      blocks: [["Password policy — CNSSI values", "current", "pwquality values match the profile P-3 set."], ["Afloat depot authenticators", "draft", "Renders once KM-PRO-0044 signs — closes FND-0209 and RFI-014."]] },
    "§6.1": { title: "Configuration management", rev: "Security plan Rev B", owner: "L. Chun", ctls: ["CM-6"],
      blocks: [["STIG-derived settings", "current", "Enforced by the Ansible baseline at build time."], ["Deviation annex reference", "current", "15 OFP-dependent settings pending ISSM concurrence."]] },
    "§3.2": { title: "Account management", rev: "Security plan Rev B", owner: "M. Okonjo", ctls: ["AC-2"],
      blocks: [["Ground segment IdAM lifecycle", "current", "Automated through the enterprise feed."], ["Air vehicle compensating measure", "draft", "Manual two-person procedure with 72-hour review — Halcyon precedent cited."]] },
    "§4.4": { title: "Software integrity", rev: "Security plan Rev B", owner: "S. Whitfield", ctls: ["CM-14", "SI-7(9)"],
      blocks: [["Signed OFP loads", "current", "Signing pipeline evidence rolls with every push."], ["Bootloader verification", "draft", "Placeholder until the P3 card refresh lands (FND-0198)."]] },
    "§6.4": { title: "Datalink authentication", rev: "Security plan Rev B", owner: "D. Iqbal", ctls: ["IA-3", "IA-3(1)"],
      blocks: [["Device authentication on the primary waveform", "stale", "Rework queued — maintenance-mode bypass removal under ECP-2231."]] }
  };

  // ---- Benchmark rules ----
  var RULES = {
    "RHEL-08-020170": { bench: "RHEL 8 STIG · V1R14", sev: "CAT II", res: "Fail", assets: "4 of 6 assets", ctl: "IA-5(1)", cci: "CCI-000195", fnd: "FND-0204", check: "Require difok = 8 changed characters in pwquality. Check: grep difok /etc/security/pwquality.conf — fielded image returns 4; the CNSSI value set requires 8.", fix: "Raise difok to 8 in the pwquality baseline and rebuild the image (staged in Ansible)." },
    "RHEL-08-020230": { bench: "RHEL 8 STIG · V1R14", sev: "CAT II", res: "Fail", assets: "6 of 6 assets", ctl: "IA-5(1)", cci: "CCI-000205", fnd: "FND-0204", check: "Enforce minlen = 15 in pwquality. The baseline image predates the April value set and pins 12.", fix: "Raise minlen 12 → 15 fleet-wide via the staged Ansible rebuild." },
    "RHEL-08-020110": { bench: "RHEL 8 STIG · V1R14", sev: "CAT II", res: "Pass", assets: "6 of 6 assets", ctl: "IA-5(1)", cci: "CCI-000192", fnd: "", check: "Enforce ucredit upper case requirement in pwquality. All six nodes return the compliant value.", fix: "" },
    "RHEL-08-020220": { bench: "RHEL 8 STIG · V1R14", sev: "CAT II", res: "Pass", assets: "6 of 6 assets", ctl: "IA-5(1)", cci: "CCI-000200", fnd: "", check: "Prohibit password reuse for 5 generations. Compliant on all nodes.", fix: "" },
    "RHEL-08-010110": { bench: "RHEL 8 STIG · V1R14", sev: "CAT II", res: "Pass", assets: "6 of 6 assets", ctl: "IA-5(1)", cci: "CCI-000196", fnd: "", check: "Store only SHA-512 protected passwords. Compliant.", fix: "" },
    "WN22-AC-000070": { bench: "Windows Server 2022 STIG · V2R2", sev: "CAT II", res: "Open", assets: "3 of 3 assets", ctl: "IA-5(1)", cci: "CCI-000205", fnd: "FND-0198", check: "Minimum password length must be 14 or greater — the CNSSI profile value requires 15. GPO currently pins 14.", fix: "One-line change in the domain policy: MinimumPasswordLength 14 → 15." },
    "WN22-AC-000080": { bench: "Windows Server 2022 STIG · V2R2", sev: "CAT II", res: "Pass", assets: "3 of 3 assets", ctl: "IA-5(1)", cci: "CCI-000192", fnd: "", check: "Password must meet complexity requirements. Compliant on all mission planning servers.", fix: "" },
    "WN22-AC-000040": { bench: "Windows Server 2022 STIG · V2R2", sev: "CAT II", res: "Pass", assets: "3 of 3 assets", ctl: "IA-5(1)", cci: "CCI-000200", fnd: "", check: "Password history set to 24. Compliant.", fix: "" },
    "RHEL-08-010294": { bench: "RHEL 8 STIG · V1R14", sev: "CAT I", res: "Fail", assets: "2 of 4 assets", ctl: "SC-8(1)", cci: "CCI-002418", fnd: "FND-0211", check: "The TLS crypto policy must not permit legacy cipher suites. Two GCS uplink nodes still carry the pre-April policy — protocol downgrade exposure on the command uplink.", fix: "Push the approved crypto policy diff (POL-DIFF) to KM-UPL-01/02 and rescan." },
    "RHEL-08-010293": { bench: "RHEL 8 STIG · V1R14", sev: "CAT II", res: "Pass", assets: "4 of 4 assets", ctl: "SC-8(1)", cci: "CCI-002421", fnd: "", check: "System-wide crypto policy set to FIPS. Compliant across the GCS enclave.", fix: "" },
    "CISC-ND-001200": { bench: "Cisco IOS-XE Router NDM STIG · V3R1", sev: "CAT II", res: "Pass", assets: "4 of 4 assets", ctl: "SC-8(1)", cci: "CCI-002418", fnd: "", check: "SSHv2 with approved algorithms only. The router path is clean.", fix: "" },
    "RHEL-08-010671": { bench: "RHEL 8 STIG · V1R14", sev: "CAT II", res: "Fail", assets: "6 of 6 assets", ctl: "CM-6", cci: "CCI-000366", fnd: "FND-0187", check: "Disable kdump kernel crash dumps. New expected value in V1R14 — true drift.", fix: "Staged in the Ansible baseline; applies 14 Aug." },
    "RHEL-08-040284": { bench: "RHEL 8 STIG · V1R14", sev: "CAT II", res: "Fail", assets: "3 of 6 assets", ctl: "CM-6", cci: "CCI-000366", fnd: "FND-0187", check: "Restrict access to the kernel message buffer. Half the fleet drifted after the V1R14 refresh.", fix: "Staged in the Ansible baseline; applies 14 Aug." },
    "WN22-SO-000110": { bench: "Windows Server 2022 STIG · V2R2", sev: "CAT II", res: "Fail", assets: "1 of 3 assets", ctl: "CM-6", cci: "CCI-000366", fnd: "FND-0204", check: "SMB packet signing required. One mission planning server out of policy.", fix: "Enable RequireSecuritySignature via GPO on MP-03." },
    "RHEL-08-020270": { bench: "RHEL 8 STIG · V1R14", sev: "CAT II", res: "Open", assets: "6 of 6 assets", ctl: "AC-2", cci: "CCI-000015", fnd: "FND-0176", check: "Account management must use automated mechanisms. The air vehicle partition has no IdAM path in flight configuration.", fix: "Compensating manual procedure pending ISSM acceptance; IdAM bridge deferred to Rev D." },
    "RHEL-08-020000": { bench: "RHEL 8 STIG · V1R14", sev: "CAT II", res: "Pass", assets: "6 of 6 assets", ctl: "AC-2", cci: "CCI-000016", fnd: "", check: "Temporary accounts expire within 72 hours. Compliant.", fix: "" },
    "RHEL-08-020260": { bench: "RHEL 8 STIG · V1R14", sev: "CAT II", res: "Pass", assets: "6 of 6 assets", ctl: "AC-2", cci: "CCI-000017", fnd: "", check: "Inactive accounts disabled after 30 days. Compliant.", fix: "" },
    "WN22-AC-000010": { bench: "Windows Server 2022 STIG · V2R2", sev: "CAT II", res: "Pass", assets: "3 of 3 assets", ctl: "AC-2", cci: "CCI-000017", fnd: "", check: "Inactive accounts disabled after 30 days. Compliant.", fix: "" }
  };

  // ---- Upstream changes ----
  var CHG = {
    "CHG-118": { title: "WBS 1.1.5.3 crypto module changed from KGV-72M to KI-700", source: "Cameo Systems Modeler · KestrelM_Arch.mdzip", raised: "27 Jul 2026",
      body: "The architecture model now shows a KI-700 where the record set still cites the KGV-72M. Impact computation flags 3 control statements, 2 SP blocks, and 2 evidence artifacts as stale, and queues the §4.3 rewrite on acceptance.",
      ctls: ["SC-12", "SC-13", "IA-7"], sp: "§4.3", ev: ["EV-01", "EV-03"], parts: ["1.1.5.3"],
      impact: [["3 control statements", "held stale until accepted"], ["2 SP blocks in §4.3", "rewrite queued"], ["2 evidence artifacts", "re-collection tasks on acceptance"], ["1 requirement (SRS-3.4.9)", "re-verify after acceptance"]] },
    "CHG-119": { title: "Advisory ICSA-26-189-02 pulls SI-7(9) into the baseline", source: "Cybersecurity advisory feed · ICSA-26-189-02", raised: "28 Jul 2026",
      body: "The advisory targets the mission computer bootloader update path. Accepting adds SI-7(9) to the effective set as a planned control and opens the boot-integrity gap already tracked under FND-0198.",
      ctls: ["SI-7(9)", "SI-7"], sp: "§4.4", ev: ["EV-14"], parts: ["1.1.4.3"],
      impact: [["1 control added", "SI-7(9) enters as planned"], ["SP §4.4", "placeholder block created"], ["FND-0198", "becomes the tracking finding"]] },
    "CHG-120": { title: "REQ-KM-0409 reworded to require module authentication at power-on", source: "Jama Connect · CDRL A012 requirements", raised: "29 Jul 2026",
      body: "The customer reworded the module-authentication requirement to bind at power-on rather than before operational mode. IA-7's statement and one SCTM row re-verify on acceptance.",
      ctls: ["IA-7"], sp: "§4.3", ev: [], parts: ["1.1.5.3"],
      impact: [["1 control statement", "IA-7 re-verifies"], ["1 SCTM row", "row 214 flagged"], ["SRS-3.4.9", "text supersedes on acceptance"]] }
  };

  window.__attestRecords = { NAMES: NAMES, FAM: FAM, REL: REL, CTL: CTL, REQ: REQ, EVR: EVR, FND: FND, PART: PART, SPS: SPS, RULES: RULES, CHG: CHG };
})();
