---
name: program-assurance-design
description: Use this skill to generate well-branded interfaces and assets for the Program Assurance Platform (cybersecurity program management — NIST 800-53 assessments, inheritance, findings, POA&M), either for production or throwaway prototypes/mocks. Contains essential design guidelines, colors, type, fonts, status vocabularies, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

Key files: `readme.md` (voice, visual foundations, iconography, index) · `styles.css` + `tokens/` (the token contract; link styles.css in every artifact) · `component-styles.css` (pa-* classes usable from plain HTML) · `components/**` (React primitives + per-component .prompt.md usage notes) · `ui_kits/platform/` (full interactive shell + four screens to copy layout patterns from) · `research/DIGEST.md` (canonical status labels, action verbs, routes — use them verbatim).

Hard rules: one accent (#2E5AC7) used ≤3 times per viewport; statuses only via the Appendix C vocabulary and StatusBadge tones (borderless tinted pills); Unknown is violet and first-class; 14px working body (13px only in compact grids), sentence case everywhere — nothing uppercase; white chrome with soft layered shadows (keyline/raised/float tokens); no gradients, no emoji, no logo (plain-type wordmark "Program Assurance"); buttons name the authority-bearing action; Lucide icons only (CDN pinned 0.460.0).

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
