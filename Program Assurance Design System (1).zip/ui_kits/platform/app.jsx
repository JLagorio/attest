const { Toast, Button, EmptyState } = window.ProgramAssuranceDesignSystem_004a77;

const NOT_BUILT = { organization: 'Organization', assets: 'Assets', library: 'Library', products: 'Products & Systems', risks: 'Risks & POA&M' };

function App() {
  const [route, setRoute] = React.useState(() => localStorage.getItem('pa-kit-route') || 'home');
  const [palette, setPalette] = React.useState(false);
  const [jobs, setJobs] = React.useState([]);
  const [toasts, setToasts] = React.useState([]);
  const nav = r => { setRoute(r); localStorage.setItem('pa-kit-route', r); };
  const notify = (tone, title, body, action) => {
    const id = Date.now() + Math.random();
    setToasts(t => [...t, { id, tone, title, body, action }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 7000);
  };
  const runJob = name => {
    const id = Date.now();
    setJobs(j => [{ id, name, pct: 0, done: false }, ...j]);
    const tick = setInterval(() => setJobs(j => j.map(x => x.id === id ? { ...x, pct: Math.min(100, x.pct + 25) } : x)), 600);
    setTimeout(() => {
      clearInterval(tick);
      setJobs(j => j.map(x => x.id === id ? { ...x, pct: 100, done: true } : x));
      notify('ok', 'Workbook export finished', '842 rows · Program NIGHTHAWK · 14s', <Button size="compact" variant="ghost" icon="download">Download SCTM.xlsx</Button>);
    }, 2600);
  };
  React.useEffect(() => {
    const onKey = e => { if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setPalette(p => !p); } };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, []);
  const screen =
    route === 'home' ? <HomeScreen onNav={nav} runJob={runJob} /> :
    route === 'assessment' ? <AssessmentScreen notify={notify} /> :
    route === 'findings' ? <FindingsScreen notify={notify} /> :
    route === 'program' ? <ProgramScreen runJob={runJob} /> :
    <EmptyState icon="layers" title={NOT_BUILT[route] + ' — not recreated in this kit'} style={{ flex: 1 }}
      action={<Button size="compact" onClick={() => nav('home')}>Back to Home</Button>}>
      This surface exists in the product spec (46-screen inventory in research/DIGEST.md) but was intentionally not rebuilt. The four built screens demonstrate the full component vocabulary.
    </EmptyState>;
  return (
    <React.Fragment>
      <Shell route={route} onNav={nav} jobs={jobs} onOpenPalette={() => setPalette(true)}>{screen}</Shell>
      <CommandPalette open={palette} onClose={() => setPalette(false)} onNav={nav} runJob={runJob} />
      <div style={{ position: 'fixed', right: 16, bottom: 16, display: 'flex', flexDirection: 'column', gap: 8, zIndex: 80 }}>
        {toasts.map(t => <Toast key={t.id} tone={t.tone} title={t.title} action={t.action} onDismiss={() => setToasts(x => x.filter(y => y.id !== t.id))}>{t.body}</Toast>)}
      </div>
    </React.Fragment>
  );
}
ReactDOM.createRoot(document.getElementById('root')).render(<App />);
