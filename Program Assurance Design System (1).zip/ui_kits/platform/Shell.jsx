const { Icon, Kbd, Input, IconButton, Tooltip, Badge } = window.ProgramAssuranceDesignSystem_004a77;

const NAV = [
  { group: 'Foundation', items: [
    { id: 'home', label: 'Home', icon: 'home', count: 6 },
    { id: 'organization', label: 'Organization', icon: 'building-2', count: 23 },
    { id: 'assets', label: 'Assets', icon: 'boxes', count: 4112 },
  ]},
  { group: 'Obligations', items: [
    { id: 'library', label: 'Library', icon: 'library', count: 57 },
  ]},
  { group: 'Delivery', items: [
    { id: 'products', label: 'Products & Systems', icon: 'layers', count: 48 },
    { id: 'program', label: 'Programs', icon: 'clipboard-list', count: 6 },
  ]},
  { group: 'Assurance work', items: [
    { id: 'assessment', label: 'Assessments', icon: 'inbox', count: 3 },
    { id: 'findings', label: 'Findings', icon: 'flag', count: 96 },
    { id: 'risks', label: 'Risks & POA&M', icon: 'shield-alert', count: 9 },
  ]},
];
const fmtCount = n => n > 9999 ? '999+' : n > 999 ? (n / 1000).toFixed(1).replace('.0', '') + 'k' : String(n);

function RailItem({ item, active, onClick }) {
  return (
    <button type="button" onClick={onClick} style={{
      all: 'unset', boxSizing: 'border-box', display: 'flex', alignItems: 'center', gap: 'var(--sp-8)', width: '100%',
      height: 'var(--row-compact)', padding: '0 var(--sp-8)', borderRadius: 'var(--r-control)', cursor: 'pointer',
      color: active ? 'var(--accent-text)' : 'var(--text-label)', fontSize: 'var(--text-body)', fontWeight: active ? 500 : 400,
      background: active ? 'var(--accent-bg)' : 'transparent',
      transition: 'background var(--t-state)',
    }}
      onMouseEnter={e => { if (!active) e.currentTarget.style.background = 'var(--surface-inset)'; }}
      onMouseLeave={e => { if (!active) e.currentTarget.style.background = 'transparent'; }}>
      <Icon name={item.icon} size={15} />
      <span style={{ flex: 1 }} className="u-truncate">{item.label}</span>
      <span className="u-num" style={{ fontSize: 'var(--text-meta)', color: 'var(--text-secondary)' }}>{fmtCount(item.count)}</span>
    </button>
  );
}

const PALETTE = [
  { g: 'Go to', t: 'Home', icon: 'home', nav: 'home' },
  { g: 'Go to', t: 'Assessment — TMC FY26', icon: 'inbox', nav: 'assessment' },
  { g: 'Go to', t: 'Findings', icon: 'flag', nav: 'findings' },
  { g: 'Go to', t: 'Program NIGHTHAWK', icon: 'clipboard-list', nav: 'program' },
  { g: 'Actions', t: 'Export SCTM workbook', icon: 'download', job: 'Workbook export — Program NIGHTHAWK' },
  { g: 'Actions', t: 'Create finding', icon: 'flag', nav: 'findings' },
  { g: 'Actions', t: 'Reassess impacted objectives (6)', icon: 'history', nav: 'assessment' },
  { g: 'Objects', t: 'Enterprise IAM Assurance Package v4.2', icon: 'git-branch', nav: 'program' },
  { g: 'Objects', t: 'Tactical Management Controller — TMC v3', icon: 'layers', nav: 'program' },
  { g: 'Objects', t: 'F-2214 · TMC serial console maintenance shell', icon: 'flag', nav: 'findings' },
];

function CommandPalette({ open, onClose, onNav, runJob }) {
  const [q, setQ] = React.useState('');
  React.useEffect(() => { if (open) setQ(''); }, [open]);
  if (!open) return null;
  const hits = PALETTE.filter(p => p.t.toLowerCase().includes(q.toLowerCase()));
  const run = p => { if (p.job) runJob(p.job); if (p.nav) onNav(p.nav); onClose(); };
  const groups = [...new Set(hits.map(h => h.g))];
  return (
    <div className="pa-scrim" style={{ alignItems: 'flex-start', paddingTop: 96 }} onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="pa-dialog" style={{ width: 560 }} role="dialog" aria-label="Command palette">
        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-8)', padding: 'var(--sp-8) var(--sp-12)', borderBottom: '1px solid var(--border-subtle)' }}>
          <Icon name="search" size={16} style={{ color: 'var(--text-secondary)' }} />
          <input autoFocus value={q} onChange={e => setQ(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && hits[0]) run(hits[0]); if (e.key === 'Escape') onClose(); }}
            placeholder="Type an object, action, or intent — e.g. why is SC-7 satisfied"
            style={{ flex: 1, border: 0, outline: 0, font: '400 14px var(--font-ui)', background: 'transparent', color: 'var(--text-primary)' }} />
          <Kbd>esc</Kbd>
        </div>
        <div style={{ maxHeight: 320, overflow: 'auto', padding: 'var(--sp-4)' }}>
          {groups.map(g => (
            <div key={g}>
              <div className="u-keycap" style={{ padding: '8px 8px 4px' }}>{g}</div>
              {hits.filter(h => h.g === g).map((p, i) => (
                <button key={p.t} type="button" onClick={() => run(p)} style={{
                  all: 'unset', boxSizing: 'border-box', display: 'flex', alignItems: 'center', gap: 'var(--sp-8)', width: '100%',
                  height: 'var(--row-default)', padding: '0 var(--sp-8)', borderRadius: 'var(--r-control)', cursor: 'pointer', fontSize: 'var(--text-body)',
                  background: g === groups[0] && i === 0 && hits[0] === p ? 'var(--selection-bg)' : 'transparent',
                }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--surface-inset)'}
                  onMouseLeave={e => e.currentTarget.style.background = hits[0] === p ? 'var(--selection-bg)' : 'transparent'}>
                  <Icon name={p.icon} size={14} style={{ color: 'var(--text-secondary)' }} />
                  <span style={{ flex: 1 }}>{p.t}</span>
                  {hits[0] === p ? <Kbd>↵</Kbd> : null}
                </button>
              ))}
            </div>
          ))}
          {hits.length === 0 ? <div style={{ padding: 'var(--sp-16)', fontSize: 'var(--text-body)', color: 'var(--text-secondary)' }}>No matches for “{q}”.</div> : null}
        </div>
      </div>
    </div>
  );
}

function JobsTray({ jobs }) {
  const [open, setOpen] = React.useState(false);
  const running = jobs.filter(j => !j.done).length;
  if (jobs.length === 0) return null;
  return (
    <span style={{ position: 'relative' }}>
      <button type="button" className="pa-btn pa-btn--ghost pa-btn--compact" onClick={() => setOpen(o => !o)}>
        <Icon name={running ? 'loader-circle' : 'check'} size={14} className={running ? 'pa-spin' : ''} style={{ color: running ? 'var(--accent-text)' : 'var(--ok-text)' }} />
        {running ? running + ' running' : 'Jobs'}
      </button>
      {open ? (
        <div style={{ position: 'absolute', top: '100%', right: 0, marginTop: 4, width: 320, background: 'var(--surface-card)', border: '1px solid var(--border-default)', borderRadius: 'var(--r-card)', boxShadow: 'var(--elev-float)', zIndex: 70, padding: 'var(--sp-4)' }}>
          {jobs.map(j => (
            <div key={j.id} style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-8)', padding: 'var(--sp-8)', fontSize: 'var(--text-body)' }}>
              <Icon name={j.done ? 'check' : 'loader-circle'} size={14} className={j.done ? '' : 'pa-spin'} style={{ color: j.done ? 'var(--ok-text)' : 'var(--accent-text)' }} />
              <span style={{ flex: 1 }} className="u-truncate">{j.name}</span>
              <span style={{ fontSize: 'var(--text-meta)', color: 'var(--text-secondary)' }}>{j.done ? 'done' : j.pct + '%'}</span>
            </div>
          ))}
        </div>
      ) : null}
    </span>
  );
}

function Shell({ route, onNav, jobs, onOpenPalette, children }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', overflow: 'hidden', background: 'var(--surface-app)' }}>
      <header style={{ height: 'var(--topbar-height)', flex: 'none', display: 'flex', alignItems: 'center', gap: 'var(--sp-16)', padding: '0 var(--sp-16)', background: 'var(--surface-card)', borderBottom: '1px solid var(--border-default)' }}>
        <span style={{ fontWeight: 600, fontSize: 'var(--text-comfort)', letterSpacing: '-.01em', color: 'var(--text-heading)', whiteSpace: 'nowrap' }}>Program Assurance</span>
        <div onClick={onOpenPalette} style={{ width: 340 }}>
          <Input icon="search" placeholder="Search controls, assets, findings…" readOnly suffix={<span style={{ display: 'flex', gap: 2 }}><Kbd>⌘</Kbd><Kbd>K</Kbd></span>} size="compact" style={{ cursor: 'pointer' }} />
        </div>
        <span style={{ flex: 1 }} />
        <JobsTray jobs={jobs} />
        <Tooltip content="Notifications"><IconButton icon="bell" label="Notifications" /></Tooltip>
        <span aria-label="Alex Naumov" title="Alex Naumov · SSE, Program NIGHTHAWK" style={{ width: 24, height: 24, borderRadius: 'var(--r-pill)', background: 'var(--n-8)', color: '#fff', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 600 }}>AN</span>
      </header>
      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        <nav style={{ width: 'var(--rail-width)', flex: 'none', background: 'var(--surface-card)', borderRight: '1px solid var(--border-subtle)', padding: 'var(--sp-8)', overflow: 'auto', boxSizing: 'border-box' }}>
          {NAV.map(g => (
            <div key={g.group} style={{ marginBottom: 'var(--sp-12)' }}>
              <div className="u-keycap" style={{ padding: '0 var(--sp-8) var(--sp-4)', color: 'var(--text-secondary)' }}>{g.group}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-2)' }}>
                {g.items.map(it => <RailItem key={it.id} item={it} active={route === it.id} onClick={() => onNav(it.id)} />)}
              </div>
            </div>
          ))}
          <div style={{ padding: 'var(--sp-8)', fontSize: 'var(--text-meta)', color: 'var(--text-placeholder)' }}>Snapshot v3 · Aug 24, 2026</div>
        </nav>
        <main style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>{children}</main>
      </div>
    </div>
  );
}

Object.assign(window, { Shell, CommandPalette, PA_NAV: NAV });
