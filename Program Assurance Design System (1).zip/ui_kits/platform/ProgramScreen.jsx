const { Table, StatusBadge, Button, Tabs, Badge, Drawer, EmptyState, Card, ProvenanceChip } = window.ProgramAssuranceDesignSystem_004a77;

const DIST = [
  ['Satisfied', 412, 'var(--ok-solid)'], ['Inherited – Current', 238, 'var(--inherited-text)'],
  ['Not Applicable', 46, 'var(--n-4)'], ['Ready for Review', 61, 'var(--info-solid)'],
  ['Awaiting Response', 44, 'var(--warn-solid)'], ['Unknown', 71, 'var(--unknown-solid)'],
  ['Other Than Satisfied', 18, 'var(--danger-solid)'],
];

function ProgramScreen({ runJob }) {
  const [tab, setTab] = React.useState('overview');
  const [rap, setRap] = React.useState(null);
  const raps = window.PA_DATA.raps;
  const total = DIST.reduce((s, d) => s + d[1], 0);
  const inheritTable = (
    <Table rows={raps} rowKey="id" onRowClick={r => setRap(r)} activeKey={rap && rap.id}
      columns={[
        { key: 'name', label: 'Assurance package', render: r => <span><span style={{ fontWeight: 500 }}>{r.name}</span> <span className="u-mono" style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{r.ver}</span></span> },
        { key: 'provider', label: 'Provider', width: 140 },
        { key: 'state', label: 'Consumption', width: 168, render: r => <StatusBadge status={r.state} /> },
        { key: 'covers', label: 'Covers', width: 62, align: 'right' },
        { key: 'residual', label: 'Residual', width: 66, align: 'right' },
        { key: 'attest', label: 'Attest.', width: 58, align: 'right', render: r => r.attest === 0 ? '—' : r.attest },
        { key: 'cond', label: 'Condition', clamp: true, width: 200 },
        { key: 'reviewed', label: 'Reviewed', width: 100, align: 'right', sortable: false, render: r => <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{r.reviewed}</span> },
      ]}
      rowState={r => r.state === 'Conflict' ? 'error' : undefined}
      footer={<span className="u-num">5 packages · 73 objectives covered · 17 residual · 2 need attention before Oct 5</span>} />
  );
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
      <div style={{ padding: 'var(--sp-12) var(--sp-24) 0', background: 'var(--surface-card)', borderBottom: '1px solid var(--border-subtle)' }}>
        <div style={{ fontSize: 'var(--text-meta)', color: 'var(--text-secondary)' }}>Programs / <span className="u-mono">PRG-114</span></div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-12)', margin: '2px 0 6px' }}>
          <h1 style={{ margin: 0, font: '600 var(--text-title)/1.2 var(--font-ui)', letterSpacing: '-.01em', color: 'var(--text-heading)' }}>Program NIGHTHAWK</h1>
          <StatusBadge status="Active" />
          <span style={{ fontSize: 'var(--text-meta)', color: 'var(--text-secondary)' }}>Customer C-114 · System: Tactical Management Controller v3 (baseline v3.2) · Control freeze Oct 5, 2026 · SSE A. Naumov</span>
        </div>
        <Tabs value={tab} onChange={setTab} tabs={[
          { id: 'overview', label: 'Overview' }, { id: 'reqs', label: 'Requirements & Controls', count: 890 },
          { id: 'inherit', label: 'Inheritance', count: 5 }, { id: 'findings', label: 'Findings', count: 23 }, { id: 'poam', label: 'Risks & POA&M', count: 4 },
        ]} style={{ borderBottom: 0 }} />
      </div>
      <div style={{ height: 'var(--toolbar-height)', flex: 'none', display: 'flex', alignItems: 'center', gap: 'var(--sp-8)', padding: '0 var(--sp-24)', background: 'var(--surface-card)', borderBottom: '1px solid var(--border-subtle)' }}>
        <span style={{ fontSize: 'var(--text-meta)', color: 'var(--text-secondary)' }}>Profile v3 pinned · last change Aug 14, 2026 · any change shows its blast radius before it lands</span>
        <span style={{ flex: 1 }} />
        <Button size="compact" variant="ghost" icon="download" onClick={() => runJob('Workbook export — Program NIGHTHAWK')}>Export SCTM workbook</Button>
        <Button size="compact" variant="primary" icon="git-branch" onClick={() => setTab('inherit')}>Review inheritance</Button>
      </div>
      <div style={{ flex: 1, overflow: 'auto', padding: 'var(--sp-16) var(--sp-24)' }}>
        {tab === 'overview' ? (
          <div style={{ display: 'grid', gridTemplateColumns: '3fr 2fr', gap: 'var(--sp-16)', alignItems: 'start' }}>
            <Card title="Objective states — factual, never a score" actions={<span className="u-num" style={{ fontSize: 12, color: 'var(--text-secondary)' }}>890 obligations</span>}>
              <div style={{ display: 'flex', height: 10, borderRadius: 'var(--r-control)', overflow: 'hidden', border: '1px solid var(--border-subtle)' }}>
                {DIST.map(([l, n, c]) => <span key={l} title={l + ' · ' + n} style={{ width: (n / total * 100) + '%', background: c }} />)}
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2px 24px', marginTop: 'var(--sp-12)' }}>
                {DIST.map(([l, n, c]) => (
                  <span key={l} style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-6)', fontSize: 'var(--text-body)', minHeight: 22 }}>
                    <span style={{ width: 8, height: 8, borderRadius: 2, background: c, flex: 'none' }} />
                    <span className="u-truncate" style={{ flex: 1 }} title={l}>{l}</span>
                    <span className="u-num" style={{ color: 'var(--text-secondary)' }}>{n}</span>
                  </span>
                ))}
              </div>
              <div style={{ marginTop: 'var(--sp-8)', fontSize: 'var(--text-meta)', color: 'var(--text-secondary)' }}>71 Unknown are work, not risk acceptance — 5 unowned. 18 Other Than Satisfied trace to 23 findings.</div>
            </Card>
            <Card title="Attention before Oct 5" padded={false}>
              {[
                ['Enterprise VPN RAP v2.8', 'Impacted', '6 objectives to reassess'],
                ['Enterprise MDM RAP v5.0', 'Conflict', 'lab asset assertion disagrees'],
                ['PKI consumer attestation', 'Attestation Required', 'device certificate scope'],
                ['SC-28(1) data-at-rest', 'Unknown', 'no owner assigned'],
              ].map(([a, s, b]) => (
                <div key={a} style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-8)', height: 'var(--row-default)', padding: '0 var(--sp-12)', borderBottom: '1px solid var(--border-subtle)', fontSize: 'var(--text-body)' }}>
                  <span className="u-truncate" style={{ flex: 1 }}>{a}</span>
                  <StatusBadge status={s} />
                  <span style={{ fontSize: 12, color: 'var(--text-secondary)', width: 160 }} className="u-truncate">{b}</span>
                </div>
              ))}
              <div style={{ padding: 'var(--sp-8) var(--sp-12)' }}><Button size="compact" variant="ghost" trailingIcon="chevron-right" onClick={() => setTab('inherit')}>Open inheritance review</Button></div>
            </Card>
            <div style={{ gridColumn: '1 / -1' }}>{inheritTable}</div>
          </div>
        ) : tab === 'inherit' ? inheritTable : (
          <EmptyState icon="layers" title="Not recreated in this kit">This tab exists in the UX spec (Appendix E); Overview and Inheritance are rebuilt here.</EmptyState>
        )}
      </div>
      <Drawer open={!!rap} onClose={() => setRap(null)} title={rap ? rap.name + ' ' + rap.ver : ''} wide>
        {rap ? (
          <div style={{ fontSize: 'var(--text-body)', lineHeight: 'var(--lh-prose)' }}>
            <div style={{ display: 'flex', gap: 'var(--sp-6)', alignItems: 'center' }}><StatusBadge status={rap.state} /><ProvenanceChip kind="inherited" source={'Published by ' + rap.provider + ' · reviewed ' + rap.reviewed}>provider: {rap.provider}</ProvenanceChip></div>
            <div className="u-keycap" style={{ margin: '14px 0 4px' }}>What this package gives you</div>
            <div className="u-num">{rap.covers} objectives resolved · {rap.residual} residual tasks stay with the consumer{rap.attest ? ' · ' + rap.attest + ' attestation(s) required' : ''}</div>
            <div className="u-keycap" style={{ margin: '14px 0 4px' }}>Applicability condition</div>
            <div>{rap.cond} — {rap.state === 'Impacted' ? 'condition changed upstream; inheritance suppressed until reassessed' : rap.state === 'Conflict' ? 'a consumer assertion disagrees; conflict stays visible until adjudicated' : 'passing for TMC v3'}</div>
            <div className="u-keycap" style={{ margin: '14px 0 4px' }}>Inheritance is a claim, not a copy</div>
            <div style={{ color: 'var(--text-secondary)', fontSize: 'var(--text-meta)' }}>Source, version, conditions, evidence lineage, and invalidation triggers stay attached. Rejecting an inappropriate claim here is what prevents false local coverage.</div>
            <div style={{ display: 'flex', gap: 'var(--sp-6)', marginTop: 'var(--sp-16)' }}>
              <Button size="compact" variant="primary">Accept applicable portion</Button>
              <Button size="compact">Request applicability review</Button>
            </div>
          </div>
        ) : null}
      </Drawer>
    </div>
  );
}
Object.assign(window, { ProgramScreen });
