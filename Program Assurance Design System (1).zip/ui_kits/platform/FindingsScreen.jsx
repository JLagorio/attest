const { Table, StatusBadge, Button, Input, Select, Badge, EmptyState, Icon } = window.ProgramAssuranceDesignSystem_004a77;

const SEV_TONE = { Critical: 'danger', High: 'warn', Moderate: 'info', Low: 'neutral' };
const OVERDUE = new Set(['Aug 12', 'Aug 20', 'Aug 22']);

function FindingsScreen({ notify }) {
  const all = window.PA_DATA.findings;
  const [q, setQ] = React.useState('');
  const [sev, setSev] = React.useState('All severities');
  const [st, setSt] = React.useState('All states');
  const [sel, setSel] = React.useState(new Set());
  const shown = all.filter(f => (sev === 'All severities' || f.sev === sev) && (st === 'All states' || f.state === st) && (q === '' || (f.id + ' ' + f.title + ' ' + f.scope).toLowerCase().includes(q.toLowerCase())));
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
      <div style={{ padding: 'var(--sp-12) var(--sp-24) var(--sp-8)', background: 'var(--surface-card)', borderBottom: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'baseline', gap: 'var(--sp-12)' }}>
        <h1 style={{ margin: 0, font: '600 var(--text-title)/1.2 var(--font-ui)', letterSpacing: '-.01em', color: 'var(--text-heading)' }}>Findings</h1>
        <span style={{ fontSize: 'var(--text-meta)', color: 'var(--text-secondary)' }}>96 across 14 scopes · 4 unassigned · 3 past due</span>
      </div>
      <div style={{ height: 'var(--toolbar-height)', flex: 'none', display: 'flex', alignItems: 'center', gap: 'var(--sp-8)', padding: '0 var(--sp-24)', background: 'var(--surface-card)', borderBottom: '1px solid var(--border-subtle)' }}>
        <Input icon="search" size="compact" placeholder="Filter by id, title, scope" value={q} onChange={e => setQ(e.target.value)} style={{ width: 220 }} />
        <Select size="compact" options={['All severities', 'Critical', 'High', 'Moderate', 'Low']} value={sev} onChange={e => setSev(e.target.value)} />
        <Select size="compact" options={['All states', 'Open', 'Triaged', 'Remediation Planned', 'In Remediation', 'Ready for Validation', 'Closed', 'Accepted/Deferred', 'False Positive']} value={st} onChange={e => setSt(e.target.value)} />
        <span style={{ flex: 1 }} />
        {sel.size > 0 ? (
          <React.Fragment>
            <span style={{ fontSize: 'var(--text-meta)', color: 'var(--text-secondary)' }} className="u-num">{sel.size} selected</span>
            <Button size="compact" icon="users" onClick={() => { notify('info', 'Assign owner', sel.size + ' findings — routing respects scope ownership'); setSel(new Set()); }}>Assign</Button>
            <Button size="compact" variant="primary" icon="link" onClick={() => { notify('ok', 'Remediation initiative created', 'RI-77 groups ' + sel.size + ' related findings'); setSel(new Set()); }}>Create remediation initiative</Button>
          </React.Fragment>
        ) : (
          <Button size="compact" variant="primary" icon="plus" onClick={() => notify('info', 'Create finding', 'Creation flow not recreated in this kit')}>Create finding</Button>
        )}
      </div>
      <div style={{ flex: 1, minHeight: 0, padding: 'var(--sp-12) var(--sp-24)', display: 'flex' }}>
        <Table density="compact" selectable selected={sel} onSelectedChange={setSel} style={{ flex: 1 }} maxHeight="100%"
          columns={[
            { key: 'id', label: 'ID', width: 70, mono: true },
            { key: 'title', label: 'Finding', clamp: true },
            { key: 'sev', label: 'Severity', width: 92, sortValue: r => ({ Critical: 0, High: 1, Moderate: 2, Low: 3 }[r.sev]), render: r => <Badge tone={SEV_TONE[r.sev]} dot>{r.sev}</Badge> },
            { key: 'scope', label: 'Scope', width: 130, clamp: true },
            { key: 'state', label: 'State', width: 160, render: r => <StatusBadge status={r.state} /> },
            { key: 'owner', label: 'Owner', width: 190, render: r => r.owner || <Badge tone="unknown" dot>Unassigned</Badge> },
            { key: 'due', label: 'Due', width: 66, align: 'right', render: r => r.due === '—' ? '—' : <span className="u-num" style={{ fontSize: 12, color: OVERDUE.has(r.due) ? 'var(--danger-text)' : 'var(--text-secondary)', fontWeight: OVERDUE.has(r.due) ? 500 : 400 }}>{r.due}</span> },
            { key: 'up', label: 'Updated', width: 76, align: 'right', sortable: false, render: r => <span style={{ color: 'var(--text-secondary)', fontSize: 12 }}>{r.up}</span> },
          ]}
          rows={shown} rowKey="id"
          rowState={r => OVERDUE.has(r.due) && r.state !== 'Closed' ? 'error' : undefined}
          footer={<span className="u-num">{shown.length} of 96 findings{sev !== 'All severities' || st !== 'All states' || q ? ' · filtered' : ''} · red rows past due</span>}
          empty={<EmptyState icon="list-filter" title="No findings match" action={<Button size="compact" onClick={() => { setQ(''); setSev('All severities'); setSt('All states'); }}>Clear filters</Button>}>Data exists — the current filter combination excludes all 96 findings.</EmptyState>} />
      </div>
    </div>
  );
}
Object.assign(window, { FindingsScreen });
