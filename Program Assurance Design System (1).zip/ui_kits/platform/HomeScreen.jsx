const { Card, Icon, StatusBadge, Button, Badge, ProvenanceChip } = window.ProgramAssuranceDesignSystem_004a77;

function HomeScreen({ onNav, runJob }) {
  const T = window.PA_DATA.tasks;
  const blockers = [
    { id: 'F-2214', what: 'TMC serial console exposes unauthenticated maintenance shell', who: 'R. Vance · Firmware Eng', due: 'Sep 5', state: 'Open' },
    { id: 'F-2196', what: 'Shared administrator credentials in integration lab jump host', who: 'M. Duran · Platform Security', due: 'Aug 12', state: 'In Remediation', over: true },
    { id: 'F-2184', what: 'POA&M milestone slipped: MFA rollout for maintenance accounts', who: 'J. Whitfield · Enterprise IAM', due: 'Aug 20', state: 'In Remediation', over: true },
    { id: 'SC-07b.[01]', what: 'Boundary protection Unknown — no owner assigned', who: null, due: 'Sep 12', state: 'Unknown' },
    { id: 'CM-06a.[02]', what: 'Gateway baseline deviation on management plane', who: 'K. Osei · Network Eng', due: 'Sep 12', state: 'Other Than Satisfied' },
  ];
  const row = { display: 'flex', alignItems: 'center', gap: 'var(--sp-8)', height: 'var(--row-default)', padding: '0 var(--sp-12)', borderBottom: '1px solid var(--border-subtle)', fontSize: 'var(--text-body)' };
  return (
    <div style={{ flex: 1, overflow: 'auto' }}>
      <div style={{ padding: 'var(--sp-16) var(--sp-24)', display: 'flex', alignItems: 'baseline', gap: 'var(--sp-12)' }}>
        <h1 style={{ margin: 0, font: '600 var(--text-title)/1.2 var(--font-ui)', letterSpacing: '-.01em', color: 'var(--text-heading)' }}>Home</h1>
        <span style={{ fontSize: 'var(--text-meta)', color: 'var(--text-secondary)' }}>Alex Naumov · SSE, Program NIGHTHAWK · Sunday, Aug 24</span>
      </div>
      <div style={{ padding: '0 var(--sp-24) var(--sp-24)', display: 'grid', gridTemplateColumns: '3fr 2fr', gap: 'var(--sp-16)', alignItems: 'start' }}>
        <Card title="Waiting on you" padded={false} actions={<Badge tone="accent">6</Badge>}>
          {T.map(t => (
            <div key={t.id} style={row}>
              <Icon name={t.icon} size={14} style={{ color: 'var(--text-secondary)' }} />
              <span className="u-keycap" style={{ width: 92, flex: 'none' }}>{t.kind}</span>
              <span className="u-truncate" style={{ flex: 1 }} title={t.text}>{t.text}</span>
              <span className="u-num" style={{ fontSize: 'var(--text-meta)', color: t.due === 'today' ? 'var(--warn-text)' : 'var(--text-secondary)' }}>{t.due}</span>
            </div>
          ))}
          <div style={{ ...row, borderBottom: 0, height: 32 }}>
            <Button size="compact" variant="ghost" trailingIcon="chevron-right" onClick={() => onNav('assessment')}>Open review queue</Button>
          </div>
        </Card>
        <Card title="Changed upstream" padded={false}>
          <div style={{ ...row, height: 'auto', padding: 'var(--sp-8) var(--sp-12)', alignItems: 'flex-start' }}>
            <Icon name="git-branch" size={14} style={{ color: 'var(--warn-text)', marginTop: 2 }} />
            <div style={{ flex: 1 }}>
              <div>Enterprise VPN RAP <span className="u-mono" style={{ fontSize: 12 }}>v2.8</span> is <StatusBadge status="Impacted" dot={false} /> — gateway config moved to GW-STD-12</div>
              <div style={{ fontSize: 'var(--text-meta)', color: 'var(--text-secondary)', margin: '2px 0 6px' }}>6 dependent objectives set to Reassessment Required · Yesterday</div>
              <Button size="compact" icon="history" onClick={() => onNav('assessment')}>Reassess impacted (6)</Button>
            </div>
          </div>
          <div style={{ ...row, height: 'auto', padding: 'var(--sp-8) var(--sp-12)', alignItems: 'flex-start' }}>
            <Icon name="upload" size={14} style={{ color: 'var(--info-text)', marginTop: 2 }} />
            <div style={{ flex: 1 }}>
              <div>Enterprise PKI published <span className="u-mono" style={{ fontSize: 12 }}>v3.2</span> — you consume <span className="u-mono" style={{ fontSize: 12 }}>v3.1</span></div>
              <div style={{ fontSize: 'var(--text-meta)', color: 'var(--text-secondary)', margin: '2px 0 6px' }}>Delta: 2 conditions tightened, 1 objective added · Aug 21</div>
              <Button size="compact" onClick={() => onNav('program')}>Review delta</Button>
            </div>
          </div>
          <div style={{ ...row, height: 'auto', padding: 'var(--sp-8) var(--sp-12)', alignItems: 'flex-start', borderBottom: 0 }}>
            <Icon name="triangle-alert" size={14} style={{ color: 'var(--danger-text)', marginTop: 2 }} />
            <div style={{ flex: 1 }}>
              <div>MDM package claim conflicts with lab asset assertion — <StatusBadge status="Conflict" dot={false} /></div>
              <div style={{ fontSize: 'var(--text-meta)', color: 'var(--text-secondary)', margin: '2px 0 6px' }}>Maintenance laptops asserted unmanaged by Integration Lab · Aug 19</div>
              <Button size="compact" onClick={() => onNav('program')}>Resolve conflict</Button>
            </div>
          </div>
        </Card>
        <Card title="What threatens the Oct 5 control freeze" padded={false} style={{ gridColumn: '1 / -1' }}
          actions={<Button size="compact" variant="ghost" icon="download" onClick={() => runJob('Workbook export — Program NIGHTHAWK')}>Export SCTM workbook</Button>}>
          {blockers.map(b => (
            <div key={b.id} style={row}>
              <span className="u-mono" style={{ width: 96, flex: 'none', fontSize: 12 }}>{b.id}</span>
              <span className="u-truncate" style={{ flex: 1 }} title={b.what}>{b.what}</span>
              <span style={{ width: 220, flex: 'none' }}>{b.who || <Badge tone="unknown" dot>Unassigned</Badge>}</span>
              <span style={{ width: 170, flex: 'none' }}><StatusBadge status={b.state} /></span>
              <span className="u-num" style={{ width: 60, flex: 'none', textAlign: 'right', fontSize: 'var(--text-meta)', color: b.over ? 'var(--danger-text)' : 'var(--text-secondary)', fontWeight: b.over ? 500 : 400 }}>{b.due}</span>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}
Object.assign(window, { HomeScreen });
