const { Table, StatusBadge, Button, Input, Select, Tabs, Badge, ProvenanceChip, DiffValue, Dialog, Drawer, Radio, EmptyState, Icon, Kbd, IconButton } = window.ProgramAssuranceDesignSystem_004a77;

function Inspector({ row, onDetermine, onWhy, notify }) {
  if (!row) return (
    <EmptyState icon="panel-right" title="Select an objective to inspect" style={{ padding: 'var(--sp-32) var(--sp-16)' }}>
      Lineage, provider assurance, evidence, and prior determinations appear here.
    </EmptyState>
  );
  const sec = { className: 'u-keycap', style: { margin: '14px 0 4px' } };
  return (
    <div style={{ padding: 'var(--sp-16)', fontSize: 'var(--text-body)', overflow: 'auto' }}>
      <div className="u-mono" style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{row.ctl} → {row.id} · SP 800-53A r5</div>
      <div style={{ margin: '6px 0 8px', lineHeight: 'var(--lh-prose)' }}>{row.st}</div>
      <StatusBadge status={row.state} />
      {row.prov ? <div style={{ marginTop: 8 }}><ProvenanceChip kind="inherited" source={row.prov.source}>{row.prov.label}</ProvenanceChip></div> : null}
      <div {...sec}>Owner</div>
      <div>{row.owner || <Badge tone="unknown" dot>Unassigned</Badge>}</div>
      <div {...sec}>Evidence · {row.ev || 0}</div>
      {row.ev ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-4)' }}>
          <span style={{ display: 'flex', gap: 6, alignItems: 'center' }}><Icon name="file-text" size={13} style={{ color: 'var(--text-secondary)' }} /><span className="u-truncate" style={{ flex: 1 }}>IAM-PROD-CONFIG-2026Q3.pdf</span><StatusBadge status="Current" dot={false} /></span>
          <span style={{ display: 'flex', gap: 6, alignItems: 'center' }}><Icon name="file-text" size={13} style={{ color: 'var(--text-secondary)' }} /><span className="u-truncate" style={{ flex: 1 }}>IdP-policy-export-aug.json</span><StatusBadge status="Expiring" dot={false} /></span>
        </div>
      ) : <span style={{ color: 'var(--text-secondary)' }}>— none linked</span>}
      <div {...sec}>Last determination</div>
      <div style={{ fontSize: 'var(--text-meta)', color: 'var(--text-secondary)', lineHeight: 1.5 }}>{row.state === 'Satisfied' || row.state === 'Inherited – Current' ? 'Satisfied · L. Ferreira · FY25 snapshot v7 · Nov 2, 2025' : '—'}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-6)', marginTop: 16 }}>
        <Button variant="primary" icon="check" onClick={onDetermine}>Record determination</Button>
        <div style={{ display: 'flex', gap: 'var(--sp-6)' }}>
          <Button size="compact" icon="message-square" onClick={() => notify('info', 'Clarification requested', row.id + ' — routed to ' + (row.owner || 'package owner'))}>Request clarification</Button>
          <Button size="compact" variant="ghost" icon="git-branch" onClick={onWhy}>Why is this here?</Button>
        </div>
      </div>
    </div>
  );
}

function AssessmentScreen({ notify }) {
  const [rows, setRows] = React.useState(window.PA_DATA.objectives);
  const [tab, setTab] = React.useState('objectives');
  const [q, setQ] = React.useState('');
  const [state, setState] = React.useState('All states');
  const [owner, setOwner] = React.useState('All owners');
  const [active, setActive] = React.useState('AC-06(1)');
  const [dlg, setDlg] = React.useState(false);
  const [why, setWhy] = React.useState(false);
  const [verdict, setVerdict] = React.useState('Satisfied');
  const owners = ['All owners', ...new Set(rows.map(r => r.owner).filter(o => o && o !== 'PROPOSED'))];
  const states = ['All states', ...new Set(rows.map(r => r.state))];
  const shown = rows.filter(r => (state === 'All states' || r.state === state) && (owner === 'All owners' || r.owner === owner) && (q === '' || (r.id + ' ' + r.st).toLowerCase().includes(q.toLowerCase())));
  const activeRow = rows.find(r => r.id === active);
  const resolveProposal = (accept) => {
    setRows(rs => rs.map(r => r.owner === 'PROPOSED' ? { ...r, owner: accept ? 'Platform Security' : 'Firmware Eng' } : r));
    notify(accept ? 'ok' : 'info', accept ? 'Proposal accepted' : 'Proposal rejected', 'AU-06a.[01] owner ' + (accept ? 'changed to Platform Security' : 'kept as Firmware Eng') + ' · attributed to mapping assist');
  };
  const record = () => {
    setRows(rs => rs.map(r => r.id === active ? { ...r, state: verdict, err: verdict === 'Other Than Satisfied' } : r));
    setDlg(false);
    notify('ok', 'Determination recorded', active + ' → ' + verdict + ' · snapshot v3');
  };
  const inherited = shown.filter(r => r.state === 'Inherited – Current').length;
  const unknown = shown.filter(r => r.state === 'Unknown').length;
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
      <div style={{ padding: 'var(--sp-12) var(--sp-24) 0', background: 'var(--surface-card)', borderBottom: '1px solid var(--border-subtle)' }}>
        <div style={{ fontSize: 'var(--text-meta)', color: 'var(--text-secondary)' }}>Assessments / <span className="u-mono">ASMT-0142</span></div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-12)', margin: '2px 0 6px' }}>
          <h1 style={{ margin: 0, font: '600 var(--text-title)/1.2 var(--font-ui)', letterSpacing: '-.01em', color: 'var(--text-heading)' }}>Tactical Management Controller — FY26</h1>
          <StatusBadge status="In Progress" />
          <span style={{ fontSize: 'var(--text-meta)', color: 'var(--text-secondary)' }}>Snapshot v3 · NIST 800-53 r5 Moderate + C-114 overlay · freeze Oct 5, 2026</span>
        </div>
        <Tabs value={tab} onChange={setTab} tabs={[
          { id: 'objectives', label: 'Objectives', count: 142 }, { id: 'packages', label: 'Packages', count: 9 },
          { id: 'evidence', label: 'Evidence', count: 1204 }, { id: 'findings', label: 'Findings', count: 7 },
        ]} style={{ borderBottom: 0 }} />
      </div>
      {tab !== 'objectives' ? (
        <EmptyState icon="layers" title="Not recreated in this kit">The {tab} view exists in the UX spec (Appendix E) but only Objectives is rebuilt here.</EmptyState>
      ) : (
        <React.Fragment>
          <div style={{ height: 'var(--toolbar-height)', flex: 'none', display: 'flex', alignItems: 'center', gap: 'var(--sp-8)', padding: '0 var(--sp-24)', background: 'var(--surface-card)', borderBottom: '1px solid var(--border-subtle)' }}>
            <Input icon="search" size="compact" placeholder="Filter 142 objectives" value={q} onChange={e => setQ(e.target.value)} style={{ width: 220 }} />
            <Select size="compact" options={states} value={state} onChange={e => setState(e.target.value)} />
            <Select size="compact" options={owners} value={owner} onChange={e => setOwner(e.target.value)} />
            <span style={{ flex: 1 }} />
            <Button size="compact" variant="ghost" icon="git-branch">Inheritance review</Button>
            <Button size="compact" variant="primary" icon="check" disabled={!activeRow} onClick={() => setDlg(true)}>Record determination</Button>
          </div>
          <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
            <div style={{ flex: 1, minWidth: 0, padding: 'var(--sp-12) 0 var(--sp-12) var(--sp-24)', overflow: 'hidden', display: 'flex' }}>
              <Table density="compact" style={{ flex: 1, alignSelf: 'stretch' }} maxHeight="100%"
                columns={[
                  { key: 'id', label: 'Objective', width: 104, mono: true },
                  { key: 'st', label: 'Statement', clamp: true },
                  { key: 'owner', label: 'Owner', width: 170, render: r => r.owner === 'PROPOSED' ? <DiffValue oldValue="Firmware Eng" newValue="Platform Security" onAccept={() => resolveProposal(true)} onReject={() => resolveProposal(false)} /> : (r.owner || <Badge tone="unknown" dot>Unassigned</Badge>) },
                  { key: 'state', label: 'State', width: 178, render: r => <StatusBadge status={r.state} /> },
                  { key: 'ev', label: 'Evidence', width: 66, align: 'right', render: r => r.ev === 0 ? '—' : r.ev },
                  { key: 'up', label: 'Updated', width: 76, align: 'right', sortable: false, render: r => <span style={{ color: 'var(--text-secondary)', fontSize: 12 }}>{r.up}</span> },
                ]}
                rows={shown} rowKey="id" activeKey={active} onRowClick={r => setActive(r.id)}
                rowState={r => r.owner === 'PROPOSED' ? 'pending' : r.err ? 'error' : undefined}
                footer={<span>{shown.length} of 142 objectives · {inherited} Inherited – Current · {unknown} Unknown · <ProvenanceChip kind="ai" source="Owner change proposed by mapping assist · 0.87 confidence">1 pending proposal</ProvenanceChip></span>}
                empty={<EmptyState icon="list-filter" title="No objectives match" action={<Button size="compact" onClick={() => { setQ(''); setState('All states'); setOwner('All owners'); }}>Clear filters</Button>}>Filters exclude all 142 objectives in this snapshot.</EmptyState>} />
            </div>
            <aside style={{ width: 'var(--inspector-width)', flex: 'none', borderLeft: '1px solid var(--border-subtle)', background: 'var(--surface-card)', margin: 'var(--sp-12) 0', display: 'flex', flexDirection: 'column', minHeight: 0, overflow: 'auto' }}>
              <Inspector row={activeRow} onDetermine={() => setDlg(true)} onWhy={() => setWhy(true)} notify={notify} />
            </aside>
          </div>
        </React.Fragment>
      )}
      <Dialog open={dlg} onClose={() => setDlg(false)} title={'Record determination — ' + active}
        footer={<React.Fragment><Button onClick={() => setDlg(false)}>Cancel</Button><Button variant="primary" icon="check" onClick={record}>Record determination</Button></React.Fragment>}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-8)' }}>
          {['Satisfied', 'Other Than Satisfied', 'Not Applicable', 'Insufficient Information'].map(v => (
            <Radio key={v} name="verdict" label={v} checked={verdict === v} onChange={() => setVerdict(v)} />
          ))}
          <label style={{ fontSize: 'var(--text-body)', fontWeight: 500, color: 'var(--text-label)', marginTop: 4 }}>Rationale</label>
          <textarea rows={3} defaultValue="Enforcement verified against IdP workflow export and linked procedure; conditions of Enterprise IAM RAP v4.2 hold for this system." style={{ font: '400 13px/1.55 var(--font-ui)', padding: 'var(--sp-8)', border: '1px solid var(--border-default)', borderRadius: 'var(--r-input)', resize: 'vertical', color: 'var(--text-primary)' }}></textarea>
          <div style={{ fontSize: 'var(--text-meta)', color: 'var(--text-secondary)' }}>Recorded as Alex Naumov · becomes part of snapshot v3 · response ≠ determination: contributor input stays attributed.</div>
        </div>
      </Dialog>
      <Drawer open={why} onClose={() => setWhy(false)} title="Why is this here?" headerExtra={<Kbd>esc</Kbd>}>
        {activeRow ? (
          <div style={{ fontSize: 'var(--text-body)', lineHeight: 'var(--lh-prose)' }}>
            <div className="u-inherited" style={{ display: 'inline' }}>{activeRow.id} — {activeRow.state}</div>
            <div style={{ color: 'var(--text-secondary)', fontSize: 'var(--text-meta)', lineHeight: 1.7, marginTop: 8 }}>
              Obligation — NIST 800-53 r5 Moderate profile + C-114 overlay §3.2<br />
              {activeRow.prov ? <React.Fragment>Source — {activeRow.prov.label}<br />Condition — {activeRow.prov.source.split('·')[1] || 'see package'}<br /></React.Fragment> : <React.Fragment>Source — local implementation on TMC v3<br /></React.Fragment>}
              Allocation — Tactical Management Controller · ground segment<br />
              History — imported Jan 8, 2026 · profile v3 pinned · last change Aug 14, 2026
            </div>
            <div style={{ marginTop: 12, display: 'flex', gap: 'var(--sp-6)' }}>
              <Button size="compact" variant="ghost" icon="external-link">Open package</Button>
              <Button size="compact" variant="ghost" icon="history">View history</Button>
            </div>
          </div>
        ) : null}
      </Drawer>
    </div>
  );
}
Object.assign(window, { AssessmentScreen });
