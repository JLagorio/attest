# Platform UI kit

Interactive recreation of the Program Assurance Platform's four core screens, composed from the design-system components (`window.ProgramAssuranceDesignSystem_004a77`). Built from the written specs (`research/DIGEST.md` — routes, statuses, actions, screen inventory); no visual source existed, so the visual layer is this design system's own foundations.

**Screens** (rail-switchable in `index.html`):
- **Home** — SSE work queue: what's waiting, what changed upstream, what threatens the freeze date.
- **Assessments** — Reviewer objective review: dense objective table + inspector, determination dialog, "Why is this here?" provenance drawer, AI-proposed owner change as a pending mutation.
- **Findings** — 30-row compact grid with live severity/state filters, bulk select, filtered-to-zero empty state.
- **Programs** — Program NIGHTHAWK overview: factual state distribution (no score), inheritance review table (5 RAPs), freeze blockers, SCTM export (runs as a job, completes to a toast).

Other rail surfaces (Organization, Assets, Library, Products & Systems, Risks & POA&M) intentionally show a "not recreated" state rather than an invented design.

Interactions: ⌘K palette (objects · actions · navigation) · row click → inspector · Esc closes overlays · route persists in localStorage.
