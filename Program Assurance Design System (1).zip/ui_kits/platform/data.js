/* Shared demo data for the Platform UI kit. Plain script — sets window.PA_DATA. */
window.PA_DATA = (() => {
  const objectives = [
    { id: 'AC-02a.[01]', ctl: 'AC-2', st: 'Account request approval enforced for privileged roles on the Tactical Management Controller', owner: 'Enterprise IAM', state: 'Inherited – Current', ev: 12, up: '2m ago', prov: { kind: 'inherited', label: 'Enterprise IAM RAP v4.2', source: 'Inherited from Enterprise IAM Assurance Package v4.2 · condition: production SSO · reviewed Aug 14, 2026' } },
    { id: 'AC-02a.[02]', ctl: 'AC-2', st: 'Account inventory reconciled against the authoritative directory on the defined cadence', owner: 'Enterprise IAM', state: 'Satisfied', ev: 8, up: '6h ago' },
    { id: 'AC-02g.[01]', ctl: 'AC-2', st: 'Privileged account use monitored and reported per organization policy', owner: 'SOC', state: 'Ready for Review', ev: 5, up: '6h ago' },
    { id: 'AC-06(1)', ctl: 'AC-6', st: 'Access to security functions restricted to explicitly authorized personnel', owner: 'Platform Security', state: 'Ready for Review', ev: 3, up: 'Yesterday' },
    { id: 'AC-17a.[01]', ctl: 'AC-17', st: 'Remote access methods documented, authorized, and monitored', owner: 'Enterprise VPN', state: 'Reassessment Required', ev: 6, up: 'Yesterday', prov: { kind: 'inherited', label: 'Enterprise VPN RAP v2.8', source: 'Enterprise VPN Assurance Package v2.8 · Impacted by gateway config change GW-STD-12 · reassessment required' } },
    { id: 'AU-06a.[01]', ctl: 'AU-6', st: 'Audit record review cadence defined and performed for the ground segment', owner: 'PROPOSED', state: 'In Progress', ev: 5, up: 'Aug 21' },
    { id: 'AU-12a.[02]', ctl: 'AU-12', st: 'Audit records generated for the events defined in AU-2 on all TMC subsystems', owner: 'SOC', state: 'Awaiting Response', ev: 2, up: 'Aug 20' },
    { id: 'CM-06a.[02]', ctl: 'CM-6', st: 'Configuration settings applied and deviations documented per baseline GW-STD-11', owner: 'Network Eng', state: 'Other Than Satisfied', ev: 4, up: 'Aug 19', err: true },
    { id: 'CM-08a.[01]', ctl: 'CM-8', st: 'System component inventory current, complete, and granular for the deployed variant', owner: 'Systems Eng', state: 'Satisfied', ev: 7, up: 'Aug 18' },
    { id: 'IA-02(1)', ctl: 'IA-2', st: 'MFA enforced for network access to privileged accounts', owner: 'Enterprise IAM', state: 'Inherited – Current', ev: 11, up: 'Aug 18', prov: { kind: 'inherited', label: 'Enterprise IAM RAP v4.2', source: 'Inherited from Enterprise IAM Assurance Package v4.2 · reviewed Aug 14, 2026' } },
    { id: 'IA-05(1)', ctl: 'IA-5', st: 'Password-based authenticator strength enforced at the enterprise IdP', owner: 'Enterprise IAM', state: 'Awaiting Response', ev: 0, up: 'Aug 15' },
    { id: 'IR-04a.[01]', ctl: 'IR-4', st: 'Incident handling capability covers preparation, detection, containment, and recovery', owner: 'Incident Response', state: 'Inherited – Current', ev: 9, up: 'Aug 14', prov: { kind: 'inherited', label: 'Enterprise IR RAP v3.0', source: 'Inherited from Enterprise Incident Response Package v3.0 · reviewed Jul 30, 2026' } },
    { id: 'SC-07b.[01]', ctl: 'SC-7', st: 'Boundary protection at external interfaces of the Tactical Management Controller', owner: null, state: 'Unknown', ev: 0, up: 'Aug 12' },
    { id: 'SC-08(1)', ctl: 'SC-8', st: 'Transmission confidentiality protected by cryptographic mechanisms on C2 links', owner: 'Comms Eng', state: 'Insufficient Information', ev: 1, up: 'Aug 12' },
    { id: 'SC-13a.[01]', ctl: 'SC-13', st: 'FIPS-validated cryptography identified for each protected data flow', owner: 'Crypto Eng', state: 'Satisfied', ev: 6, up: 'Aug 11' },
    { id: 'SC-28(1)', ctl: 'SC-28', st: 'Data-at-rest protection on removable mission data stores', owner: null, state: 'Unknown', ev: 0, up: 'Aug 9' },
    { id: 'SI-02c.[01]', ctl: 'SI-2', st: 'Flaw remediation within organization-defined response times for fielded firmware', owner: 'Firmware Eng', state: 'Reassessment Required', ev: 9, up: 'Jul 27' },
    { id: 'SI-04a.[01]', ctl: 'SI-4', st: 'Monitoring objectives defined for the TMC operational network segment', owner: 'SOC', state: 'Planned', ev: 0, up: 'Jul 27' },
    { id: 'SI-07a.[01]', ctl: 'SI-7', st: 'Software and firmware integrity verified with signed images at boot', owner: 'Firmware Signing', state: 'Inherited – Current', ev: 8, up: 'Jul 25', prov: { kind: 'inherited', label: 'Firmware Signing RAP v1.4', source: 'Inherited from Firmware Signing Assurance Package v1.4 · condition: HSM-backed pipeline · reviewed Jul 25, 2026' } },
    { id: 'PE-03a.[01]', ctl: 'PE-3', st: 'Physical access authorizations enforced at the integration lab', owner: 'Facilities', state: 'Not Applicable', ev: 2, up: 'Jul 21' },
  ];
  const sev = { C: 'Critical', H: 'High', M: 'Moderate', L: 'Low' };
  const F = (n, title, s, scope, state, owner, due, up) => ({ id: 'F-' + n, title, sev: sev[s], scope, state, owner, due, up });
  const findings = [
    F(2214, 'TMC serial console exposes unauthenticated maintenance shell in bench configuration', 'C', 'TMC v3', 'Open', 'R. Vance · Firmware Eng', 'Sep 5', '2m ago'),
    F(2213, 'Boundary protection undefined for payload telemetry interface', 'C', 'TMC v3', 'Triaged', 'K. Osei · Network Eng', 'Sep 5', '1h ago'),
    F(2209, 'Gateway config GW-STD-11 deviation: management plane reachable from ops VLAN', 'H', 'Program NIGHTHAWK', 'In Remediation', 'K. Osei · Network Eng', 'Sep 12', '3h ago'),
    F(2201, 'Audit forwarding gap — ground segment collectors drop records above 2k eps', 'H', 'Ground Segment', 'Open', null, 'Sep 12', '6h ago'),
    F(2198, 'Firmware signing key rotation overdue on legacy build pipeline', 'H', 'Firmware Signing', 'Remediation Planned', 'T. Iwu · Firmware Signing', 'Sep 19', 'Yesterday'),
    F(2196, 'Shared administrator credentials in integration lab jump host', 'H', 'Integration Lab', 'In Remediation', 'M. Duran · Platform Security', 'Aug 12', 'Yesterday'),
  ];
  const more = [
    ['2195', 'Session lock not enforced on operator consoles', 'M', 'TMC v3', 'Ready for Validation', 'A. Petrov · Systems Eng', 'Aug 29', 'Yesterday'],
    ['2189', 'SC-8 encryption claim lacks current test evidence for C2 downlink', 'M', 'Program NIGHTHAWK', 'Open', 'L. Chen · Comms Eng', 'Sep 26', 'Aug 21'],
    ['2187', 'Vulnerability scan cadence not met for air-gapped enclave', 'M', 'Vulnerability Mgmt', 'Triaged', 'S. Bright · Vuln Mgmt', 'Sep 26', 'Aug 21'],
    ['2184', 'POA&M milestone slipped: MFA rollout for maintenance accounts', 'H', 'Enterprise IAM', 'In Remediation', 'J. Whitfield · Enterprise IAM', 'Aug 20', 'Aug 20'],
    ['2183', 'Removable media handling procedure unreferenced by operators', 'L', 'Ops Unit 4', 'Closed', 'D. Kim · Ops Unit 4', '—', 'Aug 19'],
    ['2181', 'Incident escalation contact list stale for night shift', 'L', 'Incident Response', 'Closed', 'P. Marsh · IR', '—', 'Aug 19'],
    ['2178', 'TLS 1.0 accepted on legacy telemetry bridge', 'H', 'Ground Segment', 'Open', null, 'Sep 5', 'Aug 18'],
    ['2175', 'Backup restoration untested for mission planning datastore', 'M', 'Mission Planning', 'Remediation Planned', 'A. Petrov · Systems Eng', 'Oct 3', 'Aug 18'],
    ['2172', 'Privileged access review evidence older than 12 months', 'M', 'Enterprise IAM', 'Ready for Validation', 'J. Whitfield · Enterprise IAM', 'Aug 27', 'Aug 17'],
    ['2170', 'Default SNMP community strings on lab switches', 'M', 'Integration Lab', 'Closed', 'K. Osei · Network Eng', '—', 'Aug 16'],
    ['2166', 'Anti-tamper coating verification skipped on lot 7', 'H', 'TMC v3', 'Accepted/Deferred', 'Program Office', 'Dec 15', 'Aug 15'],
    ['2160', 'Audit review responsibilities unassigned for payload segment', 'M', 'Payload', 'Open', null, 'Sep 19', 'Aug 14'],
    ['2159', 'Crypto module certificate expires within 90 days', 'M', 'Crypto Eng', 'In Remediation', 'L. Chen · Comms Eng', 'Sep 30', 'Aug 14'],
    ['2154', 'Firmware rollback protection not verified on variant B', 'C', 'TMC v3-B', 'Open', 'R. Vance · Firmware Eng', 'Sep 5', 'Aug 13'],
    ['2151', 'Least-functionality baseline missing for diagnostic port set', 'M', 'TMC v3', 'Triaged', 'A. Petrov · Systems Eng', 'Oct 3', 'Aug 12'],
    ['2149', 'Supply chain attestation absent for COTS SBC lot', 'H', 'Supply Chain', 'Open', null, 'Sep 12', 'Aug 12'],
    ['2144', 'Password vault access recertification overdue', 'M', 'Platform Security', 'In Remediation', 'M. Duran · Platform Security', 'Aug 22', 'Aug 11'],
    ['2140', 'Test range spectrum authorization evidence expired', 'L', 'Test Range', 'Closed', 'Ops Unit 4', '—', 'Aug 9'],
    ['2138', 'Maintenance laptop patch level below baseline', 'M', 'Integration Lab', 'Ready for Validation', 'M. Duran · Platform Security', 'Aug 29', 'Aug 8'],
    ['2131', 'Continuous monitoring plan lacks payload telemetry coverage', 'M', 'Program NIGHTHAWK', 'Remediation Planned', 'SOC', 'Oct 10', 'Aug 7'],
    ['2127', 'Physical escort log gaps at integration facility', 'L', 'Facilities', 'False Positive', 'Facilities', '—', 'Aug 5'],
    ['2119', 'Key ceremony witness requirement unmet for signing key K-114', 'H', 'Firmware Signing', 'Ready for Validation', 'T. Iwu · Firmware Signing', 'Aug 27', 'Aug 2'],
    ['2114', 'Developer test credentials present in fielded config export', 'C', 'TMC v3', 'In Remediation', 'R. Vance · Firmware Eng', 'Sep 1', 'Jul 30'],
    ['2108', 'Interconnection agreement missing for partner ground station', 'M', 'Ground Segment', 'Open', null, 'Oct 10', 'Jul 28'],
  ].map(a => F(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]));
  const raps = [
    { id: 'RAP-IAM', name: 'Enterprise IAM Assurance Package', ver: 'v4.2', provider: 'Enterprise IAM', state: 'Active', covers: 38, residual: 7, attest: 2, cond: 'production SSO configuration', reviewed: 'Aug 14, 2026' },
    { id: 'RAP-PKI', name: 'Enterprise PKI Assurance Package', ver: 'v3.1', provider: 'Enterprise PKI', state: 'Attestation Required', covers: 12, residual: 3, attest: 1, cond: 'org-issued device certificates', reviewed: 'Aug 2, 2026' },
    { id: 'RAP-VPN', name: 'Enterprise VPN Assurance Package', ver: 'v2.8', provider: 'Enterprise VPN', state: 'Impacted', covers: 9, residual: 2, attest: 0, cond: 'managed gateway config GW-STD-12', reviewed: 'Jul 19, 2026' },
    { id: 'RAP-FWS', name: 'Firmware Signing Assurance Package', ver: 'v1.4', provider: 'Firmware Signing', state: 'Active', covers: 8, residual: 1, attest: 0, cond: 'HSM-backed pipeline', reviewed: 'Jul 25, 2026' },
    { id: 'RAP-MDM', name: 'Enterprise MDM Assurance Package', ver: 'v5.0', provider: 'Enterprise MDM', state: 'Conflict', covers: 6, residual: 4, attest: 1, cond: 'managed maintenance laptops only', reviewed: 'Jun 30, 2026' },
  ];
  const tasks = [
    { id: 'T-8841', kind: 'Review', text: '14 responses ready for review — TMC FY26 assessment', due: 'today', icon: 'inbox' },
    { id: 'T-8836', kind: 'Determination', text: 'AC-06(1) — access to security functions · response accepted as input', due: 'today', icon: 'check' },
    { id: 'T-8829', kind: 'Clarification', text: 'IA-05(1) — J. Whitfield asked which IdP policy version applies', due: 'Aug 26', icon: 'message-square' },
    { id: 'T-8822', kind: 'Inheritance', text: 'Enterprise VPN RAP v2.8 Impacted — re-resolve 6 dependent objectives', due: 'Aug 28', icon: 'git-branch' },
    { id: 'T-8817', kind: 'Attestation', text: 'PKI package requires consumer attestation: device certificate scope', due: 'Sep 2', icon: 'file-text' },
    { id: 'T-8810', kind: 'Promotion', text: 'Boundary diagram for TMC v3 submitted for broader reuse — scope review', due: 'Sep 4', icon: 'upload' },
  ];
  return { objectives, findings: [...findings, ...more], raps, tasks };
})();
