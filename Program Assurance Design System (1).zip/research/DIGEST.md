# Domain digest (extracted from uploads/*.docx — full text in research/*.md)

Product: **Program Assurance Platform** — internal assessment-and-inheritance operating system for cybersecurity program assurance (NIST SP 800-53/53A, OSCAL-aligned). One living versioned graph: who is responsible (org units, owners), what exists (assets, shared services, products/systems), what must be true (controls, requirements, assessments, evidence, findings). Assurance established once at highest valid scope, reused as governed reference (never a copy). Unknown is first-class. No fake "X% secure" score. Automation proposes, humans approve.

## Nav (4 areas, from PRD 6.1)
Foundation: Home · Organization · Assets | Obligations: Library | Delivery: Products & Systems · Programs (SCTM) | Assurance work: Assessments · Findings · Risks & POA&M

## Routes (Appendix A)
/home /organization /organization/{unit} /assets /assets/{id} /products /products/{id} /products/{id}/baselines/{v} /programs /programs/{id} /programs/{id}/systems/{id} /assessments /assessments/{id} /assessments/{id}/packages/{pkg} /work/{task} /findings /findings/{id} /risks /library /library/assurance/{rap} /library/promotions /conflicts/{id}

## Status vocab (Appendix C) — canonical, use verbatim
- Objective: Planned; Inherited – Current; Awaiting Response; Ready for Review; Insufficient Information; Satisfied; Other Than Satisfied; Not Applicable; Reassessment Required
- Task: New; Packaged; Assigned; Delegated; In Progress; Submitted; Clarification Requested; Accepted as Input; Closed
- Assurance package: Draft; Under Review; Published; Superseded; Retired; Impacted
- RAP consumption: Candidate; Applicable; Attestation Required; Active; Partially Active; Impacted; Reassessment Required; Conflict; Not Applicable; Ended/Superseded
- Evidence: Candidate; Accepted; Current; Expiring; Expired; Revoked; Impacted (visibility separate: Open / Metadata-only / Restricted)
- Finding: Open; Triaged; Remediation Planned; In Remediation; Ready for Validation; Closed; Accepted/Deferred; False Positive; Merged/Superseded
- Asset: Local/Candidate; Under Review; Canonical/Active; Superseded; Retired
- Promotion: Local; Submitted; Duplicate Review; Scope Review; Approved; Published; Rejected/Kept Local

## Action verbs (Appendix B) — name the authority-bearing action, never bare "Approve"/"Submit"
Create · Add · Link · Assign · Delegate · Reassign · Submit · Request clarification · Accept as input · Record determination · Create finding · Create remediation initiative · Create POA&M item · Request applicability review · Resolve conflict · Report change · Reassess · Submit for broader reuse · Promote · Publish · Supersede · Retire · Export

## UX principles
Work-centric Home (what do I owe, what changed, what threatens a milestone). Explain inheritance BEFORE generating work. Contributor experience = plain language, narrow ("Describe how privileged account requests are approved for the Tactical Management Controller and link the current procedure."); reviewer experience = full lineage (objective/control, snapshot, provider assurance, conflicts, evidence, prior determinations). Response ≠ determination. Unknown → owner + reason + resolution path. Provenance one click away ("Why is this here?" drawer). Conflicts stay visible until adjudicated. Versioned/pinned history.

## Screen inventory (Appendix E, 46 frames)
Home (Contributor / SSE) · Org tree · Unit Overview/Inheritance · Asset Catalog/Detail · Library landing · RAP Detail (provider/consumer) · New Org Assessment wizard · Objective Resolution preview · Package Owner view · Contributor Task (question/evidence/test) · Reviewer Queue · Reviewer Objective Review · Determination dialog · Finding creation/Detail · Promotion Queue/wizard · Product family Overview · Baseline workspace · Program Creation wizard/Launch Summary/Overview/Requirements & Controls/Inheritance Review · Add System chooser · New System Overview/Architecture-Unknowns · Variant Delta Review · Change Impact Review · Conflict Detail · Evidence Detail (open/restricted) · Remediation Initiative · POA&M Detail · Reassessment flow · Why/Provenance drawer · Import Center · Export/Workbook Center · Empty states · Permission-denied/metadata-only

## Sample entities for realistic data
Systems: Tactical Management Controller · shared services: Enterprise IAM, PKI, VPN, MDM, Vulnerability Management, Firmware Signing, Incident Response. RAP example: "Enterprise IAM Assurance Package v4.2 — resolves 38 objectives, 7 local residual tasks, 2 consumer attestations." Controls: AC-2, IA-5(1), objectives like AC-02a.[01]. SCTM = Security Controls Traceability Matrix (generated view, export not artifact).

## Tone (from docs)
Sober, precise, declarative. Sentence case everywhere. Domain states capitalized as proper labels (Satisfied, Other Than Satisfied, Unknown). No emoji. Full sentences in explanations; terse labels in chrome. Numbers stated factually ("38 objectives, 7 residual tasks"). Em-dash for definitions. "The workbook becomes an export, not a hand-maintained artifact."
