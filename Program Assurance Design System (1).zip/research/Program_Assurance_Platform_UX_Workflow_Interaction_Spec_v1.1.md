
# Program Assurance Platform
UX & Workflow Interaction Specification
Experience thesis The platform should make assurance work feel like resolving a finite set of well-explained decisions, questions, evidence requests, and reviews - not navigating a control framework. Users enter from either the organization or a product/program, inherit trusted work before new work is generated, expose unknowns and conflicts instead of hiding them, and always retain a visible path back to why an item exists and who has authority to resolve it.
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Field
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Value
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Status
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Draft for product, design, SSE, assessor, and engineering review
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Version
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>1.1
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Date
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>August 12, 2026
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Audience
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Product Design, Product Management, Systems Security Engineering, Security/GRC, Assessment, System Engineering, HW/FW/SW Engineering, Program Leadership, Frontend Engineering
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Companion documents
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Vision One-Pager v1.0; Product Requirements Document v1.1; Product & System Specification v1.1; Domain & Rules Specification v1.1
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Purpose
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Define user-facing information architecture, workflows, interaction contracts, screen behavior, role experiences, states, and acceptance journeys suitable for wireframing and implementation
This specification does not redefine the platform ontology or domain rules. It translates the canonical product and domain contracts into a coherent user experience. If an interaction described here conflicts with the Domain & Rules Specification, the domain rule wins and the UX must be redesigned rather than silently weakening the rule.

# Contents
1. Purpose, UX Contract, and Document Boundaries
2. Experience Principles
3. User Modes and Jobs
4. Global Information Architecture
5. Cross-Cutting Interaction Language
6. Home and Work Queue
7. Organization Setup and Organizational Units
8. Asset Catalog and Asset Detail
9. Assurance Library and Reusable Assurance Packages
10. Organization-First Assessment Entry
11. Product and System Baseline Management
12. Program Creation Wizard
13. System Onboarding Modes
14. New and Incomplete System Discovery
15. Effective Obligations, Tailoring, and Customer Requirements
16. Inheritance Review and Reusable Assurance Consumption
17. Variant Delta and Impact Review
18. Assessment Planning and Objective Resolution
19. Assignment Packages, Routing, and Delegation
20. Contributor Task Experience
21. Reviewer / SSE Assessment Experience
22. Findings, Remediation, Risk, and POA&M Workflow
23. Reassessment and Closure
24. Promotion, Deduplication, and Upward Propagation
25. Conflict, Source Reconciliation, and Authority Decisions
26. Evidence Experience and Restricted Visibility
27. Notifications, Deadlines, and Escalation
28. Dashboards, Rollups, and Readiness
29. Search, Graph Navigation, and Explainability
30. Import, Export, Workbook, and OSCAL-Aligned Interactions
31. Screen and Page Anatomy Catalog
32. Empty, Loading, Error, and Partial-Truth States
33. Permissions, Markings, and Sensitive-Data UX
34. Accessibility and Interaction Quality
35. MVP Interaction Scope and Delivery Sequence
36. End-to-End Acceptance Walkthroughs
Appendix A. Route and Screen Inventory
Appendix B. Standard Action Vocabulary
Appendix C. Status and Badge Vocabulary
Appendix D. OSCAL Interaction Alignment
Appendix E. Figma Frame Inventory

# Part I - Experience Foundation

# 1. Purpose, UX Contract, and Document Boundaries

## 1.1 What this document specifies
This document specifies the user experience contract for the Program Assurance Platform. It answers questions such as:
Where does a user start?
What does the application ask them to do first?
How does an organizational unit run an assessment without first creating a program?
How does a Program SSE create a program, select systems, and inherit existing organizational work?
How are unknown systems represented before architecture exists?
How are assignment packages created and delegated to individual engineers?
What does a contributor see compared with an assessor?
How does an inherited result explain where it came from and what remains local?
How are conflicts, stale evidence, sensitive evidence, and invalidated inheritance shown?
How do findings become remediation, risk, or POA&M work without turning the product into a generic project manager?
How does local work move upward into reusable organization knowledge?
The document is intended to be directly convertible into user flows, low-fidelity wireframes, Figma frames, frontend route definitions, and interaction acceptance criteria.

## 1.2 What this document does not specify
This document does not define:
physical database schemas;
API transport formats;
event-bus technology;
OSCAL serialization details;
authorization-policy implementation;
exact visual brand, color system, typography, or component library;
final information-security policy or authority delegation;
a replacement for engineering source systems such as PLM, CMDB, source control, ALM, or document repositories.
Those concerns belong in technical architecture, design-system, or organization-policy artifacts.

## 1.3 Normative relationship to companion documents
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="6268"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Question
<w:tcPr><w:tcW w:type="dxa" w:w="3452"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Canonical artifact
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="6268"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Why does the product exist and what is in scope?
<w:tcPr><w:tcW w:type="dxa" w:w="3452"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>PRD
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="6268"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>What is the entire vision in one page?
<w:tcPr><w:tcW w:type="dxa" w:w="3452"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Vision One-Pager
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="6268"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>How does the operating model work across organization, product, system, and program?
<w:tcPr><w:tcW w:type="dxa" w:w="3452"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Product & System Specification
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="6268"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>What is a valid entity, state, transition, inheritance result, evidence state, or conflict?
<w:tcPr><w:tcW w:type="dxa" w:w="3452"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Domain & Rules Specification
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="6268"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>What does the user see and do?
<w:tcPr><w:tcW w:type="dxa" w:w="3452"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>This UX & Workflow Interaction Specification
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="6268"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>How is the platform physically implemented?
<w:tcPr><w:tcW w:type="dxa" w:w="3452"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Technical Architecture / ADRs
UX constraint The interface may simplify domain language, but it may not collapse distinctions that are necessary for assurance integrity. In particular: Response is not Determination; Unknown is not Not Applicable; Inherited is not locally implemented; Evidence access is not assurance-result access; and a contributor cannot make an assessor-authority decision through a convenient button.

# 2. Experience Principles

## 2.1 Primary principles
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3291"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Principle
<w:tcPr><w:tcW w:type="dxa" w:w="6429"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>UX implication
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3291"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Work before framework
<w:tcPr><w:tcW w:type="dxa" w:w="6429"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Default views show what needs action, not a wall of control IDs. Framework traceability remains one click away.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3291"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Inheritance before questioning
<w:tcPr><w:tcW w:type="dxa" w:w="6429"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>The system resolves reusable assurance before generating contributor tasks. Users see why work disappeared or what residual work remains.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3291"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Unknown is visible
<w:tcPr><w:tcW w:type="dxa" w:w="6429"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Missing architecture, ownership, evidence, source authority, applicability, and configuration are explicit cards/items with owners and next actions.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3291"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Progressive disclosure
<w:tcPr><w:tcW w:type="dxa" w:w="6429"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Contributors see plain-language tasks. SSEs and assessors can expand objective/control/provenance detail. Governance users can inspect source versions and rule logic.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3291"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Authority is visible
<w:tcPr><w:tcW w:type="dxa" w:w="6429"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Actions that create authoritative determinations, tailoring decisions, risk acceptance, publication, or promotion identify the authority and approval consequence.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3291"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Local work is never trapped
<w:tcPr><w:tcW w:type="dxa" w:w="6429"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Every reusable local object has a clear path to submit for higher-scope promotion without blocking current work.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3291"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>No false green
<w:tcPr><w:tcW w:type="dxa" w:w="6429"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Incomplete, stale, conflicted, unreviewed, or inherited-with-residual-responsibility states are visually distinct from Satisfied.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3291"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Explain every derived state
<w:tcPr><w:tcW w:type="dxa" w:w="6429"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Every inherited, impacted, effective, suppressed, or reassessment-required state offers a “Why?” explanation with source and rule lineage.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3291"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Deadline context matters
<w:tcPr><w:tcW w:type="dxa" w:w="6429"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Program work surfaces due dates, blockers, dependencies, and delivery impact without turning assurance into generic project management.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3291"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Bulk where safe, deliberate where authoritative
<w:tcPr><w:tcW w:type="dxa" w:w="6429"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Users can bulk route, delegate, acknowledge, or tag work. High-authority decisions remain intentionally explicit.

## 2.2 Design anti-patterns
The design must avoid:
a default home screen containing hundreds of control rows;
a single percentage that implies an organization or system is “X% secure”;
automatically marking unanswered items Not Applicable;
an inherited badge with no source, version, or applicability explanation;
allowing a contributor answer of “Yes” to directly produce Satisfied;
forcing organization users to understand product/system architecture to run an organizational assessment;
forcing a Program SSE to finish the enterprise Asset Catalog before creating a new system;
hiding changed source-system data until the next formal assessment;
duplicating inherited evidence into every consuming program;
requiring users to know OSCAL model names for routine workflow.

# 3. User Modes and Jobs

## 3.1 User modes
A person may operate in multiple modes. The product should adapt surfaces by current context rather than permanently typecasting the person into one persona.
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="3331"/><w:gridCol w:w="3331"/><w:gridCol w:w="3331"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2018"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Mode
<w:tcPr><w:tcW w:type="dxa" w:w="5187"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Primary concern
<w:tcPr><w:tcW w:type="dxa" w:w="2515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Typical starting surface
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2018"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Contributor
<w:tcPr><w:tcW w:type="dxa" w:w="5187"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>“What do you need from me?”
<w:tcPr><w:tcW w:type="dxa" w:w="2515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Home / My Work
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2018"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Package Owner
<w:tcPr><w:tcW w:type="dxa" w:w="5187"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>“What does my team need to answer and who knows each answer?”
<w:tcPr><w:tcW w:type="dxa" w:w="2515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment package
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2018"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Assessor / Reviewer
<w:tcPr><w:tcW w:type="dxa" w:w="5187"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>“Do I have enough information to make a determination?”
<w:tcPr><w:tcW w:type="dxa" w:w="2515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Reviewer Queue
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2018"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Program SSE
<w:tcPr><w:tcW w:type="dxa" w:w="5187"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>“What remains unresolved before the program milestone?”
<w:tcPr><w:tcW w:type="dxa" w:w="2515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Program Overview / Work / Assessments
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2018"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>System / Product Security
<w:tcPr><w:tcW w:type="dxa" w:w="5187"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>“What is reusable about this baseline and what changed?”
<w:tcPr><w:tcW w:type="dxa" w:w="2515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Products & Systems
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2018"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Organizational Assurance Owner
<w:tcPr><w:tcW w:type="dxa" w:w="5187"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>“What does this unit own, what has been assessed, and what can downstream consumers inherit?”
<w:tcPr><w:tcW w:type="dxa" w:w="2515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Organization unit
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2018"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Asset / Shared-Service Owner
<w:tcPr><w:tcW w:type="dxa" w:w="5187"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>“What assurance do I provide and who consumes it?”
<w:tcPr><w:tcW w:type="dxa" w:w="2515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Asset / Assurance Package
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2018"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Governance / Library Steward
<w:tcPr><w:tcW w:type="dxa" w:w="5187"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>“What is authoritative, reusable, current, and properly scoped?”
<w:tcPr><w:tcW w:type="dxa" w:w="2515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Library / Promotion Queue
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2018"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Leadership
<w:tcPr><w:tcW w:type="dxa" w:w="5187"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>“Where are the unresolved facts, findings, remediation, and deadline risks?”
<w:tcPr><w:tcW w:type="dxa" w:w="2515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Organization / Program Overview

## 3.2 Default role switching
Users with multiple responsibilities should be able to switch context using scope and work views rather than separate applications. Example: an engineer who owns the Enterprise Signing Service can answer a delegated task from Home, then open the asset page to maintain reusable evidence, without switching to an “admin mode.”

# 4. Global Information Architecture

## 4.1 Primary navigation
The recommended desktop navigation is:
Home | Organization | Assets | Products & Systems | Programs | Assessments | Findings | Risks & POA&M | Library
Administrative configuration is exposed through a secondary Admin area for authorized users.
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Area
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Primary question answered
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Home
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>What needs my attention?
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Organization
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Who owns what and what assurance exists at each organizational scope?
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Assets
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>What assessable/reusable subjects exist and where are they used?
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Products & Systems
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>What do our standard products/systems contain and how are they normally assured?
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Programs
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>What are we delivering, what applies, what remains, and what threatens the milestone?
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Assessments
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>What is being assessed, who owes input, and what determinations remain?
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Findings
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>What gaps have been identified and where do they apply?
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Risks & POA&M
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>What formal risk/remediation work is active?
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Library
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>What authoritative controls, profiles, assessment content, reusable assurance, and governed knowledge can be reused?

## 4.2 Global scope selector
A scope selector should be available where the same view can operate at multiple levels. It must not silently change data meaning.
Example scopes:
ACME Defense
Enterprise Security
Product Division A
Falcon Product Family
Falcon v6 Baseline
Nightwing Program
Tactical Management Controller
The selector shows current scope, parent path, and access level. Switching scope preserves the current conceptual page where meaningful; otherwise it routes to the nearest valid landing page.

## 4.3 Global command/search entry
A global search/command entry should support:
direct entity navigation;
“go to Program Nightwing”;
“find AC-2”;
“find Enterprise IAM evidence”;
“show work assigned to me”;
“create assessment”;
“create program” for authorized users.
Search results must honor markings and may show metadata-only results where policy permits without revealing restricted content.

# 5. Cross-Cutting Interaction Language

## 5.1 Universal object header
Most object detail pages should use a shared header pattern:
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1930"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Element
<w:tcPr><w:tcW w:type="dxa" w:w="7790"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Behavior
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1930"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Breadcrumb
<w:tcPr><w:tcW w:type="dxa" w:w="7790"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Shows scope and containment path without implying organizational ownership when the path is technical.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1930"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Name + type
<w:tcPr><w:tcW w:type="dxa" w:w="7790"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Human-readable name and explicit type.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1930"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>State badges
<w:tcPr><w:tcW w:type="dxa" w:w="7790"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Lifecycle, assurance, conflict, or freshness states relevant to the object.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1930"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Owner
<w:tcPr><w:tcW w:type="dxa" w:w="7790"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Organizational owner and responsible person/role where applicable.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1930"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Source
<w:tcPr><w:tcW w:type="dxa" w:w="7790"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Canonical source or locally created origin.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1930"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Version / effective date
<w:tcPr><w:tcW w:type="dxa" w:w="7790"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Shown for versioned objects.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1930"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Primary actions
<w:tcPr><w:tcW w:type="dxa" w:w="7790"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Contextual and authority-aware.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1930"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Why / provenance
<w:tcPr><w:tcW w:type="dxa" w:w="7790"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Opens lineage drawer for derived/inherited/effective states.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1930"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Activity
<w:tcPr><w:tcW w:type="dxa" w:w="7790"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Opens chronological audit/event view.

## 5.2 “Why is this here?” drawer
Every derived item must expose an explanation drawer. The drawer should answer:
1. What is the current state?
2. Which source objects produced it?
3. Which scope and versions apply?
4. Which rule, assertion, profile operation, or human decision caused it?
5. What residual responsibilities remain?
6. What would invalidate or change this state?
7. Who has authority to change the underlying decision?
The drawer is especially important for inherited assessment results, effective parameters, suppressed tasks, impacted evidence, and customer overrides.

## 5.3 Status badges
Status badges should encode state, not judgmental color theater. Labels must remain readable without color.
Recommended cross-cutting badge language:
Current
Inherited
Local
Program-specific
Draft
Published
Unknown
Conflict
Needs review
Reassessment required
Evidence restricted
Evidence stale
Waiting on response
Ready for review
Satisfied
Other Than Satisfied
Not Applicable

## 5.4 Context drawer
Contributor-facing screens use a compact “Context” drawer rather than dumping full framework content into the task. The drawer may show:
system/program or organization scope;
relevant requirement text;
mapped control/objective;
requester and reviewer;
why the task exists;
related prior response;
downstream milestone.

## 5.5 Activity and comments
Comments are discussion attached to work. They do not alter assurance truth. Material changes require structured actions.
Example:
A comment saying “This should be N/A” does not change applicability.
The user must choose Request applicability review.
A comment saying “We upgraded the bootloader” does not change the system configuration.
The user must choose Report configuration change or edit the authoritative local configuration if permitted.
This distinction keeps chat from becoming shadow truth.

# 6. Home and Work Queue

## 6.1 Home design goal
Home is the universal front door for most users. It should immediately answer: What do I need to do, what is waiting on me, and what is at risk?

## 6.2 Home layout
Recommended desktop layout:
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1783"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Region
<w:tcPr><w:tcW w:type="dxa" w:w="7937"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Content
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1783"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Top summary
<w:tcPr><w:tcW w:type="dxa" w:w="7937"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>My overdue items; due this week; waiting for my review; blocked items; newly assigned.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1783"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>My Work
<w:tcPr><w:tcW w:type="dxa" w:w="7937"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Sortable list of assessment tasks, review items, findings, decisions, promotion reviews, and general assurance work.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1783"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Packages
<w:tcPr><w:tcW w:type="dxa" w:w="7937"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment packages I own, with completion and delegation state.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1783"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Watching / Owned
<w:tcPr><w:tcW w:type="dxa" w:w="7937"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assets, systems, programs, or organizational units where the user is owner or assurance owner.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1783"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Recent changes
<w:tcPr><w:tcW w:type="dxa" w:w="7937"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Upstream changes that impact owned work.

## 6.3 Work item row
Each work row should show:
action-oriented title;
work type;
target object/scope;
due date;
current owner;
blocking milestone or downstream consequence when relevant;
state;
one-click open;
quick delegate/reassign where allowed.
Framework IDs are secondary metadata, not the row title.

## 6.4 Saved work views
Useful presets:
Assigned to me
Awaiting my review
My assessment packages
Overdue
Due in 7 days
Blocking a program milestone
Returned for clarification
Reassessment required
Promotion reviews

# Part II - Organization-First Experience

# 7. Organization Setup and Organizational Units

## 7.1 Organization setup entry
A new tenant or new business area should not be forced into exhaustive org modeling. Initial setup requires only:
top-level organization name;
first useful organizational units;
assurance owner(s);
optional parent-child relationships;
optional identity/directory links.
The setup wizard explicitly says: “Model only what you need to start. You can add units while assessments uncover ownership.”

## 7.2 Organization tree interaction
The Organization page uses a collapsible hierarchy with a detail panel. Each unit node shows:
unit name;
assurance owner;
count of owned assets;
active assessments;
open findings;
unresolved inherited issues;
promotion candidates.
The tree is an ownership/responsibility hierarchy, not technical architecture. The UI should state this in onboarding and help content.

## 7.3 Organizational unit detail page
Suggested tabs:
Overview | Assets | Policies & Procedures | Assurance | Assessments | Findings | Risks & Remediation | Inheritance | Activity

### Overview
Shows:
unit mission/description;
parent and children;
unit owners;
inherited parent policies/assurance;
reusable assurance provided by the unit;
active work;
open findings/remediation;
downstream consumers of unit-owned assets.

### Inheritance tab
Separates:
inherited from parent;
originated here;
available to descendants;
requires descendant attestation;
shared-responsibility items.
Users can inspect residual responsibilities before using an inherited item.

## 7.4 Create organizational object during work
If an assessment uncovers a missing policy, procedure, service, or owner, users can create a local/candidate object inline without leaving the assessment. The creation panel asks for minimum viable fields and marks the object Local / Candidate until promoted.

# 8. Asset Catalog and Asset Detail

## 8.1 Catalog experience
The Asset Catalog is not presented as a CMDB clone. It is a searchable assurance-oriented inventory with filters for:
asset type;
owning organizational unit;
product/system usage;
lifecycle/version;
assessment state;
assurance package availability;
evidence freshness;
open findings;
canonical vs local candidate state.

## 8.2 Asset type presentation
The UX may use friendly categories while preserving canonical type metadata:
Policy
Procedure
Shared Service
Security Service
Process
Product
System
Subsystem
Hardware
Firmware / Software
External Service
Evidence Producer
Other Assessable Asset

## 8.3 Asset detail page
Suggested tabs:
Overview | Relationships | Implementations | Assurance Packages | Evidence | Assessments | Findings | Consumers | Changes | Activity
The Overview prominently shows:
owner and owning unit;
source-of-truth system;
version/configuration;
consumers;
current assessment state;
reusable assurance available;
stale/conflicted source data;
material unknowns.

## 8.4 Relationship graph
The Relationships tab should allow a focused graph view rather than a global spaghetti graph. Users choose relationship lenses such as:
Contains / part of
Consumes / provides
Owned by
Implements
Evidence supports
Assessed by
Used by products/programs
The graph is secondary to tabular lists for routine work.

# 9. Assurance Library and Reusable Assurance Packages

## 9.1 Library structure
The Library should be organized by reusable knowledge type:
Standards | Profiles | Requirements | Assessment Objectives | Assessment Templates | Reusable Assurance | Policies & Procedures | Evidence Patterns | Promotion Queue

## 9.2 Reusable Assurance Package list
The reusable assurance list shows:
package name;
provider asset;
owning organization unit;
version;
publication status;
supported control/objective count;
consumer responsibility count;
evidence visibility level;
last assessment date;
consumer count;
impacted/stale state.

## 9.3 Reusable Assurance Package detail
Suggested tabs:
Overview | Provides | Consumer Responsibilities | Applicability | Evidence & Results | Consumers | Versions | Activity

### Overview
Must answer:
What assurance does this package provide?
Who owns it?
What asset/service provides it?
Under what conditions can it be consumed?
What does the consumer still have to do?
When was the provider last assessed?
Can the consumer see the evidence or only the authorized result?

## 9.4 Publish flow
Publishing an assurance package is an authority-bearing workflow:
1. Validate provider asset and owner.
2. Review implementation assertions.
3. Review supported objectives/controls.
4. Define applicability conditions.
5. Define consumer responsibilities.
6. Validate evidence/result freshness.
7. Define evidence visibility.
8. Preview eligible consumers.
9. Approve/publish immutable version.
The final confirmation explicitly states that future consumers may rely on this package under its conditions.

# 10. Organization-First Assessment Entry

## 10.1 Entry points
An ad hoc assessment can begin from:
Organization page → New Assessment;
Organizational Unit → Assess this unit;
Asset → Assess asset;
Assessments → New Assessment.

## 10.2 Organization assessment setup
The wizard asks:
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Step
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Question
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Scope
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>What unit or asset are you assessing?
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Basis
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Which organization profile, control subset, requirement set, or targeted objective set applies?
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment intent
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Full assessment, targeted review, recurring review, evidence refresh, or remediation validation?
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Inheritance
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Which parent/shared assurance sources should be considered?
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Timing
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Due date / assessment window / milestone.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Authority
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Who leads, who reviews, and who may make determinations?
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Routing
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Use default ownership rules, template routing, or manual assignment?

## 10.3 Assessment preview before launch
Before launch, show:
objectives considered;
objectives already resolved by valid inheritance;
residual/local objectives;
objectives requiring attestation;
unresolved applicability;
estimated task count;
expected assignment packages;
missing owners;
source conflicts.
The user may resolve missing owners before launch or launch with explicit unresolved work.

# Part III - Product and Program Experience

# 11. Product and System Baseline Management

## 11.1 Products & Systems landing page
The landing page supports:
product families;
published baselines;
draft baselines;
system templates;
shared reusable systems;
baselines with impacted assurance;
baselines waiting for publication review.

## 11.2 Product family detail
Suggested tabs:
Overview | Baselines | Systems | Components | Assurance | Assessments | Consumers / Programs | Changes
The Overview shows the latest published baseline and clearly distinguishes latest from used by active programs.

## 11.3 Create baseline
Entry choices:
Start from previous baseline
Start from existing program/system
Import known architecture/inventory
Start blank
The baseline workspace uses a checklist across:
systems/boundaries;
major components;
reusable capabilities/services;
implementation assertions;
reusable assurance packages consumed;
evidence/results;
unresolved unknowns;
review/publish requirements.

## 11.4 Publication readiness
The UI should not show one “baseline completeness score.” Instead show dimensions:
Architecture definition
Component identification
Ownership completeness
Obligation allocation
Implementation mapping
Assurance/evidence availability
Unknowns requiring acknowledgement
Each dimension links to its unresolved items.

# 12. Program Creation Wizard

## 12.1 Design goal
Creating a program should result in an actionable starting assurance plan. The wizard is resumable and allows incomplete truth.

## 12.2 Wizard steps
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2589"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Step
<w:tcPr><w:tcW w:type="dxa" w:w="7131"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Primary interaction
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2589"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>1. Program basics
<w:tcPr><w:tcW w:type="dxa" w:w="7131"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Name, customer/mission, target milestone, Program SSE, program owner.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2589"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>2. Security context
<w:tcPr><w:tcW w:type="dxa" w:w="7131"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Required categorization/context fields and governing process.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2589"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>3. Control/profile sources
<w:tcPr><w:tcW w:type="dxa" w:w="7131"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Organization profile, overlays, CNSSI-derived selection result where applicable, other authoritative sources.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2589"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>4. Customer requirements
<w:tcPr><w:tcW w:type="dxa" w:w="7131"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Import or enter customer-specific requirements and parameter values.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2589"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>5. Systems
<w:tcPr><w:tcW w:type="dxa" w:w="7131"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Add baseline systems, variants, new systems, or placeholders.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2589"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>6. Shared organizational dependencies
<w:tcPr><w:tcW w:type="dxa" w:w="7131"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Confirm known organization-owned services/assets such as IAM, PKI, signing, vulnerability management.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2589"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>7. Ownership
<w:tcPr><w:tcW w:type="dxa" w:w="7131"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assign system owners, engineering leads, assessment authority, package-routing defaults.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2589"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>8. Review
<w:tcPr><w:tcW w:type="dxa" w:w="7131"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Show effective obligations, inheritance sources, unknowns, conflicts, and work expected at launch.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2589"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>9. Launch
<w:tcPr><w:tcW w:type="dxa" w:w="7131"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Pin sources/versions, create program graph, create work, and notify owners.

## 12.3 Customer requirements interaction
Customer requirements enter an intake grid with status:
Parsed / entered
Mapped to existing parameter
Strengthens existing requirement
New requirement
Conflict
Needs triage
Out of assurance scope
The user can open a side-by-side comparison showing organization default, product default, customer source, and proposed effective value.
No conflict is automatically resolved simply because one value appears “stricter.”

## 12.4 Launch summary
The final screen should show statements such as:
327 control obligations in the effective profile
4 systems added
2 systems based on published baselines
1 new incomplete system
1 external/shared organizational service
184 objectives currently reusable through inherited assurance
63 objectives require local work
21 applicability decisions remain
7 missing owners
2 source conflicts
Primary actions:
Launch program or Save draft.

# 13. System Onboarding Modes

## 13.1 Add System chooser
When adding a system, present three primary cards:

### Use existing baseline
Use when the delivered system is expected to match a published baseline.

### Create variant
Use when the system starts from a baseline but contains known or expected changes.

### Create new / incomplete system
Use when no reliable baseline exists or the system is still being designed.
A fourth advanced path supports legacy import.

## 13.2 Existing baseline confirmation
The user selects a baseline version and sees:
architecture summary;
major components;
consumed assurance packages;
known implementation assertions;
current reusable assessment results;
assumptions required for reuse.
The user must explicitly acknowledge whether the key assumptions appear valid. “Not reviewed yet” remains available.

## 13.3 Variant entry
Variant onboarding goes directly into Delta Review rather than making the user recreate architecture.

## 13.4 New system entry
New system onboarding creates a system placeholder with:
system name;
owner if known;
boundary state = Unknown or Draft;
architecture completeness = partial;
zero assumptions that missing means N/A.

# 14. New and Incomplete System Discovery

## 14.1 System workspace
Suggested tabs:
Overview | Architecture | Components | Capabilities | Dependencies | Requirements & Controls | Implementations | Evidence | Assessments | Changes | Activity

## 14.2 Overview layout
Top section:
System name / owner
Definition state
Boundary state
Critical unknowns
Assessment readiness
Active findings
Blocking decisions
Below that, show Unknowns requiring resolution before compliance-style summaries.

## 14.3 Architecture editor
The system should support a lightweight structured architecture editor, not a full CAD/digital-twin system.
Users can add:
subsystem;
hardware component;
firmware/software component;
external service;
data/interface relationship;
trust boundary marker;
organization-owned shared service;
unknown placeholder.
Each element may link to a canonical Asset Catalog entry or remain system-local/candidate.

## 14.4 Unknown placeholder interaction
An unknown placeholder includes:
what is unknown;
why it matters;
owner or unassigned state;
target decision date;
affected obligations/assessment objectives if known;
button: Assign discovery.
Example:
Processor / SoC - Unknown Production SoC has not been selected. This blocks 8 implementation mappings and 3 assessment objectives. Owner: Hardware Engineering Needed by: Sep 14

## 14.5 Inline discovery task creation
Selecting Assign discovery opens a compact work dialog:
request;
default owner based on technical ownership;
due date;
context;
affected items;
optional package grouping.
The result becomes general assurance work or an assessment discovery task depending on current context.

# 15. Effective Obligations, Tailoring, and Customer Requirements

## 15.1 Requirements & Controls workspace
This workspace defaults to effective obligations, with filters for provenance:
Organization baseline
Product overlay
Customer requirement
Program-specific
Tailored/modified
Conflict
Not Applicable decision
The raw source catalog remains accessible but is not the default program view.

## 15.2 Obligation row
Each row shows:
obligation name / plain-language summary;
source stack;
effective parameter/value where relevant;
allocation to system(s)/assets;
implementation state;
assurance state;
conflict/unknown badge;
“Why?” action.

## 15.3 Parameter comparison panel
When multiple parameter values exist, show a comparison:
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="2498"/><w:gridCol w:w="2498"/><w:gridCol w:w="2498"/><w:gridCol w:w="2498"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2980"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Source
<w:tcPr><w:tcW w:type="dxa" w:w="1774"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Value
<w:tcPr><w:tcW w:type="dxa" w:w="1774"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Scope
<w:tcPr><w:tcW w:type="dxa" w:w="3193"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Authority / state
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2980"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Organization baseline
<w:tcPr><w:tcW w:type="dxa" w:w="1774"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>15
<w:tcPr><w:tcW w:type="dxa" w:w="1774"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Organization
<w:tcPr><w:tcW w:type="dxa" w:w="3193"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Published default
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2980"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Product baseline
<w:tcPr><w:tcW w:type="dxa" w:w="1774"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>No change
<w:tcPr><w:tcW w:type="dxa" w:w="1774"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Product
<w:tcPr><w:tcW w:type="dxa" w:w="3193"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Inherited
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2980"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Customer CR-118
<w:tcPr><w:tcW w:type="dxa" w:w="1774"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>24
<w:tcPr><w:tcW w:type="dxa" w:w="1774"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Nightwing
<w:tcPr><w:tcW w:type="dxa" w:w="3193"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Customer source
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2980"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Effective program decision
<w:tcPr><w:tcW w:type="dxa" w:w="1774"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>24
<w:tcPr><w:tcW w:type="dxa" w:w="1774"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Nightwing
<w:tcPr><w:tcW w:type="dxa" w:w="3193"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Approved by configured authority
If the system cannot mechanically resolve the sources, the panel displays Conflict - decision required.

## 15.4 Tailoring decision modal
High-authority decisions require:
selected decision;
rationale;
source references;
scope;
effective date;
approver/authority;
affected systems;
optional expiration/review date.

# 16. Inheritance Review and Reusable Assurance Consumption

## 16.1 Inheritance Review purpose
Inheritance Review is a first-class UX surface. It answers:
What do we think we can reuse, why, what remains local, and what should not be trusted yet?

## 16.2 Review categories
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2547"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Category
<w:tcPr><w:tcW w:type="dxa" w:w="7173"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Meaning
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2547"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Applicable - current
<w:tcPr><w:tcW w:type="dxa" w:w="7173"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Source assurance is valid and can resolve the covered objective(s).
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2547"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Applicable - attestation required
<w:tcPr><w:tcW w:type="dxa" w:w="7173"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Reuse is allowed only after local confirmation.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2547"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Applicable - residual work remains
<w:tcPr><w:tcW w:type="dxa" w:w="7173"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Provider covers part; consumer still has explicit responsibilities.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2547"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Unknown
<w:tcPr><w:tcW w:type="dxa" w:w="7173"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Required facts are missing.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2547"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Conflict
<w:tcPr><w:tcW w:type="dxa" w:w="7173"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Facts/sources disagree.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2547"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Review required
<w:tcPr><w:tcW w:type="dxa" w:w="7173"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Applicability may hold but a policy/authority review is required.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2547"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Impacted
<w:tcPr><w:tcW w:type="dxa" w:w="7173"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Previously valid reuse may no longer hold because a relevant change occurred.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2547"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Not applicable
<w:tcPr><w:tcW w:type="dxa" w:w="7173"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Authorized determination says the package/result does not apply.

## 16.3 Assurance package consumption card
A card for Enterprise IAM Assurance Package v4.2 might show:
Provider: Enterprise IAM
Owner: Enterprise Security / IAM
Provides: 38 assessment objectives
Local residual: 7 objectives
Attestation: 2 items
Last assessed: date
Evidence: restricted; result reusable
Applicability checks: 6 passed, 1 unknown
Consumers: 14 products/programs
Actions:
Review applicability | Accept consumption | Resolve unknown | View provider assurance

## 16.4 Residual responsibility panel
The user must be able to see precisely what is not inherited.
Example:
Enterprise IAM provides authentication, credential lifecycle, and enterprise account disablement. Nightwing remains responsible for local role assignment, privileged-role approval, and removal of program-specific entitlements.
Residual tasks are generated only for those responsibilities.

## 16.5 Restricted provider evidence
If provider evidence is restricted, the consumer sees:
authorized result;
provider/assessor identity where permitted;
assessment date;
objective coverage;
assurance package version;
evidence access = Restricted;
access request action if policy allows.
The absence of evidence visibility must not be presented as missing evidence when a reusable authorized result is valid.

# 17. Variant Delta and Impact Review

## 17.1 Delta workspace
The Delta workspace compares a pinned baseline with the program system.
Filters:
Changed
Added
Removed
Unknown
Not reviewed
Confirmed unchanged

## 17.2 Delta row
Example:
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="1999"/><w:gridCol w:w="1999"/><w:gridCol w:w="1999"/><w:gridCol w:w="1999"/><w:gridCol w:w="1999"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1591"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Element
<w:tcPr><w:tcW w:type="dxa" w:w="1515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Baseline
<w:tcPr><w:tcW w:type="dxa" w:w="1515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Program
<w:tcPr><w:tcW w:type="dxa" w:w="1515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>State
<w:tcPr><w:tcW w:type="dxa" w:w="3585"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Assurance impact
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1591"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Bootloader
<w:tcPr><w:tcW w:type="dxa" w:w="1515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>4.2
<w:tcPr><w:tcW w:type="dxa" w:w="1515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>4.4
<w:tcPr><w:tcW w:type="dxa" w:w="1515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Changed
<w:tcPr><w:tcW w:type="dxa" w:w="3585"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>6 objectives need review
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1591"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>TPM
<w:tcPr><w:tcW w:type="dxa" w:w="1515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Model Y
<w:tcPr><w:tcW w:type="dxa" w:w="1515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Model Y
<w:tcPr><w:tcW w:type="dxa" w:w="1515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Confirmed unchanged
<w:tcPr><w:tcW w:type="dxa" w:w="3585"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>No known impact
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1591"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>FPGA
<w:tcPr><w:tcW w:type="dxa" w:w="1515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Standard
<w:tcPr><w:tcW w:type="dxa" w:w="1515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Customer FPGA 2.3
<w:tcPr><w:tcW w:type="dxa" w:w="1515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Changed
<w:tcPr><w:tcW w:type="dxa" w:w="3585"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>3 Secure Boot objectives impacted
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1591"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Network module
<w:tcPr><w:tcW w:type="dxa" w:w="1515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>None
<w:tcPr><w:tcW w:type="dxa" w:w="1515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Customer module
<w:tcPr><w:tcW w:type="dxa" w:w="1515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Added
<w:tcPr><w:tcW w:type="dxa" w:w="3585"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>New applicability review
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1591"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Production signing config
<w:tcPr><w:tcW w:type="dxa" w:w="1515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Enabled
<w:tcPr><w:tcW w:type="dxa" w:w="1515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Unknown
<w:tcPr><w:tcW w:type="dxa" w:w="1515"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Unknown
<w:tcPr><w:tcW w:type="dxa" w:w="3585"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Attestation / evidence blocked

## 17.3 Report a change
Changes can originate from:
user edit;
source-system synchronization;
program requirement change;
baseline adoption;
assessment observation.
The UX records source and does not instantly interpret a change as failure.

## 17.4 Impact review
After a change, show:
implementation assertions impacted;
evidence potentially invalidated;
inherited assessment results affected;
new obligations or applicability decisions;
impacted RAP consumptions;
generated review/reassessment work;
affected milestones.
Users may accept No known impact only when authorized and supported by the domain rules.

# Part IV - Assessment Execution

# 18. Assessment Planning and Objective Resolution

## 18.1 Assessment landing page
The Assessments landing page supports filters by:
scope;
type;
owner;
active/completed;
organization vs program;
framework/profile;
due date;
inherited reuse level;
findings generated.

## 18.2 Assessment create flow
Common steps:
1. Choose subject/scope.
2. Choose basis/profile/objectives.
3. Choose intent and assessment window.
4. Resolve inherited assurance.
5. Review applicability unknowns/conflicts.
6. Generate practical tasks from templates.
7. Group tasks into packages.
8. Assign package owners/reviewers.
9. Launch.

## 18.3 Objective Resolution screen
This is a reviewer/planner view, not a contributor view.
Columns:
objective;
source control/requirement;
subject;
resolution;
source assurance package/result;
residual responsibility;
task plan;
reviewer;
status.
The planner can filter to Unresolved only.

## 18.4 Task generation preview
Before generating tasks, show:
raw objective count;
objectives resolved by inheritance;
objectives requiring only attestation;
objectives requiring residual/local work;
objectives blocked by unknown/conflict;
tasks generated after reusable templates/dependency rules;
expected package count.
This makes the benefit of inheritance visible without turning it into a security score.

# 19. Assignment Packages, Routing, and Delegation

## 19.1 Package model in UX
A package is a coherent bundle of assessment tasks assigned to one accountable owner/team. It is the unit of coordination; tasks remain individually delegable.

## 19.2 Package list
Each package shows:
package title;
subject/system;
accountable owner;
task count;
delegated count;
answered count;
returned for clarification;
due date;
reviewer;
overdue/blocking state.

## 19.3 Automatic routing preview
Before launch, the system suggests package groupings based on:
asset owner;
organizational unit;
system/component owner;
assessment template routing;
configured defaults.
The assessment lead can edit the suggestions.

## 19.4 Package Owner view
The Package Owner sees:
package purpose;
due date;
progress by task state;
list of tasks;
current delegates;
bulk actions.
Allowed bulk actions:
assign/delegate;
change due date within authority;
request reassignment;
add package note;
filter by unanswered / missing evidence / returned.
Bulk Satisfied is not allowed.

## 19.5 Delegation interaction
Selecting one or more tasks and choosing Delegate opens:
people/team search;
suggested assignees based on asset/component ownership;
due date;
optional message;
whether delegate may re-delegate;
preview of sensitive context shared.
The package owner remains accountable unless the package itself is reassigned.

# 20. Contributor Task Experience

## 20.1 Contributor design goal
A contributor should be able to respond correctly without understanding the control framework or navigating the full platform.

## 20.2 Task page anatomy
Top:
Plain-language request
Example:
Describe how privileged account requests are approved for the Tactical Management Controller. Link the procedure or workflow used to approve them.
Then show:
Assigned to
Requested by
Due date
Program/system or organization context
Expected response type
Why this matters
Primary response area supports text, structured answer, evidence link/upload reference, test result, or interview notes depending on task type.

## 20.3 Contributor actions
Submit response
Save draft
Attach/link evidence
Delegate if allowed
Ask clarification
Flag wrong owner
Flag not applicable / request applicability review
Report conflicting source information
Create/link missing asset

## 20.4 “I don’t know” is valid
The UI must provide an explicit path for:
Unknown
Need another owner
Decision not yet made
Source conflict
Planned but not implemented
These answers create review/discovery work. They are preferable to forced Yes/No answers.

## 20.5 Prior answer reuse
When a similar current answer exists, show:
A previous response may help Enterprise IAM answered a related task on June 12.
The contributor can reference it or say it does not apply. The previous answer does not silently prefill an authoritative determination.

## 20.6 Submit confirmation
On submission, explain:
Your response has been submitted as assessment input. The assigned reviewer will determine whether additional information is needed and whether the assessment objective is satisfied.
This reinforces Response != Determination.

# 21. Reviewer / SSE Assessment Experience

## 21.1 Reviewer Queue
The reviewer queue is optimized for decision throughput and evidence sufficiency.
Filters:
Ready for review
Returned once or more
Inherited result requiring attestation
Conflicts
Insufficient information
High deadline impact
By control/objective/system/package

## 21.2 Review workspace layout
Recommended three-panel desktop layout:
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Panel
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Content
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Left
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Objective/task queue with state and urgency.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Center
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Current objective, task responses, observations, evidence, prior result, inherited source.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Right
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Context/provenance, applicability, implementation assertion, source requirement/control, history.

## 21.3 Reviewer actions
Request clarification
Accept input / observation
Record Satisfied determination
Record Other Than Satisfied determination
Record Not Applicable decision when authorized
Mark Insufficient Information
Create finding
Link existing finding
Trigger targeted follow-up task
Escalate conflict/applicability decision

## 21.4 Determination confirmation
An authoritative determination dialog requires:
outcome;
rationale;
scope/subject;
supporting observations/evidence;
snapshot reference;
reviewer identity;
effective date;
finding decision when Other Than Satisfied.
High-authority decisions should not be a one-click icon.

## 21.5 Comparison with inherited result
When reviewing an objective with prior/inherited assurance, show:
previous determination;
source package/result;
assessment date;
current facts;
changed facts;
reason reassessment was triggered.

# 22. Findings, Remediation, Risk, and POA&M Workflow

## 22.1 Finding creation
A finding can be created directly from an assessment determination or later from cross-object analysis.
Prepopulate:
source assessment/objective;
affected subject;
control/requirement links;
evidence/observation references;
current owner suggestion.
User adds:
concise finding statement;
impact/priority fields required by organization policy;
owner;
target date;
disposition path.

## 22.2 Finding detail page
Suggested tabs:
Overview | Source & Evidence | Affected Scope | Remediation | Risk / POA&M | Reassessment | Activity

## 22.3 Group into remediation initiative
From Findings, users can select multiple related findings and choose Create remediation initiative.
The dialog shows potential shared root cause and affected scopes but does not automatically merge findings.
The initiative captures:
title/root cause;
owner;
linked findings;
milestones;
dependencies;
target completion;
programs/systems impacted.

## 22.4 Risk relationship
The UI distinguishes:
Finding = observed gap/problem
Risk = uncertainty/exposure requiring treatment decision
Remediation Initiative = coordinated work
POA&M Item = formal system/program tracking artifact where required
Buttons use these nouns explicitly.

## 22.5 Create POA&M item
When applicable, the system prepopulates a POA&M creation flow from finding/risk data. The user reviews:
system/program;
weakness/source;
owner;
remediation plan;
milestones;
target dates;
deviations/acceptance authority;
closure criteria.

# 23. Reassessment and Closure

## 23.1 Closure is a validation flow
Closing remediation does not immediately turn assurance green. The UX should distinguish:
Work complete → Ready for validation → Reassessed / verified → Finding closed.

## 23.2 Targeted reassessment
The system proposes objectives impacted by the remediation and allows the assessor to create a targeted reassessment plan.
Show:
original finding;
changed implementation/configuration;
required evidence/test;
affected objectives;
previous determination;
closure authority.

## 23.3 Restore reusable assurance
After successful reassessment, the reviewer may:
close the finding locally;
update a product/system baseline candidate;
update/publish a reusable assurance package version;
submit improved evidence/template for promotion.
Historical assessments remain unchanged.

# Part V - Cross-Scope Learning, Trust, and Operations

# 24. Promotion, Deduplication, and Upward Propagation

## 24.1 Promotion entry points
Local/candidate objects show Submit for broader reuse when eligible.
Eligible object types include:
assets/components;
policies/procedures;
requirements;
implementation assertions;
evidence patterns;
assessment templates;
reusable assessment results/assurance packages;
product/system baseline candidates.

## 24.2 Promotion wizard
1. Choose proposed destination scope.
2. Show likely canonical matches.
3. Choose link/merge/new version/new canonical object.
4. Review applicability broadening.
5. Select destination owner.
6. Review sensitive data/markings.
7. Submit to approval.

## 24.3 Promotion Queue
Governance/library owners see:
source local object;
proposed destination;
submitter;
candidate duplicates;
current consumers;
applicability change;
sensitive-data impact;
origin assessment/program.

## 24.4 Promote from product assessment
A Program SSE who discovers a policy that applies across Product Division A should be able to submit it directly to that organizational unit without copying the text into a new object. Origin lineage is preserved.

# 25. Conflict, Source Reconciliation, and Authority Decisions

## 25.1 Conflict presentation
Conflicts should interrupt the relevant workflow without making the entire platform unusable.
A conflict card shows:
field/assertion in dispute;
source A;
source B;
current effective state = unresolved;
affected inheritance/assessment work;
decision owner/authority;
due date if blocking.

## 25.2 Example source conflict
PLM says TPM Model Y. Program engineer reports TPM Model Z. Current system component identity: Conflict - unresolved.
The UI offers:
Verify source
Request evidence
Assign decision
Resolve with authority
Accept bounded ambiguity (authority-only; records scope and expiry)
It does not silently prefer the newer entry or the manual entry.

## 25.3 Conflict resolution view
Resolution requires:
selected authoritative outcome;
rationale;
source(s) retained;
resolver authority;
effective time;
follow-up action to source systems if required.
If the conflict affected inheritance, resolving it automatically triggers the inheritance/impact resolver and surfaces changed downstream work.

# 26. Evidence Experience and Restricted Visibility

## 26.1 Evidence list
Evidence lists show:
title/type;
source;
owner;
supported assertion/objective;
subject/system;
freshness state;
visibility/marking;
validation state;
last used/assessed date.

## 26.2 Evidence detail
Suggested regions:
metadata/provenance;
source link/file reference;
supports relationships;
applicability conditions;
assessment uses;
freshness/revocation;
access restrictions;
history.

## 26.3 Evidence access denied
When a user can rely on a result but not inspect evidence, show:
Evidence restricted You are authorized to view the reusable assessment result, but not the underlying evidence. The result was issued by [authorized provider/assessor] for [package/version] on [date].
Actions may include Request access or Contact owner if policy allows.

## 26.4 Revoked or stale evidence
Stale/revoked evidence should show its consumers and impacted assertions/results before the user confirms revocation where authority requires it.

# 27. Notifications, Deadlines, and Escalation

## 27.1 Notification philosophy
Notifications should be event- and responsibility-driven, not every-change spam.
High-value notifications:
new assignment/delegation;
task returned for clarification;
reviewer action required;
source conflict assigned;
inherited assurance impacted;
evidence expiring where the user owns the evidence;
remediation milestone approaching;
program critical-path item at risk;
promotion review assigned;
upstream reusable assurance package changed.

## 27.2 Digest vs immediate
Immediate:
direct assignment;
blocking conflict;
access/authority decision;
critical deadline impact;
reassessment triggered by material change.
Digest:
routine completed responses;
non-blocking evidence freshness;
general activity in watched scopes.

## 27.3 Escalation
Escalation rules may be configured by scope and workflow. The UX always shows:
current owner;
escalation path;
next escalation date;
affected milestone.

# 28. Dashboards, Rollups, and Readiness

## 28.1 Dashboard rule
Dashboards show factual operational state. They do not create a proprietary maturity score or a single “coverage” percentage that implies security quality.

## 28.2 Program Overview
Recommended cards:
Systems: defined / incomplete / unknown
Assessment objectives: inherited / awaiting response / ready for review / satisfied / other than satisfied / insufficient information / reassessment required
Findings: open / critical-path / remediation active
POA&M: open / due soon / overdue
Evidence: current / expiring / invalidated
Unknowns and source conflicts
Critical-path assurance work
Next milestone

## 28.3 Organizational Unit Overview
Recommended cards:
Owned assets
Reusable assurance packages
Active assessments
Assessment tasks awaiting unit response
Open findings
Shared remediation initiatives
Downstream products/programs consuming unit assurance
Promotion candidates
Evidence freshness

## 28.4 Readiness statement
If the product uses a derived readiness indicator, it must be explainable and operational, such as:
Not ready for assessment completion because 14 objectives lack sufficient information, 3 source conflicts block applicability, and 2 critical findings remain unresolved.
No opaque numeric score is required.

# 29. Search, Graph Navigation, and Explainability

## 29.1 Search result grouping
Search groups results by type:
Organization units
Assets
Products/systems
Programs
Controls/requirements/objectives
Assessments
Evidence
Findings
Assurance packages
Work

## 29.2 Relationship navigation
Every major entity detail should expose relevant relationships as clickable chips or lists, for example:
Enterprise IAM → provides RAP v4.2 → consumed by Falcon → instantiated by Nightwing → inherited by Nightwing assessment.

## 29.3 Explainability view
For any derived state, the explainability view should provide a human-readable chain:
Nightwing inherited objective IA-X.a from Enterprise IAM RAP v4.2 because Nightwing consumes Enterprise IAM production configuration X, all required applicability facts matched the RAP predicate, the provider assessment result is current, and no material change has invalidated it. Nightwing still owns role-assignment responsibility, so one residual task remains.
Advanced users may expand source IDs and rules.

# 30. Import, Export, Workbook, and OSCAL-Aligned Interactions

## 30.1 User principle
OSCAL should appear as an interoperability/export option, not as required vocabulary in everyday screens.

## 30.2 Import center
The Import Center supports staged import with preview and validation:
control catalogs/profiles;
customer requirements;
product/system inventory;
legacy workbooks;
evidence metadata;
supported OSCAL artifacts.
Import never silently converts blank values to N/A/Satisfied.

## 30.3 Legacy workbook import
The workflow should:
1. Upload/select workbook.
2. Map columns/sections.
3. Preview recognized controls/requirements/assets/statuses.
4. Mark ambiguous values.
5. Choose destination scope.
6. Create program/local objects.
7. Generate triage tasks for unresolved rows.

## 30.4 Program workbook / SCTM export
The program workbook/report - the Security Controls Traceability Matrix (SCTM) and related views - is generated from the live graph. Export settings choose:
scope;
point-in-time snapshot;
control/requirement columns;
implementation statements;
evidence references;
assessment status;
findings/POA&M content;
sensitive-data handling.
The export includes generation timestamp and source snapshot/version information.

## 30.5 OSCAL interaction alignment
Supported system-centric workflows may expose actions such as:
Import Profile
Export Profile
Export Component Definition
Export SSP-compatible implementation package
Export Assessment Plan
Export Assessment Results
Export POA&M
The UI should explain validation errors in product language and optionally expose OSCAL paths/identifiers to advanced users.

# Part VI - Screen Contracts and Delivery

# 31. Screen and Page Anatomy Catalog

## 31.1 Core screen catalog
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="2498"/><w:gridCol w:w="2498"/><w:gridCol w:w="2498"/><w:gridCol w:w="2498"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Screen
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Primary user
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Primary job
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Key actions
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Home / My Work
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Everyone
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Resolve assigned work
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Open, delegate, respond, review
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Organization tree
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Org assurance
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Model responsibility scopes
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Add unit, assign owner, assess
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Organization unit detail
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Org assurance
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Manage unit assurance
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Add asset, assess, publish reusable work
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Asset Catalog
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>All power users
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Find assurance-relevant assets
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Search, filter, create candidate
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Asset detail
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Asset owner
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Maintain canonical asset assurance
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Update, assess, publish RAP
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Library
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Governance
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Find reusable knowledge
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Import, author, review, publish
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>RAP detail
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Provider/consumer
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Understand reusable assurance
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Publish, consume, inspect responsibilities
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Product family
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Product security
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Manage reusable product truth
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Create baseline, compare versions
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Baseline workspace
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Product/system
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Define reusable system/product
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Model, map, review, publish
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Program list
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Program security
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Navigate program portfolio
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Create program, filter risk
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Program Overview
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>SSE/leadership
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Understand readiness
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Open blockers, assessments, findings
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Program Setup
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>SSE
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Manage effective context
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Tailor, add requirements, assign roles
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>System workspace
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>SSE/engineering
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Model system and unknowns
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Add component, assign discovery
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Delta Review
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>SSE/engineering
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Confirm baseline difference
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Mark changed/unknown, impact review
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Requirements & Controls
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>SSE
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Understand obligations
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Filter, allocate, resolve conflict
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Inheritance Review
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>SSE/assessor
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Decide reusable assurance
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Consume RAP, resolve residuals
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment planner
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessor/SSE
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Define plan
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Resolve inheritance, package tasks
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment package
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Package owner
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Coordinate team input
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Delegate, track, return
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Contributor task
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Engineer/SME
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Provide information/evidence
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Respond, attach, delegate, flag
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Reviewer Queue
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessor/SSE
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Make determinations
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Clarify, determine, find
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Finding detail
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Security/remediation
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Resolve a gap
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assign, group, remediate, reassess
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Remediation initiative
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Remediation owner
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Coordinate shared fix
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Milestones, link findings
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Risk / POA&M
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Risk/SSE
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Manage formal risk/remediation
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Treat, approve, close
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Promotion Queue
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Steward
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Govern upward reuse
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Deduplicate, approve, publish
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Conflict detail
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Authority owner
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Resolve competing truth
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Compare sources, decide, propagate
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Import Center
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Admin/power user
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Bring structured data in safely
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Map, validate, triage
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1752"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Export Center
<w:tcPr><w:tcW w:type="dxa" w:w="1439"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>SSE/assessor
<w:tcPr><w:tcW w:type="dxa" w:w="2855"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Produce external artifact
<w:tcPr><w:tcW w:type="dxa" w:w="3674"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Select snapshot, format, validate

## 31.2 Standard page anatomy
For complex workspaces, use:
1. Global navigation
2. Scope breadcrumb/header
3. Object identity + state
4. Local tab navigation
5. Primary work/content region
6. Right-side context/provenance drawer when needed
7. Sticky primary action for the current workflow
8. Activity/audit access

## 31.3 Page density
Power-user screens may be dense, but density should come from structured tables and panels rather than tiny text. Contributor screens should be materially simpler than SSE/assessor screens.

# 32. Empty, Loading, Error, and Partial-Truth States

## 32.1 Empty states must teach the model
Examples:

### No organization assets yet
No assets are cataloged for this unit yet. You can add known assets now or start an assessment and create assets as they are discovered.
Actions: Add asset | Start assessment

### New system has no architecture
This system has not been defined yet. Unknown architecture is allowed. Add major components now or assign discovery work to engineering.
Actions: Add component | Assign discovery

### No assessment template
The selected objective has no organization-authored assessment template. Use the canonical assessment objective as guidance and create tasks for this assessment. You can later submit the improved task set for reuse.

## 32.2 Loading and calculation states
Inheritance and impact calculations may take time at scale. Use explicit states:
Resolving applicable assurance...
Evaluating 42 reusable packages...
Calculating impact across 18 dependent systems...
If asynchronous, the user can leave the page and receives completion status. Never show the old result as if it were current without an “Updating” indicator.

## 32.3 Error states
Errors distinguish:
authorization/access;
invalid source data;
import validation;
rules conflict;
synchronization unavailable;
calculation failure.
The interface must not collapse a failed calculation into Unknown applicability without saying the calculation failed.

# 33. Permissions, Markings, and Sensitive-Data UX

## 33.1 Permission-aware actions
Users may see a state they cannot modify. The UI should show why an action is unavailable:
You can view this determination but only an authorized assessor can change it.

## 33.2 Markings
Sensitive objects should show markings consistently in headers, lists, previews, exports, and share dialogs. Copy/paste or export actions may be restricted based on markings.

## 33.3 Metadata-only visibility
When policy permits metadata inheritance without content access, distinguish:
Result visible
Evidence restricted
Implementation detail restricted
Do not display a generic broken-lock icon that leaves users guessing.

## 33.4 Delegation preview
Before delegating a sensitive task, preview the context and attachments the delegate will receive. If the selected delegate lacks access, the UI blocks the delegation or offers a sanitized task variant when policy supports it.

# 34. Accessibility and Interaction Quality

## 34.1 Accessibility requirements
The experience should support:
keyboard navigation for work queues and tables;
visible focus states;
semantic headings and labels;
no status communicated by color alone;
accessible table sorting/filtering;
screen-reader-friendly badges;
form errors associated with fields;
sufficient target sizes;
reduced motion compatibility;
text equivalents for graph relationships.

## 34.2 Table usability
Large tables should support:
sticky header;
column chooser;
saved filters;
density preference;
bulk selection;
keyboard row navigation;
accessible export;
deep-link to row/object.

## 34.3 Confirmation design
Use confirmation only when actions are irreversible, authoritative, or broad in blast radius. Routine saves and task responses should not generate modal fatigue.

# 35. MVP Interaction Scope and Delivery Sequence

## 35.1 MVP UX hypothesis
Stage 1 (R0-R2): if a program team can assemble its catalog, resolve its effective controls, and generate its SCTM from the live graph, the foundation experience is proven. Stage 2 (R3-R4): if an organizational unit can run a real delegated assessment, publish reusable assurance, and a Program SSE inherits that work generating only residual tasks - with clear contributor/reviewer separation - the compounding experience is proven.

## 35.2 R0-R2 must-have screens (Catalog, Controls, SCTM)
1. Home / My Work
2. Organization tree + unit detail
3. Asset Catalog + basic asset detail
4. Library: standards, profiles, objectives
5. Program creation wizard (basic)
6. Add System chooser + system workspace with Unknown placeholders
7. Requirements & Controls: effective obligations + parameter comparison
8. Customer requirements intake + tailoring decision modal
9. Conflict detail (parameter/source conflicts)
10. Import Center: catalogs, controls, legacy workbooks
11. Product family + baseline workspace (basic)
12. Export / Workbook Center: SCTM generation
13. Why/provenance drawer
14. Local/candidate asset creation inline

## 35.3 R3 screens (Assessment engine)
New Assessment wizard
Objective Resolution
Assignment Package view + delegation
Contributor Task (question, evidence request, test)
Reviewer Queue + determination dialog
Finding creation/detail
Evidence detail + freshness
Program Overview / critical path
Assessment results / export

## 35.4 R4 screens (Inheritance + remediation)
Remediation initiatives
Risk treatment
POA&M
Targeted reassessment/closure
Cross-scope findings
Inheritance Review
RAP detail/consumption workflow
Delta Review + Change Impact Review
Promotion Queue (basic)

## 35.5 R5 screens (Learning + interoperability)
Advanced blast radius
recurring/continuous assessment administration
source-system reconciliation center
advanced promotion/deduplication
OSCAL artifact center
machine-generated evidence integrations
assisted routing/mapping recommendations

# 36. End-to-End Acceptance Walkthroughs

## 36.1 Organization-first IAM assessment
1. Organization admin creates ACME and Enterprise Security / IAM.
2. IAM owner creates Enterprise IAM asset.
3. IAM owner selects Assess this asset.
4. Assessment wizard uses organization NIST profile and imported assessment objectives.
5. Objective Resolution suppresses parent-level inherited items and generates remaining work.
6. System groups 31 tasks into an Identity package.
7. Package owner delegates provisioning questions to Engineer A, access-review evidence to Engineer B, and a test to Security Test.
8. Engineer A answers without seeing raw control syntax by default.
9. Reviewer receives submitted inputs in Reviewer Queue.
10. Reviewer records determinations; one objective is Other Than Satisfied and creates a finding.
11. Satisfied results and supporting implementation assertions are assembled into Enterprise IAM RAP v1 draft.
12. Authorized owner publishes RAP v1 with residual consumer responsibilities.
13. Evidence is restricted but reusable result metadata is visible to eligible consumers.
Pass condition: a downstream product can consume the published result without repeating the provider questions.

## 36.2 Nightwing program inherits Enterprise IAM
1. Program SSE creates Nightwing.
2. Setup selects organizational profile/security context and adds customer requirements.
3. SSE adds Falcon v6 variant plus new Tactical Management Controller.
4. Nightwing declares Enterprise IAM as shared dependency.
5. Inheritance Review evaluates Enterprise IAM RAP v1 (the first publication; mature-state examples elsewhere in the suite show v4.2).
6. 38 objectives are current/applicable; 7 residual local responsibilities remain; 2 require attestation.
7. Only residual/attestation tasks are generated.
8. Why drawer explains source, version, applicability, and consumer responsibilities.
Pass condition: valid organization work eliminates redundant questioning without hiding local responsibility.

## 36.3 Customer password override
1. Organization default is 15 characters.
2. Customer requirement CR-118 says 24 characters.
3. Requirements workspace shows both sources.
4. System proposes mapping to parameter but does not silently overwrite the organization default.
5. Program authority approves effective 24-character value with rationale.
6. Affected tasks/objectives update.
7. Source provenance remains visible.
Pass condition: the program can explain exactly why 24 applies without mutating source standards or organization policy.

## 36.4 New incomplete system
1. SSE creates Tactical Management Controller with no baseline.
2. System Overview shows incomplete architecture and Unknown states.
3. SSE creates unknown placeholders for SoC, bootloader version, and signing configuration.
4. Discovery tasks route to hardware/firmware owners.
5. Hardware engineer identifies a new SoC not in Asset Catalog and creates a program-local candidate inline.
6. The program continues immediately.
7. Candidate SoC can later be submitted to the organization catalog.
Pass condition: incomplete architecture creates work, not false N/A or false satisfaction.

## 36.5 Variant change invalidates inherited assurance
1. Falcon v6 baseline uses TPM Y and customer program initially confirms it.
2. Source sync later reports TPM Z.
3. Program engineer disputes the change.
4. System creates Source Conflict and marks related inherited assurance Review Required rather than Failed.
5. Authority resolves TPM Z as correct.
6. Impact engine identifies Secure Boot dependency.
7. Three assessment objectives become Reassessment Required; unaffected objectives remain inherited.
Pass condition: change blast radius is targeted and historical truth is preserved.

## 36.6 Findings grouped into remediation
1. Assessment creates four related access-governance findings across two systems.
2. Security lead selects the findings and creates Enterprise Access Governance remediation initiative.
3. Program-specific formal requirements create linked POA&M items where required.
4. Engineering completes remediation milestones.
5. Findings move to Ready for Validation, not Closed.
6. Assessor launches targeted reassessment.
7. Successful determinations close the findings and update reusable assurance where applicable.
Pass condition: remediation can be shared while finding/system traceability remains intact.

## 36.7 Product assessment promotes policy upward
1. Falcon assessment discovers a firmware-signing procedure used across Product Division A.
2. Procedure begins as Falcon-local candidate.
3. SSE chooses Submit for broader reuse.
4. Promotion wizard suggests Product Division A and checks for duplicates.
5. Division assurance owner reviews scope and markings.
6. Procedure is approved/published at division scope.
7. Existing Falcon history still references the original local version/lineage.
8. Future assessments inherit the new canonical policy.
Pass condition: local work compounds into higher-scope organizational truth without rewriting history.

# Appendix A. Route and Screen Inventory
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Route concept
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Example
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Home
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/home
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Organization
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/organization
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Organization unit
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/organization/{unit-id}
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Asset Catalog
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/assets
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Asset detail
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/assets/{asset-id}
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Products
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/products
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Product family
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/products/{product-id}
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Product baseline
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/products/{product-id}/baselines/{version-id}
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Programs
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/programs
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Program
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/programs/{program-id}
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Program system
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/programs/{program-id}/systems/{system-id}
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessments
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/assessments
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/assessments/{assessment-id}
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assignment package
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/assessments/{assessment-id}/packages/{package-id}
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Task
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/work/{task-id}
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Findings
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/findings
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Finding
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/findings/{finding-id}
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Risks & POA&M
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/risks
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Library
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/library
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>RAP detail
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/library/assurance/{rap-id}
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Promotion Queue
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/library/promotions
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="3571"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Conflict
<w:tcPr><w:tcW w:type="dxa" w:w="6149"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos Mono" w:hAnsi="Aptos Mono"/><w:sz w:val="15"/></w:rPr><w:t>/conflicts/{conflict-id}
Routes are conceptual and do not constrain frontend framework implementation.

# Appendix B. Standard Action Vocabulary
Use consistent verbs:
Create
Add
Link
Assign
Delegate
Reassign
Submit
Request clarification
Accept as input
Record determination
Create finding
Create remediation initiative
Create POA&M item
Request applicability review
Resolve conflict
Report change
Reassess
Submit for broader reuse
Promote
Publish
Supersede
Retire
Export
Avoid ambiguous buttons such as Approve when the user is actually publishing, making a determination, accepting risk, or resolving a conflict. Name the authority-bearing action.

# Appendix C. Status and Badge Vocabulary
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1921"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Domain
<w:tcPr><w:tcW w:type="dxa" w:w="7799"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Preferred labels
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1921"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment objective
<w:tcPr><w:tcW w:type="dxa" w:w="7799"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Planned; Inherited - Current; Awaiting Response; Ready for Review; Insufficient Information; Satisfied; Other Than Satisfied; Not Applicable; Reassessment Required
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1921"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment task
<w:tcPr><w:tcW w:type="dxa" w:w="7799"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>New; Packaged; Assigned; Delegated; In Progress; Submitted; Clarification Requested; Accepted as Input; Closed
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1921"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assurance package
<w:tcPr><w:tcW w:type="dxa" w:w="7799"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Draft; Under Review; Published; Superseded; Retired; Impacted
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1921"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>RAP consumption
<w:tcPr><w:tcW w:type="dxa" w:w="7799"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Candidate; Applicable; Attestation Required; Active; Partially Active; Impacted; Reassessment Required; Conflict; Not Applicable; Ended/Superseded
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1921"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Evidence
<w:tcPr><w:tcW w:type="dxa" w:w="7799"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Candidate/Unreviewed; Accepted/Validated; Current; Expiring; Expired; Revoked; Impacted (visibility shown separately: Open / Metadata-only / Restricted)
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1921"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Finding
<w:tcPr><w:tcW w:type="dxa" w:w="7799"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Open; Triaged; Remediation Planned; In Remediation; Ready for Validation; Closed; Accepted/Deferred; False Positive; Merged/Superseded
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1921"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Asset
<w:tcPr><w:tcW w:type="dxa" w:w="7799"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Local/Candidate; Under Review; Canonical/Active; Superseded; Retired
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1921"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Promotion
<w:tcPr><w:tcW w:type="dxa" w:w="7799"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Local; Submitted; Duplicate Review; Scope Review; Approved; Published; Rejected/Kept Local

# Appendix D. OSCAL Interaction Alignment
The product experience is intentionally workflow-native while preserving clean mapping to OSCAL where the external semantic fit exists.
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="3331"/><w:gridCol w:w="3331"/><w:gridCol w:w="3331"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2812"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Product UX concept
<w:tcPr><w:tcW w:type="dxa" w:w="2165"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>OSCAL alignment
<w:tcPr><w:tcW w:type="dxa" w:w="4743"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>UX rule
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2812"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Imported control catalog
<w:tcPr><w:tcW w:type="dxa" w:w="2165"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Catalog
<w:tcPr><w:tcW w:type="dxa" w:w="4743"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Users browse controls normally; OSCAL format is implementation detail.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2812"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Selected/tailored organization or program profile
<w:tcPr><w:tcW w:type="dxa" w:w="2165"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Profile
<w:tcPr><w:tcW w:type="dxa" w:w="4743"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>UI shows effective obligations and provenance, not profile operations by default.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2812"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Reusable asset/component implementation
<w:tcPr><w:tcW w:type="dxa" w:w="2165"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Component Definition where semantically appropriate
<w:tcPr><w:tcW w:type="dxa" w:w="4743"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Users work with assets/assurance packages; export may emit Component Definition content.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2812"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>System implementation
<w:tcPr><w:tcW w:type="dxa" w:w="2165"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>SSP
<w:tcPr><w:tcW w:type="dxa" w:w="4743"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>System workspace collects system characteristics, inventory, roles, and implementation content without forcing SSP-native navigation.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2812"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>System assessment plan
<w:tcPr><w:tcW w:type="dxa" w:w="2165"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment Plan
<w:tcPr><w:tcW w:type="dxa" w:w="4743"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment planner can export AP-compatible structure for system-centric workflows.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2812"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>System assessment result
<w:tcPr><w:tcW w:type="dxa" w:w="2165"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment Results
<w:tcPr><w:tcW w:type="dxa" w:w="4743"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Determinations, observations, evidence, findings, and risks can map to AR where applicable.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2812"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Formal system remediation
<w:tcPr><w:tcW w:type="dxa" w:w="2165"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>POA&M
<w:tcPr><w:tcW w:type="dxa" w:w="4743"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>POA&M workspace can export supported OSCAL structure.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2812"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Program SCTM / workbook
<w:tcPr><w:tcW w:type="dxa" w:w="2165"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Projection across Profile, SSP, and Assessment Results content
<w:tcPr><w:tcW w:type="dxa" w:w="4743"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>The SCTM is a generated traceability view; export decomposes to standards artifacts where the semantic fit exists.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2812"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Organization hierarchy
<w:tcPr><w:tcW w:type="dxa" w:w="2165"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Application layer
<w:tcPr><w:tcW w:type="dxa" w:w="4743"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Do not force into an OSCAL model that does not represent the organizational operating workflow.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2812"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assignment packages/delegation
<w:tcPr><w:tcW w:type="dxa" w:w="2165"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Application workflow layer
<w:tcPr><w:tcW w:type="dxa" w:w="4743"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Preserve assessment task/activity lineage while keeping human routing UX outside standards-native terminology.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2812"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Reusable Assurance Package
<w:tcPr><w:tcW w:type="dxa" w:w="2165"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Application abstraction across OSCAL-aligned implementation/results
<w:tcPr><w:tcW w:type="dxa" w:w="4743"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>RAP is the human/product abstraction for controlled reuse; export decomposes to appropriate standards artifacts where needed.
The Assessment Results experience must remain tied to an assessment plan/snapshot for system-centric OSCAL export. Organization-unit ad hoc assessments may use the same internal engine without pretending every such assessment is literally an OSCAL system Assessment Plan.

# Appendix E. Figma Frame Inventory
The first wireframe/design pass should include at minimum:
1. Home - Contributor
2. Home - Program SSE
3. Organization tree
4. Organization unit Overview
5. Organization unit Inheritance
6. Asset Catalog
7. Asset Detail
8. Library landing
9. RAP Detail - provider view
10. RAP Detail - consumer view
11. New Organization Assessment - wizard
12. Assessment Preview / Objective Resolution
13. Package Owner view
14. Contributor Task - question
15. Contributor Task - evidence request
16. Contributor Task - test
17. Reviewer Queue
18. Reviewer Objective Review
19. Determination dialog
20. Finding creation
21. Finding Detail
22. Promotion Queue
23. Promotion wizard
24. Product family Overview
25. Baseline workspace
26. Program Creation - wizard
27. Program Launch Summary
28. Program Overview
29. Program Requirements & Controls
30. Program Inheritance Review
31. Add System chooser
32. New System Overview
33. New System Architecture / Unknowns
34. Variant Delta Review
35. Change Impact Review
36. Conflict Detail
37. Evidence Detail - unrestricted
38. Evidence Detail - restricted result reuse
39. Remediation Initiative
40. POA&M Detail
41. Reassessment flow
42. Why / Provenance drawer
43. Import Center
44. Export / Workbook Center
45. Empty-state variants
46. Permission-denied / metadata-only variants
Definition of a successful UX foundation A contributor can understand and answer a task without learning the control framework; an assessor can make a defensible determination with complete lineage; an SSE can see what remains before a program milestone; an organizational owner can establish reusable assurance once; and every inherited or derived state can explain exactly why it exists, what remains local, and what would cause it to change.