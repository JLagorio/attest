
# Program Assurance Platform
Domain & Rules Specification
Purpose This document defines the canonical domain semantics and business rules that product design, application services, APIs, persistence, automation, and testing must implement consistently. It is the engineering contract underneath the Product Requirements Document and the Product & System Specification. If a UI, database design, integration, or automation conflicts with a rule in this document, the domain rule wins until the rule is deliberately revised.
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Field
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Value
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Status
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Draft for product, security, architecture, and engineering review
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Version
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>1.1
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Date
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>August 12, 2026
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Parent documents
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Program Assurance Platform PRD v1.1; Product & System Specification v1.1. This document is the canonical semantic contract for the suite; where other suite documents differ on semantics, this document governs.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Primary audience
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Product, application architecture, data architecture, backend/frontend engineering, security engineering, assessment leads, QA
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Normative intent
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Defines canonical entities, relationships, invariants, state transitions, resolution rules, and acceptance scenarios

# Contents
1. Purpose, Normative Language, and Design Philosophy
2. Non-Negotiable System Invariants
3. Canonical Identity and Object Taxonomy
4. Scope, Ownership, and Responsibility Model
5. Authority, Provenance, and Source-of-Truth Model
6. Obligations: Controls, Profiles, Requirements, and Parameters
7. Asset, Product, System, and Component Graph
8. Implementation Assertions and Shared Responsibility
9. Reusable Assurance Packages
10. Applicability Rule Model
11. Inheritance Resolution Engine
12. Assessment Content and Execution Model
13. Assessment Snapshots
14. Evidence Trust, Visibility, and Reuse
15. Conflict Detection and Reconciliation
16. Change Events, Impact Analysis, and Invalidation
17. Findings, Remediation, Risk, and POA&M
18. Promotion, Deduplication, and Canonicalization
19. Versioning, Temporal Semantics, and Historical Reconstruction
20. Permissions, Markings, and Cross-Scope Visibility
21. State Machines and Transition Rules
22. Audit Ledger and Domain Events
23. Derived Views and Calculation Semantics
24. Domain Service Contracts
25. Worked Scenarios
26. MVP Domain Contract and Deferred Semantics
27. Acceptance and Conformance Scenarios
Appendix A. Glossary
Appendix B. Relationship Catalog
Appendix C. Recommended Identifiers and Required Metadata
Appendix D. Open Domain Decisions

# Part I - Contract and Ontology

# 1. Purpose, Normative Language, and Design Philosophy

## 1.1 What this document is
The PRD defines why the product exists and what outcomes matter. The Product & System Specification defines the platform operating model and major user/system behavior. This document defines the semantic contract: the rules that must remain true regardless of interface, storage engine, service boundaries, or delivery phase.
This document is intentionally more precise than the product specification. It answers questions such as:
What exactly is an Asset, System, Requirement, Determination, or Reusable Assurance Package?
Which objects are authoritative facts and which states are derived?
When may a child scope inherit a higher-scope result?
What must be captured before an assessment determination can be considered reusable?
What happens when two authoritative sources disagree?
What changes invalidate an inherited result, evidence item, or implementation assertion?
Which historical facts must remain reconstructable after canonical objects change?
Which state transitions are legal and what side effects must occur?

## 1.2 Normative language
The terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY are normative.
MUST / MUST NOT indicate system invariants or requirements that cannot be violated without changing this specification.
SHOULD / SHOULD NOT indicate expected behavior that may be overridden only for a documented reason.
MAY indicates optional behavior or implementation freedom.

## 1.3 Design philosophy
The system is built around several deliberate separations:
1. Fact versus interpretation. A source assertion, contributor response, observation, implementation claim, assessment determination, and derived dashboard state are not interchangeable.
2. Scope versus containment. Organizational ownership, technical composition, assessment scope, and program delivery context are separate dimensions.
3. Reuse versus copying. Inheritance is a versioned reference with applicability and responsibility semantics, not duplicated rows.
4. Current truth versus historical truth. Current canonical state may evolve; historical assessments and program decisions must remain reproducible.
5. Knowledge versus authority. A person may know an answer without having authority to approve a policy, determine a control objective, accept risk, or publish reusable assurance.
6. Unknown versus negative. Unknown, insufficiently documented, not assessed, not applicable, and other-than-satisfied are materially different states.
7. Evidence versus conclusion. Evidence supports a conclusion but does not create that conclusion automatically.
8. Automation versus approval. Automation can propose, route, compare, detect, and calculate; it does not silently create authoritative assurance truth.

# 2. Non-Negotiable System Invariants
The following rules are the platform's core laws. Engineering designs that make any of these difficult should be reconsidered.
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>ID
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Invariant
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-001
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Every canonical object MUST have a stable immutable identifier independent of mutable name, path, owner, or display label.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-002
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Historical references MUST resolve to the version/state actually used at that time; current canonical changes MUST NOT rewrite historical program or assessment truth.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-003
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Missing data MUST remain Unknown or Unresolved; it MUST NOT silently become Not Applicable, Satisfied, absent, or inherited.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-004
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Contributor Responses MUST NOT directly produce final Assessment Determinations.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-005
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>A final Assessment Determination MUST identify assessment scope, objective, reviewer authority, supporting inputs, and effective time/snapshot.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-006
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Inheritance MUST be derived from explicit source, scope, version, applicability conditions, consumer facts, and residual responsibilities.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-007
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Inherited assurance MUST remain traceable to its provider and MUST NOT be represented as locally authored assurance.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-008
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>A consumer MUST NOT inherit assurance beyond the provider package's declared scope, applicability, visibility, or validity conditions.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-009
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Partial/shared implementation MUST preserve provider and consumer responsibilities separately.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-010
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>An evidence artifact MUST NOT be treated as universally reusable merely because it is attached to a reusable implementation.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-011
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Restricted evidence MAY support reusable assurance without being visible to every assurance consumer; result visibility and evidence visibility are separate.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-012
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Source conflicts MUST be preserved and resolved explicitly; the system MUST NOT silently overwrite one source with another.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-013
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Risk acceptance MUST be an explicit authority action and MUST NOT be inferred from age, inactivity, waived work, or missed deadlines.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-014
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>A closed finding or remediation item MUST NOT automatically restore a prior determination without required validation or reassessment.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-015
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Promotion to a broader scope MUST preserve origin lineage and MUST NOT retroactively broaden historical applicability.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-016
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Published product/system baselines, profiles, templates, and Reusable Assurance Packages MUST be immutable or versioned.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-017
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>A change to a dependency MUST trigger evaluation of affected assertions, evidence, inherited results, and assessments rather than directly declaring compliance or noncompliance.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-018
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Organizational hierarchy MUST NOT be used as a substitute for technical system/component architecture.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-019
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Technical containment MUST NOT automatically imply policy applicability or organizational ownership.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-020
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Program delivery context MUST NOT be used as the canonical identity of a reusable organization/product asset.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-021
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>A control catalog source text MUST remain distinguishable from organization/customer requirements and tailoring decisions.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-022
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Effective parameter values MUST preserve every contributing source and decision; source values MUST NOT be destructively overwritten.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-023
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Derived rollups MUST be reproducible from underlying canonical facts and rules and MUST expose their definition.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-024
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Every material state-changing action MUST be attributable to an actor or automated service identity, timestamp, and source event.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-025
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Automation-generated proposals MUST be distinguishable from approved/published authoritative objects.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1736"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>INV-026
<w:tcPr><w:tcW w:type="dxa" w:w="7984"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>The same semantic rule MUST produce the same result regardless of whether the initiating workflow began from an organizational assessment or a program/system assessment.

# 3. Canonical Identity and Object Taxonomy

## 3.1 Identity model
Every persistent domain object MUST have:
id: stable immutable platform identifier;
type: canonical domain type;
created_at and created_by;
lifecycle_state where applicable;
scope_ref or explicit global/imported scope;
version semantics where the object is publishable or historically referenced;
provenance sufficient to explain where the object came from.
Names are labels, not identifiers. A renamed team, product, requirement, or component retains its stable identity.

## 3.2 Entity classes
The platform uses four broad classes of objects.
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="3331"/><w:gridCol w:w="3331"/><w:gridCol w:w="3331"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1394"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Class
<w:tcPr><w:tcW w:type="dxa" w:w="4163"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Meaning
<w:tcPr><w:tcW w:type="dxa" w:w="4163"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Examples
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1394"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Reference content
<w:tcPr><w:tcW w:type="dxa" w:w="4163"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Imported or governed content describing external/internal obligations or assessment intent.
<w:tcPr><w:tcW w:type="dxa" w:w="4163"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Control Catalog, Control, Assessment Objective, Profile definition
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1394"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Managed subjects
<w:tcPr><w:tcW w:type="dxa" w:w="4163"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Things that exist, are owned, composed, consumed, or assessed.
<w:tcPr><w:tcW w:type="dxa" w:w="4163"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Organization Unit, Asset, Product, System, Component, Policy, Procedure, Service
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1394"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Assurance knowledge
<w:tcPr><w:tcW w:type="dxa" w:w="4163"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assertions and results about managed subjects.
<w:tcPr><w:tcW w:type="dxa" w:w="4163"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Requirement, Implementation Assertion, Evidence, Reusable Assurance Package, Assessment Determination
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1394"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:sz w:val="16"/></w:rPr><w:t>Execution/governance
<w:tcPr><w:tcW w:type="dxa" w:w="4163"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Work and decisions through which assurance knowledge is produced or changed.
<w:tcPr><w:tcW w:type="dxa" w:w="4163"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Program, Assessment, Task, Response, Finding, Remediation Initiative, Risk, POA&M, Promotion Request

## 3.3 Asset as common assessable subject
Asset is the common identity abstraction for an assurance-relevant subject that can have ownership, relationships, versions, evidence, implementations, or assessment history.
Asset types MAY include:
policy;
procedure;
shared service;
business/security process;
product;
system;
subsystem;
hardware component;
firmware/software component;
external service;
evidence-producing/test service;
facility/site where relevant;
generic/custom assessable subject.
Specialized product/system/component objects MAY be stored through subtype tables, typed document structures, or service-specific models. Regardless of implementation, they MUST share stable Asset identity when they participate in the assurance graph.

## 3.4 Capability semantics
A Capability is not a maturity concept. It is a reusable logical grouping of assets/components/processes that jointly provide a security or assurance function when no single constituent is sufficient.
Examples: Secure Boot, Secure Update, Enterprise Identity, Firmware Signing.
A Capability:
MAY have a stable Asset identity if it is independently governed, versioned, assessed, and consumed;
MUST declare constituent relationships rather than hide them;
MUST NOT imply that every constituent independently satisfies every mapped control;
SHOULD normally be the provider subject for a Reusable Assurance Package when the organization intends consumers to rely on the combined function.

## 3.5 Object identity versus version identity
Objects that evolve over time require both stable identity and immutable version identity.
Example:
Product Family: Falcon - stable identity.
Product Baseline Version: Falcon v6 - immutable version identity.
Reusable Assurance Package: Enterprise IAM Assurance - stable identity.
RAP Version: Enterprise IAM Assurance v4.2 - immutable version identity.
A historical assessment points to the version identity, not merely the stable family identity.

# 4. Scope, Ownership, and Responsibility Model

## 4.1 Scope is first-class
A Scope identifies where an object or assertion is authored, valid, assessed, or governed. Scope MUST NOT be inferred solely from storage location or URL path.
Supported scope kinds include:
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="3331"/><w:gridCol w:w="3331"/><w:gridCol w:w="3331"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1424"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Scope kind
<w:tcPr><w:tcW w:type="dxa" w:w="2679"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Example
<w:tcPr><w:tcW w:type="dxa" w:w="5618"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Typical use
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1424"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Organization
<w:tcPr><w:tcW w:type="dxa" w:w="2679"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>ACME Defense
<w:tcPr><w:tcW w:type="dxa" w:w="5618"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Enterprise policy, control baseline, canonical library
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1424"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Organizational Unit
<w:tcPr><w:tcW w:type="dxa" w:w="2679"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Enterprise Security / IAM
<w:tcPr><w:tcW w:type="dxa" w:w="5618"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Unit policy, shared-service assurance, assessments
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1424"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Asset
<w:tcPr><w:tcW w:type="dxa" w:w="2679"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Enterprise IAM service
<w:tcPr><w:tcW w:type="dxa" w:w="5618"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Asset-specific implementation/evidence/result
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1424"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Product
<w:tcPr><w:tcW w:type="dxa" w:w="2679"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Falcon product family/baseline
<w:tcPr><w:tcW w:type="dxa" w:w="5618"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Reusable product assurance
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1424"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>System
<w:tcPr><w:tcW w:type="dxa" w:w="2679"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Falcon Mission Controller
<w:tcPr><w:tcW w:type="dxa" w:w="5618"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>System-specific architecture/assessment
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1424"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Program
<w:tcPr><w:tcW w:type="dxa" w:w="2679"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Nightwing
<w:tcPr><w:tcW w:type="dxa" w:w="5618"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Customer/program requirement, delivery-specific work
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1424"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment
<w:tcPr><w:tcW w:type="dxa" w:w="2679"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Nightwing FY27 control assessment
<w:tcPr><w:tcW w:type="dxa" w:w="5618"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Responses, observations, assessment-local evidence
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1424"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Imported/External
<w:tcPr><w:tcW w:type="dxa" w:w="2679"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>NIST catalog
<w:tcPr><w:tcW w:type="dxa" w:w="5618"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Authoritative external reference content

## 4.2 Responsibility graph
Organizational hierarchy represents responsibility and administrative scope, not technical composition.
Each organizational unit MUST support:
stable identity;
parent unit where applicable;
assurance owner(s);
administrative owner(s);
routing roles;
inherited policy/assurance relationships;
scoped permissions.
A product/system/component MAY be owned by one organizational unit and consumed by systems owned by other units.

## 4.3 Technical graph
The technical graph represents composition, interfaces, consumption, and dependency relationships among assets.
Relationships SHOULD include explicit semantics such as:
contains / part_of;
depends_on;
consumes_service;
implements_with;
interfaces_with;
produces_evidence_for;
derived_from_baseline;
variant_of.

## 4.4 Scope inheritance is not ownership inheritance
If Unit B inherits a policy or assurance package from Unit A:
Unit B does not become the owner of the source object;
Unit B cannot edit the source unless separately authorized;
Unit B MAY create local additions, exceptions, or residual responsibilities;
downstream views MUST show the source owner.

## 4.5 Scope broadening requires governance
An object created at Program scope MUST NOT become Organization or Organizational Unit truth merely because several programs use it. Broadening scope requires a Promotion Request or equivalent governed action.

# Part II - Assurance Semantics

# 5. Authority, Provenance, and Source-of-Truth Model

## 5.1 Assertion provenance
Every assertion that could influence assurance state MUST preserve provenance.
Minimum provenance includes:
source type;
source identifier/link where applicable;
source owner/authority;
observed/imported/asserted time;
actor/service that created the platform record;
original scope;
confidence or verification state when the assertion is not yet authoritative;
supersession/version lineage where applicable.

## 5.2 Source classes
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="3331"/><w:gridCol w:w="3331"/><w:gridCol w:w="3331"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2507"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Source class
<w:tcPr><w:tcW w:type="dxa" w:w="2318"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Examples
<w:tcPr><w:tcW w:type="dxa" w:w="4895"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Default treatment
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2507"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Authoritative external standard
<w:tcPr><w:tcW w:type="dxa" w:w="2318"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>NIST control catalog
<w:tcPr><w:tcW w:type="dxa" w:w="4895"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Source content immutable; local tailoring represented separately
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2507"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Authoritative enterprise system
<w:tcPr><w:tcW w:type="dxa" w:w="2318"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>PLM, CMDB, identity directory
<w:tcPr><w:tcW w:type="dxa" w:w="4895"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Trusted for configured fields, subject to freshness/conflict detection
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2507"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Governed organization publication
<w:tcPr><w:tcW w:type="dxa" w:w="2318"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Approved policy, published RAP
<w:tcPr><w:tcW w:type="dxa" w:w="4895"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Authoritative within declared scope/version
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2507"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Product/system baseline
<w:tcPr><w:tcW w:type="dxa" w:w="2318"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Published Falcon v6 model
<w:tcPr><w:tcW w:type="dxa" w:w="4895"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Authoritative baseline claim, not proof that every program matches it
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2507"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment result
<w:tcPr><w:tcW w:type="dxa" w:w="2318"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Approved determination
<w:tcPr><w:tcW w:type="dxa" w:w="4895"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Authoritative for assessed snapshot/scope/time within validity rules
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2507"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Contributor assertion
<w:tcPr><w:tcW w:type="dxa" w:w="2318"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Engineer response
<w:tcPr><w:tcW w:type="dxa" w:w="4895"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Input requiring review; not automatically authoritative assurance truth
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2507"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Automated observation
<w:tcPr><w:tcW w:type="dxa" w:w="2318"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Scanner/test/build output
<w:tcPr><w:tcW w:type="dxa" w:w="4895"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Evidence/observation whose trust depends on source identity and collection controls
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2507"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Imported legacy content
<w:tcPr><w:tcW w:type="dxa" w:w="2318"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Spreadsheet/workbook
<w:tcPr><w:tcW w:type="dxa" w:w="4895"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Historical input; authority and semantics may require triage

## 5.3 Field-level authority
A single Asset may have different authoritative sources for different attributes.
Example:
name/model number: PLM;
operational owner: organization directory;
security classification: security authority;
current firmware version for a program instance: release/build system;
assurance package: security governance.
The platform SHOULD therefore maintain source authority at field or assertion level where practical rather than assigning one global “source of truth” to the entire asset.

## 5.4 Authority does not suppress contradictions
If a lower-authority source contradicts a higher-authority source, the lower-authority observation MUST still be recordable. The system flags a SourceConflict; it does not discard the contradictory information.
Example: PLM says Product Alpha uses SoC X; an engineer states the delivered build uses SoC Y. The engineer response is not silently rejected. It becomes a conflict that must be resolved because the mismatch may reveal source-system drift.

# 6. Obligations: Controls, Profiles, Requirements, and Parameters

## 6.1 Control Catalog
A Control Catalog is imported/governed reference content. A Control retains source family, identifier, source version, statement parts, parameters, and related source metadata.
The platform MUST NOT edit source control text to represent customer or organization-specific modifications.

## 6.2 Profile
A Profile selects, tailors, parameterizes, or overlays control content for a declared scope/use.
A Profile version MUST preserve:
imported source catalog/profile versions;
included/excluded controls;
parameter values and source;
modifications/overlays;
rationale/approval where required;
publication/version identity.

## 6.3 Requirement
A Requirement is a first-class obligation authored outside the immutable source control text.
Requirement source types include:
organizational security requirement;
product requirement;
customer/contractual requirement;
program-specific requirement;
engineering constraint;
derived implementation requirement.
A Requirement MAY map to one or more Controls or Assessment Objectives, but a mapping MUST express relationship semantics rather than assuming equivalence.
Recommended mapping relationships:
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1806"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Relationship
<w:tcPr><w:tcW w:type="dxa" w:w="7914"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Meaning
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1806"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Implements
<w:tcPr><w:tcW w:type="dxa" w:w="7914"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Meeting the requirement is intended to implement all or part of the mapped obligation
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1806"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Supports
<w:tcPr><w:tcW w:type="dxa" w:w="7914"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Requirement contributes to but does not independently satisfy the obligation
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1806"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Strengthens
<w:tcPr><w:tcW w:type="dxa" w:w="7914"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Requirement imposes a stricter or additional constraint
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1806"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Derived from
<w:tcPr><w:tcW w:type="dxa" w:w="7914"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Requirement was created because of the mapped source obligation
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1806"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Related to
<w:tcPr><w:tcW w:type="dxa" w:w="7914"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Informational association without satisfaction semantics

## 6.4 Effective obligations
An Effective Obligation Set is derived for a specific scope/snapshot from:
governing profile(s);
organization/product overlays;
customer requirements;
program tailoring decisions;
applicability decisions;
approved exceptions or deviations.
The set MUST retain provenance for every included obligation and every tailored value.

## 6.5 Parameters
Parameter values MUST be represented as scoped assertions, not destructive edits.
Minimum parameter assertion:
parameter identifier;
source object/version;
value;
scope;
effective interval where applicable;
approval state;
rationale;
precedence or adjudication decision when conflicts exist.
The effective parameter value is derived. It is not the only stored value.

## 6.6 Parameter conflict
The system MUST create a conflict when two applicable parameter assertions cannot be mechanically reconciled.
Examples:
organization minimum password length = 15; customer minimum = 24: may be proposed as 24 if policy permits but still retains both sources;
organization session timeout = 15 minutes; customer says “no idle timeout”: semantic conflict requiring authority review;
one requirement says 90 days, another says quarterly: potentially equivalent but SHOULD require normalization/decision rather than blind numeric comparison.

# 7. Asset, Product, System, and Component Graph

## 7.1 Product Family
A Product Family is a stable reusable product identity independent of any single program.

## 7.2 Product Baseline Version
A Product Baseline Version is an immutable published claim about a standard product configuration at a point in time.
It MAY include:
system templates/boundaries;
expected components and versions/ranges;
consumed organization services;
capabilities;
implementation assertions;
candidate RAPs;
evidence references;
baseline assessment results;
known unknowns/completeness metadata.
Publication does not imply complete assurance. Completeness is separately represented.

## 7.3 System Template and System Instance
A System Template belongs to a product baseline and represents a reusable standard system boundary/model.
A System Instance belongs to a concrete program/delivery/assessment context and may be:
instantiated from a System Template;
created as a variant;
created without a reusable baseline;
imported from legacy content.

## 7.4 Component identity
A component in a program/system MUST distinguish:
canonical component identity, if known;
product baseline component reference, if inherited;
program/system instance configuration;
local candidate identity when canonicalization has not occurred.
A program-local component can participate fully in assurance before being promoted to the organization catalog.

## 7.5 Unknown placeholders
Unknown architecture MUST be explicit.
An Unknown placeholder MUST include:
unknown kind;
parent system/context;
why the information is expected/required;
owner or unresolved routing state;
target date if applicable;
source that revealed the unknown;
resolution status.
Removing an Unknown placeholder requires either replacing it with known facts or an authorized decision that the information is not required/applicable.

# 8. Implementation Assertions and Shared Responsibility

## 8.1 Definition
An Implementation Assertion states how a subject contributes to an obligation under explicit conditions.
Minimum fields:
provider subject (asset/capability/system/process);
obligation target(s): requirement/control/control-part/objective as appropriate;
implementation statement;
implementation status;
applicability conditions;
provider responsibilities;
consumer/local responsibilities, if shared;
source owner and approval state;
version/effective interval;
related evidence and assessment results.

## 8.2 Assertion is not determination
An Implementation Assertion is a claim about implementation. It MAY be supported by assessment results, but the existence of the assertion does not itself mean the corresponding objective is Satisfied.

## 8.3 Granularity
Assertions SHOULD map to the smallest meaningful obligation portion when a control contains multiple materially independent responsibilities.
Overly broad assertions such as “Enterprise IAM satisfies AC-2” SHOULD be rejected or decomposed when actual responsibility is split across provider and consumer.

## 8.4 Shared responsibility
A shared implementation MUST make the division explicit.
Example:
Enterprise IAM provider responsibilities
authenticates enterprise identities;
enforces centrally configured credential policy;
disables identities when authoritative HR termination is received.
Consumer system responsibilities
maps enterprise identities to application roles;
approves privileged role assignments;
removes local entitlements no longer required;
retains local access-review evidence.
The consumer may inherit provider assurance for the first set while still receiving assessment tasks for the residual responsibilities.

# 9. Reusable Assurance Packages

## 9.1 Purpose
A Reusable Assurance Package (RAP) is the governed unit through which a provider offers reusable assurance to downstream consumers. It prevents consumers from having to reason about dozens of disconnected implementation assertions, evidence objects, determinations, and validity rules.
Canonical question answered by a RAP “What assurance does this provider offer me, under what conditions, based on what assessment, and what responsibilities still remain mine?”

## 9.2 RAP identity and versioning
A RAP has stable identity plus immutable published versions.
Example:
RAP family: Enterprise IAM Assurance
RAP version: Enterprise IAM Assurance v4.2
Consumers pin the version they relied upon.

## 9.3 Required RAP content
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2462"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Area
<w:tcPr><w:tcW w:type="dxa" w:w="7258"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Required semantics
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2462"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Provider
<w:tcPr><w:tcW w:type="dxa" w:w="7258"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Canonical asset/capability/service that owns the assurance
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2462"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Owner / authority
<w:tcPr><w:tcW w:type="dxa" w:w="7258"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Organization unit and publishing authority
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2462"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Version
<w:tcPr><w:tcW w:type="dxa" w:w="7258"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Immutable package version
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2462"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Supported obligations
<w:tcPr><w:tcW w:type="dxa" w:w="7258"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Controls/requirements/objectives or portions supported
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2462"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Implementation assertions
<w:tcPr><w:tcW w:type="dxa" w:w="7258"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Approved provider implementation claims
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2462"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Provider responsibilities
<w:tcPr><w:tcW w:type="dxa" w:w="7258"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>What the provider is accountable for
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2462"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Consumer responsibilities
<w:tcPr><w:tcW w:type="dxa" w:w="7258"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Residual work every consumer must perform or confirm
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2462"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Applicability rule
<w:tcPr><w:tcW w:type="dxa" w:w="7258"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Facts that must be true for a consumer to rely on the package
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2462"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment basis
<w:tcPr><w:tcW w:type="dxa" w:w="7258"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Approved assessment result(s)/snapshot(s) supporting the package
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2462"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Evidence basis
<w:tcPr><w:tcW w:type="dxa" w:w="7258"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Evidence references and visibility/reuse rules
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2462"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Validity
<w:tcPr><w:tcW w:type="dxa" w:w="7258"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Time/event/change conditions that trigger review or expiration
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2462"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Attestation policy
<w:tcPr><w:tcW w:type="dxa" w:w="7258"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Whether consumers must confirm configuration/use
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2462"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Visibility
<w:tcPr><w:tcW w:type="dxa" w:w="7258"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Which metadata/results/evidence consumers may see
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2462"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Publication status
<w:tcPr><w:tcW w:type="dxa" w:w="7258"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Draft, under review, published, superseded, retired

## 9.4 RAP does not equal blanket control satisfaction
A RAP MAY resolve only part of a control or objective set. The package MUST express supported portions and consumer residual responsibilities.

## 9.5 RAP consumption record
When a consumer relies on a RAP, the system MUST create a RAPConsumption record containing:
consumer scope/subject;
RAP version;
consumer facts used to evaluate applicability;
evaluation result;
attestation/approval if required;
effective date;
residual tasks generated;
snapshot reference for formal assessments/program milestones;
later impact/invalidation status.
The system MUST NOT represent RAP use by copying package contents into the consumer scope.

## 9.6 Restricted evidence
A RAP can be consumable even when supporting evidence is not directly visible to the consumer, provided policy allows reuse of the approved determination. The consumer view MUST distinguish:
result is reusable;
evidence exists and was reviewed by authority;
evidence access is restricted;
consumer has no direct evidence entitlement.

# 10. Applicability Rule Model

## 10.1 Applicability is a predicate
Applicability is modeled as a structured predicate evaluated against facts about a candidate consumer or scope.
An applicability rule MUST NOT be stored only as prose if it drives automated inheritance or suppression of assessment work.

## 10.2 Fact model
Candidate facts may include:
organization ancestry;
asset type;
product family/baseline;
component identity/version;
system classification/categorization;
environment;
customer/mission;
configuration values;
consumed service/capability;
boundary relationship;
cryptographic mode;
location/site;
effective date;
explicit human attestation.
Facts MUST preserve source and freshness.

## 10.3 Predicate operators
The rule model SHOULD support:
equals / not equals;
one-of / none-of;
exists / absent;
greater-than / less-than for normalized values;
version range;
organizational descendant-of;
consumes / does-not-consume relationship;
all / any / not logical composition;
date/time interval;
explicit approved attestation;
human-review-required predicate for non-computable conditions.

## 10.4 Applicability result
Applicability evaluation returns more than Boolean.
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1997"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Result
<w:tcPr><w:tcW w:type="dxa" w:w="7723"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Meaning
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1997"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Applicable
<w:tcPr><w:tcW w:type="dxa" w:w="7723"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Required facts are known and predicate is true
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1997"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Not Applicable
<w:tcPr><w:tcW w:type="dxa" w:w="7723"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Required facts are known and predicate is false
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1997"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Unknown
<w:tcPr><w:tcW w:type="dxa" w:w="7723"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Required facts are missing/ambiguous
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1997"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Conflict
<w:tcPr><w:tcW w:type="dxa" w:w="7723"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Required facts disagree across sources
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1997"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Review Required
<w:tcPr><w:tcW w:type="dxa" w:w="7723"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Rule explicitly requires human judgment or policy decision
Only Applicable may proceed to automatic inheritance. Unknown, Conflict, and Review Required create work.

## 10.5 Rule provenance
Every rule MUST identify owner, version, scope, effective interval, and source rationale.

# 11. Inheritance Resolution Engine

## 11.1 Inheritance is derived state
“Inherited” is not a free-form user assertion. It is the result of evaluating a reusable source against a consumer context.
The resolver MUST consider:
1. source publication status and version;
2. consumer eligibility/scope;
3. applicability rule result;
4. provider assessment/result status;
5. evidence/result validity rules;
6. known changes after assessment/package publication;
7. visibility/reuse permissions;
8. consumer residual responsibilities;
9. conflicting local or authoritative facts;
10. assessment snapshot/time context.

## 11.2 Resolution output
For each obligation/objective supported by a reusable source, the resolver SHOULD produce one of:
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2610"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Resolution
<w:tcPr><w:tcW w:type="dxa" w:w="7110"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Meaning / action
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2610"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Resolved by inheritance
<w:tcPr><w:tcW w:type="dxa" w:w="7110"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Current provider result applies; no redundant substantive local task
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2610"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Resolved with attestation
<w:tcPr><w:tcW w:type="dxa" w:w="7110"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Provider result applies if consumer confirms declared condition
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2610"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Partially resolved
<w:tcPr><w:tcW w:type="dxa" w:w="7110"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Provider portion inherited; residual local responsibilities generate tasks
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2610"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Reassessment required
<w:tcPr><w:tcW w:type="dxa" w:w="7110"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Prior provider result/package is impacted, stale, expired, or changed
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2610"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Applicability unknown
<w:tcPr><w:tcW w:type="dxa" w:w="7110"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Required consumer facts missing; create discovery/applicability work
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2610"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Conflict
<w:tcPr><w:tcW w:type="dxa" w:w="7110"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Consumer/source facts or applicable sources disagree; adjudication required
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2610"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Not reusable
<w:tcPr><w:tcW w:type="dxa" w:w="7110"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Package/result is valid for provider but policy/scope prevents reuse here
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2610"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Not applicable
<w:tcPr><w:tcW w:type="dxa" w:w="7110"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Reusable source does not apply to this consumer

## 11.3 Recommended resolution sequence
The logical order is normative even if implementation is optimized:
1. Identify candidate reusable sources by obligation and consumer relationships.
2. Filter to published/eligible source versions.
3. Evaluate consumer visibility and reuse permission.
4. Evaluate structured applicability predicates.
5. Evaluate provider result/package validity.
6. Compare consumer facts against provider assumptions/snapshot.
7. Detect local overrides/conflicts/changes.
8. Resolve supported provider responsibilities.
9. Generate residual local responsibilities/tasks.
10. Persist a traceable resolution record or cache derived result with dependency references.

## 11.4 Multiple candidate sources
If multiple packages or inherited sources cover the same objective:
the system MAY combine complementary partial responsibilities;
the system MUST NOT double-count the same responsibility as stronger assurance merely because multiple sources claim it;
conflicting claims MUST create a conflict;
source priority MAY choose a preferred package only if governance has explicitly configured that policy;
the final provenance view MUST show all sources materially involved in the resolution.

## 11.5 Local work superseding inheritance
A local determination MAY supersede an inherited result for that consumer/snapshot without altering the provider result.
Examples:
local implementation differs from the provider assumptions;
customer requirement strengthens the obligation;
local test demonstrates a provider result is not applicable to the consumer configuration.
The local result MUST preserve the inherited source relationship and the reason inheritance was replaced or narrowed.

# Part III - Assessment Semantics

# 12. Assessment Content and Execution Model

## 12.1 Canonical layers
Assessment semantics MUST preserve these layers:
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2278"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Layer
<w:tcPr><w:tcW w:type="dxa" w:w="7442"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Purpose
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2278"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Control / Requirement
<w:tcPr><w:tcW w:type="dxa" w:w="7442"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Obligation to be satisfied
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2278"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment Objective
<w:tcPr><w:tcW w:type="dxa" w:w="7442"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Canonical determination target
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2278"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment Template
<w:tcPr><w:tcW w:type="dxa" w:w="7442"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Organization-approved way to gather sufficient information for an objective
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2278"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment Task
<w:tcPr><w:tcW w:type="dxa" w:w="7442"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Concrete execution work in a specific assessment
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2278"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Response
<w:tcPr><w:tcW w:type="dxa" w:w="7442"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Contributor-provided information
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2278"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Observation
<w:tcPr><w:tcW w:type="dxa" w:w="7442"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Structured fact/result accepted or recorded during assessment
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2278"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Evidence
<w:tcPr><w:tcW w:type="dxa" w:w="7442"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Supporting artifact/result with provenance
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2278"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Determination
<w:tcPr><w:tcW w:type="dxa" w:w="7442"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Authorized conclusion for an objective at a scope/snapshot/time
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2278"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Finding
<w:tcPr><w:tcW w:type="dxa" w:w="7442"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Gap/issue requiring disposition
No implementation MAY collapse Response and Determination into the same record/state.

## 12.2 Assessment Template
A Template is reusable organization knowledge that maps canonical assessment objectives to practical steps.
A template version MAY define:
objective mapping;
task sequence;
assessment methods;
plain-language wording;
expected response/evidence types;
default package/routing rule;
branching/dependency logic;
preconditions;
reusable evidence patterns;
reviewer guidance;
supersession/reassessment triggers.
Published templates MUST be versioned. Updating template wording MUST NOT rewrite prior assessment tasks.

## 12.3 Assessment Campaign
An Assessment or Assessment Campaign defines a bounded execution context.
Minimum fields:
assessment identity;
target scope/subjects;
effective obligation/profile basis;
objective set;
assessment lead;
reviewer/authority model;
planned dates/milestone;
inheritance policy;
snapshot policy;
lifecycle state;
source template/profile versions.

## 12.4 Objective Resolution
Before tasks are instantiated, every objective MUST be evaluated against reusable assurance.
Objectives resolved by current inheritance should not generate redundant substantive tasks. Objectives with residual consumer responsibilities generate only those residual tasks.

## 12.5 Assignment Package
An Assignment Package groups tasks for operational delegation while retaining objective lineage.
Package grouping MAY use:
organizational unit;
asset/shared-service owner;
system/component owner;
functional routing rule;
task method/type;
due date/milestone.
A package owner remains accountable for package completion even after delegating tasks unless the package itself is reassigned.

## 12.6 Task
Each Assessment Task MUST include:
source assessment;
supported objective(s);
task type/method;
assignee and package owner;
due date where used;
target subject/context;
prompt/action;
expected response/evidence shape;
lifecycle state;
dependency/branching references;
reviewer or review route.

## 12.7 Response
A Response records what the contributor provided.
A Response MUST preserve:
contributor identity;
submission time;
original answer/content;
evidence links/attachments;
response version/edits;
delegation/reassignment lineage;
source task.
A Response MAY be marked complete by the contributor while still being insufficient for reviewer determination.

## 12.8 Observation
An Observation is a structured fact or result recorded during assessment.
Examples:
configuration value observed;
documented procedure exists;
test passed/failed;
interview statement;
discrepancy between PLM and delivered hardware;
evidence item verified.
An Observation SHOULD identify method, subject, time, actor/tool, source evidence, and any relevant confidence/limitations.

## 12.9 Determination
A Determination is the authoritative assessment conclusion for one objective in one assessment context.
Required fields:
objective;
assessed subject/scope;
assessment snapshot;
outcome;
reviewer identity/authority;
rationale;
supporting responses/observations/evidence;
determination time;
validity/reassessment conditions where applicable.

## 12.10 Determination outcomes
Internal workflow may contain many states, but final outcome semantics SHOULD include at least:
Satisfied;
Other Than Satisfied;
Not Applicable, when the organization's process permits an authorized N/A outcome;
No Determination / Insufficient Information for incomplete work, which is operationally distinct from a final negative outcome.

## 12.11 Finding generation
An Other Than Satisfied determination SHOULD normally produce or link to at least one Finding unless organizational policy explicitly permits a documented no-finding disposition.
Insufficient Information MAY create a discovery/evidence work item without immediately creating a formal Finding.

# 13. Assessment Snapshots

## 13.1 Why snapshots are required
An assessment can take days or months while the underlying environment changes. A determination is meaningless unless the platform can reconstruct what was assessed.
An AssessmentSnapshot freezes the relevant semantic context without necessarily copying every underlying object.

## 13.2 Snapshot content
A snapshot SHOULD pin or materialize references to:
assessment target subjects and boundaries;
effective control/profile/requirement versions;
product/system baseline versions;
system/component/configuration facts used by applicability;
RAP versions and consumption records;
inherited assessment result versions;
relevant evidence versions/references;
organization policy/profile versions;
customer requirement versions;
open conflicts/unknowns material to the assessment;
scope and ownership references;
time/effective date.

## 13.3 Snapshot timing
The platform SHOULD support at least:
planning snapshot: basis when assessment is launched;
determination snapshot: basis when reviewer makes a determination;
final assessment snapshot: consolidated basis for published results.
A lightweight MVP MAY use one final snapshot if all relevant changes during execution are audited and surfaced to reviewers.

## 13.4 Snapshot change handling
If a material underlying fact changes during an active assessment:
1. record the change event;
2. identify affected objectives/tasks/determinations;
3. flag the assessment snapshot as having a material delta;
4. require reviewer choice to adopt the new fact, retain old assessment basis, or split/reassess as appropriate;
5. preserve both histories.
The system MUST NOT silently mutate an active assessment's basis.

# 14. Evidence Trust, Visibility, and Reuse

## 14.1 Evidence record
Evidence is a structured record referencing an artifact or machine result. Required metadata SHOULD include:
stable evidence identity;
artifact/source location or embedded content reference;
evidence type;
subject(s);
producer/collector;
created/observed time;
integrity metadata where applicable;
source system;
supported assertions/objectives/observations;
validity/freshness policy;
applicability conditions;
visibility/marking;
review state;
supersession/revocation state.

## 14.2 Evidence trust dimensions
The system SHOULD model trust using independent dimensions rather than a single score.
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1893"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Dimension
<w:tcPr><w:tcW w:type="dxa" w:w="7827"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Examples
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1893"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Source authority
<w:tcPr><w:tcW w:type="dxa" w:w="7827"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Authoritative system, approved procedure owner, manual upload
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1893"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Collection method
<w:tcPr><w:tcW w:type="dxa" w:w="7827"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Machine-generated, assessor-observed, contributor-submitted
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1893"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Integrity
<w:tcPr><w:tcW w:type="dxa" w:w="7827"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Hash/signature available, source-controlled artifact, unverifiable attachment
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1893"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Freshness
<w:tcPr><w:tcW w:type="dxa" w:w="7827"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Current, expiring, expired, timeless subject to change triggers
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1893"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Applicability
<w:tcPr><w:tcW w:type="dxa" w:w="7827"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Exact assessed version/config, broader scope with conditions, unknown
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1893"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Review
<w:tcPr><w:tcW w:type="dxa" w:w="7827"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Unreviewed, accepted as input, assessor-validated
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1893"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Visibility
<w:tcPr><w:tcW w:type="dxa" w:w="7827"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Open to consumer, metadata-only, restricted evidence

## 14.3 Evidence freshness
Freshness MAY be time-based, event-based, or both.
Examples:
policy: valid until superseded or annual review date;
penetration test: valid until defined architecture/configuration change or expiration;
FIPS certificate: valid according to external status/version;
build test: valid only for exact build/component version;
organization process interview: requires periodic reassessment.

## 14.4 Evidence revocation
Evidence can be revoked or invalidated without deleting historical use.
Revocation MUST:
preserve the artifact and prior assessment lineage;
mark current reuse unavailable;
trigger impact analysis for consumers relying on it;
create reassessment/refresh work where policy requires.

## 14.5 Evidence access versus assurance access
The platform MUST support cases where:
consumer can see the full evidence;
consumer can see evidence metadata but not content;
consumer can only see an approved determination/package statement;
evidence is restricted to assessor/provider authority.
Lack of direct evidence visibility does not necessarily invalidate inheritance if governance permits reliance on the approved provider determination.

# 15. Conflict Detection and Reconciliation

## 15.1 Conflict is first-class
A Conflict records incompatible assertions that materially affect assurance, applicability, configuration, ownership, or requirements.
Conflict types include:
source data conflict;
parameter/requirement conflict;
ownership conflict;
applicability conflict;
implementation conflict;
assessment-result conflict;
version/configuration conflict.

## 15.2 Conflict lifecycle
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1805"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>State
<w:tcPr><w:tcW w:type="dxa" w:w="7915"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Meaning
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1805"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Detected
<w:tcPr><w:tcW w:type="dxa" w:w="7915"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Incompatible assertions identified
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1805"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Triaged
<w:tcPr><w:tcW w:type="dxa" w:w="7915"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Responsible authority identified and materiality assessed
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1805"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Under Review
<w:tcPr><w:tcW w:type="dxa" w:w="7915"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Resolution work active
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1805"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Resolved
<w:tcPr><w:tcW w:type="dxa" w:w="7915"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Authoritative decision/current fact established with rationale
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1805"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Accepted Ambiguity
<w:tcPr><w:tcW w:type="dxa" w:w="7915"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Authority permits unresolved ambiguity for a bounded period/scope
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1805"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Superseded
<w:tcPr><w:tcW w:type="dxa" w:w="7915"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Conflict resolved by later authoritative information/version

## 15.3 Conflict resolution record
Resolution MUST preserve:
all conflicting source assertions;
decision authority;
selected/derived effective fact;
rationale;
scope;
effective date;
impacted objects/work;
whether source-system correction is required.

## 15.4 Conflict blocking semantics
A conflict SHOULD block automatic inheritance or final determination only when it is material to the relevant applicability/assessment decision.
Non-material conflicts remain visible but need not halt unrelated work.

## 15.5 No destructive reconciliation
Resolving a conflict does not delete or rewrite the original assertions. It adds an authoritative resolution and may mark older assertions superseded or incorrect for current use.

# 16. Change Events, Impact Analysis, and Invalidation

## 16.1 ChangeEvent
A ChangeEvent represents a material change or newly discovered change in a dependency that may alter assurance state.
Examples:
component version changed;
system boundary changed;
customer requirement changed;
policy/RAP/profile new version published;
evidence expired/revoked;
provider implementation changed;
source conflict resolved;
organizational ownership moved;
assessment determination superseded.

## 16.2 Change is not failure
A ChangeEvent does not directly set a control/objective to failed. It initiates impact evaluation.

## 16.3 Dependency traversal
Impact analysis SHOULD traverse explicit dependency edges from changed nodes to:
applicability facts/rules;
Implementation Assertions;
RAP versions/consumptions;
Evidence;
Assessment Determinations;
Requirements/Controls/Objectives;
Product/system baselines;
active Programs;
Findings/POA&M where relevant;
milestones/work items.

## 16.4 Impact result
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2685"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Impact state
<w:tcPr><w:tcW w:type="dxa" w:w="7035"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Meaning
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2685"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>No Known Impact
<w:tcPr><w:tcW w:type="dxa" w:w="7035"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>No documented dependency invalidated; event retained
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2685"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Review Required
<w:tcPr><w:tcW w:type="dxa" w:w="7035"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Dependency exists but rule cannot safely decide impact
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2685"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Applicability Changed
<w:tcPr><w:tcW w:type="dxa" w:w="7035"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Source/consumer rule may now evaluate differently
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2685"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assertion Impacted
<w:tcPr><w:tcW w:type="dxa" w:w="7035"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Implementation claim assumptions changed
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2685"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Evidence Impacted
<w:tcPr><w:tcW w:type="dxa" w:w="7035"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Evidence may not support changed context
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2685"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Determination Impacted
<w:tcPr><w:tcW w:type="dxa" w:w="7035"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Prior objective result no longer safely reusable
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2685"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>RAP Consumption Impacted
<w:tcPr><w:tcW w:type="dxa" w:w="7035"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Consumer package reliance requires attestation/review/reassessment
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2685"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>New Obligation
<w:tcPr><w:tcW w:type="dxa" w:w="7035"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Change introduces new applicable requirement/control/objective

## 16.5 Invalidation versus impact
Impacted means review is required. Invalidated means a known rule or approved decision concludes the prior item is not valid for current reuse.
The system SHOULD avoid invalidating when the effect is uncertain; uncertainty becomes Review Required.

## 16.6 Cascading side effects
When a dependency becomes invalidated:
current derived inheritance may change;
affected assessment objectives move to Impacted / Reassessment Required;
redundant local tasks may become active again;
dashboards/work queues update;
historical determinations remain unchanged within their original snapshots.

# Part IV - Governance and Lifecycle Semantics

# 17. Findings, Remediation, Risk, and POA&M

## 17.1 Finding
A Finding represents an identified assurance gap, deficiency, inconsistency, or material issue requiring disposition.
A Finding MUST preserve source and affected scope.
Minimum fields:
description;
source assessment/observation/determination or manual authority source;
affected subjects/scopes;
related obligations/objectives;
owner;
state;
severity/priority if used;
due/target date if used;
evidence/observations;
disposition.

## 17.2 Finding is not Risk
A Finding answers what gap was observed. Risk answers what adverse outcome/exposure may result and how it will be treated.
The relationship is many-to-many.

## 17.3 Remediation Initiative
A Remediation Initiative groups work addressing one or more Findings through common root cause or implementation change.
It MUST NOT erase finding-specific scope or closure requirements.

## 17.4 POA&M
A POA&M Item is a formal system/program-tracked remediation record where required by the authorization/governance process.
A Finding MAY exist without a POA&M Item. A POA&M Item MUST preserve source finding/risk lineage when created from them.

## 17.5 Closure
Finding closure requires a disposition and, where applicable, validation.
Possible dispositions include:
remediated and validated;
accepted risk/deviation with authority;
false positive/invalid finding with rationale;
not applicable after authorized reassessment;
merged/superseded into another finding.
Closing a Finding MUST NOT automatically close associated Risk or POA&M objects unless their own rules are satisfied.

# 18. Promotion, Deduplication, and Canonicalization

## 18.1 Local-first creation
Objects created inside an Assessment, System, Product, or Program MAY remain local and usable immediately.
Local-first objects include:
assets/components;
policy/procedure records;
requirements;
Implementation Assertions;
evidence patterns;
Assessment Templates;
RAP candidates.

## 18.2 Promotion Request
A Promotion Request proposes broader reusable scope.
Required semantics:
source local object/version;
proposed destination scope;
destination owner;
duplicate/candidate matches;
proposed canonical identity/new version;
applicability justification;
supporting evidence/usage;
reviewer/approval state.

## 18.3 Deduplication
Deduplication MUST distinguish:
exact duplicate identity;
same canonical asset, new version;
similar asset but distinct configuration/owner;
potentially equivalent requirement/template;
no match.
The system SHOULD suggest candidates but MUST NOT automatically merge high-impact assurance objects without governed policy.

## 18.4 Canonicalization outcomes
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2252"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Outcome
<w:tcPr><w:tcW w:type="dxa" w:w="7468"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Meaning
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2252"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Link to existing
<w:tcPr><w:tcW w:type="dxa" w:w="7468"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Local object was a reference to already-canonical object
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2252"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Merge metadata
<w:tcPr><w:tcW w:type="dxa" w:w="7468"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Non-conflicting metadata incorporated into canonical object/new revision
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2252"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Publish new version
<w:tcPr><w:tcW w:type="dxa" w:w="7468"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Local change materially changes existing reusable object
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2252"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Create new canonical
<w:tcPr><w:tcW w:type="dxa" w:w="7468"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Distinct reusable object approved
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2252"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Keep local
<w:tcPr><w:tcW w:type="dxa" w:w="7468"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Object not reusable outside source scope
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2252"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Reject
<w:tcPr><w:tcW w:type="dxa" w:w="7468"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Proposal invalid/duplicate/not authorized

## 18.5 Historical lineage
Promotion MUST NOT change the identity/version referenced by past assessments. A historical local object MAY record that it later became linked to a canonical object, but the original historical reference remains reconstructable.

# 19. Versioning, Temporal Semantics, and Historical Reconstruction

## 19.1 Versioned object classes
At minimum, the following SHOULD be versioned when published/reused:
Profiles/Baselines;
Product/System Baselines;
Assessment Templates;
Reusable Assurance Packages;
policies/procedures when represented as governed assurance objects;
significant Implementation Assertions;
canonical components/configuration definitions where version matters.

## 19.2 Immutable published versions
Published versions MUST NOT be edited in place. Corrections create a new version/revision or an explicit erratum mechanism that preserves prior content.

## 19.3 Effective time
Objects may have:
created time;
published time;
effective-from time;
effective-to/superseded time;
observed time;
assessment time.
These are distinct.

## 19.4 Bi-temporal need
The persistence design SHOULD support the conceptual distinction between:
valid time: when a fact was true in the real world;
system time: when the platform learned/recorded the fact.
Full bi-temporal storage is an engineering choice, but the domain MUST preserve enough temporal metadata to answer: “What did we know then, and what was actually true then?” for material assurance decisions.

## 19.5 Historical reconstruction
The system MUST be able to reconstruct:
effective obligations for a program/assessment at a historical milestone;
pinned baselines/RAP versions;
component/configuration facts used;
evidence/result versions;
decision/approval lineage;
open conflicts/unknowns known at the time;
assessment determination and snapshot.

# 20. Permissions, Markings, and Cross-Scope Visibility

## 20.1 Permission dimensions
Authorization SHOULD consider:
user/service identity;
role/capability;
organization scope;
program membership;
object ownership;
assessment role;
information marking/classification;
action type;
provider/consumer relationship.

## 20.2 Object permission versus field/content visibility
Some objects require partial visibility.
Example RAP consumer may be allowed to see:
package existence/name/version;
supported obligations;
determination status/date;
provider/consumer responsibilities;
but not:
restricted evidence contents;
assessor notes;
provider-sensitive configuration details.

## 20.3 Metadata-level inheritance
The platform MUST support inheritance of approved assurance metadata/result when underlying evidence remains restricted, if policy allows.

## 20.4 Promotion security check
Promotion to broader scope MUST evaluate whether any embedded data is more restricted than the destination scope. The system SHOULD support promoting sanitized metadata or a reusable assertion without copying restricted evidence.

## 20.5 Search leakage
Search, counts, notifications, and relationship graphs MUST respect visibility rules. A user SHOULD NOT infer sensitive program/assets merely from hidden-object counts or autocomplete results unless policy permits.

# 21. State Machines and Transition Rules

## 21.1 Assessment lifecycle
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="3331"/><w:gridCol w:w="3331"/><w:gridCol w:w="3331"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1695"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>State
<w:tcPr><w:tcW w:type="dxa" w:w="2543"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Allowed next states
<w:tcPr><w:tcW w:type="dxa" w:w="5482"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Key gate
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1695"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Draft
<w:tcPr><w:tcW w:type="dxa" w:w="2543"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Planned, Cancelled
<w:tcPr><w:tcW w:type="dxa" w:w="5482"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Scope/owner exists
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1695"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Planned
<w:tcPr><w:tcW w:type="dxa" w:w="2543"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Active, Cancelled
<w:tcPr><w:tcW w:type="dxa" w:w="5482"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Objective set and assessment authority configured
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1695"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Active
<w:tcPr><w:tcW w:type="dxa" w:w="2543"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Paused, Completing, Cancelled
<w:tcPr><w:tcW w:type="dxa" w:w="5482"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Work executing
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1695"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Paused
<w:tcPr><w:tcW w:type="dxa" w:w="2543"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Active, Cancelled
<w:tcPr><w:tcW w:type="dxa" w:w="5482"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Authorized resume
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1695"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Completing
<w:tcPr><w:tcW w:type="dxa" w:w="2543"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Published, Active
<w:tcPr><w:tcW w:type="dxa" w:w="5482"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Reviewer resolves required pending items or documents exceptions
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1695"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Published
<w:tcPr><w:tcW w:type="dxa" w:w="2543"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Superseded
<w:tcPr><w:tcW w:type="dxa" w:w="5482"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Results immutable; later changes create new/reassessment campaign
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1695"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Cancelled
<w:tcPr><w:tcW w:type="dxa" w:w="2543"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>None
<w:tcPr><w:tcW w:type="dxa" w:w="5482"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>History retained
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1695"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Superseded
<w:tcPr><w:tcW w:type="dxa" w:w="2543"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>None
<w:tcPr><w:tcW w:type="dxa" w:w="5482"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Replacement assessment/result identified

## 21.2 Assessment objective lifecycle
Operational state is derived from tasks, inheritance, and determination.
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="3331"/><w:gridCol w:w="3331"/><w:gridCol w:w="3331"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2011"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>State
<w:tcPr><w:tcW w:type="dxa" w:w="4255"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Entry condition
<w:tcPr><w:tcW w:type="dxa" w:w="3455"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Exit trigger
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2011"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Planned
<w:tcPr><w:tcW w:type="dxa" w:w="4255"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Objective in assessment snapshot; not resolved
<w:tcPr><w:tcW w:type="dxa" w:w="3455"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Inheritance/task resolution
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2011"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Inherited Current
<w:tcPr><w:tcW w:type="dxa" w:w="4255"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Applicable reusable determination resolves objective
<w:tcPr><w:tcW w:type="dxa" w:w="3455"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Impact/change/local override
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2011"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Attestation Required
<w:tcPr><w:tcW w:type="dxa" w:w="4255"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Inheritance contingent on consumer confirmation
<w:tcPr><w:tcW w:type="dxa" w:w="3455"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Attestation accepted/rejected
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2011"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Awaiting Response
<w:tcPr><w:tcW w:type="dxa" w:w="4255"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Active tasks outstanding
<w:tcPr><w:tcW w:type="dxa" w:w="3455"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Required inputs submitted
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2011"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Ready for Review
<w:tcPr><w:tcW w:type="dxa" w:w="4255"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Inputs sufficient to enter reviewer queue
<w:tcPr><w:tcW w:type="dxa" w:w="3455"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Reviewer action
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2011"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Insufficient Information
<w:tcPr><w:tcW w:type="dxa" w:w="4255"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Reviewer cannot determine
<w:tcPr><w:tcW w:type="dxa" w:w="3455"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>New inputs submitted
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2011"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Satisfied
<w:tcPr><w:tcW w:type="dxa" w:w="4255"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Authorized determination
<w:tcPr><w:tcW w:type="dxa" w:w="3455"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Material change creates impacted state for current reuse
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2011"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Other Than Satisfied
<w:tcPr><w:tcW w:type="dxa" w:w="4255"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Authorized negative determination
<w:tcPr><w:tcW w:type="dxa" w:w="3455"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Reassessment creates new determination; original retained
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2011"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Not Applicable
<w:tcPr><w:tcW w:type="dxa" w:w="4255"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Authorized applicability determination
<w:tcPr><w:tcW w:type="dxa" w:w="3455"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Scope/facts change
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="2011"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Impacted / Reassessment Required
<w:tcPr><w:tcW w:type="dxa" w:w="4255"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Current reusable result no longer safe
<w:tcPr><w:tcW w:type="dxa" w:w="3455"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>New review/determination

## 21.3 Assessment task lifecycle
New -> Packaged -> Assigned -> In Progress/Delegated -> Submitted -> Clarification Requested or Accepted as Input -> Closed
Rules:
Delegation does not remove package accountability.
Clarification returns task to active contributor state while preserving prior response versions.
Accepted as Input does not imply objective satisfaction.

## 21.4 RAP lifecycle
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1824"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>State
<w:tcPr><w:tcW w:type="dxa" w:w="7896"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Meaning
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1824"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Draft
<w:tcPr><w:tcW w:type="dxa" w:w="7896"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Provider assembling assertions/evidence/results
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1824"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Under Review
<w:tcPr><w:tcW w:type="dxa" w:w="7896"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Governance/assessment review active
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1824"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Published
<w:tcPr><w:tcW w:type="dxa" w:w="7896"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Available to eligible consumers
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1824"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Impacted
<w:tcPr><w:tcW w:type="dxa" w:w="7896"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Material provider change requires package review; policy determines continued reuse
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1824"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Superseded
<w:tcPr><w:tcW w:type="dxa" w:w="7896"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>New published version replaces default future use
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1824"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Retired
<w:tcPr><w:tcW w:type="dxa" w:w="7896"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Not available for new consumption; history retained
A Published RAP version is immutable.

## 21.5 RAP Consumption lifecycle
Possible states:
Candidate;
Applicable;
Attestation Required;
Active;
Partially Active;
Impacted;
Reassessment Required;
Not Applicable;
Conflict;
Ended/Superseded.

## 21.6 Evidence lifecycle
Candidate/Unreviewed -> Accepted/Validated -> Current -> Expiring -> Expired with possible Revoked or Impacted from any current state as policy permits.

## 21.7 Finding lifecycle
Open -> Triaged -> Remediation Planned -> In Remediation -> Ready for Validation -> Closed, with configured alternatives Accepted/Deferred, False Positive, Merged/Superseded.
Risk acceptance must be a separate authority record when used.

## 21.8 Promotion lifecycle
Local -> Submitted -> Duplicate Review -> Scope/Applicability Review -> Approved -> Published or Rejected/Kept Local.

## 21.9 Asset lifecycle
Local/Candidate -> Under Review -> Canonical/Active -> Superseded -> Retired
Rules: a local/candidate asset is immediately usable within its creating scope (18.1). Canonicalization occurs only through the promotion lifecycle (21.8). Superseding or retiring an asset MUST NOT break historical references (INV-002), and retired human-readable keys MUST NOT be reused where ambiguity could result (C.1). This lifecycle matches the Asset status vocabulary in the UX Specification, Appendix C.

# Part V - Platform Rule Services and Derived State

# 22. Audit Ledger and Domain Events

## 22.1 Audit versus domain event
The platform SHOULD distinguish:
Audit record: who changed what and when;
Domain event: meaningful business event that can trigger downstream rules.
Not every field edit needs to become a domain event, but every domain event should be auditable.

## 22.2 Material domain events
Examples:
OrganizationUnitCreated/Changed;
AssetCanonicalized;
ProductBaselinePublished;
ProfilePublished;
RAPPublished;
RAPImpacted;
RAPConsumed;
ComponentVersionChanged;
RequirementAdded/Changed;
CustomerOverrideApproved;
AssessmentStarted;
AssessmentSnapshotCreated;
ResponseSubmitted;
EvidenceAccepted/Expired/Revoked;
DeterminationRecorded;
FindingCreated/Closed;
RiskAccepted;
POAMItemCreated/Closed;
PromotionApproved;
SourceConflictDetected/Resolved.

## 22.3 Idempotency
Integrations and event handlers MUST be designed so replaying the same source event does not create duplicate canonical objects, duplicate findings, or repeated invalidation work.

## 22.4 Event causality
Material derived changes SHOULD preserve causal linkage.
Example:
ComponentVersionChanged -> RAPConsumptionImpacted -> ObjectiveReassessmentRequired -> WorkItemCreated
The UI should be able to explain that chain.

# 23. Derived Views and Calculation Semantics

## 23.1 Derived state principle
Dashboards SHOULD favor derived state over stored aggregates where consistency matters. Cached/indexed projections MAY be used for performance but MUST be rebuildable from canonical events/data.

## 23.2 System definition completeness
System completeness MUST NOT be presented as security satisfaction.
If implemented, completeness may include independent dimensions:
boundary defined;
required owners assigned;
expected component slots resolved;
component versions known;
interfaces/dependencies known;
obligations allocated;
implementation mapping coverage;
evidence mapping coverage.
The calculation definition MUST be transparent and SHOULD avoid a single deceptive percentage when dimensions differ materially.

## 23.3 Assessment state rollup
Rollups count objective states within a defined snapshot/scope. The denominator MUST be explicit.
Examples:
objectives in scope;
objectives resolved by current inheritance;
objectives satisfied by local determination;
other-than-satisfied;
insufficient information;
not assessed;
impacted/reassessment required.
“Not Applicable” SHOULD be displayed separately rather than silently removed from denominator unless the report definition explicitly says otherwise.

## 23.4 No synthetic security score
The core system MUST NOT reduce heterogeneous findings/objectives/unknowns into an opaque “X% secure” score.

## 23.5 Readiness
Program readiness MAY be expressed using explicit blocking conditions such as:
unresolved critical applicability decisions;
required assessment objectives without final determination;
open findings designated release/authorization blockers;
overdue POA&M milestones;
system definition unknowns that block assessment;
impacted inherited assurance awaiting review.
Readiness rules must be organization-configurable and explainable.

## 23.6 SCTM as a derived view
The Security Controls Traceability Matrix (SCTM) is a derived view over the canonical graph, not an independently edited artifact. For a declared scope and snapshot, the SCTM MUST be renderable per effective obligation with: the source/provenance stack; allocation to systems/components; implementation assertions and provider/consumer responsibilities where shared; supporting evidence references and their visibility state; assessment objective states and determinations; related findings, risks, and POA&M items; and open Unknowns and Conflicts.
Every SCTM cell MUST be traceable to canonical objects and rules (INV-023) and reproducible against the snapshot used to generate it (INV-002). An exported SCTM MUST identify its generation time and snapshot basis. Editing an exported SCTM does not change assurance truth; corrections flow through the canonical objects and rules.

# 24. Domain Service Contracts
These are logical domain services. Physical service boundaries are an engineering architecture decision.

## 24.1 Scope Resolver
Input: user/action, target object, requested operation.
Output: effective scope, ownership, authorization context, inheritance ancestors/consumers as needed.
Must not conflate org ancestry with system composition.

## 24.2 Obligation Resolver
Input: scope/program/system + effective time/snapshot.
Output: effective controls/requirements/parameters with full provenance and conflicts.

## 24.3 Applicability Evaluator
Input: rule version + candidate consumer facts.
Output: Applicable, Not Applicable, Unknown, Conflict, or Review Required; facts used; facts missing; source versions.

## 24.4 Assurance Inheritance Resolver
Input: consumer subject/scope, obligation/objective set, time/snapshot.
Output: candidate provider sources, RAP consumptions, resolved responsibilities, residual responsibilities, inheritance state, explanation graph.

## 24.5 Assessment Planner
Input: assessment scope, objective set, snapshot policy, available reusable assurance, template versions.
Output: objective-resolution plan, assignment-package candidates, tasks, inheritance/attestation work, unresolved applicability items.

## 24.6 Assessment Reviewer Service
Input: objective, responses, observations, evidence, inherited results, snapshot, reviewer authority.
Output: reviewer workspace; accepted input records; final determination when authorized; finding creation linkage.
The service MUST NOT auto-determine solely from contributor answers.

## 24.7 Evidence Evaluator
Input: evidence + candidate assertion/objective/consumer/snapshot.
Output: current/applicable status, visibility, freshness, trust metadata, review requirements.

## 24.8 Change Impact Engine
Input: ChangeEvent.
Output: affected graph nodes, impact classification, required review/reassessment/work, causal explanation.

## 24.9 Conflict Service
Input: incompatible assertions/facts/requirements.
Output: conflict record, materiality, responsible authority, blocked dependent decisions, resolution lineage.

## 24.10 Promotion Service
Input: local object/version + proposed destination scope.
Output: duplicate candidates, required destination owner/review, promotion state, published canonical identity/version if approved.

## 24.11 Snapshot Service
Input: assessment/program milestone + requested snapshot policy.
Output: immutable snapshot manifest of pinned versions/facts/relationships required for historical reconstruction.

## 24.12 Explainability Service
Every major derived state SHOULD support a consistent “Why?” contract that returns:
direct sources;
rule version(s);
facts used;
decisions/approvals;
inheritance/provider chain;
conflicts/unknowns;
current blockers;
causal change event where relevant.

# 25. Worked Scenarios

## 25.1 Enterprise IAM inherited by Nightwing
Provider state
Enterprise IAM publishes RAP v4.2. It supports defined IA/AC objective portions. The package states that Enterprise IAM authenticates enterprise identities and manages credential lifecycle, while consumer systems remain responsible for role assignment and privileged-access review.
Applicability rule
Consumer must:
consume Enterprise IAM production service;
use approved protocol/configuration;
not bypass IAM with local password authentication;
fall within declared organization/program reuse policy.
Nightwing facts
Nightwing System A consumes Enterprise IAM using approved configuration. Facts are current and source-linked.
Resolution
provider objectives -> Resolved by inheritance;
privileged role assignment -> residual local task;
quarterly local entitlement review -> residual local task;
evidence backing Enterprise IAM assessment -> metadata visible, detailed content restricted.
Result
Nightwing does not re-ask Enterprise IAM how identities are authenticated. It assesses only local responsibilities and any customer-specific strengthening requirements.

## 25.2 Customer password requirement
Organization profile defines password minimum length 15. Customer requirement CR-118 requires minimum 24 for Nightwing.
The system stores both assertions and maps CR-118 as a strengthening requirement. Program Security approves effective parameter 24 for the relevant systems.
The effective value is derived. The organization baseline remains 15. Other programs are unaffected.
If one Nightwing system inherits Enterprise IAM and Enterprise IAM is configured at 15 globally, the system detects that the consumer cannot satisfy the 24-character customer requirement through the inherited provider configuration. The inherited implementation is therefore insufficient for the strengthened obligation even if it remains valid for the organization baseline. A local/provider change or exception decision is required.

## 25.3 Secure Boot product variant
Falcon v6 baseline uses TPM Y, Bootloader 4.2, Signing Service v3, and Secure Boot RAP v4.
Nightwing variant changes TPM Y to TPM Z.
Change Impact Engine traverses:
TPM component -> Secure Boot implementation assertion -> RAP applicability condition -> inherited evidence -> assessment objectives
The rule says TPM Y or approved equivalent list is required. TPM Z is not yet on the approved list.
Result:
RAPConsumption becomes Review Required/Impacted;
three objectives move to Reassessment Required;
evidence tied to TPM Y becomes impacted for Nightwing;
unaffected secure-boot objectives remain inherited;
a task is assigned to the secure-boot owner to validate TPM Z and update package/baseline if reusable.
The system does not mark all Secure Boot controls failed.

## 25.4 New system with incomplete architecture
Nightwing creates Tactical Management Controller with no reusable baseline.
Known facts:
system owner assigned;
network interface expected;
processor/SoC unknown;
bootloader unknown;
Enterprise IAM usage undecided.
The system creates Unknown placeholders and discovery tasks. Applicability for authentication objectives returns Unknown because the authentication architecture is not known.
No objectives are silently marked Not Applicable. Assessment Planner waits or generates the minimum discovery/applicability tasks necessary before creating substantive authentication tasks.
An engineer identifies AMD XYZ as the SoC. It is created as program-local Asset and used immediately. Later, a Promotion Request proposes it for canonical Asset Catalog inclusion.

## 25.5 Organization-first ad hoc assessment creates reusable knowledge
Enterprise PKI team launches an assessment of the Firmware Signing service.
During assessment:
policy/procedure links are captured;
service/component assets are canonicalized;
implementation assertions are reviewed;
assessment objectives are determined;
evidence is validated;
two findings are remediated.
After successful reassessment, the team publishes Firmware Signing RAP v1.0.
Future products that consume the service under declared conditions can resolve provider-side objectives by inheritance while retaining local signing-key/request responsibilities.

## 25.6 Source conflict during assessment
A program baseline says Bootloader 4.2. CI/build metadata says production image contains Bootloader 4.4. Engineer confirms 4.4 was deliberately adopted.
The platform creates a SourceConflict rather than silently updating the baseline.
The reviewer determines the actual assessed system is 4.4, creates/adopts the relevant change in the assessment snapshot, and routes a correction/update to product baseline owners. Any assurance depending on 4.2-specific evidence is re-evaluated.
Historical Falcon v6 baseline remains 4.2 until a new baseline/version is published.

## 25.7 Restricted evidence reuse
Enterprise vulnerability management assessment is supported by sensitive scan results. Organization policy permits downstream systems to inherit the approved determination but not view raw scan data.
The RAP exposes:
provider/service;
objectives supported;
assessment date/outcome;
assessor/authority;
evidence status = validated/restricted;
consumer residual responsibilities.
Nightwing can inherit the result without direct evidence access. The audit record shows that the provider assessor had access to evidence and approved reuse.

# 26. MVP Domain Contract and Deferred Semantics

## 26.1 MVP rules that MUST exist from day one
The MVP may simplify interfaces and automation, but it MUST preserve these semantic boundaries:
stable identity and scope;
organization hierarchy separate from asset/system graph;
Asset common identity with local/canonical lifecycle;
imported control/objective identity/version;
Requirement separate from Control;
Response separate from Determination;
Evidence with provenance and scope;
explicit Unknown;
published version immutability;
RAP family/version and consumer residual responsibility;
structured applicability with Unknown/Review states;
reference-based inheritance with explanation;
assessment snapshot sufficient for historical reconstruction;
Conflict first-class rather than overwrite;
Finding separate from Risk and Remediation;
promotion without historical rewrite;
audit of material changes.

## 26.2 MVP simplifications allowed
The MVP MAY:
support a limited applicability predicate vocabulary;
require manual creation/approval of RAPs;
use manual source authority configuration;
support one final assessment snapshot rather than multiple snapshot phases;
compute impact synchronously for small graphs;
expose restricted evidence as metadata-only without fine-grained field-level policies;
support limited product/system asset types;
use manually configured routing rules;
defer full bi-temporal database implementation while retaining required timestamps/version references;
defer automatic deduplication to suggestion/manual review;
export only the standards artifacts required for pilots.

## 26.3 Semantics that MUST NOT be deferred even if UI is deferred
Engineering MUST NOT choose a schema that makes the following impossible without destructive migration:
many-to-many provider/consumer responsibility;
partial inheritance;
version-pinned RAP consumption;
assessment snapshots;
multiple source assertions/conflicts;
evidence visibility separate from result visibility;
historical reconstruction;
program-local objects promoted later;
objective-level determination lineage;
change dependency traversal.

# 27. Acceptance and Conformance Scenarios
The domain implementation is conformant only if these scenarios can be represented without special-case side databases or destructive edits.

## 27.1 Identity and scope
Rename an organizational unit without changing object identity or breaking historical ownership references.
Move a team to a new parent unit without rewriting historical assessment scope.
Use one Enterprise IAM asset across three product systems owned by different units.
Create a program-local component and later link/promote it to canonical identity without rewriting past assessment references.

## 27.2 Obligations
Import a new NIST catalog release while retaining historical programs on their pinned source/profile versions.
Apply a customer strengthening requirement without editing source NIST control text.
Preserve organization parameter 15 and program customer parameter 24 while deriving effective 24 for the program.
Represent an unresolved parameter conflict without choosing a value.

## 27.3 RAP and inheritance
Publish Enterprise IAM RAP v4.2 with provider and consumer responsibilities.
Consume RAP v4.2 in Nightwing and resolve only provider-side objectives.
Require a consumer attestation before activating inheritance.
Restrict evidence visibility while allowing approved determination reuse.
Publish RAP v4.3 without silently updating Nightwing from v4.2.
Mark v4.2 impacted and identify every active consumer.

## 27.4 Assessment
Launch an organization-unit assessment and a program-system assessment through the same canonical assessment engine.
Resolve current inherited objectives before task generation.
Delegate an assignment package to a team, then individual tasks to SMEs.
Accept a contributor Response without producing a Determination.
Request clarification while preserving the first response.
Record a Satisfied determination against an immutable assessment snapshot.
Record Other Than Satisfied and create a Finding.

## 27.5 Unknown and conflict
Create a system with unknown SoC and authentication architecture and ensure no related objectives become N/A automatically.
Detect PLM = TPM Y versus program observation = TPM Z and preserve both assertions.
Resolve the source conflict with an authority decision and trigger impact analysis.

## 27.6 Change and invalidation
Change a component version and reopen only impacted objectives.
Expire an evidence item and identify RAP consumptions relying on it.
Change customer requirement after an assessment snapshot and require reviewer decision before changing assessment basis.
Retain historical satisfied determination even after current reuse becomes impacted.

## 27.7 Findings and closure
Link one Finding to multiple objectives and assets.
Group multiple Findings into one Remediation Initiative.
Create a POA&M Item for one affected system without forcing every related finding into a POA&M.
Accept risk only through explicit authority record.
Close remediation but keep assurance impacted until required reassessment succeeds.

## 27.8 Promotion and history
Promote a program-authored policy to an organizational unit after review.
Publish a new canonical assessment template version while old assessments retain original wording/version.
Deduplicate a local component against existing canonical identity.
Show that the next program reuses newly promoted assurance while the prior program retains its original historical references.

# Appendix A. Glossary
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="4997"/><w:gridCol w:w="4997"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Term
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Definition
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Applicability
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Structured evaluation of whether an obligation, implementation, RAP, evidence item, or result applies to a candidate scope/subject.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Bounded execution that evaluates objectives for declared subjects/scope/time.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment Objective
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Canonical determination target used by an assessment.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment Snapshot
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Immutable manifest of the relevant versions/facts/context that formed the basis of an assessment determination/result.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Asset
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Common assurance-relevant subject identity: policy, procedure, service, product, system, component, process, etc.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Capability
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Logical grouping of assets/components/processes jointly providing a reusable function; unrelated to maturity models.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Conflict
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>First-class record of materially incompatible assertions requiring adjudication.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Determination
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Authorized assessment conclusion for one objective at a declared scope/snapshot/time.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Evidence
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Structured record of an artifact or machine/human-produced result supporting assurance analysis.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Finding
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Identified assurance gap/issue requiring disposition.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Implementation Assertion
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Claim describing how a subject contributes to an obligation under explicit conditions/responsibilities.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Inheritance
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Derived reuse of approved higher/reusable assurance when scope/applicability/validity/responsibility conditions are met.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Observation
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Structured fact/result recorded during assessment.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Program
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Delivery/customer context combining effective obligations and one or more system instances.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Promotion
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Governed movement of validated local knowledge to broader reusable scope.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>RAP
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Reusable Assurance Package: governed provider package of implementations, supported obligations, assessment basis, applicability, validity, and residual consumer responsibilities.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Requirement
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Organization/customer/product/program obligation stored separately from immutable source control text.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Response
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Contributor-provided answer/submission; not a final determination.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Scope
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Domain boundary at which an object/assertion is authored, governed, assessed, or applicable.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>SCTM
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Security Controls Traceability Matrix: derived traceability view rendering effective obligations, allocations, implementations, evidence, assessment states, and dispositions for a scope/snapshot (23.6). Exported as the program workbook artifact.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>SourceConflict
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Conflict specifically between claims from separate source systems/actors.
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1778"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Unknown
<w:tcPr><w:tcW w:type="dxa" w:w="7942"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Explicit lack of sufficient fact; not equivalent to false, absent, N/A, or failed.

# Appendix B. Relationship Catalog
<w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:type="dxa" w:w="9720"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/><w:tblLook w:firstColumn="1" w:firstRow="1" w:lastColumn="0" w:lastRow="0" w:noHBand="0" w:noVBand="1" w:val="04A0"/></w:tblPr><w:tblGrid><w:gridCol w:w="2498"/><w:gridCol w:w="2498"/><w:gridCol w:w="2498"/><w:gridCol w:w="2498"/></w:tblGrid><w:tr><w:trPr><w:tblHeader w:val="true"/></w:trPr><w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>From
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Relationship
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>To
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="D9EAF7"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:b/><w:color w:val="17365D"/><w:sz w:val="16"/></w:rPr><w:t>Semantic note
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Organization Unit
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>parent_of
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Organization Unit
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Responsibility hierarchy only
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Organization Unit
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>owns
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Asset
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Default ownership/routing; not technical containment
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Asset
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>contains
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Asset
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Technical/logical composition
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Asset
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>depends_on
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Asset
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Change-impact dependency
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>System
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>consumes_service
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Asset/Capability
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Enables candidate assurance-package reuse
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Product Baseline
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>includes
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>System Template/Asset
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Immutable baseline composition
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>System Instance
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>derived_from
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Product/System Baseline
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Pins source baseline version
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Requirement
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>mapped_to
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Control/Objective
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Relationship type required
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Implementation Assertion
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>supports
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Requirement/Control/Objective
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Does not itself create satisfaction
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Implementation Assertion
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>provided_by
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Asset/Capability
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Provider responsibility
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>RAP
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>packages
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Implementation Assertion/Determination/Evidence
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Reusable assurance unit
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>RAP
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>applicable_to
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Consumer predicate
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Structured rule, not direct static list only
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>RAP Consumption
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>consumes
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>RAP Version
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Version-pinned provider/consumer link
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>targets
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Scope/Asset/System/Program
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment subject
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment Task
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>supports
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment Objective
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Many-to-many allowed
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Response
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>answers
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment Task
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Contributor input
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Observation
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>derived_from
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Response/Evidence/Test
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Structured fact/result
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Determination
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>evaluates
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assessment Objective
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Snapshot-bound authority decision
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Determination
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>supported_by
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Observation/Evidence/Inherited Result
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Provenance
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Finding
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>arises_from
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Determination/Observation
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Gap lineage
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Finding
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>contributes_to
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Risk
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Many-to-many
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Remediation Initiative
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>addresses
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Finding
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Grouped corrective work
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>POA&M Item
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>tracks
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Finding/Risk
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Formal system/program remediation
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Promotion Request
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>proposes
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Local Object Version
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Broader canonicalization
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>ChangeEvent
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>impacts
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Domain Object
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Causal impact graph
<w:tc><w:tcPr><w:tcW w:type="dxa" w:w="1678"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Conflict
<w:tcPr><w:tcW w:type="dxa" w:w="1428"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>concerns
<w:tcPr><w:tcW w:type="dxa" w:w="2657"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Assertion/Object
<w:tcPr><w:tcW w:type="dxa" w:w="3957"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="70" w:type="dxa"/><w:start w:w="85" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:end w:w="85" w:type="dxa"/></w:tcMar><w:shd w:fill="FAFCFD"/></w:tcPr><w:p><w:pPr><w:pStyle w:val="Compact"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="16"/></w:rPr><w:t>Preserves contradictory claims

# Appendix C. Recommended Identifiers and Required Metadata

## C.1 Identifier conventions
Human-readable keys MAY exist for usability, but canonical references MUST use stable machine identifiers.
Examples:
asset_uuid + display key AST-00142;
requirement_uuid + display key REQ-IAM-014;
finding_uuid + display key FND-00218;
rap_uuid + version 4.2;
imported control retains source key AC-2 plus source catalog/version identity.
Human-readable keys MUST NOT be reused after retirement if doing so would create historical ambiguity.

## C.2 Required cross-cutting metadata
Most governed objects SHOULD support:
id;
display name/key;
type;
scope;
owner;
lifecycle state;
created/updated actor/time;
source/provenance;
version/effective interval where relevant;
sensitivity/marking;
tags/custom metadata only where they do not replace canonical semantics.

# Appendix D. Open Domain Decisions
The following require architecture/security-authority validation before the domain contract is considered fully locked:
1. Exact canonical Asset subtype set for R0/R1.
2. Whether Capability is always an Asset subtype or may remain a separate grouping entity with optional Asset identity.
3. Exact CNSSI-derived categorization/profile entities and parameter sources used by the organization.
4. Which RAP/result reuse rules require explicit consumer attestation versus automatic applicability.
5. Default RAP validity and provider change-review policy.
6. Whether final assessment outcomes require vocabulary beyond Satisfied / Other Than Satisfied / N/A in the target authorization process.
7. Evidence integrity requirements for machine-generated and restricted evidence.
8. Required markings model and cross-program metadata visibility.
9. Required temporal reconstruction level and whether the persistence architecture implements full bi-temporal history.
10. Which source systems are authoritative for which Asset/System attributes in the first pilot.
11. Whether organization-level ad hoc assessments publish reusable Determinations directly or only through a RAP/publication review. Working assumption pending decision: publication occurs through RAP review (UX Specification 36.1).
12. Exact policy for combining multiple partial provider packages supporting the same objective.
13. Which domain events require synchronous versus queued impact resolution.
14. Data retention and archival requirements for historical assessments, evidence references, and audit events.
Definition of a stable domain foundation Product, UX, and engineering can independently implement the platform without inventing different meanings for identity, scope, applicability, inheritance, evidence, assessment, conflict, versioning, or historical truth. A program can explain every effective obligation and inherited result; an assessment can reconstruct exactly what was assessed; a provider can publish reusable assurance without granting unnecessary evidence access; and any material change can be traced to the assurance state it may affect.