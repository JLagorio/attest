# Program Assurance Design System

Design system for the **Program Assurance Platform** — an internal assessment-and-inheritance operating system for cybersecurity program assurance. It manages who is responsible (organization units, owners, delegation), what exists (assets, shared services, products, systems), and what must be true (NIST SP 800-53/53A controls, requirements, assessments, evidence, findings, risks & POA&M) as one living, versioned graph. Assurance is established once at the highest valid scope and reused everywhere it still applies — as a governed reference with conditions and provenance, never a copy.

This is a **high-density operational workspace** for professionals (SSEs, GRC leads, assessors, engineers) on large monitors in long sessions — never a marketing surface. The visual language is engineered for credibility: restrained, factual, dense.

## Sources
- `uploads/Program_Assurance_Platform_Vision_One_Pager_v1.0.docx` — the story on a page
- `uploads/Program_Assurance_Platform_PRD_v1.1.docx` — users, journeys, product model, nav
- `uploads/Program_Assurance_Platform_Product_System_Spec_v1.1.docx` — operating model
- `uploads/Program_Assurance_Platform_Domain_Rules_Spec_v1.1.docx` — canonical semantics
- `uploads/Program_Assurance_Platform_UX_Workflow_Interaction_Spec_v1.1.docx` — workflows, routes, status/action vocabularies (Appendices A–E). **Explicitly leaves visual brand, color, typography, and component library undefined** — this design system fills that gap.
- `uploads/*.png|webp` — competitor/market screenshots (Tenable et al.), provided as **examples only** for density reference. Their brand is not copied.
- Extracted doc text: `research/*.md`; condensed domain vocabulary: `research/DIGEST.md`.

No Figma, codebase, logo, or font files were provided. **There is no logo**: render the product name in plain type (Public Sans 600) wherever a mark would go. Never invent a mark.

## The four product areas (navigation)
Foundation: **Home · Organization · Assets** — Obligations: **Library** — Delivery: **Products & Systems · Programs** — Assurance work: **Assessments · Findings · Risks & POA&M**

---

## CONTENT FUNDAMENTALS

**Voice.** Sober, precise, declarative. The product states facts and names obligations; it never markets, celebrates, or hedges. No exclamation points, no emoji, ever.

**Casing.** Sentence case for everything — headings, buttons, labels, column headers. Nothing renders uppercase. Domain states are proper labels and keep their canonical capitalization: `Satisfied`, `Other Than Satisfied`, `Inherited – Current`, `Unknown`.

**Name the authority-bearing action.** Buttons say what the click legally does: `Record determination`, `Accept as input`, `Publish v4.3`, `Create finding`, `Request clarification`, `Resolve conflict`, `Promote`. Never `Submit`, `OK`, `Approve`, `Get started`, `Learn more`. Full verb list in `research/DIGEST.md`.

**Contributor vs reviewer register.** Tasks addressed to contributors are plain language, second person, one ask: *"Describe how privileged account requests are approved for the Tactical Management Controller and link the current procedure."* Reviewer surfaces use domain terminology with full lineage (control, objective, snapshot, provider).

**Facts over adjectives.** Counts and states, not qualitative claims: *"Resolves 38 objectives · 7 residual tasks · 2 attestations required."* Never "almost done", never a percent-secure score.

**Unknown is honest.** Missing knowledge is labeled `Unknown` with an owner and a path to resolution — never silently `N/A`, never blank. Empty values render as an em-dash (—).

**Provenance is a sentence away.** Every derived state can answer "Why is this here?" — e.g. *"Inherited from Enterprise IAM Assurance Package v4.2 · condition: production SSO configuration · reviewed Mar 14, 2026."*

**Timestamps.** Relative under 24h (`2m ago`, `6h ago`), `Yesterday`, then absolute date (`Mar 14`); add year when not current (`Nov 2, 2025`). Deadlines always absolute.

---

## VISUAL FOUNDATIONS

**Feel.** Light fintech-dashboard language: white chrome, hairline separation, soft layered shadows on controls and cards, borderless pill statuses, sentence-case labels, accent-colored selection. Density comes from type and rhythm, not darkness.

**Temperature.** One committed cool-slate neutral ramp (`--n-0…--n-10`), 11 steps. App chrome and cards sit on white (`#FFFFFF`); wells and hovers at steps 1–2 (`--surface-well`, `--surface-inset`), borders at 3–4 (as alpha), secondary text 6–7, primary text 9–10; darkest text `#141927`. Light theme only (v1); dark mode is not defined yet.

**Accent.** Exactly one hue — deep federal indigo-blue `--accent: #2E5AC7`. It appears at most three times per viewport and marks only: the primary action, the current selection, and focus. Never decoration, never gradients, never large fills.

**Semantic states.** Triplets (text / border / bg at 8–12% alpha over surface), never solid saturated fills — status badges are borderless tinted pills: `ok` green, `warn` amber, `danger` red, `info` cyan-blue — plus a domain-mandated fifth: **`unknown` violet**, because Unknown is first-class truth in this product. Neutral gray chip for lifecycle states (Draft, Closed, Retired). **Inherited/derived values** get the teal `inherited` treatment plus a non-color cue (↧ glyph or dashed underline) so provenance survives grayscale.

**Borders.** Neutral-10 at alpha (`rgba(20,25,39,.08/.13/.22)`), never solid gray steps. Hairlines separate; whitespace groups (≤8px inside a component, ≥12px between components).

**Elevation.** Soft layered shadows are part of the language: keyline (`--elev-keyline`) on buttons/inputs, raised (`--elev-raised`) on cards and tables, float (`--elev-float`) on dialogs, drawers, popovers. Always paired with a hairline border; never a single heavy blur, never shadow as decoration.

**Radius.** 6px controls and inputs · 8px cards and tables · 12px overlays · 9999px pills, badges, avatars. Nothing larger, ever.

**Type.** Public Sans (UI) + IBM Plex Mono (control IDs, versions, evidence refs, tabular numerics). Scale: 12/500 (column headers, group labels — sentence case, never uppercase) · 12 (meta) · 13 (compact grids only) · **14 (the working default — tables, body, controls)** · 16/600 (section and card headers) · 24/700 (page title) · 28/600 (overview metrics). Numerics always `font-variant-numeric: tabular-nums`. Line-height 1.45 dense, 1.55 prose.

**Spacing.** 2/4/6/8/12/16/24/32/48 only. Density tiers per surface: Compact (32px rows, 28px controls) for data grids; Default (40/32) for lists, forms, toolbars; Comfortable (48/40) for dialogs and settings. Tiers mix on one screen deliberately.

**Layout shell.** 240px nav rail (collapsible to 48px icon dock; items show counts, not just labels) · scrollable canvas owning a sticky 40px toolbar (primary action, filters, view switcher; table headers stick under it) · 320px inspector, collapsible, with defined empty and multi-select states. Backgrounds are flat token surfaces — no imagery, no textures, no gradients anywhere.

**Motion.** 120ms ease-out state changes · 180ms cubic-bezier(.32,.72,0,1) panels · 0ms for keyboard-triggered changes. Nothing animates on page load. `prefers-reduced-motion` collapses both to 0.

**Interaction states.** Hover = background shift to `--surface-well` (never opacity-only). Press = one shade darker, no shrink. Focus = `:focus-visible` only: 1px accent line + 4px soft accent halo. Selected = `--selection-bg` wash; nav items and tabs turn `--accent-text`. Disabled = `--text-disabled` + 55% opacity on controls only.

**Data display.** Skeletons match real row geometry (never a centered spinner). Truncation: ellipsis + `title`; long cells clamp at 2 lines. Counts >999 abbreviate (`1.2k`), >9999 cap (`999+`). Null = em-dash. One value per table should demonstrate truncation.

**Intelligence in the UI.** AI never chats: proposals land as **pending mutations** in the real UI (`--pending-bg` cell wash, strikethrough original, per-unit Accept/Reject), always attributable (provenance chip: source, confidence, timestamp, revert) and reversible. Streaming = progressive materialization into final geometry. Long work lives in a jobs tray, completion marks the object. Failures set a `needs review` state on the object itself — they do not evaporate with a toast.

---

## ICONOGRAPHY

**System: [Lucide](https://lucide.dev) via CDN, pinned.** The sources contain no icon assets and no icon font, so Lucide (ISC license) was selected for its 1.5px-stroke consistency at 16px — a documented substitution, flagged for review. No hand-drawn SVGs, no emoji, no mixed sets.

Load once per page: `<script src="https://unpkg.com/lucide@0.460.0/dist/umd/lucide.min.js"></script>` — then either the React `Icon` component (`components/core/Icon.jsx`) or, in static HTML, `<i data-lucide="name"></i>` + `lucide.createIcons()`.

Default size 16px, stroke 1.75 at 16px / 1.5 at 20px+, color inherits `currentColor`. Icons are always paired with text except in the icon dock and IconButtons (which require `aria-label` + tooltip).

**Canonical assignments** (do not improvise): Home `home` · Organization `building-2` · Assets `boxes` · Library `library` · Products & Systems `layers` · Programs `clipboard-list` · Assessments `inbox` · Findings `flag` · Risks & POA&M `shield-alert` · Unknown `circle-dashed` · Inherited/provenance `git-branch` · Evidence `file-text` · AI-derived `sparkles` · warning `triangle-alert` · error `circle-alert` · info `info` · help `circle-help` · clarification `message-square`. Unicode glyphs used as text, not icons: `↧` inherited mark, `—` null, `·` separator.

---

## Index

- `styles.css` — global entry (imports everything below)
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `effects.css`, `fonts.css`, `base.css`
- `guidelines/` — foundation specimen cards (Design System tab: Colors, Type, Spacing, Patterns groups)
- `components/` — React primitives, grouped:
  - `core/` Icon, Kbd
  - `forms/` Button, IconButton, Input, Select, Checkbox, Radio, Switch
  - `display/` Card, Badge, StatusBadge, Tag, ProvenanceChip, Skeleton, EmptyState
  - `overlay/` Dialog, Drawer, Tooltip, Toast
  - `navigation/` Tabs
  - `data/` Table, DiffValue
- `ui_kits/platform/` — full-screen interactive recreation of the platform (Home, Assessment review, Findings, Program overview)
- `research/` — extracted spec text + `DIGEST.md` (domain vocabulary: statuses, actions, routes)
- `SKILL.md` — agent skill entry point

**Intentional additions** (no component inventory existed in sources; standard set sized to the product, plus):
- `StatusBadge` — maps the canonical Appendix C status vocabulary to semantic tones so status coloring is never improvised.
- `ProvenanceChip` — the "why is this here" affordance (inherited / AI-derived / imported values).
- `DiffValue` — pending-mutation rendering (AI proposals as reviewable diffs, per Layer-4 pattern).
- `Kbd` — keyboard-first workflows require keycap rendering in tooltips and menus.

## Caveats
- **Fonts substituted:** no font files were provided. Public Sans + IBM Plex Mono loaded from Google Fonts (`tokens/fonts.css`). Provide real brand fonts to replace.
- **Icons substituted:** Lucide via CDN (pinned 0.460.0), offline use requires vendoring the files.
- **No logo provided** — plain-type wordmark used; supply a mark to replace.
- Light theme only; dark mode tokens not yet defined.
