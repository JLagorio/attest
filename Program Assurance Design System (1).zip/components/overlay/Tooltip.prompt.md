Hover/focus label; mandatory on icon-only controls; shows the shortcut keycap.

```jsx
<Tooltip content="Record determination" kbd="D"><IconButton icon="check" label="Record determination" /></Tooltip>
```
