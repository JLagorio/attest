import { IconButton } from '../forms/IconButton.jsx';
export function Drawer({ open, onClose, title, wide, headerExtra, children }) {
  React.useEffect(() => {
    if (!open) return;
    const onKey = e => { if (e.key === 'Escape' && onClose) onClose(); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <React.Fragment>
      <div className="pa-drawer-scrim" onMouseDown={onClose} />
      <aside className={'pa-drawer' + (wide ? ' pa-drawer--wide' : '')} role="dialog" aria-label={typeof title === 'string' ? title : undefined}>
        <div className="pa-drawer-h">
          <span className="pa-dialog-title" style={{ flex: 1 }}>{title}</span>
          {headerExtra}
          <IconButton icon="x" label="Close" size="compact" onClick={onClose} />
        </div>
        <div className="pa-drawer-b">{children}</div>
      </aside>
    </React.Fragment>
  );
}
