import { IconButton } from '../forms/IconButton.jsx';
export function Dialog({ open, onClose, title, footer, width = 480, children }) {
  React.useEffect(() => {
    if (!open) return;
    const onKey = e => { if (e.key === 'Escape' && onClose) onClose(); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="pa-scrim" onMouseDown={e => { if (e.target === e.currentTarget && onClose) onClose(); }}>
      <div className="pa-dialog" role="dialog" aria-modal="true" aria-label={typeof title === 'string' ? title : undefined} style={{ width }}>
        <div className="pa-dialog-h">
          <span className="pa-dialog-title">{title}</span>
          {onClose ? <IconButton icon="x" label="Close" size="compact" onClick={onClose} /> : null}
        </div>
        <div className="pa-dialog-b">{children}</div>
        {footer ? <div className="pa-dialog-f">{footer}</div> : null}
      </div>
    </div>
  );
}
