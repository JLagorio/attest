Modal for authority-bearing decisions. Footer names the action.

```jsx
<Dialog open={open} onClose={close} title="Record determination"
  footer={<><Button onClick={close}>Cancel</Button><Button variant="primary">Record determination</Button></>}>
  …
</Dialog>
```
