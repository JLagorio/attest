/** Modal for consequential, authority-bearing decisions (Record determination, Publish, Resolve conflict). Footer names the action — never "OK". Esc and scrim-click close. */
export interface DialogProps {
  open: boolean;
  onClose?: () => void;
  title: React.ReactNode;
  /** Right-aligned action row; primary action last */
  footer?: React.ReactNode;
  /** @default 480 */
  width?: number;
  children?: React.ReactNode;
}
export declare function Dialog(props: DialogProps): JSX.Element | null;
