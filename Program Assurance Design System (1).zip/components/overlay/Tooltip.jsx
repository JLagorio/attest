import { Kbd } from '../core/Kbd.jsx';
export function Tooltip({ content, kbd, children, style }) {
  return (
    <span className="pa-tt" style={style}>
      {children}
      <span className="pa-tt-bubble" role="tooltip">
        {content}
        {kbd ? <Kbd>{kbd}</Kbd> : null}
      </span>
    </span>
  );
}
