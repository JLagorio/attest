/** Hover/focus label. Mandatory on icon-only controls; shows the shortcut keycap when one exists. */
export interface TooltipProps {
  content: React.ReactNode;
  /** Shortcut key shown as a keycap, e.g. "D" */
  kbd?: string;
  /** The trigger element */
  children: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Tooltip(props: TooltipProps): JSX.Element;
