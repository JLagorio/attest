Job-completion notice only — never the sole error surface (errors persist inline on the object).

```jsx
<Toast tone="ok" title="Workbook export finished" onDismiss={hide}
  action={<Button size="compact" variant="ghost" icon="download">Download SCTM.xlsx</Button>}>
  842 rows · Program NIGHTHAWK · 14s
</Toast>
```
