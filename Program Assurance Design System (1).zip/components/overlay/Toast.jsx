import { Icon } from '../core/Icon.jsx';
import { IconButton } from '../forms/IconButton.jsx';
const PA_TOAST_ICONS = { ok: 'check', info: 'info', warn: 'triangle-alert', danger: 'circle-alert' };
const PA_TOAST_COLORS = { ok: 'var(--ok-text)', info: 'var(--info-text)', warn: 'var(--warn-text)', danger: 'var(--danger-text)' };
export function Toast({ tone = 'info', title, action, onDismiss, children, style }) {
  return (
    <div className="pa-toast" role="status" style={style}>
      <Icon name={PA_TOAST_ICONS[tone]} size={16} style={{ color: PA_TOAST_COLORS[tone], marginTop: 1 }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div className="pa-toast-title">{title}</div>
        {children ? <div className="pa-toast-body">{children}</div> : null}
        {action ? <div style={{ marginTop: 'var(--sp-6)' }}>{action}</div> : null}
      </div>
      {onDismiss ? <IconButton icon="x" label="Dismiss" size="compact" onClick={onDismiss} /> : null}
    </div>
  );
}
