Right-side panel — the Why/Provenance drawer, evidence detail, quick inspect. 320px, wide=480px.

```jsx
<Drawer open={open} onClose={close} title="Why is this here?">…</Drawer>
```
