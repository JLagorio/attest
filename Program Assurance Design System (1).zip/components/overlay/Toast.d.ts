/** Transient notice for job completion and confirmations only. Never the sole error surface — errors persist inline on the affected object. */
export interface ToastProps {
  /** @default "info" */
  tone?: 'ok' | 'info' | 'warn' | 'danger';
  title: React.ReactNode;
  /** Optional action, e.g. a "View results" ghost button */
  action?: React.ReactNode;
  onDismiss?: () => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Toast(props: ToastProps): JSX.Element;
