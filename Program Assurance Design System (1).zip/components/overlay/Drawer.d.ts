/** Right-side overlay panel — the "Why / Provenance" drawer, evidence detail, quick inspect. 320px (wide: 480px). */
export interface DrawerProps {
  open: boolean;
  onClose?: () => void;
  title: React.ReactNode;
  /** 480px instead of 320px */
  wide?: boolean;
  /** Extra header controls before the close button */
  headerExtra?: React.ReactNode;
  children?: React.ReactNode;
}
export declare function Drawer(props: DrawerProps): JSX.Element | null;
