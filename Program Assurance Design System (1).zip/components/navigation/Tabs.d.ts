/** Underline tabs for views of one object (Overview / Requirements / Inheritance / Findings). Counts on tabs whenever the view is a list. */
export interface TabsProps {
  tabs: { id: string; label: React.ReactNode; count?: number; icon?: string }[];
  /** Selected tab id */
  value: string;
  onChange?: (id: string) => void;
  style?: React.CSSProperties;
}
export declare function Tabs(props: TabsProps): JSX.Element;
