Underline tabs for views of one object; list views carry counts.

```jsx
<Tabs value={tab} onChange={setTab} tabs={[
  {id:'overview',label:'Overview'},
  {id:'objectives',label:'Objectives',count:142},
  {id:'findings',label:'Findings',count:7},
]} />
```
