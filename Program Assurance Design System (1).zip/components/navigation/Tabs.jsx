import { Icon } from '../core/Icon.jsx';
export function Tabs({ tabs = [], value, onChange, style }) {
  return (
    <div className="pa-tabs" role="tablist" style={style}>
      {tabs.map(t => (
        <button key={t.id} type="button" role="tab" className="pa-tab" aria-selected={t.id === value}
          onClick={() => onChange && onChange(t.id)}>
          {t.icon ? <Icon name={t.icon} size={14} /> : null}
          {t.label}
          {t.count != null ? <span className="pa-tab-count">{t.count > 999 ? '999+' : t.count}</span> : null}
        </button>
      ))}
    </div>
  );
}
