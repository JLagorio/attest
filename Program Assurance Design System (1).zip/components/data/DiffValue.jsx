import { Icon } from '../core/Icon.jsx';
export function DiffValue({ oldValue, newValue, onAccept, onReject, style }) {
  const act = (label, icon, fn, color) => (
    <button type="button" aria-label={label} title={label} onClick={fn}
      style={{ all: 'unset', cursor: 'pointer', display: 'inline-flex', padding: 2, borderRadius: 3, color }}>
      <Icon name={icon} size={12} />
    </button>
  );
  return (
    <span className="pa-diff" style={style}>
      {oldValue != null && oldValue !== '' ? <del>{oldValue}</del> : null}
      <ins>{newValue}</ins>
      {(onAccept || onReject) ? (
        <span className="pa-diff-act">
          {onAccept ? act('Accept', 'check', onAccept, 'var(--ok-text)') : null}
          {onReject ? act('Reject', 'x', onReject, 'var(--danger-text)') : null}
        </span>
      ) : null}
    </span>
  );
}
