/** Dense data grid: 36px sticky sentence-case (12/500) headers, sortable columns, multi-select, row states, sticky footer count. The workhorse of every list surface. */
export interface TableColumn<Row = any> {
  key: string;
  label: React.ReactNode;
  /** CSS width, e.g. 120 or "18%" */
  width?: number | string;
  /** "right" also sets tabular numerals */
  align?: 'left' | 'right';
  /** Render cell in IBM Plex Mono 12 (IDs, versions) */
  mono?: boolean;
  /** Truncate with ellipsis + title tooltip */
  clamp?: boolean;
  sortable?: boolean;
  /** Custom sort accessor */
  sortValue?: (row: Row) => string | number;
  render?: (row: Row) => React.ReactNode;
}
export interface TableProps<Row = any> {
  columns: TableColumn<Row>[];
  rows: Row[];
  /** Field used as the stable row key @default "id" */
  rowKey?: string;
  /** @default "default" */
  density?: 'compact' | 'default';
  /** Column sorting on click @default true */
  sortable?: boolean;
  /** Adds a leading checkbox column */
  selectable?: boolean;
  /** Controlled selection */
  selected?: Set<string>;
  onSelectedChange?: (next: Set<string>) => void;
  /** Per-row visual state: "pending" (AI-proposed) or "error" */
  rowState?: (row: Row) => 'pending' | 'error' | undefined;
  onRowClick?: (row: Row) => void;
  /** Row key rendered as selected (e.g. open in inspector) */
  activeKey?: string;
  /** Sticky footer, e.g. "142 objectives · filtered from 890" */
  footer?: React.ReactNode;
  /** Rendered when rows is empty (use EmptyState) */
  empty?: React.ReactNode;
  /** Scroll region cap — over-capacity lists must scroll, not grow */
  maxHeight?: number | string;
  style?: React.CSSProperties;
}
export declare function Table<Row = any>(props: TableProps<Row>): JSX.Element;
