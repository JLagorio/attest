The workhorse dense grid: 36px sticky sentence-case (12/500) headers, sortable columns, multi-select, row states (pending/error), sticky footer count, scroll-capped.

```jsx
<Table density="compact" selectable selected={sel} onSelectedChange={setSel}
  columns={[
    {key:'id',label:'Control',width:90,mono:true},
    {key:'title',label:'Objective',clamp:true},
    {key:'status',label:'State',width:160,render:r=><StatusBadge status={r.status}/>},
    {key:'age',label:'Age',width:64,align:'right'},
  ]}
  rows={rows} rowState={r=>r.proposed?'pending':undefined}
  footer="142 objectives · 38 inherited · 11 unknown" maxHeight={480} />
```

Null cells render an em-dash automatically.
