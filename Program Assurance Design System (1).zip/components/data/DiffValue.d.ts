/** Pending-mutation rendering: AI or import proposals land as reviewable diffs in place — strikethrough original, tinted proposed value, per-unit Accept/Reject. Never prose output. */
export interface DiffValueProps {
  /** Current value (omit for net-new values) */
  oldValue?: React.ReactNode;
  /** Proposed value */
  newValue: React.ReactNode;
  onAccept?: () => void;
  onReject?: () => void;
  style?: React.CSSProperties;
}
export declare function DiffValue(props: DiffValueProps): JSX.Element;
