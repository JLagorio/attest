Pending mutations rendered as reviewable in-place diffs (AI/import proposals) — the user reviews a table, not a paragraph.

```jsx
<DiffValue oldValue="Firmware Engineering" newValue="Platform Security" onAccept={ok} onReject={no} />
```
