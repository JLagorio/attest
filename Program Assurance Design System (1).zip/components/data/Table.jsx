import { Icon } from '../core/Icon.jsx';
import { Checkbox } from '../forms/Checkbox.jsx';
export function Table({ columns = [], rows = [], rowKey = 'id', density = 'default', sortable = true, selectable, selected, onSelectedChange, rowState, onRowClick, activeKey, footer, empty, maxHeight, style }) {
  const [sort, setSort] = React.useState(null); // {key, dir}
  const sorted = React.useMemo(() => {
    if (!sort) return rows;
    const col = columns.find(c => c.key === sort.key);
    const val = r => (col && col.sortValue ? col.sortValue(r) : r[sort.key]);
    return [...rows].sort((a, b) => {
      const x = val(a), y = val(b);
      const c = typeof x === 'number' && typeof y === 'number' ? x - y : String(x ?? '').localeCompare(String(y ?? ''));
      return sort.dir === 'asc' ? c : -c;
    });
  }, [rows, sort, columns]);
  const sel = selected || new Set();
  const toggle = k => {
    if (!onSelectedChange) return;
    const next = new Set(sel); next.has(k) ? next.delete(k) : next.add(k);
    onSelectedChange(next);
  };
  const allKeys = sorted.map(r => r[rowKey]);
  const allOn = allKeys.length > 0 && allKeys.every(k => sel.has(k));
  const someOn = allKeys.some(k => sel.has(k));
  return (
    <div className="pa-table-wrap" style={{ maxHeight, ...style }}>
      <table className={'pa-table' + (density === 'compact' ? ' pa-table--compact' : '')}>
        <thead><tr>
          {selectable ? <th style={{ width: 32 }}><Checkbox checked={allOn} indeterminate={someOn && !allOn} onChange={() => onSelectedChange && onSelectedChange(allOn ? new Set() : new Set(allKeys))} aria-label="Select all" /></th> : null}
          {columns.map(c => (
            <th key={c.key} className={c.align === 'right' ? 'is-num' : undefined} style={{ width: c.width }}>
              {sortable && c.sortable !== false ? (
                <button type="button" className="pa-th-sort" aria-sort={sort && sort.key === c.key ? (sort.dir === 'asc' ? 'ascending' : 'descending') : undefined}
                  onClick={() => setSort(s => s && s.key === c.key ? (s.dir === 'asc' ? { key: c.key, dir: 'desc' } : null) : { key: c.key, dir: 'asc' })}>
                  {c.label}
                  <Icon name={sort && sort.key === c.key ? (sort.dir === 'asc' ? 'chevron-up' : 'chevron-down') : 'chevrons-up-down'} size={12}
                    style={{ color: sort && sort.key === c.key ? 'var(--text-primary)' : 'var(--n-5)' }} />
                </button>
              ) : c.label}
            </th>
          ))}
        </tr></thead>
        <tbody>
          {sorted.length === 0 && empty ? (
            <tr><td colSpan={columns.length + (selectable ? 1 : 0)} style={{ height: 'auto', padding: 0 }}>{empty}</td></tr>
          ) : sorted.map(r => {
            const k = r[rowKey];
            const st = rowState ? rowState(r) : undefined;
            const cls = [sel.has(k) || activeKey === k ? 'is-selected' : '', st === 'pending' ? 'is-pending' : '', st === 'error' ? 'is-error' : '', onRowClick ? 'is-clickable' : ''].filter(Boolean).join(' ');
            return (
              <tr key={k} className={cls || undefined} onClick={onRowClick ? () => onRowClick(r) : undefined}>
                {selectable ? <td onClick={e => e.stopPropagation()}><Checkbox checked={sel.has(k)} onChange={() => toggle(k)} aria-label={'Select row ' + k} /></td> : null}
                {columns.map(c => (
                  <td key={c.key} className={[c.align === 'right' ? 'is-num' : '', c.mono ? 'is-mono' : ''].filter(Boolean).join(' ') || undefined}
                    style={c.clamp ? { maxWidth: c.width || 240 } : undefined}>
                    {c.render ? c.render(r) : c.clamp ? <span className="u-truncate" title={String(r[c.key] ?? '')} style={{ display: 'block' }}>{r[c.key] ?? '—'}</span> : (r[c.key] ?? '—')}
                  </td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </table>
      {footer ? <div className="pa-table-foot">{footer}</div> : null}
    </div>
  );
}
