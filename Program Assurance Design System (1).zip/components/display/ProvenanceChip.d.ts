/** "Why is this here" marker for values not entered by hand — inherited, AI-proposed, or imported. Dashed border + glyph make provenance legible without color. `source` (hover title) should name package, version, condition, and date. */
export interface ProvenanceChipProps {
  /** @default "inherited" */
  kind?: 'inherited' | 'ai' | 'imported';
  /** Full provenance sentence for the hover title, e.g. "Inherited from Enterprise IAM Assurance Package v4.2 · reviewed Mar 14, 2026" */
  source?: string;
  /** Shows a revert affordance */
  onRevert?: () => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function ProvenanceChip(props: ProvenanceChipProps): JSX.Element;
