import { Icon } from '../core/Icon.jsx';
export function EmptyState({ icon = 'inbox', title, action, children, style }) {
  return (
    <div className="pa-empty" style={style}>
      <Icon name={icon} size={20} style={{ color: 'var(--text-placeholder)' }} />
      <div className="pa-empty-title">{title}</div>
      {children ? <div className="pa-empty-body">{children}</div> : null}
      {action ? <div style={{ marginTop: 'var(--sp-4)' }}>{action}</div> : null}
    </div>
  );
}
