/** Neutral metadata chip (labels, filters, applicability conditions). Not for statuses — use StatusBadge. */
export interface TagProps {
  children: React.ReactNode;
  /** Renders a remove ✕; called on click */
  onRemove?: () => void;
  title?: string;
  style?: React.CSSProperties;
}
export declare function Tag(props: TagProps): JSX.Element;
