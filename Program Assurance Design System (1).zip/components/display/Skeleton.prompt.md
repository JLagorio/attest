Loading placeholders preserving real geometry — never a centered spinner.

```jsx
<Skeleton width={180} height={10} />
<SkeletonRows rows={8} columns={['22%','40%','12%','10%']} />
```
