The "why is this here" marker for values not entered by hand. Dashed border + glyph keep provenance legible without color.

```jsx
<ProvenanceChip kind="inherited" source="Inherited from Enterprise IAM Assurance Package v4.2 · reviewed Mar 14, 2026">RAP v4.2</ProvenanceChip>
<ProvenanceChip kind="ai" source="Proposed by mapping assist · 0.87 confidence · 2m ago" onRevert={undo}>proposed</ProvenanceChip>
```
