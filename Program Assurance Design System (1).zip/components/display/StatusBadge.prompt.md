Renders a canonical status label (UX spec Appendix C) with its mandated tone; never hand-pick status colors.

```jsx
<StatusBadge status="Other Than Satisfied" />
<StatusBadge status="Inherited – Current" />
<StatusBadge status="Awaiting Response" dot={false} />
```

statusTone(label) is exported for rows/charts needing the same mapping.
