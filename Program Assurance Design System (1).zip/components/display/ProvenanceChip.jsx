import { Icon } from '../core/Icon.jsx';
const PA_PROV_ICONS = { inherited: 'git-branch', ai: 'sparkles', imported: 'download' };
export function ProvenanceChip({ kind = 'inherited', source, onRevert, children, style }) {
  return (
    <span className={'pa-prov pa-prov--' + kind} title={source} style={style}>
      <Icon name={PA_PROV_ICONS[kind] || 'git-branch'} size={12} />
      {children}
      {onRevert ? (
        <button type="button" aria-label="Revert" title="Revert" onClick={onRevert}
          style={{ all: 'unset', cursor: 'pointer', display: 'inline-flex', marginLeft: 2 }}>
          <Icon name="history" size={12} />
        </button>
      ) : null}
    </span>
  );
}
