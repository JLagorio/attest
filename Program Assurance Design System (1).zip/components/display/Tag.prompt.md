Neutral metadata chip (applicability conditions, filters). Not for statuses.

```jsx
<Tag>production SSO</Tag>
<Tag onRemove={clear}>owner: Firmware Eng</Tag>
```
