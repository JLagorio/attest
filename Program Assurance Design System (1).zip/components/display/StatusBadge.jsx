import { Badge } from './Badge.jsx';
/* Canonical status → tone map (UX spec Appendix C). Key = lowercase, non-alphanumerics stripped. */
const PA_STATUS_TONES = {
  satisfied: 'ok', published: 'ok', current: 'ok', active: 'ok', canonicalactive: 'ok', canonical: 'ok',
  accepted: 'ok', acceptedvalidated: 'ok', approved: 'ok', applicable: 'ok', validated: 'ok',
  inheritedcurrent: 'inherited', inherited: 'inherited',
  inprogress: 'info', underreview: 'info', submitted: 'info', readyforreview: 'info', readyforvalidation: 'info',
  duplicatereview: 'info', scopereview: 'info', triaged: 'info', packaged: 'info', assigned: 'info',
  delegated: 'info', acceptedasinput: 'info', inremediation: 'info', remediationplanned: 'info',
  awaitingresponse: 'warn', clarificationrequested: 'warn', expiring: 'warn', impacted: 'warn',
  reassessmentrequired: 'warn', partiallyactive: 'warn', attestationrequired: 'warn',
  insufficientinformation: 'warn', accepteddeferred: 'warn', stale: 'warn', needsreview: 'warn',
  otherthansatisfied: 'danger', expired: 'danger', revoked: 'danger', conflict: 'danger', open: 'danger', overdue: 'danger',
  unknown: 'unknown', unassigned: 'unknown', notdetermined: 'unknown',
  planned: 'neutral', draft: 'neutral', new: 'neutral', closed: 'neutral', retired: 'neutral',
  superseded: 'neutral', endedsuperseded: 'neutral', mergedsuperseded: 'neutral', notapplicable: 'neutral',
  local: 'neutral', localcandidate: 'neutral', candidate: 'neutral', candidateunreviewed: 'neutral',
  falsepositive: 'neutral', rejectedkeptlocal: 'neutral', ended: 'neutral',
};
export function statusTone(status) {
  return PA_STATUS_TONES[String(status).toLowerCase().replace(/[^a-z0-9]/g, '')] || 'neutral';
}
export function StatusBadge({ status, dot = true, title, style }) {
  return <Badge tone={statusTone(status)} dot={dot} title={title} style={style}>{status}</Badge>;
}
