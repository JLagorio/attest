/** Zero-data region. Each zero-condition gets its own copy: first-run explains the object and offers the creating action; filtered-to-zero offers to clear the filter; error names what failed and offers retry. Never one generic empty state. */
export interface EmptyStateProps {
  /** Lucide icon @default "inbox" */
  icon?: string;
  title: React.ReactNode;
  /** Action button(s) — e.g. Create assessment / Clear filters / Retry */
  action?: React.ReactNode;
  /** Explanatory body copy */
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function EmptyState(props: EmptyStateProps): JSX.Element;
