/** Semantic-tone chip: alpha background + border + text, never solid fills. For canonical platform statuses use StatusBadge instead. */
export interface BadgeProps {
  /** @default "neutral" */
  tone?: 'ok' | 'warn' | 'danger' | 'info' | 'unknown' | 'neutral' | 'accent' | 'inherited';
  /** Leading 6px dot in the tone color */
  dot?: boolean;
  children: React.ReactNode;
  title?: string;
  style?: React.CSSProperties;
}
export declare function Badge(props: BadgeProps): JSX.Element;
