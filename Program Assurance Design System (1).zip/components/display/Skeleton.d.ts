/** Loading placeholders that preserve real geometry — never a centered spinner. */
export interface SkeletonProps {
  /** @default "100%" */
  width?: number | string;
  /** @default 12 */
  height?: number | string;
  style?: React.CSSProperties;
}
export declare function Skeleton(props: SkeletonProps): JSX.Element;
/** Table-shaped skeleton: rows matching row height, columns matching column widths. */
export interface SkeletonRowsProps {
  /** @default 6 */
  rows?: number;
  /** Row height @default var(--row-default) */
  height?: number | string;
  /** Column widths @default ["24%","38%","14%","12%"] */
  columns?: string[];
}
export declare function SkeletonRows(props: SkeletonRowsProps): JSX.Element;
