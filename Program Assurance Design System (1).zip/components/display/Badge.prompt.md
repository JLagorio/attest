Semantic chip (alpha bg + border + text). For canonical platform statuses use StatusBadge — it enforces the mandated tone.

```jsx
<Badge tone="ok" dot>Satisfied</Badge>
<Badge tone="unknown" dot>Unknown</Badge>
<Badge tone="neutral">v4.2</Badge>
```

Tones: ok · warn · danger · info · unknown · neutral · accent · inherited.
