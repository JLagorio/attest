/** Renders a canonical platform status (Appendix C vocabulary) with its mandated semantic tone — never hand-pick status colors. Unmapped labels fall back to neutral. */
export interface StatusBadgeProps {
  /** Canonical label verbatim, e.g. "Other Than Satisfied", "Inherited – Current", "Awaiting Response" */
  status: string;
  /** Leading tone dot @default true */
  dot?: boolean;
  title?: string;
  style?: React.CSSProperties;
}
export declare function StatusBadge(props: StatusBadgeProps): JSX.Element;
/** Tone lookup used by StatusBadge; exported for charts/rows that need the same mapping. */
export declare function statusTone(status: string): 'ok' | 'warn' | 'danger' | 'info' | 'unknown' | 'neutral' | 'inherited';
