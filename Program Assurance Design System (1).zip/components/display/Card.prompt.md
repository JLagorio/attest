Flat surface container; raised only to separate from a busy background.

```jsx
<Card title="Residual responsibilities" actions={<Button size="compact" variant="ghost" icon="plus">Add</Button>}>…</Card>
<Card padded={false}><Table … /></Card>
```
