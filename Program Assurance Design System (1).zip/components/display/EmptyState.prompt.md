Zero-data region; every zero-condition gets its own copy (first-run ≠ filtered-to-zero ≠ error).

```jsx
<EmptyState icon="inbox" title="No assessments yet" action={<Button variant="primary" icon="plus">Create assessment</Button>}>
  Assessments turn objectives into delegated, plain-language tasks.
</EmptyState>
<EmptyState icon="list-filter" title="No findings match" action={<Button>Clear filters</Button>} />
```
