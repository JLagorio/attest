export function Card({ title, actions, footer, raised, padded = true, children, style, className = '' }) {
  return (
    <section className={['pa-card', raised && 'pa-card--raised', className].filter(Boolean).join(' ')} style={style}>
      {title || actions ? (
        <header className="pa-card-h">
          <span className="pa-card-title" style={{ flex: 1 }}>{title}</span>
          {actions}
        </header>
      ) : null}
      {padded ? <div className="pa-card-b">{children}</div> : children}
      {footer ? <footer className="pa-card-f">{footer}</footer> : null}
    </section>
  );
}
