export function Badge({ tone = 'neutral', dot, children, title, style }) {
  return (
    <span className={'pa-badge pa-badge--' + tone} title={title} style={style}>
      {dot ? <span className="pa-dot" style={{ background: 'currentColor' }} /> : null}
      {children}
    </span>
  );
}
