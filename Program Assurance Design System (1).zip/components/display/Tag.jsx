import { Icon } from '../core/Icon.jsx';
export function Tag({ children, onRemove, title, style }) {
  return (
    <span className="pa-tag" title={title} style={style}>
      {children}
      {onRemove ? <button type="button" aria-label="Remove" onClick={onRemove}><Icon name="x" size={12} /></button> : null}
    </span>
  );
}
