/** Flat-by-default surface container. `raised` only when it must separate from a busy background. */
export interface CardProps {
  /** Header title (14/600); header renders only when title or actions present */
  title?: React.ReactNode;
  /** Right-aligned header actions */
  actions?: React.ReactNode;
  footer?: React.ReactNode;
  /** Adds the raised elevation recipe @default false */
  raised?: boolean;
  /** Wrap children in 12px body padding @default true — set false for tables */
  padded?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
  className?: string;
}
export declare function Card(props: CardProps): JSX.Element;
