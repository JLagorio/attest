export function Skeleton({ width = '100%', height = 12, style }) {
  return <span className="pa-skel" aria-hidden="true" style={{ display: 'block', width, height, ...style }} />;
}
export function SkeletonRows({ rows = 6, height, columns = ['24%', '38%', '14%', '12%'] }) {
  const h = height || 'var(--row-default)';
  return (
    <div aria-busy="true">
      {Array.from({ length: rows }, (_, i) => (
        <div key={i} style={{ display: 'flex', gap: 'var(--sp-12)', alignItems: 'center', height: h, borderBottom: '1px solid var(--border-subtle)', padding: '0 var(--sp-12)' }}>
          {columns.map((w, j) => <Skeleton key={j} width={w} height={10} />)}
        </div>
      ))}
    </div>
  );
}
