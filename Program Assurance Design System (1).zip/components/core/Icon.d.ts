/** Lucide icon by kebab-case name (e.g. "circle-dashed"). Requires the pinned lucide UMD script on the page — see readme ICONOGRAPHY for the canonical name assignments. */
export interface IconProps {
  /** Lucide icon name, kebab-case, e.g. "clipboard-list" */
  name: string;
  /** Square size in px @default 16 */
  size?: number;
  /** Stroke width; defaults 1.75 under 20px, 1.5 at 20px+ */
  strokeWidth?: number;
  /** Accessible label; omit for decorative icons (aria-hidden) */
  label?: string;
  className?: string;
  style?: React.CSSProperties;
}
export declare function Icon(props: IconProps): JSX.Element;
