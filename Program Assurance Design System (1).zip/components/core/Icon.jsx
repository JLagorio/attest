export function Icon({ name, size = 16, strokeWidth, label, className, style }) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const el = ref.current; if (!el) return;
    el.textContent = '';
    const lib = window.lucide;
    if (lib && lib.icons && lib.createElement) {
      const pascal = String(name).split('-').map(s => s.charAt(0).toUpperCase() + s.slice(1)).join('');
      const node = lib.icons[pascal];
      if (node) {
        const svg = lib.createElement(node);
        svg.setAttribute('width', size); svg.setAttribute('height', size);
        svg.setAttribute('stroke-width', strokeWidth || (size >= 20 ? 1.5 : 1.75));
        el.appendChild(svg);
        return;
      }
    }
    if (!window.__paIconWarned) { window.__paIconWarned = true; console.warn('Icon: lucide CDN script not loaded or icon missing — see readme ICONOGRAPHY'); }
  }, [name, size, strokeWidth]);
  return <span ref={ref} role={label ? 'img' : undefined} aria-label={label} aria-hidden={label ? undefined : true} className={className}
    style={{ display: 'inline-flex', flex: 'none', width: size, height: size, alignItems: 'center', justifyContent: 'center', ...style }} />;
}
