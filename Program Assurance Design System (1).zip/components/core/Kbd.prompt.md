Keycap for shortcuts in tooltips, menus, and hints.

```jsx
<Kbd>D</Kbd> <Kbd>⌘</Kbd><Kbd>K</Kbd>
```
