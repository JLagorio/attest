/** Keycap for keyboard shortcuts, shown in tooltips, menus, and hints. */
export interface KbdProps {
  /** Key label, e.g. "D", "⌘", "↵" */
  children: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Kbd(props: KbdProps): JSX.Element;
