export function Kbd({ children, style }) {
  return <kbd className="pa-kbd" style={style}>{children}</kbd>;
}
