Lucide icon by kebab-case name; requires the pinned lucide UMD script on the page (see readme ICONOGRAPHY).

```jsx
<Icon name="circle-dashed" />            // decorative, 16px
<Icon name="flag" size={14} label="Findings" />
```

Canonical assignments live in readme.md — do not improvise per-concept icons. Color inherits currentColor.
