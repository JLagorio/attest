/** Toggle for immediate-effect binary settings (never inside a form that needs saving). */
export interface SwitchProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: React.ReactNode;
}
export declare function Switch(props: SwitchProps): JSX.Element;
