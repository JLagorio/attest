Checkbox with optional inline label; indeterminate for bulk-select headers.

```jsx
<Checkbox label="Include superseded versions" />
<Checkbox indeterminate onChange={toggleAll} aria-label="Select all" />
```
