/** Checkbox with optional inline label. Supports indeterminate (bulk-select headers). */
export interface CheckboxProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: React.ReactNode;
  indeterminate?: boolean;
}
export declare function Checkbox(props: CheckboxProps): JSX.Element;
