Single choice among 2–5 visible options; group by name.

```jsx
<Radio name="scope" label="This system only" defaultChecked />
<Radio name="scope" label="All consumers of the package" />
```
