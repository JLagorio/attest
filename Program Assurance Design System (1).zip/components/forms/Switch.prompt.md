Immediate-effect binary toggle (never inside a form that needs saving).

```jsx
<Switch label="Notify consumers on publish" defaultChecked />
```
