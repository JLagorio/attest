Text input with optional leading icon, suffix node, stacked label/help/error.

```jsx
<Input icon="search" placeholder="Search 4,112 assets" suffix={<Kbd>/</Kbd>} />
<Input label="Package name" help="Visible to consumers" defaultValue="Enterprise IAM Assurance Package" />
<Input label="Version" error="v4.2 already exists" defaultValue="4.2" />
```

Placeholder shows a real example value, never the label restated.
