Icon-only button; label prop is mandatory (aria-label + title). Wrap in Tooltip when a shortcut exists.

```jsx
<IconButton icon="panel-right" label="Open inspector" />
<IconButton icon="ellipsis" label="More actions" variant="outline" size="compact" />
```
