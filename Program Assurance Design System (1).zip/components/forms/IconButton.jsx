import { Icon } from '../core/Icon.jsx';
export function IconButton({ icon, label, variant = 'ghost', size = 'default', disabled, className = '', ...rest }) {
  const cls = ['pa-iconbtn', variant === 'outline' && 'pa-iconbtn--outline', size !== 'default' && 'pa-iconbtn--' + size, className].filter(Boolean).join(' ');
  return (
    <button type="button" className={cls} aria-label={label} title={label} disabled={disabled} {...rest}>
      <Icon name={icon} size={size === 'compact' ? 14 : 16} />
    </button>
  );
}
