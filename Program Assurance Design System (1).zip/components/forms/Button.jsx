import { Icon } from '../core/Icon.jsx';
export function Button({ variant = 'secondary', size = 'default', icon, trailingIcon, loading, disabled, children, className = '', type = 'button', ...rest }) {
  const cls = ['pa-btn', 'pa-btn--' + variant, size !== 'default' && 'pa-btn--' + size, loading && 'pa-btn--loading', className].filter(Boolean).join(' ');
  const iconSize = size === 'compact' ? 14 : 16;
  return (
    <button type={type} className={cls} disabled={disabled || loading} aria-busy={loading || undefined} {...rest}>
      {loading ? <Icon name="loader-circle" size={iconSize} className="pa-spin" /> : icon ? <Icon name={icon} size={iconSize} /> : null}
      {children}
      {trailingIcon ? <Icon name={trailingIcon} size={iconSize} /> : null}
    </button>
  );
}
