/** Icon-only button. `label` is mandatory — it becomes aria-label and title. */
export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Lucide icon name */
  icon: string;
  /** Required accessible label (also the hover title) */
  label: string;
  /** @default "ghost" */
  variant?: 'ghost' | 'outline';
  /** @default "default" */
  size?: 'compact' | 'default' | 'comfortable';
}
export declare function IconButton(props: IconButtonProps): JSX.Element;
