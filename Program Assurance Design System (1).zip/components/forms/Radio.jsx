export function Radio({ label, disabled, style, ...rest }) {
  const dot = <input type="radio" className="pa-radio" disabled={disabled} {...rest} />;
  if (!label) return dot;
  return <label className={'pa-choice' + (disabled ? ' pa-choice--disabled' : '')} style={style}>{dot}{label}</label>;
}
