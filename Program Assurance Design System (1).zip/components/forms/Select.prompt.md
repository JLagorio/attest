Token-styled native select for 6+ options; fewer than that, prefer Radio or Tabs.

```jsx
<Select label="Assessment method" options={['Examine','Interview','Test','Attestation','Discovery']} />
<Select size="compact" options={[{value:'all',label:'All owners'},{value:'iam',label:'Enterprise IAM'}]} />
```
