export function Select({ options = [], size = 'default', label, id, style, className = '', ...rest }) {
  const auto = React.useRef('pa-sel-' + Math.random().toString(36).slice(2, 7)).current;
  const selId = id || auto;
  const cls = ['pa-select', size !== 'default' && 'pa-select--' + size, className].filter(Boolean).join(' ');
  const el = (
    <select id={selId} className={cls} style={label ? undefined : style} {...rest}>
      {options.map(o => typeof o === 'string' ? <option key={o} value={o}>{o}</option> : <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  );
  if (!label) return el;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-4)', ...style }}>
      <label htmlFor={selId} style={{ fontSize: 'var(--text-body)', fontWeight: 500, color: 'var(--text-label)' }}>{label}</label>
      {el}
    </div>
  );
}
