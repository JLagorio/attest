/** Native select, token-styled. For 6+ options; 2–5 short options prefer Radio or Tabs. */
export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  /** Option strings or {value,label} pairs */
  options?: (string | { value: string; label: string })[];
  /** @default "default" */
  size?: 'compact' | 'default';
  /** Optional stacked label rendered above */
  label?: string;
}
export declare function Select(props: SelectProps): JSX.Element;
