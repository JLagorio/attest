Action button. Label the authority-bearing action ("Record determination", "Publish v4.3") — never "Submit"/"OK". One primary per view.

```jsx
<Button variant="primary" icon="check">Record determination</Button>
<Button>Request clarification</Button>
<Button variant="ghost" size="compact" trailingIcon="chevron-down">Mar 7 – Apr 6</Button>
<Button variant="danger">Revoke evidence</Button>
<Button loading>Publishing…</Button>
```

Variants primary/secondary/ghost/danger; sizes compact 24 / default 32 / comfortable 40.
