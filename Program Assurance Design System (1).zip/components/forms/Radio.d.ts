/** Radio with optional inline label. Group by shared `name`. */
export interface RadioProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: React.ReactNode;
}
export declare function Radio(props: RadioProps): JSX.Element;
