import { Icon } from '../core/Icon.jsx';
export function Input({ icon, suffix, invalid, size = 'default', disabled, label, help, error, id, style, className = '', ...rest }) {
  const auto = React.useRef('pa-in-' + Math.random().toString(36).slice(2, 7)).current;
  const inputId = id || auto;
  const cls = ['pa-input', size !== 'default' && 'pa-input--' + size, (invalid || error) && 'pa-input--invalid', disabled && 'pa-input--disabled', className].filter(Boolean).join(' ');
  const field = (
    <span className={cls} style={label ? undefined : style}>
      {icon ? <Icon name={icon} size={14} style={{ color: 'var(--text-secondary)' }} /> : null}
      <input id={inputId} disabled={disabled} aria-invalid={invalid || !!error || undefined} {...rest} />
      {suffix}
    </span>
  );
  if (!label && !help && !error) return field;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-4)', ...style }}>
      {label ? <label htmlFor={inputId} style={{ fontSize: 'var(--text-body)', fontWeight: 500, color: 'var(--text-label)' }}>{label}</label> : null}
      {field}
      {error ? <span style={{ fontSize: 'var(--text-meta)', color: 'var(--danger-text)' }}>{error}</span>
        : help ? <span style={{ fontSize: 'var(--text-meta)', color: 'var(--text-secondary)' }}>{help}</span> : null}
    </div>
  );
}
