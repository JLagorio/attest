/** Action button. Label the authority-bearing action ("Record determination", "Publish v4.3") — never "Submit" or "OK". One primary per view. */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** @default "secondary" */
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  /** Density tier @default "default" */
  size?: 'compact' | 'default' | 'comfortable';
  /** Leading lucide icon name */
  icon?: string;
  /** Trailing lucide icon name (e.g. "chevron-down" for menus) */
  trailingIcon?: string;
  /** Replaces leading icon with a spinner and disables */
  loading?: boolean;
  children?: React.ReactNode;
}
export declare function Button(props: ButtonProps): JSX.Element;
