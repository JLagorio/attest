export function Switch({ label, disabled, style, ...rest }) {
  return (
    <label className={'pa-switch' + (disabled ? ' pa-choice--disabled' : '')} style={style}>
      <input type="checkbox" role="switch" disabled={disabled} {...rest} />
      <span className="pa-switch-track" />
      {label ? <span style={{ fontSize: 'var(--text-body)' }}>{label}</span> : null}
    </label>
  );
}
