export function Checkbox({ label, indeterminate, disabled, style, ...rest }) {
  const ref = React.useRef(null);
  React.useEffect(() => { if (ref.current) ref.current.indeterminate = !!indeterminate; }, [indeterminate]);
  const box = <input ref={ref} type="checkbox" className="pa-check" disabled={disabled} {...rest} />;
  if (!label) return box;
  return <label className={'pa-choice' + (disabled ? ' pa-choice--disabled' : '')} style={style}>{box}{label}</label>;
}
