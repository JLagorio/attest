/** Text input. Placeholder never duplicates the label — show a real example value instead. */
export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  /** Leading lucide icon (e.g. "search") */
  icon?: string;
  /** Trailing node (e.g. a Kbd hint) */
  suffix?: React.ReactNode;
  invalid?: boolean;
  /** @default "default" */
  size?: 'compact' | 'default' | 'comfortable';
  /** Optional stacked label rendered above */
  label?: string;
  /** Helper text below (replaced by error when set) */
  help?: string;
  /** Error message below; also sets invalid styling */
  error?: string;
}
export declare function Input(props: InputProps): JSX.Element;
