/* @ds-bundle: {"format":4,"namespace":"ProgramAssuranceDesignSystem_004a77","components":[{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"Kbd","sourcePath":"components/core/Kbd.jsx"},{"name":"DiffValue","sourcePath":"components/data/DiffValue.jsx"},{"name":"Table","sourcePath":"components/data/Table.jsx"},{"name":"Badge","sourcePath":"components/display/Badge.jsx"},{"name":"Card","sourcePath":"components/display/Card.jsx"},{"name":"EmptyState","sourcePath":"components/display/EmptyState.jsx"},{"name":"ProvenanceChip","sourcePath":"components/display/ProvenanceChip.jsx"},{"name":"Skeleton","sourcePath":"components/display/Skeleton.jsx"},{"name":"SkeletonRows","sourcePath":"components/display/Skeleton.jsx"},{"name":"StatusBadge","sourcePath":"components/display/StatusBadge.jsx"},{"name":"Tag","sourcePath":"components/display/Tag.jsx"},{"name":"Button","sourcePath":"components/forms/Button.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"IconButton","sourcePath":"components/forms/IconButton.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"Dialog","sourcePath":"components/overlay/Dialog.jsx"},{"name":"Drawer","sourcePath":"components/overlay/Drawer.jsx"},{"name":"Toast","sourcePath":"components/overlay/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/overlay/Tooltip.jsx"}],"sourceHashes":{"components/core/Icon.jsx":"8d5cd72d5de9","components/core/Kbd.jsx":"8dcfb80d4a99","components/data/DiffValue.jsx":"c329cffe3d78","components/data/Table.jsx":"9b185553f7f2","components/display/Badge.jsx":"289c6665dccd","components/display/Card.jsx":"f1f67dd2fcf7","components/display/EmptyState.jsx":"6446939cda3f","components/display/ProvenanceChip.jsx":"2f628b9877f4","components/display/Skeleton.jsx":"bbfa69f5eced","components/display/StatusBadge.jsx":"0e6576f7633c","components/display/Tag.jsx":"44705e630ff4","components/forms/Button.jsx":"cff777d1c6f6","components/forms/Checkbox.jsx":"a108dcd28805","components/forms/IconButton.jsx":"32415753ca41","components/forms/Input.jsx":"3ed1771ede89","components/forms/Radio.jsx":"bd712fe49041","components/forms/Select.jsx":"76b91bd4c5ae","components/forms/Switch.jsx":"535d12a92edc","components/navigation/Tabs.jsx":"bcf9d773ff01","components/overlay/Dialog.jsx":"2f91c4d937c7","components/overlay/Drawer.jsx":"20e186d04221","components/overlay/Toast.jsx":"baaf3f2c5d9d","components/overlay/Tooltip.jsx":"3c9a4c994e08","ui_kits/platform/AssessmentScreen.jsx":"750c26b75f5b","ui_kits/platform/FindingsScreen.jsx":"8c6f5dcf4897","ui_kits/platform/HomeScreen.jsx":"3ed3208ec1dd","ui_kits/platform/ProgramScreen.jsx":"7abb634d489f","ui_kits/platform/Shell.jsx":"6ae97b3fe86a","ui_kits/platform/app.jsx":"69c471469e8d","ui_kits/platform/data.js":"60f1e524dcff"},"inlinedExternals":[],"unexposedExports":[{"name":"statusTone","sourcePath":"components/display/StatusBadge.jsx"}]} */

(() => {

const __ds_ns = (window.ProgramAssuranceDesignSystem_004a77 = window.ProgramAssuranceDesignSystem_004a77 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Icon.jsx
try { (() => {
function Icon({
  name,
  size = 16,
  strokeWidth,
  label,
  className,
  style
}) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.textContent = '';
    const lib = window.lucide;
    if (lib && lib.icons && lib.createElement) {
      const pascal = String(name).split('-').map(s => s.charAt(0).toUpperCase() + s.slice(1)).join('');
      const node = lib.icons[pascal];
      if (node) {
        const svg = lib.createElement(node);
        svg.setAttribute('width', size);
        svg.setAttribute('height', size);
        svg.setAttribute('stroke-width', strokeWidth || (size >= 20 ? 1.5 : 1.75));
        el.appendChild(svg);
        return;
      }
    }
    if (!window.__paIconWarned) {
      window.__paIconWarned = true;
      console.warn('Icon: lucide CDN script not loaded or icon missing — see readme ICONOGRAPHY');
    }
  }, [name, size, strokeWidth]);
  return /*#__PURE__*/React.createElement("span", {
    ref: ref,
    role: label ? 'img' : undefined,
    "aria-label": label,
    "aria-hidden": label ? undefined : true,
    className: className,
    style: {
      display: 'inline-flex',
      flex: 'none',
      width: size,
      height: size,
      alignItems: 'center',
      justifyContent: 'center',
      ...style
    }
  });
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Kbd.jsx
try { (() => {
function Kbd({
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("kbd", {
    className: "pa-kbd",
    style: style
  }, children);
}
Object.assign(__ds_scope, { Kbd });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Kbd.jsx", error: String((e && e.message) || e) }); }

// components/data/DiffValue.jsx
try { (() => {
function DiffValue({
  oldValue,
  newValue,
  onAccept,
  onReject,
  style
}) {
  const act = (label, icon, fn, color) => /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": label,
    title: label,
    onClick: fn,
    style: {
      all: 'unset',
      cursor: 'pointer',
      display: 'inline-flex',
      padding: 2,
      borderRadius: 3,
      color
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 12
  }));
  return /*#__PURE__*/React.createElement("span", {
    className: "pa-diff",
    style: style
  }, oldValue != null && oldValue !== '' ? /*#__PURE__*/React.createElement("del", null, oldValue) : null, /*#__PURE__*/React.createElement("ins", null, newValue), onAccept || onReject ? /*#__PURE__*/React.createElement("span", {
    className: "pa-diff-act"
  }, onAccept ? act('Accept', 'check', onAccept, 'var(--ok-text)') : null, onReject ? act('Reject', 'x', onReject, 'var(--danger-text)') : null) : null);
}
Object.assign(__ds_scope, { DiffValue });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/DiffValue.jsx", error: String((e && e.message) || e) }); }

// components/display/Badge.jsx
try { (() => {
function Badge({
  tone = 'neutral',
  dot,
  children,
  title,
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: 'pa-badge pa-badge--' + tone,
    title: title,
    style: style
  }, dot ? /*#__PURE__*/React.createElement("span", {
    className: "pa-dot",
    style: {
      background: 'currentColor'
    }
  }) : null, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/display/Card.jsx
try { (() => {
function Card({
  title,
  actions,
  footer,
  raised,
  padded = true,
  children,
  style,
  className = ''
}) {
  return /*#__PURE__*/React.createElement("section", {
    className: ['pa-card', raised && 'pa-card--raised', className].filter(Boolean).join(' '),
    style: style
  }, title || actions ? /*#__PURE__*/React.createElement("header", {
    className: "pa-card-h"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pa-card-title",
    style: {
      flex: 1
    }
  }, title), actions) : null, padded ? /*#__PURE__*/React.createElement("div", {
    className: "pa-card-b"
  }, children) : children, footer ? /*#__PURE__*/React.createElement("footer", {
    className: "pa-card-f"
  }, footer) : null);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Card.jsx", error: String((e && e.message) || e) }); }

// components/display/EmptyState.jsx
try { (() => {
function EmptyState({
  icon = 'inbox',
  title,
  action,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "pa-empty",
    style: style
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 20,
    style: {
      color: 'var(--text-placeholder)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "pa-empty-title"
  }, title), children ? /*#__PURE__*/React.createElement("div", {
    className: "pa-empty-body"
  }, children) : null, action ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--sp-4)'
    }
  }, action) : null);
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/display/ProvenanceChip.jsx
try { (() => {
const PA_PROV_ICONS = {
  inherited: 'git-branch',
  ai: 'sparkles',
  imported: 'download'
};
function ProvenanceChip({
  kind = 'inherited',
  source,
  onRevert,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: 'pa-prov pa-prov--' + kind,
    title: source,
    style: style
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: PA_PROV_ICONS[kind] || 'git-branch',
    size: 12
  }), children, onRevert ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Revert",
    title: "Revert",
    onClick: onRevert,
    style: {
      all: 'unset',
      cursor: 'pointer',
      display: 'inline-flex',
      marginLeft: 2
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "history",
    size: 12
  })) : null);
}
Object.assign(__ds_scope, { ProvenanceChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/ProvenanceChip.jsx", error: String((e && e.message) || e) }); }

// components/display/Skeleton.jsx
try { (() => {
function Skeleton({
  width = '100%',
  height = 12,
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "pa-skel",
    "aria-hidden": "true",
    style: {
      display: 'block',
      width,
      height,
      ...style
    }
  });
}
function SkeletonRows({
  rows = 6,
  height,
  columns = ['24%', '38%', '14%', '12%']
}) {
  const h = height || 'var(--row-default)';
  return /*#__PURE__*/React.createElement("div", {
    "aria-busy": "true"
  }, Array.from({
    length: rows
  }, (_, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 'var(--sp-12)',
      alignItems: 'center',
      height: h,
      borderBottom: '1px solid var(--border-subtle)',
      padding: '0 var(--sp-12)'
    }
  }, columns.map((w, j) => /*#__PURE__*/React.createElement(Skeleton, {
    key: j,
    width: w,
    height: 10
  })))));
}
Object.assign(__ds_scope, { Skeleton, SkeletonRows });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Skeleton.jsx", error: String((e && e.message) || e) }); }

// components/display/StatusBadge.jsx
try { (() => {
/* Canonical status → tone map (UX spec Appendix C). Key = lowercase, non-alphanumerics stripped. */
const PA_STATUS_TONES = {
  satisfied: 'ok',
  published: 'ok',
  current: 'ok',
  active: 'ok',
  canonicalactive: 'ok',
  canonical: 'ok',
  accepted: 'ok',
  acceptedvalidated: 'ok',
  approved: 'ok',
  applicable: 'ok',
  validated: 'ok',
  inheritedcurrent: 'inherited',
  inherited: 'inherited',
  inprogress: 'info',
  underreview: 'info',
  submitted: 'info',
  readyforreview: 'info',
  readyforvalidation: 'info',
  duplicatereview: 'info',
  scopereview: 'info',
  triaged: 'info',
  packaged: 'info',
  assigned: 'info',
  delegated: 'info',
  acceptedasinput: 'info',
  inremediation: 'info',
  remediationplanned: 'info',
  awaitingresponse: 'warn',
  clarificationrequested: 'warn',
  expiring: 'warn',
  impacted: 'warn',
  reassessmentrequired: 'warn',
  partiallyactive: 'warn',
  attestationrequired: 'warn',
  insufficientinformation: 'warn',
  accepteddeferred: 'warn',
  stale: 'warn',
  needsreview: 'warn',
  otherthansatisfied: 'danger',
  expired: 'danger',
  revoked: 'danger',
  conflict: 'danger',
  open: 'danger',
  overdue: 'danger',
  unknown: 'unknown',
  unassigned: 'unknown',
  notdetermined: 'unknown',
  planned: 'neutral',
  draft: 'neutral',
  new: 'neutral',
  closed: 'neutral',
  retired: 'neutral',
  superseded: 'neutral',
  endedsuperseded: 'neutral',
  mergedsuperseded: 'neutral',
  notapplicable: 'neutral',
  local: 'neutral',
  localcandidate: 'neutral',
  candidate: 'neutral',
  candidateunreviewed: 'neutral',
  falsepositive: 'neutral',
  rejectedkeptlocal: 'neutral',
  ended: 'neutral'
};
function statusTone(status) {
  return PA_STATUS_TONES[String(status).toLowerCase().replace(/[^a-z0-9]/g, '')] || 'neutral';
}
function StatusBadge({
  status,
  dot = true,
  title,
  style
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: statusTone(status),
    dot: dot,
    title: title,
    style: style
  }, status);
}
Object.assign(__ds_scope, { statusTone, StatusBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/StatusBadge.jsx", error: String((e && e.message) || e) }); }

// components/display/Tag.jsx
try { (() => {
function Tag({
  children,
  onRemove,
  title,
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "pa-tag",
    title: title,
    style: style
  }, children, onRemove ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Remove",
    onClick: onRemove
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 12
  })) : null);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Tag.jsx", error: String((e && e.message) || e) }); }

// components/forms/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Button({
  variant = 'secondary',
  size = 'default',
  icon,
  trailingIcon,
  loading,
  disabled,
  children,
  className = '',
  type = 'button',
  ...rest
}) {
  const cls = ['pa-btn', 'pa-btn--' + variant, size !== 'default' && 'pa-btn--' + size, loading && 'pa-btn--loading', className].filter(Boolean).join(' ');
  const iconSize = size === 'compact' ? 14 : 16;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    className: cls,
    disabled: disabled || loading,
    "aria-busy": loading || undefined
  }, rest), loading ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "loader-circle",
    size: iconSize,
    className: "pa-spin"
  }) : icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: iconSize
  }) : null, children, trailingIcon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: trailingIcon,
    size: iconSize
  }) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Button.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Checkbox({
  label,
  indeterminate,
  disabled,
  style,
  ...rest
}) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (ref.current) ref.current.indeterminate = !!indeterminate;
  }, [indeterminate]);
  const box = /*#__PURE__*/React.createElement("input", _extends({
    ref: ref,
    type: "checkbox",
    className: "pa-check",
    disabled: disabled
  }, rest));
  if (!label) return box;
  return /*#__PURE__*/React.createElement("label", {
    className: 'pa-choice' + (disabled ? ' pa-choice--disabled' : ''),
    style: style
  }, box, label);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/data/Table.jsx
try { (() => {
function Table({
  columns = [],
  rows = [],
  rowKey = 'id',
  density = 'default',
  sortable = true,
  selectable,
  selected,
  onSelectedChange,
  rowState,
  onRowClick,
  activeKey,
  footer,
  empty,
  maxHeight,
  style
}) {
  const [sort, setSort] = React.useState(null); // {key, dir}
  const sorted = React.useMemo(() => {
    if (!sort) return rows;
    const col = columns.find(c => c.key === sort.key);
    const val = r => col && col.sortValue ? col.sortValue(r) : r[sort.key];
    return [...rows].sort((a, b) => {
      const x = val(a),
        y = val(b);
      const c = typeof x === 'number' && typeof y === 'number' ? x - y : String(x ?? '').localeCompare(String(y ?? ''));
      return sort.dir === 'asc' ? c : -c;
    });
  }, [rows, sort, columns]);
  const sel = selected || new Set();
  const toggle = k => {
    if (!onSelectedChange) return;
    const next = new Set(sel);
    next.has(k) ? next.delete(k) : next.add(k);
    onSelectedChange(next);
  };
  const allKeys = sorted.map(r => r[rowKey]);
  const allOn = allKeys.length > 0 && allKeys.every(k => sel.has(k));
  const someOn = allKeys.some(k => sel.has(k));
  return /*#__PURE__*/React.createElement("div", {
    className: "pa-table-wrap",
    style: {
      maxHeight,
      ...style
    }
  }, /*#__PURE__*/React.createElement("table", {
    className: 'pa-table' + (density === 'compact' ? ' pa-table--compact' : '')
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, selectable ? /*#__PURE__*/React.createElement("th", {
    style: {
      width: 32
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Checkbox, {
    checked: allOn,
    indeterminate: someOn && !allOn,
    onChange: () => onSelectedChange && onSelectedChange(allOn ? new Set() : new Set(allKeys)),
    "aria-label": "Select all"
  })) : null, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key,
    className: c.align === 'right' ? 'is-num' : undefined,
    style: {
      width: c.width
    }
  }, sortable && c.sortable !== false ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "pa-th-sort",
    "aria-sort": sort && sort.key === c.key ? sort.dir === 'asc' ? 'ascending' : 'descending' : undefined,
    onClick: () => setSort(s => s && s.key === c.key ? s.dir === 'asc' ? {
      key: c.key,
      dir: 'desc'
    } : null : {
      key: c.key,
      dir: 'asc'
    })
  }, c.label, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: sort && sort.key === c.key ? sort.dir === 'asc' ? 'chevron-up' : 'chevron-down' : 'chevrons-up-down',
    size: 12,
    style: {
      color: sort && sort.key === c.key ? 'var(--text-primary)' : 'var(--n-5)'
    }
  })) : c.label)))), /*#__PURE__*/React.createElement("tbody", null, sorted.length === 0 && empty ? /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
    colSpan: columns.length + (selectable ? 1 : 0),
    style: {
      height: 'auto',
      padding: 0
    }
  }, empty)) : sorted.map(r => {
    const k = r[rowKey];
    const st = rowState ? rowState(r) : undefined;
    const cls = [sel.has(k) || activeKey === k ? 'is-selected' : '', st === 'pending' ? 'is-pending' : '', st === 'error' ? 'is-error' : '', onRowClick ? 'is-clickable' : ''].filter(Boolean).join(' ');
    return /*#__PURE__*/React.createElement("tr", {
      key: k,
      className: cls || undefined,
      onClick: onRowClick ? () => onRowClick(r) : undefined
    }, selectable ? /*#__PURE__*/React.createElement("td", {
      onClick: e => e.stopPropagation()
    }, /*#__PURE__*/React.createElement(__ds_scope.Checkbox, {
      checked: sel.has(k),
      onChange: () => toggle(k),
      "aria-label": 'Select row ' + k
    })) : null, columns.map(c => /*#__PURE__*/React.createElement("td", {
      key: c.key,
      className: [c.align === 'right' ? 'is-num' : '', c.mono ? 'is-mono' : ''].filter(Boolean).join(' ') || undefined,
      style: c.clamp ? {
        maxWidth: c.width || 240
      } : undefined
    }, c.render ? c.render(r) : c.clamp ? /*#__PURE__*/React.createElement("span", {
      className: "u-truncate",
      title: String(r[c.key] ?? ''),
      style: {
        display: 'block'
      }
    }, r[c.key] ?? '—') : r[c.key] ?? '—')));
  }))), footer ? /*#__PURE__*/React.createElement("div", {
    className: "pa-table-foot"
  }, footer) : null);
}
Object.assign(__ds_scope, { Table });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Table.jsx", error: String((e && e.message) || e) }); }

// components/forms/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function IconButton({
  icon,
  label,
  variant = 'ghost',
  size = 'default',
  disabled,
  className = '',
  ...rest
}) {
  const cls = ['pa-iconbtn', variant === 'outline' && 'pa-iconbtn--outline', size !== 'default' && 'pa-iconbtn--' + size, className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: cls,
    "aria-label": label,
    title: label,
    disabled: disabled
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: size === 'compact' ? 14 : 16
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  icon,
  suffix,
  invalid,
  size = 'default',
  disabled,
  label,
  help,
  error,
  id,
  style,
  className = '',
  ...rest
}) {
  const auto = React.useRef('pa-in-' + Math.random().toString(36).slice(2, 7)).current;
  const inputId = id || auto;
  const cls = ['pa-input', size !== 'default' && 'pa-input--' + size, (invalid || error) && 'pa-input--invalid', disabled && 'pa-input--disabled', className].filter(Boolean).join(' ');
  const field = /*#__PURE__*/React.createElement("span", {
    className: cls,
    style: label ? undefined : style
  }, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 14,
    style: {
      color: 'var(--text-secondary)'
    }
  }) : null, /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    disabled: disabled,
    "aria-invalid": invalid || !!error || undefined
  }, rest)), suffix);
  if (!label && !help && !error) return field;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--sp-4)',
      ...style
    }
  }, label ? /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontSize: 'var(--text-body)',
      fontWeight: 500,
      color: 'var(--text-label)'
    }
  }, label) : null, field, error ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-meta)',
      color: 'var(--danger-text)'
    }
  }, error) : help ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-meta)',
      color: 'var(--text-secondary)'
    }
  }, help) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Radio({
  label,
  disabled,
  style,
  ...rest
}) {
  const dot = /*#__PURE__*/React.createElement("input", _extends({
    type: "radio",
    className: "pa-radio",
    disabled: disabled
  }, rest));
  if (!label) return dot;
  return /*#__PURE__*/React.createElement("label", {
    className: 'pa-choice' + (disabled ? ' pa-choice--disabled' : ''),
    style: style
  }, dot, label);
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  options = [],
  size = 'default',
  label,
  id,
  style,
  className = '',
  ...rest
}) {
  const auto = React.useRef('pa-sel-' + Math.random().toString(36).slice(2, 7)).current;
  const selId = id || auto;
  const cls = ['pa-select', size !== 'default' && 'pa-select--' + size, className].filter(Boolean).join(' ');
  const el = /*#__PURE__*/React.createElement("select", _extends({
    id: selId,
    className: cls,
    style: label ? undefined : style
  }, rest), options.map(o => typeof o === 'string' ? /*#__PURE__*/React.createElement("option", {
    key: o,
    value: o
  }, o) : /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label)));
  if (!label) return el;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--sp-4)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("label", {
    htmlFor: selId,
    style: {
      fontSize: 'var(--text-body)',
      fontWeight: 500,
      color: 'var(--text-label)'
    }
  }, label), el);
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Switch({
  label,
  disabled,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: 'pa-switch' + (disabled ? ' pa-choice--disabled' : ''),
    style: style
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    role: "switch",
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "pa-switch-track"
  }), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body)'
    }
  }, label) : null);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function Tabs({
  tabs = [],
  value,
  onChange,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "pa-tabs",
    role: "tablist",
    style: style
  }, tabs.map(t => /*#__PURE__*/React.createElement("button", {
    key: t.id,
    type: "button",
    role: "tab",
    className: "pa-tab",
    "aria-selected": t.id === value,
    onClick: () => onChange && onChange(t.id)
  }, t.icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: t.icon,
    size: 14
  }) : null, t.label, t.count != null ? /*#__PURE__*/React.createElement("span", {
    className: "pa-tab-count"
  }, t.count > 999 ? '999+' : t.count) : null)));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Dialog.jsx
try { (() => {
function Dialog({
  open,
  onClose,
  title,
  footer,
  width = 480,
  children
}) {
  React.useEffect(() => {
    if (!open) return;
    const onKey = e => {
      if (e.key === 'Escape' && onClose) onClose();
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "pa-scrim",
    onMouseDown: e => {
      if (e.target === e.currentTarget && onClose) onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pa-dialog",
    role: "dialog",
    "aria-modal": "true",
    "aria-label": typeof title === 'string' ? title : undefined,
    style: {
      width
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pa-dialog-h"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pa-dialog-title"
  }, title), onClose ? /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Close",
    size: "compact",
    onClick: onClose
  }) : null), /*#__PURE__*/React.createElement("div", {
    className: "pa-dialog-b"
  }, children), footer ? /*#__PURE__*/React.createElement("div", {
    className: "pa-dialog-f"
  }, footer) : null));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Drawer.jsx
try { (() => {
function Drawer({
  open,
  onClose,
  title,
  wide,
  headerExtra,
  children
}) {
  React.useEffect(() => {
    if (!open) return;
    const onKey = e => {
      if (e.key === 'Escape' && onClose) onClose();
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "pa-drawer-scrim",
    onMouseDown: onClose
  }), /*#__PURE__*/React.createElement("aside", {
    className: 'pa-drawer' + (wide ? ' pa-drawer--wide' : ''),
    role: "dialog",
    "aria-label": typeof title === 'string' ? title : undefined
  }, /*#__PURE__*/React.createElement("div", {
    className: "pa-drawer-h"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pa-dialog-title",
    style: {
      flex: 1
    }
  }, title), headerExtra, /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Close",
    size: "compact",
    onClick: onClose
  })), /*#__PURE__*/React.createElement("div", {
    className: "pa-drawer-b"
  }, children)));
}
Object.assign(__ds_scope, { Drawer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Drawer.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Toast.jsx
try { (() => {
const PA_TOAST_ICONS = {
  ok: 'check',
  info: 'info',
  warn: 'triangle-alert',
  danger: 'circle-alert'
};
const PA_TOAST_COLORS = {
  ok: 'var(--ok-text)',
  info: 'var(--info-text)',
  warn: 'var(--warn-text)',
  danger: 'var(--danger-text)'
};
function Toast({
  tone = 'info',
  title,
  action,
  onDismiss,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "pa-toast",
    role: "status",
    style: style
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: PA_TOAST_ICONS[tone],
    size: 16,
    style: {
      color: PA_TOAST_COLORS[tone],
      marginTop: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pa-toast-title"
  }, title), children ? /*#__PURE__*/React.createElement("div", {
    className: "pa-toast-body"
  }, children) : null, action ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--sp-6)'
    }
  }, action) : null), onDismiss ? /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Dismiss",
    size: "compact",
    onClick: onDismiss
  }) : null);
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Toast.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Tooltip.jsx
try { (() => {
function Tooltip({
  content,
  kbd,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "pa-tt",
    style: style
  }, children, /*#__PURE__*/React.createElement("span", {
    className: "pa-tt-bubble",
    role: "tooltip"
  }, content, kbd ? /*#__PURE__*/React.createElement(__ds_scope.Kbd, null, kbd) : null));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Tooltip.jsx", error: String((e && e.message) || e) }); }

// ui_kits/platform/AssessmentScreen.jsx
try { (() => {
const {
  Table,
  StatusBadge,
  Button,
  Input,
  Select,
  Tabs,
  Badge,
  ProvenanceChip,
  DiffValue,
  Dialog,
  Drawer,
  Radio,
  EmptyState,
  Icon,
  Kbd,
  IconButton
} = window.ProgramAssuranceDesignSystem_004a77;
function Inspector({
  row,
  onDetermine,
  onWhy,
  notify
}) {
  if (!row) return /*#__PURE__*/React.createElement(EmptyState, {
    icon: "panel-right",
    title: "Select an objective to inspect",
    style: {
      padding: 'var(--sp-32) var(--sp-16)'
    }
  }, "Lineage, provider assurance, evidence, and prior determinations appear here.");
  const sec = {
    className: 'u-keycap',
    style: {
      margin: '14px 0 4px'
    }
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--sp-16)',
      fontSize: 'var(--text-body)',
      overflow: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "u-mono",
    style: {
      fontSize: 12,
      color: 'var(--text-secondary)'
    }
  }, row.ctl, " \u2192 ", row.id, " \xB7 SP 800-53A r5"), /*#__PURE__*/React.createElement("div", {
    style: {
      margin: '6px 0 8px',
      lineHeight: 'var(--lh-prose)'
    }
  }, row.st), /*#__PURE__*/React.createElement(StatusBadge, {
    status: row.state
  }), row.prov ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement(ProvenanceChip, {
    kind: "inherited",
    source: row.prov.source
  }, row.prov.label)) : null, /*#__PURE__*/React.createElement("div", sec, "Owner"), /*#__PURE__*/React.createElement("div", null, row.owner || /*#__PURE__*/React.createElement(Badge, {
    tone: "unknown",
    dot: true
  }, "Unassigned")), /*#__PURE__*/React.createElement("div", sec, "Evidence \xB7 ", row.ev || 0), row.ev ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--sp-4)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: 6,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "file-text",
    size: 13,
    style: {
      color: 'var(--text-secondary)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "u-truncate",
    style: {
      flex: 1
    }
  }, "IAM-PROD-CONFIG-2026Q3.pdf"), /*#__PURE__*/React.createElement(StatusBadge, {
    status: "Current",
    dot: false
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: 6,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "file-text",
    size: 13,
    style: {
      color: 'var(--text-secondary)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "u-truncate",
    style: {
      flex: 1
    }
  }, "IdP-policy-export-aug.json"), /*#__PURE__*/React.createElement(StatusBadge, {
    status: "Expiring",
    dot: false
  }))) : /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-secondary)'
    }
  }, "\u2014 none linked"), /*#__PURE__*/React.createElement("div", sec, "Last determination"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-meta)',
      color: 'var(--text-secondary)',
      lineHeight: 1.5
    }
  }, row.state === 'Satisfied' || row.state === 'Inherited – Current' ? 'Satisfied · L. Ferreira · FY25 snapshot v7 · Nov 2, 2025' : '—'), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--sp-6)',
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: "check",
    onClick: onDetermine
  }, "Record determination"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--sp-6)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "compact",
    icon: "message-square",
    onClick: () => notify('info', 'Clarification requested', row.id + ' — routed to ' + (row.owner || 'package owner'))
  }, "Request clarification"), /*#__PURE__*/React.createElement(Button, {
    size: "compact",
    variant: "ghost",
    icon: "git-branch",
    onClick: onWhy
  }, "Why is this here?"))));
}
function AssessmentScreen({
  notify
}) {
  const [rows, setRows] = React.useState(window.PA_DATA.objectives);
  const [tab, setTab] = React.useState('objectives');
  const [q, setQ] = React.useState('');
  const [state, setState] = React.useState('All states');
  const [owner, setOwner] = React.useState('All owners');
  const [active, setActive] = React.useState('AC-06(1)');
  const [dlg, setDlg] = React.useState(false);
  const [why, setWhy] = React.useState(false);
  const [verdict, setVerdict] = React.useState('Satisfied');
  const owners = ['All owners', ...new Set(rows.map(r => r.owner).filter(o => o && o !== 'PROPOSED'))];
  const states = ['All states', ...new Set(rows.map(r => r.state))];
  const shown = rows.filter(r => (state === 'All states' || r.state === state) && (owner === 'All owners' || r.owner === owner) && (q === '' || (r.id + ' ' + r.st).toLowerCase().includes(q.toLowerCase())));
  const activeRow = rows.find(r => r.id === active);
  const resolveProposal = accept => {
    setRows(rs => rs.map(r => r.owner === 'PROPOSED' ? {
      ...r,
      owner: accept ? 'Platform Security' : 'Firmware Eng'
    } : r));
    notify(accept ? 'ok' : 'info', accept ? 'Proposal accepted' : 'Proposal rejected', 'AU-06a.[01] owner ' + (accept ? 'changed to Platform Security' : 'kept as Firmware Eng') + ' · attributed to mapping assist');
  };
  const record = () => {
    setRows(rs => rs.map(r => r.id === active ? {
      ...r,
      state: verdict,
      err: verdict === 'Other Than Satisfied'
    } : r));
    setDlg(false);
    notify('ok', 'Determination recorded', active + ' → ' + verdict + ' · snapshot v3');
  };
  const inherited = shown.filter(r => r.state === 'Inherited – Current').length;
  const unknown = shown.filter(r => r.state === 'Unknown').length;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--sp-12) var(--sp-24) 0',
      background: 'var(--surface-card)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-meta)',
      color: 'var(--text-secondary)'
    }
  }, "Assessments / ", /*#__PURE__*/React.createElement("span", {
    className: "u-mono"
  }, "ASMT-0142")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--sp-12)',
      margin: '2px 0 6px'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      font: '600 var(--text-title)/1.2 var(--font-ui)',
      letterSpacing: '-.01em',
      color: 'var(--text-heading)'
    }
  }, "Tactical Management Controller \u2014 FY26"), /*#__PURE__*/React.createElement(StatusBadge, {
    status: "In Progress"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-meta)',
      color: 'var(--text-secondary)'
    }
  }, "Snapshot v3 \xB7 NIST 800-53 r5 Moderate + C-114 overlay \xB7 freeze Oct 5, 2026")), /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    tabs: [{
      id: 'objectives',
      label: 'Objectives',
      count: 142
    }, {
      id: 'packages',
      label: 'Packages',
      count: 9
    }, {
      id: 'evidence',
      label: 'Evidence',
      count: 1204
    }, {
      id: 'findings',
      label: 'Findings',
      count: 7
    }],
    style: {
      borderBottom: 0
    }
  })), tab !== 'objectives' ? /*#__PURE__*/React.createElement(EmptyState, {
    icon: "layers",
    title: "Not recreated in this kit"
  }, "The ", tab, " view exists in the UX spec (Appendix E) but only Objectives is rebuilt here.") : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 'var(--toolbar-height)',
      flex: 'none',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--sp-8)',
      padding: '0 var(--sp-24)',
      background: 'var(--surface-card)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    icon: "search",
    size: "compact",
    placeholder: "Filter 142 objectives",
    value: q,
    onChange: e => setQ(e.target.value),
    style: {
      width: 220
    }
  }), /*#__PURE__*/React.createElement(Select, {
    size: "compact",
    options: states,
    value: state,
    onChange: e => setState(e.target.value)
  }), /*#__PURE__*/React.createElement(Select, {
    size: "compact",
    options: owners,
    value: owner,
    onChange: e => setOwner(e.target.value)
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(Button, {
    size: "compact",
    variant: "ghost",
    icon: "git-branch"
  }, "Inheritance review"), /*#__PURE__*/React.createElement(Button, {
    size: "compact",
    variant: "primary",
    icon: "check",
    disabled: !activeRow,
    onClick: () => setDlg(true)
  }, "Record determination")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      padding: 'var(--sp-12) 0 var(--sp-12) var(--sp-24)',
      overflow: 'hidden',
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement(Table, {
    density: "compact",
    style: {
      flex: 1,
      alignSelf: 'stretch'
    },
    maxHeight: "100%",
    columns: [{
      key: 'id',
      label: 'Objective',
      width: 104,
      mono: true
    }, {
      key: 'st',
      label: 'Statement',
      clamp: true
    }, {
      key: 'owner',
      label: 'Owner',
      width: 170,
      render: r => r.owner === 'PROPOSED' ? /*#__PURE__*/React.createElement(DiffValue, {
        oldValue: "Firmware Eng",
        newValue: "Platform Security",
        onAccept: () => resolveProposal(true),
        onReject: () => resolveProposal(false)
      }) : r.owner || /*#__PURE__*/React.createElement(Badge, {
        tone: "unknown",
        dot: true
      }, "Unassigned")
    }, {
      key: 'state',
      label: 'State',
      width: 178,
      render: r => /*#__PURE__*/React.createElement(StatusBadge, {
        status: r.state
      })
    }, {
      key: 'ev',
      label: 'Evidence',
      width: 66,
      align: 'right',
      render: r => r.ev === 0 ? '—' : r.ev
    }, {
      key: 'up',
      label: 'Updated',
      width: 76,
      align: 'right',
      sortable: false,
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--text-secondary)',
          fontSize: 12
        }
      }, r.up)
    }],
    rows: shown,
    rowKey: "id",
    activeKey: active,
    onRowClick: r => setActive(r.id),
    rowState: r => r.owner === 'PROPOSED' ? 'pending' : r.err ? 'error' : undefined,
    footer: /*#__PURE__*/React.createElement("span", null, shown.length, " of 142 objectives \xB7 ", inherited, " Inherited \u2013 Current \xB7 ", unknown, " Unknown \xB7 ", /*#__PURE__*/React.createElement(ProvenanceChip, {
      kind: "ai",
      source: "Owner change proposed by mapping assist \xB7 0.87 confidence"
    }, "1 pending proposal")),
    empty: /*#__PURE__*/React.createElement(EmptyState, {
      icon: "list-filter",
      title: "No objectives match",
      action: /*#__PURE__*/React.createElement(Button, {
        size: "compact",
        onClick: () => {
          setQ('');
          setState('All states');
          setOwner('All owners');
        }
      }, "Clear filters")
    }, "Filters exclude all 142 objectives in this snapshot.")
  })), /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 'var(--inspector-width)',
      flex: 'none',
      borderLeft: '1px solid var(--border-subtle)',
      background: 'var(--surface-card)',
      margin: 'var(--sp-12) 0',
      display: 'flex',
      flexDirection: 'column',
      minHeight: 0,
      overflow: 'auto'
    }
  }, /*#__PURE__*/React.createElement(Inspector, {
    row: activeRow,
    onDetermine: () => setDlg(true),
    onWhy: () => setWhy(true),
    notify: notify
  })))), /*#__PURE__*/React.createElement(Dialog, {
    open: dlg,
    onClose: () => setDlg(false),
    title: 'Record determination — ' + active,
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      onClick: () => setDlg(false)
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: "check",
      onClick: record
    }, "Record determination"))
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--sp-8)'
    }
  }, ['Satisfied', 'Other Than Satisfied', 'Not Applicable', 'Insufficient Information'].map(v => /*#__PURE__*/React.createElement(Radio, {
    key: v,
    name: "verdict",
    label: v,
    checked: verdict === v,
    onChange: () => setVerdict(v)
  })), /*#__PURE__*/React.createElement("label", {
    style: {
      fontSize: 'var(--text-body)',
      fontWeight: 500,
      color: 'var(--text-label)',
      marginTop: 4
    }
  }, "Rationale"), /*#__PURE__*/React.createElement("textarea", {
    rows: 3,
    defaultValue: "Enforcement verified against IdP workflow export and linked procedure; conditions of Enterprise IAM RAP v4.2 hold for this system.",
    style: {
      font: '400 13px/1.55 var(--font-ui)',
      padding: 'var(--sp-8)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--r-input)',
      resize: 'vertical',
      color: 'var(--text-primary)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-meta)',
      color: 'var(--text-secondary)'
    }
  }, "Recorded as Alex Naumov \xB7 becomes part of snapshot v3 \xB7 response \u2260 determination: contributor input stays attributed."))), /*#__PURE__*/React.createElement(Drawer, {
    open: why,
    onClose: () => setWhy(false),
    title: "Why is this here?",
    headerExtra: /*#__PURE__*/React.createElement(Kbd, null, "esc")
  }, activeRow ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-body)',
      lineHeight: 'var(--lh-prose)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "u-inherited",
    style: {
      display: 'inline'
    }
  }, activeRow.id, " \u2014 ", activeRow.state), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-secondary)',
      fontSize: 'var(--text-meta)',
      lineHeight: 1.7,
      marginTop: 8
    }
  }, "Obligation \u2014 NIST 800-53 r5 Moderate profile + C-114 overlay \xA73.2", /*#__PURE__*/React.createElement("br", null), activeRow.prov ? /*#__PURE__*/React.createElement(React.Fragment, null, "Source \u2014 ", activeRow.prov.label, /*#__PURE__*/React.createElement("br", null), "Condition \u2014 ", activeRow.prov.source.split('·')[1] || 'see package', /*#__PURE__*/React.createElement("br", null)) : /*#__PURE__*/React.createElement(React.Fragment, null, "Source \u2014 local implementation on TMC v3", /*#__PURE__*/React.createElement("br", null)), "Allocation \u2014 Tactical Management Controller \xB7 ground segment", /*#__PURE__*/React.createElement("br", null), "History \u2014 imported Jan 8, 2026 \xB7 profile v3 pinned \xB7 last change Aug 14, 2026"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12,
      display: 'flex',
      gap: 'var(--sp-6)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "compact",
    variant: "ghost",
    icon: "external-link"
  }, "Open package"), /*#__PURE__*/React.createElement(Button, {
    size: "compact",
    variant: "ghost",
    icon: "history"
  }, "View history"))) : null));
}
Object.assign(window, {
  AssessmentScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/platform/AssessmentScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/platform/FindingsScreen.jsx
try { (() => {
const {
  Table,
  StatusBadge,
  Button,
  Input,
  Select,
  Badge,
  EmptyState,
  Icon
} = window.ProgramAssuranceDesignSystem_004a77;
const SEV_TONE = {
  Critical: 'danger',
  High: 'warn',
  Moderate: 'info',
  Low: 'neutral'
};
const OVERDUE = new Set(['Aug 12', 'Aug 20', 'Aug 22']);
function FindingsScreen({
  notify
}) {
  const all = window.PA_DATA.findings;
  const [q, setQ] = React.useState('');
  const [sev, setSev] = React.useState('All severities');
  const [st, setSt] = React.useState('All states');
  const [sel, setSel] = React.useState(new Set());
  const shown = all.filter(f => (sev === 'All severities' || f.sev === sev) && (st === 'All states' || f.state === st) && (q === '' || (f.id + ' ' + f.title + ' ' + f.scope).toLowerCase().includes(q.toLowerCase())));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--sp-12) var(--sp-24) var(--sp-8)',
      background: 'var(--surface-card)',
      borderBottom: '1px solid var(--border-subtle)',
      display: 'flex',
      alignItems: 'baseline',
      gap: 'var(--sp-12)'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      font: '600 var(--text-title)/1.2 var(--font-ui)',
      letterSpacing: '-.01em',
      color: 'var(--text-heading)'
    }
  }, "Findings"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-meta)',
      color: 'var(--text-secondary)'
    }
  }, "96 across 14 scopes \xB7 4 unassigned \xB7 3 past due")), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 'var(--toolbar-height)',
      flex: 'none',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--sp-8)',
      padding: '0 var(--sp-24)',
      background: 'var(--surface-card)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    icon: "search",
    size: "compact",
    placeholder: "Filter by id, title, scope",
    value: q,
    onChange: e => setQ(e.target.value),
    style: {
      width: 220
    }
  }), /*#__PURE__*/React.createElement(Select, {
    size: "compact",
    options: ['All severities', 'Critical', 'High', 'Moderate', 'Low'],
    value: sev,
    onChange: e => setSev(e.target.value)
  }), /*#__PURE__*/React.createElement(Select, {
    size: "compact",
    options: ['All states', 'Open', 'Triaged', 'Remediation Planned', 'In Remediation', 'Ready for Validation', 'Closed', 'Accepted/Deferred', 'False Positive'],
    value: st,
    onChange: e => setSt(e.target.value)
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), sel.size > 0 ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-meta)',
      color: 'var(--text-secondary)'
    },
    className: "u-num"
  }, sel.size, " selected"), /*#__PURE__*/React.createElement(Button, {
    size: "compact",
    icon: "users",
    onClick: () => {
      notify('info', 'Assign owner', sel.size + ' findings — routing respects scope ownership');
      setSel(new Set());
    }
  }, "Assign"), /*#__PURE__*/React.createElement(Button, {
    size: "compact",
    variant: "primary",
    icon: "link",
    onClick: () => {
      notify('ok', 'Remediation initiative created', 'RI-77 groups ' + sel.size + ' related findings');
      setSel(new Set());
    }
  }, "Create remediation initiative")) : /*#__PURE__*/React.createElement(Button, {
    size: "compact",
    variant: "primary",
    icon: "plus",
    onClick: () => notify('info', 'Create finding', 'Creation flow not recreated in this kit')
  }, "Create finding")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      padding: 'var(--sp-12) var(--sp-24)',
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement(Table, {
    density: "compact",
    selectable: true,
    selected: sel,
    onSelectedChange: setSel,
    style: {
      flex: 1
    },
    maxHeight: "100%",
    columns: [{
      key: 'id',
      label: 'ID',
      width: 70,
      mono: true
    }, {
      key: 'title',
      label: 'Finding',
      clamp: true
    }, {
      key: 'sev',
      label: 'Severity',
      width: 92,
      sortValue: r => ({
        Critical: 0,
        High: 1,
        Moderate: 2,
        Low: 3
      })[r.sev],
      render: r => /*#__PURE__*/React.createElement(Badge, {
        tone: SEV_TONE[r.sev],
        dot: true
      }, r.sev)
    }, {
      key: 'scope',
      label: 'Scope',
      width: 130,
      clamp: true
    }, {
      key: 'state',
      label: 'State',
      width: 160,
      render: r => /*#__PURE__*/React.createElement(StatusBadge, {
        status: r.state
      })
    }, {
      key: 'owner',
      label: 'Owner',
      width: 190,
      render: r => r.owner || /*#__PURE__*/React.createElement(Badge, {
        tone: "unknown",
        dot: true
      }, "Unassigned")
    }, {
      key: 'due',
      label: 'Due',
      width: 66,
      align: 'right',
      render: r => r.due === '—' ? '—' : /*#__PURE__*/React.createElement("span", {
        className: "u-num",
        style: {
          fontSize: 12,
          color: OVERDUE.has(r.due) ? 'var(--danger-text)' : 'var(--text-secondary)',
          fontWeight: OVERDUE.has(r.due) ? 500 : 400
        }
      }, r.due)
    }, {
      key: 'up',
      label: 'Updated',
      width: 76,
      align: 'right',
      sortable: false,
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--text-secondary)',
          fontSize: 12
        }
      }, r.up)
    }],
    rows: shown,
    rowKey: "id",
    rowState: r => OVERDUE.has(r.due) && r.state !== 'Closed' ? 'error' : undefined,
    footer: /*#__PURE__*/React.createElement("span", {
      className: "u-num"
    }, shown.length, " of 96 findings", sev !== 'All severities' || st !== 'All states' || q ? ' · filtered' : '', " \xB7 red rows past due"),
    empty: /*#__PURE__*/React.createElement(EmptyState, {
      icon: "list-filter",
      title: "No findings match",
      action: /*#__PURE__*/React.createElement(Button, {
        size: "compact",
        onClick: () => {
          setQ('');
          setSev('All severities');
          setSt('All states');
        }
      }, "Clear filters")
    }, "Data exists \u2014 the current filter combination excludes all 96 findings.")
  })));
}
Object.assign(window, {
  FindingsScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/platform/FindingsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/platform/HomeScreen.jsx
try { (() => {
const {
  Card,
  Icon,
  StatusBadge,
  Button,
  Badge,
  ProvenanceChip
} = window.ProgramAssuranceDesignSystem_004a77;
function HomeScreen({
  onNav,
  runJob
}) {
  const T = window.PA_DATA.tasks;
  const blockers = [{
    id: 'F-2214',
    what: 'TMC serial console exposes unauthenticated maintenance shell',
    who: 'R. Vance · Firmware Eng',
    due: 'Sep 5',
    state: 'Open'
  }, {
    id: 'F-2196',
    what: 'Shared administrator credentials in integration lab jump host',
    who: 'M. Duran · Platform Security',
    due: 'Aug 12',
    state: 'In Remediation',
    over: true
  }, {
    id: 'F-2184',
    what: 'POA&M milestone slipped: MFA rollout for maintenance accounts',
    who: 'J. Whitfield · Enterprise IAM',
    due: 'Aug 20',
    state: 'In Remediation',
    over: true
  }, {
    id: 'SC-07b.[01]',
    what: 'Boundary protection Unknown — no owner assigned',
    who: null,
    due: 'Sep 12',
    state: 'Unknown'
  }, {
    id: 'CM-06a.[02]',
    what: 'Gateway baseline deviation on management plane',
    who: 'K. Osei · Network Eng',
    due: 'Sep 12',
    state: 'Other Than Satisfied'
  }];
  const row = {
    display: 'flex',
    alignItems: 'center',
    gap: 'var(--sp-8)',
    height: 'var(--row-default)',
    padding: '0 var(--sp-12)',
    borderBottom: '1px solid var(--border-subtle)',
    fontSize: 'var(--text-body)'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--sp-16) var(--sp-24)',
      display: 'flex',
      alignItems: 'baseline',
      gap: 'var(--sp-12)'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      font: '600 var(--text-title)/1.2 var(--font-ui)',
      letterSpacing: '-.01em',
      color: 'var(--text-heading)'
    }
  }, "Home"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-meta)',
      color: 'var(--text-secondary)'
    }
  }, "Alex Naumov \xB7 SSE, Program NIGHTHAWK \xB7 Sunday, Aug 24")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 var(--sp-24) var(--sp-24)',
      display: 'grid',
      gridTemplateColumns: '3fr 2fr',
      gap: 'var(--sp-16)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: "Waiting on you",
    padded: false,
    actions: /*#__PURE__*/React.createElement(Badge, {
      tone: "accent"
    }, "6")
  }, T.map(t => /*#__PURE__*/React.createElement("div", {
    key: t.id,
    style: row
  }, /*#__PURE__*/React.createElement(Icon, {
    name: t.icon,
    size: 14,
    style: {
      color: 'var(--text-secondary)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "u-keycap",
    style: {
      width: 92,
      flex: 'none'
    }
  }, t.kind), /*#__PURE__*/React.createElement("span", {
    className: "u-truncate",
    style: {
      flex: 1
    },
    title: t.text
  }, t.text), /*#__PURE__*/React.createElement("span", {
    className: "u-num",
    style: {
      fontSize: 'var(--text-meta)',
      color: t.due === 'today' ? 'var(--warn-text)' : 'var(--text-secondary)'
    }
  }, t.due))), /*#__PURE__*/React.createElement("div", {
    style: {
      ...row,
      borderBottom: 0,
      height: 32
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "compact",
    variant: "ghost",
    trailingIcon: "chevron-right",
    onClick: () => onNav('assessment')
  }, "Open review queue"))), /*#__PURE__*/React.createElement(Card, {
    title: "Changed upstream",
    padded: false
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...row,
      height: 'auto',
      padding: 'var(--sp-8) var(--sp-12)',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "git-branch",
    size: 14,
    style: {
      color: 'var(--warn-text)',
      marginTop: 2
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", null, "Enterprise VPN RAP ", /*#__PURE__*/React.createElement("span", {
    className: "u-mono",
    style: {
      fontSize: 12
    }
  }, "v2.8"), " is ", /*#__PURE__*/React.createElement(StatusBadge, {
    status: "Impacted",
    dot: false
  }), " \u2014 gateway config moved to GW-STD-12"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-meta)',
      color: 'var(--text-secondary)',
      margin: '2px 0 6px'
    }
  }, "6 dependent objectives set to Reassessment Required \xB7 Yesterday"), /*#__PURE__*/React.createElement(Button, {
    size: "compact",
    icon: "history",
    onClick: () => onNav('assessment')
  }, "Reassess impacted (6)"))), /*#__PURE__*/React.createElement("div", {
    style: {
      ...row,
      height: 'auto',
      padding: 'var(--sp-8) var(--sp-12)',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "upload",
    size: 14,
    style: {
      color: 'var(--info-text)',
      marginTop: 2
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", null, "Enterprise PKI published ", /*#__PURE__*/React.createElement("span", {
    className: "u-mono",
    style: {
      fontSize: 12
    }
  }, "v3.2"), " \u2014 you consume ", /*#__PURE__*/React.createElement("span", {
    className: "u-mono",
    style: {
      fontSize: 12
    }
  }, "v3.1")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-meta)',
      color: 'var(--text-secondary)',
      margin: '2px 0 6px'
    }
  }, "Delta: 2 conditions tightened, 1 objective added \xB7 Aug 21"), /*#__PURE__*/React.createElement(Button, {
    size: "compact",
    onClick: () => onNav('program')
  }, "Review delta"))), /*#__PURE__*/React.createElement("div", {
    style: {
      ...row,
      height: 'auto',
      padding: 'var(--sp-8) var(--sp-12)',
      alignItems: 'flex-start',
      borderBottom: 0
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "triangle-alert",
    size: 14,
    style: {
      color: 'var(--danger-text)',
      marginTop: 2
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", null, "MDM package claim conflicts with lab asset assertion \u2014 ", /*#__PURE__*/React.createElement(StatusBadge, {
    status: "Conflict",
    dot: false
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-meta)',
      color: 'var(--text-secondary)',
      margin: '2px 0 6px'
    }
  }, "Maintenance laptops asserted unmanaged by Integration Lab \xB7 Aug 19"), /*#__PURE__*/React.createElement(Button, {
    size: "compact",
    onClick: () => onNav('program')
  }, "Resolve conflict")))), /*#__PURE__*/React.createElement(Card, {
    title: "What threatens the Oct 5 control freeze",
    padded: false,
    style: {
      gridColumn: '1 / -1'
    },
    actions: /*#__PURE__*/React.createElement(Button, {
      size: "compact",
      variant: "ghost",
      icon: "download",
      onClick: () => runJob('Workbook export — Program NIGHTHAWK')
    }, "Export SCTM workbook")
  }, blockers.map(b => /*#__PURE__*/React.createElement("div", {
    key: b.id,
    style: row
  }, /*#__PURE__*/React.createElement("span", {
    className: "u-mono",
    style: {
      width: 96,
      flex: 'none',
      fontSize: 12
    }
  }, b.id), /*#__PURE__*/React.createElement("span", {
    className: "u-truncate",
    style: {
      flex: 1
    },
    title: b.what
  }, b.what), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 220,
      flex: 'none'
    }
  }, b.who || /*#__PURE__*/React.createElement(Badge, {
    tone: "unknown",
    dot: true
  }, "Unassigned")), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 170,
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement(StatusBadge, {
    status: b.state
  })), /*#__PURE__*/React.createElement("span", {
    className: "u-num",
    style: {
      width: 60,
      flex: 'none',
      textAlign: 'right',
      fontSize: 'var(--text-meta)',
      color: b.over ? 'var(--danger-text)' : 'var(--text-secondary)',
      fontWeight: b.over ? 500 : 400
    }
  }, b.due))))));
}
Object.assign(window, {
  HomeScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/platform/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/platform/ProgramScreen.jsx
try { (() => {
const {
  Table,
  StatusBadge,
  Button,
  Tabs,
  Badge,
  Drawer,
  EmptyState,
  Card,
  ProvenanceChip
} = window.ProgramAssuranceDesignSystem_004a77;
const DIST = [['Satisfied', 412, 'var(--ok-solid)'], ['Inherited – Current', 238, 'var(--inherited-text)'], ['Not Applicable', 46, 'var(--n-4)'], ['Ready for Review', 61, 'var(--info-solid)'], ['Awaiting Response', 44, 'var(--warn-solid)'], ['Unknown', 71, 'var(--unknown-solid)'], ['Other Than Satisfied', 18, 'var(--danger-solid)']];
function ProgramScreen({
  runJob
}) {
  const [tab, setTab] = React.useState('overview');
  const [rap, setRap] = React.useState(null);
  const raps = window.PA_DATA.raps;
  const total = DIST.reduce((s, d) => s + d[1], 0);
  const inheritTable = /*#__PURE__*/React.createElement(Table, {
    rows: raps,
    rowKey: "id",
    onRowClick: r => setRap(r),
    activeKey: rap && rap.id,
    columns: [{
      key: 'name',
      label: 'Assurance package',
      render: r => /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
        style: {
          fontWeight: 500
        }
      }, r.name), " ", /*#__PURE__*/React.createElement("span", {
        className: "u-mono",
        style: {
          fontSize: 12,
          color: 'var(--text-secondary)'
        }
      }, r.ver))
    }, {
      key: 'provider',
      label: 'Provider',
      width: 140
    }, {
      key: 'state',
      label: 'Consumption',
      width: 168,
      render: r => /*#__PURE__*/React.createElement(StatusBadge, {
        status: r.state
      })
    }, {
      key: 'covers',
      label: 'Covers',
      width: 62,
      align: 'right'
    }, {
      key: 'residual',
      label: 'Residual',
      width: 66,
      align: 'right'
    }, {
      key: 'attest',
      label: 'Attest.',
      width: 58,
      align: 'right',
      render: r => r.attest === 0 ? '—' : r.attest
    }, {
      key: 'cond',
      label: 'Condition',
      clamp: true,
      width: 200
    }, {
      key: 'reviewed',
      label: 'Reviewed',
      width: 100,
      align: 'right',
      sortable: false,
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 12,
          color: 'var(--text-secondary)'
        }
      }, r.reviewed)
    }],
    rowState: r => r.state === 'Conflict' ? 'error' : undefined,
    footer: /*#__PURE__*/React.createElement("span", {
      className: "u-num"
    }, "5 packages \xB7 73 objectives covered \xB7 17 residual \xB7 2 need attention before Oct 5")
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--sp-12) var(--sp-24) 0',
      background: 'var(--surface-card)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-meta)',
      color: 'var(--text-secondary)'
    }
  }, "Programs / ", /*#__PURE__*/React.createElement("span", {
    className: "u-mono"
  }, "PRG-114")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--sp-12)',
      margin: '2px 0 6px'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      font: '600 var(--text-title)/1.2 var(--font-ui)',
      letterSpacing: '-.01em',
      color: 'var(--text-heading)'
    }
  }, "Program NIGHTHAWK"), /*#__PURE__*/React.createElement(StatusBadge, {
    status: "Active"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-meta)',
      color: 'var(--text-secondary)'
    }
  }, "Customer C-114 \xB7 System: Tactical Management Controller v3 (baseline v3.2) \xB7 Control freeze Oct 5, 2026 \xB7 SSE A. Naumov")), /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    tabs: [{
      id: 'overview',
      label: 'Overview'
    }, {
      id: 'reqs',
      label: 'Requirements & Controls',
      count: 890
    }, {
      id: 'inherit',
      label: 'Inheritance',
      count: 5
    }, {
      id: 'findings',
      label: 'Findings',
      count: 23
    }, {
      id: 'poam',
      label: 'Risks & POA&M',
      count: 4
    }],
    style: {
      borderBottom: 0
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 'var(--toolbar-height)',
      flex: 'none',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--sp-8)',
      padding: '0 var(--sp-24)',
      background: 'var(--surface-card)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-meta)',
      color: 'var(--text-secondary)'
    }
  }, "Profile v3 pinned \xB7 last change Aug 14, 2026 \xB7 any change shows its blast radius before it lands"), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(Button, {
    size: "compact",
    variant: "ghost",
    icon: "download",
    onClick: () => runJob('Workbook export — Program NIGHTHAWK')
  }, "Export SCTM workbook"), /*#__PURE__*/React.createElement(Button, {
    size: "compact",
    variant: "primary",
    icon: "git-branch",
    onClick: () => setTab('inherit')
  }, "Review inheritance")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: 'auto',
      padding: 'var(--sp-16) var(--sp-24)'
    }
  }, tab === 'overview' ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '3fr 2fr',
      gap: 'var(--sp-16)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: "Objective states \u2014 factual, never a score",
    actions: /*#__PURE__*/React.createElement("span", {
      className: "u-num",
      style: {
        fontSize: 12,
        color: 'var(--text-secondary)'
      }
    }, "890 obligations")
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      height: 10,
      borderRadius: 'var(--r-control)',
      overflow: 'hidden',
      border: '1px solid var(--border-subtle)'
    }
  }, DIST.map(([l, n, c]) => /*#__PURE__*/React.createElement("span", {
    key: l,
    title: l + ' · ' + n,
    style: {
      width: n / total * 100 + '%',
      background: c
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: '2px 24px',
      marginTop: 'var(--sp-12)'
    }
  }, DIST.map(([l, n, c]) => /*#__PURE__*/React.createElement("span", {
    key: l,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--sp-6)',
      fontSize: 'var(--text-body)',
      minHeight: 22
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: 2,
      background: c,
      flex: 'none'
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "u-truncate",
    style: {
      flex: 1
    },
    title: l
  }, l), /*#__PURE__*/React.createElement("span", {
    className: "u-num",
    style: {
      color: 'var(--text-secondary)'
    }
  }, n)))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--sp-8)',
      fontSize: 'var(--text-meta)',
      color: 'var(--text-secondary)'
    }
  }, "71 Unknown are work, not risk acceptance \u2014 5 unowned. 18 Other Than Satisfied trace to 23 findings.")), /*#__PURE__*/React.createElement(Card, {
    title: "Attention before Oct 5",
    padded: false
  }, [['Enterprise VPN RAP v2.8', 'Impacted', '6 objectives to reassess'], ['Enterprise MDM RAP v5.0', 'Conflict', 'lab asset assertion disagrees'], ['PKI consumer attestation', 'Attestation Required', 'device certificate scope'], ['SC-28(1) data-at-rest', 'Unknown', 'no owner assigned']].map(([a, s, b]) => /*#__PURE__*/React.createElement("div", {
    key: a,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--sp-8)',
      height: 'var(--row-default)',
      padding: '0 var(--sp-12)',
      borderBottom: '1px solid var(--border-subtle)',
      fontSize: 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "u-truncate",
    style: {
      flex: 1
    }
  }, a), /*#__PURE__*/React.createElement(StatusBadge, {
    status: s
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--text-secondary)',
      width: 160
    },
    className: "u-truncate"
  }, b))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--sp-8) var(--sp-12)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "compact",
    variant: "ghost",
    trailingIcon: "chevron-right",
    onClick: () => setTab('inherit')
  }, "Open inheritance review"))), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: '1 / -1'
    }
  }, inheritTable)) : tab === 'inherit' ? inheritTable : /*#__PURE__*/React.createElement(EmptyState, {
    icon: "layers",
    title: "Not recreated in this kit"
  }, "This tab exists in the UX spec (Appendix E); Overview and Inheritance are rebuilt here.")), /*#__PURE__*/React.createElement(Drawer, {
    open: !!rap,
    onClose: () => setRap(null),
    title: rap ? rap.name + ' ' + rap.ver : '',
    wide: true
  }, rap ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-body)',
      lineHeight: 'var(--lh-prose)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--sp-6)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(StatusBadge, {
    status: rap.state
  }), /*#__PURE__*/React.createElement(ProvenanceChip, {
    kind: "inherited",
    source: 'Published by ' + rap.provider + ' · reviewed ' + rap.reviewed
  }, "provider: ", rap.provider)), /*#__PURE__*/React.createElement("div", {
    className: "u-keycap",
    style: {
      margin: '14px 0 4px'
    }
  }, "What this package gives you"), /*#__PURE__*/React.createElement("div", {
    className: "u-num"
  }, rap.covers, " objectives resolved \xB7 ", rap.residual, " residual tasks stay with the consumer", rap.attest ? ' · ' + rap.attest + ' attestation(s) required' : ''), /*#__PURE__*/React.createElement("div", {
    className: "u-keycap",
    style: {
      margin: '14px 0 4px'
    }
  }, "Applicability condition"), /*#__PURE__*/React.createElement("div", null, rap.cond, " \u2014 ", rap.state === 'Impacted' ? 'condition changed upstream; inheritance suppressed until reassessed' : rap.state === 'Conflict' ? 'a consumer assertion disagrees; conflict stays visible until adjudicated' : 'passing for TMC v3'), /*#__PURE__*/React.createElement("div", {
    className: "u-keycap",
    style: {
      margin: '14px 0 4px'
    }
  }, "Inheritance is a claim, not a copy"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-secondary)',
      fontSize: 'var(--text-meta)'
    }
  }, "Source, version, conditions, evidence lineage, and invalidation triggers stay attached. Rejecting an inappropriate claim here is what prevents false local coverage."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--sp-6)',
      marginTop: 'var(--sp-16)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "compact",
    variant: "primary"
  }, "Accept applicable portion"), /*#__PURE__*/React.createElement(Button, {
    size: "compact"
  }, "Request applicability review"))) : null));
}
Object.assign(window, {
  ProgramScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/platform/ProgramScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/platform/Shell.jsx
try { (() => {
const {
  Icon,
  Kbd,
  Input,
  IconButton,
  Tooltip,
  Badge
} = window.ProgramAssuranceDesignSystem_004a77;
const NAV = [{
  group: 'Foundation',
  items: [{
    id: 'home',
    label: 'Home',
    icon: 'home',
    count: 6
  }, {
    id: 'organization',
    label: 'Organization',
    icon: 'building-2',
    count: 23
  }, {
    id: 'assets',
    label: 'Assets',
    icon: 'boxes',
    count: 4112
  }]
}, {
  group: 'Obligations',
  items: [{
    id: 'library',
    label: 'Library',
    icon: 'library',
    count: 57
  }]
}, {
  group: 'Delivery',
  items: [{
    id: 'products',
    label: 'Products & Systems',
    icon: 'layers',
    count: 48
  }, {
    id: 'program',
    label: 'Programs',
    icon: 'clipboard-list',
    count: 6
  }]
}, {
  group: 'Assurance work',
  items: [{
    id: 'assessment',
    label: 'Assessments',
    icon: 'inbox',
    count: 3
  }, {
    id: 'findings',
    label: 'Findings',
    icon: 'flag',
    count: 96
  }, {
    id: 'risks',
    label: 'Risks & POA&M',
    icon: 'shield-alert',
    count: 9
  }]
}];
const fmtCount = n => n > 9999 ? '999+' : n > 999 ? (n / 1000).toFixed(1).replace('.0', '') + 'k' : String(n);
function RailItem({
  item,
  active,
  onClick
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    style: {
      all: 'unset',
      boxSizing: 'border-box',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--sp-8)',
      width: '100%',
      height: 'var(--row-compact)',
      padding: '0 var(--sp-8)',
      borderRadius: 'var(--r-control)',
      cursor: 'pointer',
      color: active ? 'var(--accent-text)' : 'var(--text-label)',
      fontSize: 'var(--text-body)',
      fontWeight: active ? 500 : 400,
      background: active ? 'var(--accent-bg)' : 'transparent',
      transition: 'background var(--t-state)'
    },
    onMouseEnter: e => {
      if (!active) e.currentTarget.style.background = 'var(--surface-inset)';
    },
    onMouseLeave: e => {
      if (!active) e.currentTarget.style.background = 'transparent';
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: item.icon,
    size: 15
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    },
    className: "u-truncate"
  }, item.label), /*#__PURE__*/React.createElement("span", {
    className: "u-num",
    style: {
      fontSize: 'var(--text-meta)',
      color: 'var(--text-secondary)'
    }
  }, fmtCount(item.count)));
}
const PALETTE = [{
  g: 'Go to',
  t: 'Home',
  icon: 'home',
  nav: 'home'
}, {
  g: 'Go to',
  t: 'Assessment — TMC FY26',
  icon: 'inbox',
  nav: 'assessment'
}, {
  g: 'Go to',
  t: 'Findings',
  icon: 'flag',
  nav: 'findings'
}, {
  g: 'Go to',
  t: 'Program NIGHTHAWK',
  icon: 'clipboard-list',
  nav: 'program'
}, {
  g: 'Actions',
  t: 'Export SCTM workbook',
  icon: 'download',
  job: 'Workbook export — Program NIGHTHAWK'
}, {
  g: 'Actions',
  t: 'Create finding',
  icon: 'flag',
  nav: 'findings'
}, {
  g: 'Actions',
  t: 'Reassess impacted objectives (6)',
  icon: 'history',
  nav: 'assessment'
}, {
  g: 'Objects',
  t: 'Enterprise IAM Assurance Package v4.2',
  icon: 'git-branch',
  nav: 'program'
}, {
  g: 'Objects',
  t: 'Tactical Management Controller — TMC v3',
  icon: 'layers',
  nav: 'program'
}, {
  g: 'Objects',
  t: 'F-2214 · TMC serial console maintenance shell',
  icon: 'flag',
  nav: 'findings'
}];
function CommandPalette({
  open,
  onClose,
  onNav,
  runJob
}) {
  const [q, setQ] = React.useState('');
  React.useEffect(() => {
    if (open) setQ('');
  }, [open]);
  if (!open) return null;
  const hits = PALETTE.filter(p => p.t.toLowerCase().includes(q.toLowerCase()));
  const run = p => {
    if (p.job) runJob(p.job);
    if (p.nav) onNav(p.nav);
    onClose();
  };
  const groups = [...new Set(hits.map(h => h.g))];
  return /*#__PURE__*/React.createElement("div", {
    className: "pa-scrim",
    style: {
      alignItems: 'flex-start',
      paddingTop: 96
    },
    onMouseDown: e => {
      if (e.target === e.currentTarget) onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pa-dialog",
    style: {
      width: 560
    },
    role: "dialog",
    "aria-label": "Command palette"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--sp-8)',
      padding: 'var(--sp-8) var(--sp-12)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search",
    size: 16,
    style: {
      color: 'var(--text-secondary)'
    }
  }), /*#__PURE__*/React.createElement("input", {
    autoFocus: true,
    value: q,
    onChange: e => setQ(e.target.value),
    onKeyDown: e => {
      if (e.key === 'Enter' && hits[0]) run(hits[0]);
      if (e.key === 'Escape') onClose();
    },
    placeholder: "Type an object, action, or intent \u2014 e.g. why is SC-7 satisfied",
    style: {
      flex: 1,
      border: 0,
      outline: 0,
      font: '400 14px var(--font-ui)',
      background: 'transparent',
      color: 'var(--text-primary)'
    }
  }), /*#__PURE__*/React.createElement(Kbd, null, "esc")), /*#__PURE__*/React.createElement("div", {
    style: {
      maxHeight: 320,
      overflow: 'auto',
      padding: 'var(--sp-4)'
    }
  }, groups.map(g => /*#__PURE__*/React.createElement("div", {
    key: g
  }, /*#__PURE__*/React.createElement("div", {
    className: "u-keycap",
    style: {
      padding: '8px 8px 4px'
    }
  }, g), hits.filter(h => h.g === g).map((p, i) => /*#__PURE__*/React.createElement("button", {
    key: p.t,
    type: "button",
    onClick: () => run(p),
    style: {
      all: 'unset',
      boxSizing: 'border-box',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--sp-8)',
      width: '100%',
      height: 'var(--row-default)',
      padding: '0 var(--sp-8)',
      borderRadius: 'var(--r-control)',
      cursor: 'pointer',
      fontSize: 'var(--text-body)',
      background: g === groups[0] && i === 0 && hits[0] === p ? 'var(--selection-bg)' : 'transparent'
    },
    onMouseEnter: e => e.currentTarget.style.background = 'var(--surface-inset)',
    onMouseLeave: e => e.currentTarget.style.background = hits[0] === p ? 'var(--selection-bg)' : 'transparent'
  }, /*#__PURE__*/React.createElement(Icon, {
    name: p.icon,
    size: 14,
    style: {
      color: 'var(--text-secondary)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, p.t), hits[0] === p ? /*#__PURE__*/React.createElement(Kbd, null, "\u21B5") : null)))), hits.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--sp-16)',
      fontSize: 'var(--text-body)',
      color: 'var(--text-secondary)'
    }
  }, "No matches for \u201C", q, "\u201D.") : null)));
}
function JobsTray({
  jobs
}) {
  const [open, setOpen] = React.useState(false);
  const running = jobs.filter(j => !j.done).length;
  if (jobs.length === 0) return null;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "pa-btn pa-btn--ghost pa-btn--compact",
    onClick: () => setOpen(o => !o)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: running ? 'loader-circle' : 'check',
    size: 14,
    className: running ? 'pa-spin' : '',
    style: {
      color: running ? 'var(--accent-text)' : 'var(--ok-text)'
    }
  }), running ? running + ' running' : 'Jobs'), open ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: '100%',
      right: 0,
      marginTop: 4,
      width: 320,
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--r-card)',
      boxShadow: 'var(--elev-float)',
      zIndex: 70,
      padding: 'var(--sp-4)'
    }
  }, jobs.map(j => /*#__PURE__*/React.createElement("div", {
    key: j.id,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--sp-8)',
      padding: 'var(--sp-8)',
      fontSize: 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: j.done ? 'check' : 'loader-circle',
    size: 14,
    className: j.done ? '' : 'pa-spin',
    style: {
      color: j.done ? 'var(--ok-text)' : 'var(--accent-text)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    },
    className: "u-truncate"
  }, j.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-meta)',
      color: 'var(--text-secondary)'
    }
  }, j.done ? 'done' : j.pct + '%')))) : null);
}
function Shell({
  route,
  onNav,
  jobs,
  onOpenPalette,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      height: '100vh',
      overflow: 'hidden',
      background: 'var(--surface-app)'
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      height: 'var(--topbar-height)',
      flex: 'none',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--sp-16)',
      padding: '0 var(--sp-16)',
      background: 'var(--surface-card)',
      borderBottom: '1px solid var(--border-default)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      fontSize: 'var(--text-comfort)',
      letterSpacing: '-.01em',
      color: 'var(--text-heading)',
      whiteSpace: 'nowrap'
    }
  }, "Program Assurance"), /*#__PURE__*/React.createElement("div", {
    onClick: onOpenPalette,
    style: {
      width: 340
    }
  }, /*#__PURE__*/React.createElement(Input, {
    icon: "search",
    placeholder: "Search controls, assets, findings\u2026",
    readOnly: true,
    suffix: /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'flex',
        gap: 2
      }
    }, /*#__PURE__*/React.createElement(Kbd, null, "\u2318"), /*#__PURE__*/React.createElement(Kbd, null, "K")),
    size: "compact",
    style: {
      cursor: 'pointer'
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(JobsTray, {
    jobs: jobs
  }), /*#__PURE__*/React.createElement(Tooltip, {
    content: "Notifications"
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "bell",
    label: "Notifications"
  })), /*#__PURE__*/React.createElement("span", {
    "aria-label": "Alex Naumov",
    title: "Alex Naumov \xB7 SSE, Program NIGHTHAWK",
    style: {
      width: 24,
      height: 24,
      borderRadius: 'var(--r-pill)',
      background: 'var(--n-8)',
      color: '#fff',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 10,
      fontWeight: 600
    }
  }, "AN")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("nav", {
    style: {
      width: 'var(--rail-width)',
      flex: 'none',
      background: 'var(--surface-card)',
      borderRight: '1px solid var(--border-subtle)',
      padding: 'var(--sp-8)',
      overflow: 'auto',
      boxSizing: 'border-box'
    }
  }, NAV.map(g => /*#__PURE__*/React.createElement("div", {
    key: g.group,
    style: {
      marginBottom: 'var(--sp-12)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "u-keycap",
    style: {
      padding: '0 var(--sp-8) var(--sp-4)',
      color: 'var(--text-secondary)'
    }
  }, g.group), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--sp-2)'
    }
  }, g.items.map(it => /*#__PURE__*/React.createElement(RailItem, {
    key: it.id,
    item: it,
    active: route === it.id,
    onClick: () => onNav(it.id)
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--sp-8)',
      fontSize: 'var(--text-meta)',
      color: 'var(--text-placeholder)'
    }
  }, "Snapshot v3 \xB7 Aug 24, 2026")), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden'
    }
  }, children)));
}
Object.assign(window, {
  Shell,
  CommandPalette,
  PA_NAV: NAV
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/platform/Shell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/platform/app.jsx
try { (() => {
const {
  Toast,
  Button,
  EmptyState
} = window.ProgramAssuranceDesignSystem_004a77;
const NOT_BUILT = {
  organization: 'Organization',
  assets: 'Assets',
  library: 'Library',
  products: 'Products & Systems',
  risks: 'Risks & POA&M'
};
function App() {
  const [route, setRoute] = React.useState(() => localStorage.getItem('pa-kit-route') || 'home');
  const [palette, setPalette] = React.useState(false);
  const [jobs, setJobs] = React.useState([]);
  const [toasts, setToasts] = React.useState([]);
  const nav = r => {
    setRoute(r);
    localStorage.setItem('pa-kit-route', r);
  };
  const notify = (tone, title, body, action) => {
    const id = Date.now() + Math.random();
    setToasts(t => [...t, {
      id,
      tone,
      title,
      body,
      action
    }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 7000);
  };
  const runJob = name => {
    const id = Date.now();
    setJobs(j => [{
      id,
      name,
      pct: 0,
      done: false
    }, ...j]);
    const tick = setInterval(() => setJobs(j => j.map(x => x.id === id ? {
      ...x,
      pct: Math.min(100, x.pct + 25)
    } : x)), 600);
    setTimeout(() => {
      clearInterval(tick);
      setJobs(j => j.map(x => x.id === id ? {
        ...x,
        pct: 100,
        done: true
      } : x));
      notify('ok', 'Workbook export finished', '842 rows · Program NIGHTHAWK · 14s', /*#__PURE__*/React.createElement(Button, {
        size: "compact",
        variant: "ghost",
        icon: "download"
      }, "Download SCTM.xlsx"));
    }, 2600);
  };
  React.useEffect(() => {
    const onKey = e => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setPalette(p => !p);
      }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, []);
  const screen = route === 'home' ? /*#__PURE__*/React.createElement(HomeScreen, {
    onNav: nav,
    runJob: runJob
  }) : route === 'assessment' ? /*#__PURE__*/React.createElement(AssessmentScreen, {
    notify: notify
  }) : route === 'findings' ? /*#__PURE__*/React.createElement(FindingsScreen, {
    notify: notify
  }) : route === 'program' ? /*#__PURE__*/React.createElement(ProgramScreen, {
    runJob: runJob
  }) : /*#__PURE__*/React.createElement(EmptyState, {
    icon: "layers",
    title: NOT_BUILT[route] + ' — not recreated in this kit',
    style: {
      flex: 1
    },
    action: /*#__PURE__*/React.createElement(Button, {
      size: "compact",
      onClick: () => nav('home')
    }, "Back to Home")
  }, "This surface exists in the product spec (46-screen inventory in research/DIGEST.md) but was intentionally not rebuilt. The four built screens demonstrate the full component vocabulary.");
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Shell, {
    route: route,
    onNav: nav,
    jobs: jobs,
    onOpenPalette: () => setPalette(true)
  }, screen), /*#__PURE__*/React.createElement(CommandPalette, {
    open: palette,
    onClose: () => setPalette(false),
    onNav: nav,
    runJob: runJob
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      right: 16,
      bottom: 16,
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      zIndex: 80
    }
  }, toasts.map(t => /*#__PURE__*/React.createElement(Toast, {
    key: t.id,
    tone: t.tone,
    title: t.title,
    action: t.action,
    onDismiss: () => setToasts(x => x.filter(y => y.id !== t.id))
  }, t.body))));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/platform/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/platform/data.js
try { (() => {
/* Shared demo data for the Platform UI kit. Plain script — sets window.PA_DATA. */
window.PA_DATA = (() => {
  const objectives = [{
    id: 'AC-02a.[01]',
    ctl: 'AC-2',
    st: 'Account request approval enforced for privileged roles on the Tactical Management Controller',
    owner: 'Enterprise IAM',
    state: 'Inherited – Current',
    ev: 12,
    up: '2m ago',
    prov: {
      kind: 'inherited',
      label: 'Enterprise IAM RAP v4.2',
      source: 'Inherited from Enterprise IAM Assurance Package v4.2 · condition: production SSO · reviewed Aug 14, 2026'
    }
  }, {
    id: 'AC-02a.[02]',
    ctl: 'AC-2',
    st: 'Account inventory reconciled against the authoritative directory on the defined cadence',
    owner: 'Enterprise IAM',
    state: 'Satisfied',
    ev: 8,
    up: '6h ago'
  }, {
    id: 'AC-02g.[01]',
    ctl: 'AC-2',
    st: 'Privileged account use monitored and reported per organization policy',
    owner: 'SOC',
    state: 'Ready for Review',
    ev: 5,
    up: '6h ago'
  }, {
    id: 'AC-06(1)',
    ctl: 'AC-6',
    st: 'Access to security functions restricted to explicitly authorized personnel',
    owner: 'Platform Security',
    state: 'Ready for Review',
    ev: 3,
    up: 'Yesterday'
  }, {
    id: 'AC-17a.[01]',
    ctl: 'AC-17',
    st: 'Remote access methods documented, authorized, and monitored',
    owner: 'Enterprise VPN',
    state: 'Reassessment Required',
    ev: 6,
    up: 'Yesterday',
    prov: {
      kind: 'inherited',
      label: 'Enterprise VPN RAP v2.8',
      source: 'Enterprise VPN Assurance Package v2.8 · Impacted by gateway config change GW-STD-12 · reassessment required'
    }
  }, {
    id: 'AU-06a.[01]',
    ctl: 'AU-6',
    st: 'Audit record review cadence defined and performed for the ground segment',
    owner: 'PROPOSED',
    state: 'In Progress',
    ev: 5,
    up: 'Aug 21'
  }, {
    id: 'AU-12a.[02]',
    ctl: 'AU-12',
    st: 'Audit records generated for the events defined in AU-2 on all TMC subsystems',
    owner: 'SOC',
    state: 'Awaiting Response',
    ev: 2,
    up: 'Aug 20'
  }, {
    id: 'CM-06a.[02]',
    ctl: 'CM-6',
    st: 'Configuration settings applied and deviations documented per baseline GW-STD-11',
    owner: 'Network Eng',
    state: 'Other Than Satisfied',
    ev: 4,
    up: 'Aug 19',
    err: true
  }, {
    id: 'CM-08a.[01]',
    ctl: 'CM-8',
    st: 'System component inventory current, complete, and granular for the deployed variant',
    owner: 'Systems Eng',
    state: 'Satisfied',
    ev: 7,
    up: 'Aug 18'
  }, {
    id: 'IA-02(1)',
    ctl: 'IA-2',
    st: 'MFA enforced for network access to privileged accounts',
    owner: 'Enterprise IAM',
    state: 'Inherited – Current',
    ev: 11,
    up: 'Aug 18',
    prov: {
      kind: 'inherited',
      label: 'Enterprise IAM RAP v4.2',
      source: 'Inherited from Enterprise IAM Assurance Package v4.2 · reviewed Aug 14, 2026'
    }
  }, {
    id: 'IA-05(1)',
    ctl: 'IA-5',
    st: 'Password-based authenticator strength enforced at the enterprise IdP',
    owner: 'Enterprise IAM',
    state: 'Awaiting Response',
    ev: 0,
    up: 'Aug 15'
  }, {
    id: 'IR-04a.[01]',
    ctl: 'IR-4',
    st: 'Incident handling capability covers preparation, detection, containment, and recovery',
    owner: 'Incident Response',
    state: 'Inherited – Current',
    ev: 9,
    up: 'Aug 14',
    prov: {
      kind: 'inherited',
      label: 'Enterprise IR RAP v3.0',
      source: 'Inherited from Enterprise Incident Response Package v3.0 · reviewed Jul 30, 2026'
    }
  }, {
    id: 'SC-07b.[01]',
    ctl: 'SC-7',
    st: 'Boundary protection at external interfaces of the Tactical Management Controller',
    owner: null,
    state: 'Unknown',
    ev: 0,
    up: 'Aug 12'
  }, {
    id: 'SC-08(1)',
    ctl: 'SC-8',
    st: 'Transmission confidentiality protected by cryptographic mechanisms on C2 links',
    owner: 'Comms Eng',
    state: 'Insufficient Information',
    ev: 1,
    up: 'Aug 12'
  }, {
    id: 'SC-13a.[01]',
    ctl: 'SC-13',
    st: 'FIPS-validated cryptography identified for each protected data flow',
    owner: 'Crypto Eng',
    state: 'Satisfied',
    ev: 6,
    up: 'Aug 11'
  }, {
    id: 'SC-28(1)',
    ctl: 'SC-28',
    st: 'Data-at-rest protection on removable mission data stores',
    owner: null,
    state: 'Unknown',
    ev: 0,
    up: 'Aug 9'
  }, {
    id: 'SI-02c.[01]',
    ctl: 'SI-2',
    st: 'Flaw remediation within organization-defined response times for fielded firmware',
    owner: 'Firmware Eng',
    state: 'Reassessment Required',
    ev: 9,
    up: 'Jul 27'
  }, {
    id: 'SI-04a.[01]',
    ctl: 'SI-4',
    st: 'Monitoring objectives defined for the TMC operational network segment',
    owner: 'SOC',
    state: 'Planned',
    ev: 0,
    up: 'Jul 27'
  }, {
    id: 'SI-07a.[01]',
    ctl: 'SI-7',
    st: 'Software and firmware integrity verified with signed images at boot',
    owner: 'Firmware Signing',
    state: 'Inherited – Current',
    ev: 8,
    up: 'Jul 25',
    prov: {
      kind: 'inherited',
      label: 'Firmware Signing RAP v1.4',
      source: 'Inherited from Firmware Signing Assurance Package v1.4 · condition: HSM-backed pipeline · reviewed Jul 25, 2026'
    }
  }, {
    id: 'PE-03a.[01]',
    ctl: 'PE-3',
    st: 'Physical access authorizations enforced at the integration lab',
    owner: 'Facilities',
    state: 'Not Applicable',
    ev: 2,
    up: 'Jul 21'
  }];
  const sev = {
    C: 'Critical',
    H: 'High',
    M: 'Moderate',
    L: 'Low'
  };
  const F = (n, title, s, scope, state, owner, due, up) => ({
    id: 'F-' + n,
    title,
    sev: sev[s],
    scope,
    state,
    owner,
    due,
    up
  });
  const findings = [F(2214, 'TMC serial console exposes unauthenticated maintenance shell in bench configuration', 'C', 'TMC v3', 'Open', 'R. Vance · Firmware Eng', 'Sep 5', '2m ago'), F(2213, 'Boundary protection undefined for payload telemetry interface', 'C', 'TMC v3', 'Triaged', 'K. Osei · Network Eng', 'Sep 5', '1h ago'), F(2209, 'Gateway config GW-STD-11 deviation: management plane reachable from ops VLAN', 'H', 'Program NIGHTHAWK', 'In Remediation', 'K. Osei · Network Eng', 'Sep 12', '3h ago'), F(2201, 'Audit forwarding gap — ground segment collectors drop records above 2k eps', 'H', 'Ground Segment', 'Open', null, 'Sep 12', '6h ago'), F(2198, 'Firmware signing key rotation overdue on legacy build pipeline', 'H', 'Firmware Signing', 'Remediation Planned', 'T. Iwu · Firmware Signing', 'Sep 19', 'Yesterday'), F(2196, 'Shared administrator credentials in integration lab jump host', 'H', 'Integration Lab', 'In Remediation', 'M. Duran · Platform Security', 'Aug 12', 'Yesterday')];
  const more = [['2195', 'Session lock not enforced on operator consoles', 'M', 'TMC v3', 'Ready for Validation', 'A. Petrov · Systems Eng', 'Aug 29', 'Yesterday'], ['2189', 'SC-8 encryption claim lacks current test evidence for C2 downlink', 'M', 'Program NIGHTHAWK', 'Open', 'L. Chen · Comms Eng', 'Sep 26', 'Aug 21'], ['2187', 'Vulnerability scan cadence not met for air-gapped enclave', 'M', 'Vulnerability Mgmt', 'Triaged', 'S. Bright · Vuln Mgmt', 'Sep 26', 'Aug 21'], ['2184', 'POA&M milestone slipped: MFA rollout for maintenance accounts', 'H', 'Enterprise IAM', 'In Remediation', 'J. Whitfield · Enterprise IAM', 'Aug 20', 'Aug 20'], ['2183', 'Removable media handling procedure unreferenced by operators', 'L', 'Ops Unit 4', 'Closed', 'D. Kim · Ops Unit 4', '—', 'Aug 19'], ['2181', 'Incident escalation contact list stale for night shift', 'L', 'Incident Response', 'Closed', 'P. Marsh · IR', '—', 'Aug 19'], ['2178', 'TLS 1.0 accepted on legacy telemetry bridge', 'H', 'Ground Segment', 'Open', null, 'Sep 5', 'Aug 18'], ['2175', 'Backup restoration untested for mission planning datastore', 'M', 'Mission Planning', 'Remediation Planned', 'A. Petrov · Systems Eng', 'Oct 3', 'Aug 18'], ['2172', 'Privileged access review evidence older than 12 months', 'M', 'Enterprise IAM', 'Ready for Validation', 'J. Whitfield · Enterprise IAM', 'Aug 27', 'Aug 17'], ['2170', 'Default SNMP community strings on lab switches', 'M', 'Integration Lab', 'Closed', 'K. Osei · Network Eng', '—', 'Aug 16'], ['2166', 'Anti-tamper coating verification skipped on lot 7', 'H', 'TMC v3', 'Accepted/Deferred', 'Program Office', 'Dec 15', 'Aug 15'], ['2160', 'Audit review responsibilities unassigned for payload segment', 'M', 'Payload', 'Open', null, 'Sep 19', 'Aug 14'], ['2159', 'Crypto module certificate expires within 90 days', 'M', 'Crypto Eng', 'In Remediation', 'L. Chen · Comms Eng', 'Sep 30', 'Aug 14'], ['2154', 'Firmware rollback protection not verified on variant B', 'C', 'TMC v3-B', 'Open', 'R. Vance · Firmware Eng', 'Sep 5', 'Aug 13'], ['2151', 'Least-functionality baseline missing for diagnostic port set', 'M', 'TMC v3', 'Triaged', 'A. Petrov · Systems Eng', 'Oct 3', 'Aug 12'], ['2149', 'Supply chain attestation absent for COTS SBC lot', 'H', 'Supply Chain', 'Open', null, 'Sep 12', 'Aug 12'], ['2144', 'Password vault access recertification overdue', 'M', 'Platform Security', 'In Remediation', 'M. Duran · Platform Security', 'Aug 22', 'Aug 11'], ['2140', 'Test range spectrum authorization evidence expired', 'L', 'Test Range', 'Closed', 'Ops Unit 4', '—', 'Aug 9'], ['2138', 'Maintenance laptop patch level below baseline', 'M', 'Integration Lab', 'Ready for Validation', 'M. Duran · Platform Security', 'Aug 29', 'Aug 8'], ['2131', 'Continuous monitoring plan lacks payload telemetry coverage', 'M', 'Program NIGHTHAWK', 'Remediation Planned', 'SOC', 'Oct 10', 'Aug 7'], ['2127', 'Physical escort log gaps at integration facility', 'L', 'Facilities', 'False Positive', 'Facilities', '—', 'Aug 5'], ['2119', 'Key ceremony witness requirement unmet for signing key K-114', 'H', 'Firmware Signing', 'Ready for Validation', 'T. Iwu · Firmware Signing', 'Aug 27', 'Aug 2'], ['2114', 'Developer test credentials present in fielded config export', 'C', 'TMC v3', 'In Remediation', 'R. Vance · Firmware Eng', 'Sep 1', 'Jul 30'], ['2108', 'Interconnection agreement missing for partner ground station', 'M', 'Ground Segment', 'Open', null, 'Oct 10', 'Jul 28']].map(a => F(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]));
  const raps = [{
    id: 'RAP-IAM',
    name: 'Enterprise IAM Assurance Package',
    ver: 'v4.2',
    provider: 'Enterprise IAM',
    state: 'Active',
    covers: 38,
    residual: 7,
    attest: 2,
    cond: 'production SSO configuration',
    reviewed: 'Aug 14, 2026'
  }, {
    id: 'RAP-PKI',
    name: 'Enterprise PKI Assurance Package',
    ver: 'v3.1',
    provider: 'Enterprise PKI',
    state: 'Attestation Required',
    covers: 12,
    residual: 3,
    attest: 1,
    cond: 'org-issued device certificates',
    reviewed: 'Aug 2, 2026'
  }, {
    id: 'RAP-VPN',
    name: 'Enterprise VPN Assurance Package',
    ver: 'v2.8',
    provider: 'Enterprise VPN',
    state: 'Impacted',
    covers: 9,
    residual: 2,
    attest: 0,
    cond: 'managed gateway config GW-STD-12',
    reviewed: 'Jul 19, 2026'
  }, {
    id: 'RAP-FWS',
    name: 'Firmware Signing Assurance Package',
    ver: 'v1.4',
    provider: 'Firmware Signing',
    state: 'Active',
    covers: 8,
    residual: 1,
    attest: 0,
    cond: 'HSM-backed pipeline',
    reviewed: 'Jul 25, 2026'
  }, {
    id: 'RAP-MDM',
    name: 'Enterprise MDM Assurance Package',
    ver: 'v5.0',
    provider: 'Enterprise MDM',
    state: 'Conflict',
    covers: 6,
    residual: 4,
    attest: 1,
    cond: 'managed maintenance laptops only',
    reviewed: 'Jun 30, 2026'
  }];
  const tasks = [{
    id: 'T-8841',
    kind: 'Review',
    text: '14 responses ready for review — TMC FY26 assessment',
    due: 'today',
    icon: 'inbox'
  }, {
    id: 'T-8836',
    kind: 'Determination',
    text: 'AC-06(1) — access to security functions · response accepted as input',
    due: 'today',
    icon: 'check'
  }, {
    id: 'T-8829',
    kind: 'Clarification',
    text: 'IA-05(1) — J. Whitfield asked which IdP policy version applies',
    due: 'Aug 26',
    icon: 'message-square'
  }, {
    id: 'T-8822',
    kind: 'Inheritance',
    text: 'Enterprise VPN RAP v2.8 Impacted — re-resolve 6 dependent objectives',
    due: 'Aug 28',
    icon: 'git-branch'
  }, {
    id: 'T-8817',
    kind: 'Attestation',
    text: 'PKI package requires consumer attestation: device certificate scope',
    due: 'Sep 2',
    icon: 'file-text'
  }, {
    id: 'T-8810',
    kind: 'Promotion',
    text: 'Boundary diagram for TMC v3 submitted for broader reuse — scope review',
    due: 'Sep 4',
    icon: 'upload'
  }];
  return {
    objectives,
    findings: [...findings, ...more],
    raps,
    tasks
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/platform/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Kbd = __ds_scope.Kbd;

__ds_ns.DiffValue = __ds_scope.DiffValue;

__ds_ns.Table = __ds_scope.Table;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.ProvenanceChip = __ds_scope.ProvenanceChip;

__ds_ns.Skeleton = __ds_scope.Skeleton;

__ds_ns.SkeletonRows = __ds_scope.SkeletonRows;

__ds_ns.StatusBadge = __ds_scope.StatusBadge;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Drawer = __ds_scope.Drawer;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

})();
