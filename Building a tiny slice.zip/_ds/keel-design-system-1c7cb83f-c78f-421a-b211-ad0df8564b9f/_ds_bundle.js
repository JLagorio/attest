/* @ds-bundle: {"format":4,"namespace":"KeelDesignSystem_1c7cb8","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Banner","sourcePath":"components/core/Banner.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"CoverageBar","sourcePath":"components/data/CoverageBar.jsx"},{"name":"DataTable","sourcePath":"components/data/DataTable.jsx"},{"name":"DiffRow","sourcePath":"components/data/DiffRow.jsx"},{"name":"EmptyState","sourcePath":"components/data/EmptyState.jsx"},{"name":"KeyValue","sourcePath":"components/data/KeyValue.jsx"},{"name":"MetricTile","sourcePath":"components/data/MetricTile.jsx"},{"name":"ProvenanceTrail","sourcePath":"components/data/ProvenanceTrail.jsx"},{"name":"StatusPill","sourcePath":"components/data/StatusPill.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Field","sourcePath":"components/forms/Field.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"},{"name":"Breadcrumb","sourcePath":"components/navigation/Breadcrumb.jsx"},{"name":"Pagination","sourcePath":"components/navigation/Pagination.jsx"},{"name":"SideNav","sourcePath":"components/navigation/SideNav.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"Toolbar","sourcePath":"components/navigation/Toolbar.jsx"},{"name":"ToolbarDivider","sourcePath":"components/navigation/Toolbar.jsx"},{"name":"TopBar","sourcePath":"components/navigation/TopBar.jsx"},{"name":"Dialog","sourcePath":"components/overlay/Dialog.jsx"},{"name":"Drawer","sourcePath":"components/overlay/Drawer.jsx"},{"name":"DrawerSection","sourcePath":"components/overlay/Drawer.jsx"},{"name":"Menu","sourcePath":"components/overlay/Menu.jsx"},{"name":"MenuAnchor","sourcePath":"components/overlay/Menu.jsx"},{"name":"Toast","sourcePath":"components/overlay/Toast.jsx"},{"name":"ToastStack","sourcePath":"components/overlay/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/overlay/Tooltip.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"1a5919f107ce","components/core/Banner.jsx":"8f3155ba10cd","components/core/Button.jsx":"50bc97704d8f","components/core/Card.jsx":"ba3208a50a60","components/core/Icon.jsx":"c9ea6cb067cf","components/core/IconButton.jsx":"27eb6b11eb22","components/core/Tag.jsx":"a298c9b58352","components/data/CoverageBar.jsx":"c84353f4fb4c","components/data/DataTable.jsx":"bb3594c644bd","components/data/DiffRow.jsx":"38b979a73ee2","components/data/EmptyState.jsx":"380610767462","components/data/KeyValue.jsx":"e372d5276a75","components/data/MetricTile.jsx":"917526b4dc5b","components/data/ProvenanceTrail.jsx":"9278eb6935f9","components/data/StatusPill.jsx":"7d5d061673c1","components/forms/Checkbox.jsx":"71e01521d75c","components/forms/Field.jsx":"7d0f8bcf70ff","components/forms/Input.jsx":"964320a51458","components/forms/Radio.jsx":"26192c98540e","components/forms/Select.jsx":"9e3085be6609","components/forms/Switch.jsx":"a61faa5e9046","components/forms/Textarea.jsx":"9a4c2d17442f","components/navigation/Breadcrumb.jsx":"0827bcadbcf7","components/navigation/Pagination.jsx":"34842441499b","components/navigation/SideNav.jsx":"d22f2dadf0ba","components/navigation/Tabs.jsx":"ddeabc0c9be0","components/navigation/Toolbar.jsx":"98445aab2fec","components/navigation/TopBar.jsx":"2d4e1d53ce02","components/overlay/Dialog.jsx":"8a29b3888e3a","components/overlay/Drawer.jsx":"90f9a1b4355a","components/overlay/Menu.jsx":"2b8fe839520b","components/overlay/Toast.jsx":"2d42d136a634","components/overlay/Tooltip.jsx":"2535b89b4372","ui_kits/console/BaselineScreen.jsx":"74d3474b3b96","ui_kits/console/DiscoveryScreen.jsx":"b472b12639a1","ui_kits/console/ProgramScreen.jsx":"7514ca62da41","ui_kits/console/QueueScreen.jsx":"dee44369fd23","ui_kits/console/RebaseScreen.jsx":"ab5f638256e9","ui_kits/console/Shell.jsx":"9ab0d1ae16e9","ui_kits/console/data.js":"05a12cfc4c53"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.KeelDesignSystem_1c7cb8 = window.KeelDesignSystem_1c7cb8 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** A small non-interactive label. For assurance state use StatusPill instead. */
function Badge({
  tone = 'neutral',
  variant = 'soft',
  size = 'md',
  dot = false,
  mono = false,
  className = '',
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    className: `k-badge k-badge--${variant} k-badge--${tone} k-badge--${size}${mono ? ' k-badge--mono' : ''} ${className}`
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    className: "k-badge__dot"
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** A bounded region of the canvas. Keel cards are hairline-bordered, barely elevated. */
function Card({
  title,
  subtitle,
  actions,
  footer,
  variant = 'default',
  flush = false,
  interactive = false,
  className = '',
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("section", _extends({
    className: `k-card k-card--${variant}${interactive ? ' k-card--interactive' : ''} ${className}`
  }, rest), (title || actions) && /*#__PURE__*/React.createElement("header", {
    className: "k-card__header"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    className: "k-card__title"
  }, title), subtitle && /*#__PURE__*/React.createElement("div", {
    className: "k-card__subtitle"
  }, subtitle)), actions && /*#__PURE__*/React.createElement("div", {
    className: "k-card__actions"
  }, actions)), /*#__PURE__*/React.createElement("div", {
    className: `k-card__body${flush ? ' k-card__body--flush' : ''}`
  }, children), footer && /*#__PURE__*/React.createElement("footer", {
    className: "k-card__footer"
  }, footer));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Renders a glyph from the Keel icon set (Lucide, masked so it inherits currentColor). */
function Icon({
  name,
  size = 'md',
  className = '',
  title,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    className: `k-icon k-icon--${size} k-icon--${name} ${className}`,
    role: title ? 'img' : undefined,
    "aria-label": title,
    "aria-hidden": title ? undefined : true,
    style: style
  }, rest));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** The standard Keel action. Exactly one primary button per view. */
function Button({
  variant = 'secondary',
  size = 'md',
  iconLeft,
  iconRight,
  loading = false,
  disabled = false,
  block = false,
  as = 'button',
  className = '',
  children,
  ...rest
}) {
  const Tag = as;
  const iconSize = size === 'lg' ? 'md' : size === 'xs' ? 'xs' : 'sm';
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: `k-btn k-btn--${variant} k-btn--${size}${block ? ' k-btn--block' : ''} ${className}`,
    disabled: Tag === 'button' ? disabled || loading : undefined,
    "aria-disabled": Tag !== 'button' && (disabled || loading) ? true : undefined
  }, rest), loading && /*#__PURE__*/React.createElement("span", {
    className: "k-btn__spinner",
    "aria-hidden": "true"
  }), !loading && iconLeft && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconLeft,
    size: iconSize
  }), children, iconRight && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconRight,
    size: iconSize
  }));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** A square, label-less action. `label` is required — it becomes the accessible name. */
function IconButton({
  icon,
  label,
  size = 'md',
  variant = 'ghost',
  pressed,
  disabled = false,
  className = '',
  ...rest
}) {
  const iconSize = size === 'lg' ? 'md' : size === 'xs' ? 'xs' : 'sm';
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: `k-iconbtn k-iconbtn--${variant} k-iconbtn--${size} ${className}`,
    "aria-label": label,
    title: label,
    "aria-pressed": pressed,
    disabled: disabled
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: iconSize
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Banner.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONE_ICON = {
  info: 'info',
  success: 'circle-check',
  warning: 'triangle-alert',
  danger: 'circle-alert',
  neutral: 'circle-dashed'
};

/** An in-page message pinned above the content it concerns. Never used for transient success. */
function Banner({
  tone = 'info',
  title,
  icon,
  actions,
  onDismiss,
  className = '',
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `k-banner k-banner--${tone} ${className}`,
    role: tone === 'danger' ? 'alert' : 'status'
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon || TONE_ICON[tone],
    size: "md",
    className: "k-banner__icon"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    className: "k-banner__title"
  }, title), children && /*#__PURE__*/React.createElement("div", {
    className: "k-banner__desc"
  }, children), actions && /*#__PURE__*/React.createElement("div", {
    className: "k-banner__actions"
  }, actions)), onDismiss && /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Dismiss",
    size: "xs",
    onClick: onDismiss
  }));
}
Object.assign(__ds_scope, { Banner });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Banner.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** A filter token or metadata chip. Pass `label`+`value` for the key:value form used in FilterBar. */
function Tag({
  label,
  value,
  icon,
  selected = false,
  size = 'md',
  onRemove,
  onClick,
  className = '',
  children,
  ...rest
}) {
  const clickable = !!onClick;
  return /*#__PURE__*/React.createElement("span", _extends({
    className: `k-tag k-tag--${size}${onRemove ? '' : ' k-tag--noremove'}${selected ? ' k-tag--selected' : ''}${clickable ? ' k-tag--clickable' : ''} ${className}`,
    onClick: onClick
  }, rest), icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: "xs"
  }), label && /*#__PURE__*/React.createElement("span", {
    className: "k-tag__key"
  }, label), value && /*#__PURE__*/React.createElement("span", {
    className: "k-tag__value"
  }, value), children, onRemove && /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "k-tag__remove",
    "aria-label": `Remove ${label || value || 'filter'}`,
    onClick: e => {
      e.stopPropagation();
      onRemove(e);
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: "xs"
  })));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/data/CoverageBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const ORDER = ['validated', 'inherited', 'inflight', 'expiring', 'deviation', 'waived', 'unknown'];
const LABEL = {
  validated: 'Validated',
  inherited: 'Inherited',
  inflight: 'In review',
  expiring: 'Expiring',
  deviation: 'Deviation',
  waived: 'Waived',
  unknown: 'Unknown'
};

/** Stacked assurance mix for a scope. Unknown is hatched — never blank, never green. */
function CoverageBar({
  segments = {},
  size = 'md',
  legend = false,
  total,
  className = '',
  ...rest
}) {
  const sum = total != null ? total : ORDER.reduce((n, k) => n + (segments[k] || 0), 0) || 1;
  const present = ORDER.filter(k => segments[k]);
  const describe = present.map(k => LABEL[k] + ' ' + segments[k]).join(', ');
  return /*#__PURE__*/React.createElement("div", _extends({
    className: 'k-coverage k-coverage--' + size + ' ' + className
  }, rest), /*#__PURE__*/React.createElement("div", {
    className: "k-coverage__track",
    role: "img",
    "aria-label": describe
  }, present.map(k => /*#__PURE__*/React.createElement("span", {
    key: k,
    className: 'k-coverage__seg k-coverage__seg--' + k,
    style: {
      width: segments[k] / sum * 100 + '%'
    },
    title: LABEL[k] + ': ' + segments[k]
  }))), legend && /*#__PURE__*/React.createElement("div", {
    className: "k-coverage__legend"
  }, present.map(k => /*#__PURE__*/React.createElement("span", {
    key: k,
    className: "k-coverage__legend-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: 'k-coverage__chip k-coverage__seg--' + k
  }), LABEL[k], /*#__PURE__*/React.createElement("span", {
    className: "k-coverage__count"
  }, segments[k])))));
}
Object.assign(__ds_scope, { CoverageBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/CoverageBar.jsx", error: String((e && e.message) || e) }); }

// components/data/DataTable.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * The dense record table. Columns are objects:
 * { key, header, width, align:'num', mono, muted, tight, sortable, render(row, i) }
 */
function DataTable({
  columns = [],
  rows = [],
  density = 'standard',
  sticky = true,
  hoverable = true,
  getRowKey = (r, i) => r.id ?? i,
  selectedKeys = [],
  onRowClick,
  sort,
  onSortChange,
  rowVariant,
  className = '',
  ...rest
}) {
  const cls = c => [c.align === 'num' && 'k-table__cell--num', c.mono && 'k-table__cell--mono', c.muted && 'k-table__cell--muted', c.tight && 'k-table__cell--tight'].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("table", _extends({
    className: `k-table k-table--${density}${sticky ? ' k-table--sticky' : ''}${hoverable ? ' k-table--hoverable' : ''}${onRowClick ? ' k-table--clickable' : ''} ${className}`
  }, rest), /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(c => {
    const active = sort && sort.key === c.key;
    return /*#__PURE__*/React.createElement("th", {
      key: c.key,
      style: {
        width: c.width,
        textAlign: c.align === 'num' ? 'right' : undefined
      },
      className: c.sortable ? 'k-table__th--sortable' : undefined,
      "aria-sort": active ? sort.dir === 'asc' ? 'ascending' : 'descending' : undefined,
      onClick: c.sortable && onSortChange ? () => onSortChange(c.key) : undefined
    }, /*#__PURE__*/React.createElement("span", {
      className: "k-table__sort"
    }, c.header, c.sortable && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      size: "xs",
      name: active ? sort.dir === 'asc' ? 'chevron-up' : 'chevron-down' : 'chevrons-up-down'
    })));
  }))), /*#__PURE__*/React.createElement("tbody", null, rows.map((row, i) => {
    const key = getRowKey(row, i);
    const variant = rowVariant ? rowVariant(row) : null;
    return /*#__PURE__*/React.createElement("tr", {
      key: key,
      "aria-selected": selectedKeys.includes(key) || undefined,
      className: variant ? `k-table__row--${variant}` : undefined,
      onClick: onRowClick ? () => onRowClick(row) : undefined
    }, columns.map(c => /*#__PURE__*/React.createElement("td", {
      key: c.key,
      className: cls(c)
    }, c.render ? c.render(row, i) : row[c.key])));
  })));
}
Object.assign(__ds_scope, { DataTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/DataTable.jsx", error: String((e && e.message) || e) }); }

// components/data/DiffRow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const MARK = {
  added: '+',
  removed: '−',
  changed: '~',
  context: ''
};

/** One line of a baseline or assertion diff. Stack them inside a flush Card body. */
function DiffRow({
  kind = 'context',
  text,
  was,
  meta,
  className = '',
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `k-diff k-diff--${kind} ${className}`
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "k-diff__mark",
    "aria-hidden": "true"
  }, MARK[kind]), /*#__PURE__*/React.createElement("span", {
    className: "k-diff__body"
  }, was && /*#__PURE__*/React.createElement("span", {
    className: "k-diff__was"
  }, was), text, children, meta && /*#__PURE__*/React.createElement("span", {
    className: "k-diff__meta"
  }, meta)));
}
Object.assign(__ds_scope, { DiffRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/DiffRow.jsx", error: String((e && e.message) || e) }); }

// components/data/EmptyState.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** No rows. Say whether that means "nothing to do" or "nothing is known" — they are different. */
function EmptyState({
  icon = 'inbox',
  title,
  description,
  actions,
  variant = 'default',
  align = 'center',
  size = 'md',
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `k-empty k-empty--${variant}${align === 'left' ? ' k-empty--left' : ''}${size === 'sm' ? ' k-empty--inline' : ''} ${className}`
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "k-empty__icon"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: "lg"
  })), title && /*#__PURE__*/React.createElement("div", {
    className: "k-empty__title"
  }, title), description && /*#__PURE__*/React.createElement("div", {
    className: "k-empty__desc"
  }, description), actions && /*#__PURE__*/React.createElement("div", {
    className: "k-empty__actions"
  }, actions));
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/data/KeyValue.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Record metadata. `items` are { key, value, mono, empty }. */
function KeyValue({
  items = [],
  layout = 'grid',
  className = '',
  ...rest
}) {
  if (layout === 'rows') {
    return /*#__PURE__*/React.createElement("dl", _extends({
      className: `k-kv k-kv--rows ${className}`
    }, rest), items.map(it => /*#__PURE__*/React.createElement("div", {
      className: "k-kv__row",
      key: it.key
    }, /*#__PURE__*/React.createElement("dt", {
      className: "k-kv__k"
    }, it.key), /*#__PURE__*/React.createElement("dd", {
      className: `k-kv__v${it.mono ? ' k-kv__v--mono' : ''}${it.empty ? ' k-kv__v--empty' : ''}`,
      style: {
        margin: 0
      }
    }, it.empty ? 'Not recorded' : it.value))));
  }
  return /*#__PURE__*/React.createElement("dl", _extends({
    className: `k-kv ${className}`
  }, rest), items.map(it => /*#__PURE__*/React.createElement(React.Fragment, {
    key: it.key
  }, /*#__PURE__*/React.createElement("dt", {
    className: "k-kv__k"
  }, it.key), /*#__PURE__*/React.createElement("dd", {
    className: `k-kv__v${it.mono ? ' k-kv__v--mono' : ''}${it.empty ? ' k-kv__v--empty' : ''}`,
    style: {
      margin: 0
    }
  }, it.empty ? 'Not recorded' : it.value))));
}
Object.assign(__ds_scope, { KeyValue });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/KeyValue.jsx", error: String((e && e.message) || e) }); }

// components/data/MetricTile.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const DELTA_ICON = {
  up: 'trending-up',
  down: 'trending-down',
  flat: 'minus'
};

/** A single headline number with its scope. Four to a row, never more. */
function MetricTile({
  label,
  value,
  unit,
  delta,
  deltaDirection = 'flat',
  footnote,
  tone = 'default',
  bordered = false,
  className = '',
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `k-metric k-metric--${tone}${bordered ? ' k-metric--bordered' : ''} ${className}`
  }, rest), /*#__PURE__*/React.createElement("div", {
    className: "k-metric__label"
  }, label), /*#__PURE__*/React.createElement("div", {
    className: "k-metric__value"
  }, value, unit && /*#__PURE__*/React.createElement("span", {
    className: "k-metric__unit"
  }, unit)), (delta || footnote) && /*#__PURE__*/React.createElement("div", {
    className: "k-metric__foot"
  }, delta && /*#__PURE__*/React.createElement("span", {
    className: `k-metric__delta k-metric__delta--${deltaDirection}`
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: DELTA_ICON[deltaDirection],
    size: "xs"
  }), delta), footnote), children);
}
Object.assign(__ds_scope, { MetricTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/MetricTile.jsx", error: String((e && e.message) || e) }); }

// components/data/ProvenanceTrail.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Where a claim came from: organizational assertion → baseline → program instance.
 * `nodes` are { title, meta, icon, variant:'active'|'inherited'|'unknown', dashed, badge }.
 */
function ProvenanceTrail({
  nodes = [],
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `k-prov ${className}`
  }, rest), nodes.map((n, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: `k-prov__node${n.variant ? ` k-prov__node--${n.variant}` : ''}${n.dashed ? ' k-prov__node--dashed' : ''}`
  }, /*#__PURE__*/React.createElement("div", {
    className: "k-prov__rail"
  }, /*#__PURE__*/React.createElement("span", {
    className: "k-prov__marker"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: n.icon || 'circle',
    size: "xs"
  })), i < nodes.length - 1 && /*#__PURE__*/React.createElement("span", {
    className: "k-prov__line"
  })), /*#__PURE__*/React.createElement("div", {
    className: "k-prov__content"
  }, /*#__PURE__*/React.createElement("div", {
    className: "k-prov__title"
  }, n.title, n.badge), n.meta && /*#__PURE__*/React.createElement("div", {
    className: "k-prov__meta"
  }, n.meta)))));
}
Object.assign(__ds_scope, { ProvenanceTrail });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ProvenanceTrail.jsx", error: String((e && e.message) || e) }); }

// components/data/StatusPill.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const LABEL = {
  validated: 'Validated',
  inherited: 'Inherited',
  deviation: 'Deviation',
  expiring: 'Expiring',
  waived: 'Waived',
  unknown: 'Unknown',
  inflight: 'In review'
};

/** The assurance state of a control, claim or system. Keel's most-used component. */
function StatusPill({
  state = 'unknown',
  label,
  size = 'md',
  bare = false,
  className = '',
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    className: `k-status k-status--${state} k-status--${size}${bare ? ' k-status--bare' : ''} ${className}`
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "k-status__dot"
  }), children || label || LABEL[state]);
}
Object.assign(__ds_scope, { StatusPill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatusPill.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Checkbox with optional description. `indeterminate` drives the mixed state in table headers. */
function Checkbox({
  label,
  description,
  indeterminate = false,
  disabled = false,
  className = '',
  ...rest
}) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (ref.current) ref.current.indeterminate = indeterminate;
  }, [indeterminate]);
  return /*#__PURE__*/React.createElement("label", {
    className: `k-check${disabled ? ' k-check--disabled' : ''} ${className}`
  }, /*#__PURE__*/React.createElement("input", _extends({
    ref: ref,
    type: "checkbox",
    className: "k-check__input",
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "k-check__box"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: indeterminate ? 'minus' : 'check',
    size: "xs",
    className: "k-check__glyph",
    style: {
      width: 11,
      height: 11
    }
  })), (label || description) && /*#__PURE__*/React.createElement("span", {
    className: "k-check__text"
  }, label, description && /*#__PURE__*/React.createElement("span", {
    className: "k-check__desc"
  }, description)));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Field.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Label + hint + error wrapper for any control. Keel labels sit above, left-aligned. */
function Field({
  label,
  hint,
  error,
  required = false,
  optional = false,
  htmlFor,
  layout = 'stacked',
  className = '',
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `k-field k-field--${layout} ${className}`
  }, rest), label && /*#__PURE__*/React.createElement("label", {
    className: "k-field__label",
    htmlFor: htmlFor
  }, label, required && /*#__PURE__*/React.createElement("span", {
    className: "k-field__req"
  }, "*"), optional && /*#__PURE__*/React.createElement("span", {
    className: "k-field__optional"
  }, "optional")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)'
    }
  }, children, hint && !error && /*#__PURE__*/React.createElement("div", {
    className: "k-field__hint"
  }, hint), error && /*#__PURE__*/React.createElement("div", {
    className: "k-field__error"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "circle-alert",
    size: "xs"
  }), error)));
}
Object.assign(__ds_scope, { Field });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Field.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Single-line text input. `mono` for identifiers, versions and hashes. */
function Input({
  size = 'md',
  icon,
  iconRight,
  affix,
  invalid = false,
  mono = false,
  onClear,
  className = '',
  ...rest
}) {
  const wrapped = icon || iconRight || affix || onClear;
  const input = /*#__PURE__*/React.createElement("input", _extends({
    className: `k-input k-input--${size}${mono ? ' k-input--mono' : ''}${invalid ? ' k-input--invalid' : ''} ${className}`,
    "aria-invalid": invalid || undefined
  }, rest));
  if (!wrapped) return input;
  return /*#__PURE__*/React.createElement("div", {
    className: `k-inputwrap${icon ? ' k-inputwrap--icon' : ''}${iconRight || affix || onClear ? ' k-inputwrap--icon-right' : ''}`
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: "sm",
    className: "k-inputwrap__icon"
  }), input, iconRight && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconRight,
    size: "sm",
    className: "k-inputwrap__icon k-inputwrap__icon--right"
  }), affix && /*#__PURE__*/React.createElement("span", {
    className: "k-inputwrap__affix"
  }, affix), onClear && /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "k-inputwrap__clear",
    "aria-label": "Clear",
    onClick: onClear
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: "xs"
  })));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Single choice within a `name` group. Two to five options; beyond that use Select. */
function Radio({
  label,
  description,
  disabled = false,
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: `k-check${disabled ? ' k-check--disabled' : ''} ${className}`
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "radio",
    className: "k-check__input",
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "k-check__box k-check__box--radio"
  }, /*#__PURE__*/React.createElement("span", {
    className: "k-check__dot"
  })), (label || description) && /*#__PURE__*/React.createElement("span", {
    className: "k-check__text"
  }, label, description && /*#__PURE__*/React.createElement("span", {
    className: "k-check__desc"
  }, description)));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Native select styled to match Input. Options accept strings or {value,label} objects. */
function Select({
  options = [],
  size = 'md',
  invalid = false,
  placeholder,
  className = '',
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "k-select"
  }, /*#__PURE__*/React.createElement("select", _extends({
    className: `k-input k-input--${size}${invalid ? ' k-input--invalid' : ''} ${className}`,
    "aria-invalid": invalid || undefined
  }, rest), placeholder && /*#__PURE__*/React.createElement("option", {
    value: ""
  }, placeholder), options.map(o => {
    const value = typeof o === 'string' ? o : o.value;
    const label = typeof o === 'string' ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: value,
      value: value
    }, label);
  }), children), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: "xs",
    className: "k-select__chevron"
  }));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Immediate-effect toggle — never inside a form that needs saving. Use Checkbox for that. */
function Switch({
  label,
  disabled = false,
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: `k-switch${disabled ? ' k-switch--disabled' : ''} ${className}`
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    role: "switch",
    className: "k-switch__input",
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "k-switch__track"
  }, /*#__PURE__*/React.createElement("span", {
    className: "k-switch__knob"
  })), label);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Multi-line input. Used for rationale, scope notes and deviation justifications. */
function Textarea({
  rows = 3,
  invalid = false,
  mono = false,
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("textarea", _extends({
    rows: rows,
    className: `k-input k-input--textarea${mono ? ' k-input--mono' : ''}${invalid ? ' k-input--invalid' : ''} ${className}`,
    "aria-invalid": invalid || undefined
  }, rest));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Breadcrumb.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Where the record sits in the hierarchy. `items` are { label, href, mono }. */
function Breadcrumb({
  items = [],
  variant = 'default',
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("nav", _extends({
    className: `k-crumbs${variant === 'inverse' ? ' k-crumbs--inverse' : ''} ${className}`,
    "aria-label": "Breadcrumb"
  }, rest), items.map((it, i) => {
    const last = i === items.length - 1;
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: i
    }, i > 0 && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "chevron-right",
      size: "xs",
      className: "k-crumbs__sep"
    }), last ? /*#__PURE__*/React.createElement("span", {
      className: `k-crumbs__current${it.mono ? ' k-crumbs__mono' : ''}`,
      "aria-current": "page"
    }, it.label) : /*#__PURE__*/React.createElement("a", {
      href: it.href || '#',
      className: it.mono ? 'k-crumbs__mono' : undefined
    }, it.label));
  }));
}
Object.assign(__ds_scope, { Breadcrumb });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Breadcrumb.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Pagination.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Row-range footer for a DataTable. Keel pages by range, not by numbered pages. */
function Pagination({
  page = 1,
  pageSize = 50,
  total = 0,
  onPageChange,
  onPageSizeChange,
  pageSizes = [25, 50, 100, 250],
  className = '',
  ...rest
}) {
  const start = total === 0 ? 0 : (page - 1) * pageSize + 1;
  const end = Math.min(page * pageSize, total);
  const last = Math.max(1, Math.ceil(total / pageSize));
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `k-pager ${className}`
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "k-pager__range"
  }, /*#__PURE__*/React.createElement("b", null, start, "\u2013", end), " of ", /*#__PURE__*/React.createElement("b", null, total.toLocaleString())), /*#__PURE__*/React.createElement("span", {
    className: "k-pager__size"
  }, "Rows", /*#__PURE__*/React.createElement(__ds_scope.Select, {
    size: "sm",
    value: pageSize,
    onChange: e => onPageSizeChange && onPageSizeChange(Number(e.target.value)),
    options: pageSizes.map(n => ({
      value: String(n),
      label: String(n)
    })),
    style: {
      width: 68
    }
  })), /*#__PURE__*/React.createElement("span", {
    className: "k-pager__controls"
  }, /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "chevron-left",
    label: "Previous page",
    size: "sm",
    variant: "secondary",
    disabled: page <= 1,
    onClick: () => onPageChange && onPageChange(page - 1)
  }), /*#__PURE__*/React.createElement("span", {
    className: "k-pager__page"
  }, page, " / ", last), /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "chevron-right",
    label: "Next page",
    size: "sm",
    variant: "secondary",
    disabled: page >= last,
    onClick: () => onPageChange && onPageChange(page + 1)
  })));
}
Object.assign(__ds_scope, { Pagination });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Pagination.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SideNav.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * The dark product rail. `sections` are { label, items: [{ id, label, icon, count, alert, href }] }.
 */
function SideNav({
  sections = [],
  activeId,
  onNavigate,
  brand = 'Keel',
  scope,
  user,
  collapsed = false,
  footer,
  className = '',
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("nav", _extends({
    className: `k-nav${collapsed ? ' k-nav--collapsed' : ''} ${className}`
  }, rest), /*#__PURE__*/React.createElement("div", {
    className: "k-nav__brand"
  }, /*#__PURE__*/React.createElement("span", {
    className: "k-nav__mark"
  }, "K"), !collapsed && /*#__PURE__*/React.createElement("span", {
    className: "k-nav__wordmark"
  }, brand)), scope && !collapsed && /*#__PURE__*/React.createElement("div", {
    className: "k-nav__scope"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "k-nav__scope-btn",
    onClick: scope.onClick
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      minWidth: 0,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "k-nav__scope-label",
    style: {
      display: 'block'
    }
  }, scope.label), /*#__PURE__*/React.createElement("span", {
    className: "k-nav__scope-value",
    style: {
      display: 'block'
    }
  }, scope.value)), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevrons-up-down",
    size: "xs"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "k-nav__body"
  }, sections.map((s, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: s.label || i
  }, s.label && !collapsed && /*#__PURE__*/React.createElement("div", {
    className: "k-nav__section"
  }, s.label), s.items.map(it => /*#__PURE__*/React.createElement("button", {
    key: it.id,
    type: "button",
    className: "k-nav__item",
    "aria-current": activeId === it.id ? 'page' : undefined,
    title: collapsed ? it.label : undefined,
    onClick: () => onNavigate && onNavigate(it.id)
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: it.icon,
    size: "sm"
  }), !collapsed && /*#__PURE__*/React.createElement("span", {
    className: "k-nav__label"
  }, it.label), !collapsed && it.count != null && /*#__PURE__*/React.createElement("span", {
    className: `k-nav__count${it.alert ? ' k-nav__count--alert' : ''}`
  }, it.count))))), children), (user || footer) && /*#__PURE__*/React.createElement("div", {
    className: "k-nav__foot"
  }, footer, user && /*#__PURE__*/React.createElement("div", {
    className: "k-nav__user"
  }, /*#__PURE__*/React.createElement("span", {
    className: "k-nav__avatar"
  }, user.initials), !collapsed && /*#__PURE__*/React.createElement("span", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "k-nav__scope-value",
    style: {
      display: 'block'
    }
  }, user.name), /*#__PURE__*/React.createElement("span", {
    className: "k-nav__scope-label",
    style: {
      display: 'block'
    }
  }, user.role)))));
}
Object.assign(__ds_scope, { SideNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SideNav.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Underlined view switcher. `items` are { id, label, count, alert, disabled }. */
function Tabs({
  items = [],
  activeId,
  onChange,
  variant = 'underline',
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `k-tabs${variant === 'contained' ? ' k-tabs--contained' : ''} ${className}`,
    role: "tablist"
  }, rest), items.map(it => /*#__PURE__*/React.createElement("button", {
    key: it.id,
    type: "button",
    role: "tab",
    className: "k-tab",
    "aria-selected": activeId === it.id,
    disabled: it.disabled,
    onClick: () => onChange && onChange(it.id)
  }, it.label, it.count != null && /*#__PURE__*/React.createElement("span", {
    className: `k-tab__count${it.alert ? ' k-tab__count--alert' : ''}`
  }, it.count))));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Toolbar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** The filter/action strip above a table. Children go left; `actions` are pushed right. */
function Toolbar({
  variant = 'default',
  actions,
  count,
  className = '',
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `k-toolbar${variant !== 'default' ? ` k-toolbar--${variant}` : ''} ${className}`
  }, rest), /*#__PURE__*/React.createElement("div", {
    className: "k-toolbar__group"
  }, children), (count || actions) && /*#__PURE__*/React.createElement("div", {
    className: "k-toolbar__group k-toolbar__group--end"
  }, count && /*#__PURE__*/React.createElement("span", {
    className: "k-toolbar__count"
  }, count), actions));
}

/** Hairline separator between logical groups inside a Toolbar. */
function ToolbarDivider() {
  return /*#__PURE__*/React.createElement("span", {
    className: "k-toolbar__divider"
  });
}
Object.assign(__ds_scope, { Toolbar, ToolbarDivider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Toolbar.jsx", error: String((e && e.message) || e) }); }

// components/navigation/TopBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** The 48px chrome bar: context on the left, global search centre, account actions right. */
function TopBar({
  title,
  breadcrumb,
  search,
  onSearchChange,
  searchPlaceholder = 'Search controls, systems, assertions',
  env,
  actions,
  variant = 'dark',
  className = '',
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("header", _extends({
    className: `k-topbar${variant === 'light' ? ' k-topbar--light' : ''} ${className}`
  }, rest), breadcrumb, title && /*#__PURE__*/React.createElement("span", {
    className: "k-topbar__title"
  }, title), onSearchChange !== undefined && /*#__PURE__*/React.createElement("div", {
    className: "k-topbar__search"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "search",
    size: "sm"
  }), /*#__PURE__*/React.createElement("input", {
    value: search,
    onChange: onSearchChange,
    placeholder: searchPlaceholder
  }), /*#__PURE__*/React.createElement("span", {
    className: "k-topbar__kbd"
  }, "/")), children, /*#__PURE__*/React.createElement("div", {
    className: "k-topbar__actions"
  }, env && /*#__PURE__*/React.createElement("span", {
    className: "k-topbar__env"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "server",
    size: "xs"
  }), env), actions));
}
Object.assign(__ds_scope, { TopBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/TopBar.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Dialog.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** A modal decision. Used only when the action cannot be undone or needs a rationale. */
function Dialog({
  open = true,
  onClose,
  title,
  icon,
  tone = 'default',
  size = 'default',
  footer,
  footerLeft,
  className = '',
  children,
  ...rest
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "k-scrim",
    style: {
      zIndex: 'var(--z-dialog)'
    },
    onClick: onClose
  }), /*#__PURE__*/React.createElement("div", _extends({
    className: `k-dialog${size !== 'default' ? ` k-dialog--${size}` : ''} ${className}`,
    role: "dialog",
    "aria-modal": "true",
    "aria-label": typeof title === 'string' ? title : 'Dialog'
  }, rest), /*#__PURE__*/React.createElement("header", {
    className: "k-dialog__header"
  }, icon && /*#__PURE__*/React.createElement("span", {
    className: `k-dialog__icon${tone !== 'default' ? ` k-dialog__icon--${tone}` : ''}`
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: "md"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("h2", {
    className: "k-dialog__title"
  }, title)), onClose && /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Close",
    size: "xs",
    onClick: onClose
  })), /*#__PURE__*/React.createElement("div", {
    className: "k-dialog__body"
  }, children), (footer || footerLeft) && /*#__PURE__*/React.createElement("footer", {
    className: `k-dialog__footer${footerLeft ? ' k-dialog__footer--split' : ''}`
  }, footerLeft && /*#__PURE__*/React.createElement("div", null, footerLeft), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-4)'
    }
  }, footer))));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Drawer.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** The record inspector. Keel opens records in a right drawer, keeping the list in place. */
function Drawer({
  open = true,
  onClose,
  eyebrow,
  title,
  subtitle,
  tabs,
  footer,
  width = 'default',
  inline = false,
  scrim = true,
  flush = false,
  className = '',
  children,
  ...rest
}) {
  if (!open) return null;
  const panel = /*#__PURE__*/React.createElement("aside", _extends({
    className: `k-drawer${inline ? ' k-drawer--inline' : ''}${width === 'wide' ? ' k-drawer--wide' : ''} ${className}`,
    role: "dialog",
    "aria-label": typeof title === 'string' ? title : 'Record',
    style: width !== 'default' && width !== 'wide' ? {
      width
    } : undefined
  }, rest), /*#__PURE__*/React.createElement("header", {
    className: "k-drawer__header"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      flex: 1
    }
  }, eyebrow && /*#__PURE__*/React.createElement("div", {
    className: "k-drawer__eyebrow"
  }, eyebrow), title && /*#__PURE__*/React.createElement("h2", {
    className: "k-drawer__title"
  }, title), subtitle && /*#__PURE__*/React.createElement("div", {
    className: "k-drawer__sub"
  }, subtitle)), onClose && /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Close",
    size: "sm",
    onClick: onClose
  })), tabs && /*#__PURE__*/React.createElement("div", {
    className: "k-drawer__tabs"
  }, tabs), /*#__PURE__*/React.createElement("div", {
    className: `k-drawer__body${flush ? ' k-drawer__body--flush' : ''}`
  }, children), footer && /*#__PURE__*/React.createElement("footer", {
    className: "k-drawer__footer"
  }, footer));
  if (inline || !scrim) return panel;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "k-scrim",
    onClick: onClose
  }), panel);
}

/** A titled block inside a Drawer body. */
function DrawerSection({
  title,
  actions,
  className = '',
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("section", _extends({
    className: `k-drawer__section ${className}`
  }, rest), title && /*#__PURE__*/React.createElement("div", {
    className: "k-drawer__section-title"
  }, title, actions && /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto'
    }
  }, actions)), children);
}
Object.assign(__ds_scope, { Drawer, DrawerSection });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Drawer.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Menu.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Dropdown list of actions. `items` are { id, label, icon, shortcut, danger, checked, separator, group }. */
function Menu({
  items = [],
  onSelect,
  align = 'right',
  className = '',
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `k-menu ${className}`,
    role: "menu",
    style: style
  }, rest), items.map((it, i) => {
    if (it.separator) return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "k-menu__sep"
    });
    if (it.group) return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "k-menu__label"
    }, it.group);
    return /*#__PURE__*/React.createElement("button", {
      key: it.id || i,
      type: "button",
      role: it.checked != null ? 'menuitemcheckbox' : 'menuitem',
      "aria-checked": it.checked,
      disabled: it.disabled,
      className: `k-menu__item${it.danger ? ' k-menu__item--danger' : ''}`,
      onClick: () => onSelect && onSelect(it.id, it)
    }, it.icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: it.icon,
      size: "sm"
    }), it.label, it.checked && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "check",
      size: "xs",
      style: {
        marginLeft: 'auto'
      }
    }), it.shortcut && /*#__PURE__*/React.createElement("span", {
      className: "k-menu__shortcut"
    }, it.shortcut));
  }));
}

/** Anchors a Menu under a trigger. `trigger` is a render prop receiving { open, toggle }. */
function MenuAnchor({
  trigger,
  items,
  onSelect,
  align = 'right',
  className = ''
}) {
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!open) return undefined;
    const onDoc = e => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, [open]);
  return /*#__PURE__*/React.createElement("span", {
    className: `k-menu__anchor ${className}`,
    ref: ref
  }, trigger({
    open,
    toggle: () => setOpen(v => !v)
  }), open && /*#__PURE__*/React.createElement("div", {
    className: `k-menu__pop${align === 'left' ? ' k-menu__pop--left' : ''}`
  }, /*#__PURE__*/React.createElement(Menu, {
    items: items,
    onSelect: (id, it) => {
      setOpen(false);
      onSelect && onSelect(id, it);
    }
  })));
}
Object.assign(__ds_scope, { Menu, MenuAnchor });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Menu.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONE_ICON = {
  success: 'circle-check',
  danger: 'circle-alert',
  info: 'info'
};

/** Confirmation that a write landed. Always carries the undo or the link to what changed. */
function Toast({
  tone = 'info',
  title,
  description,
  actionLabel,
  onAction,
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `k-toast k-toast--${tone} ${className}`,
    role: "status"
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: TONE_ICON[tone],
    size: "sm",
    className: "k-toast__icon"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "k-toast__title"
  }, title), description && /*#__PURE__*/React.createElement("div", {
    className: "k-toast__desc"
  }, description)), actionLabel && /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "k-toast__action",
    onClick: onAction
  }, actionLabel));
}

/** Bottom-right stack. Never more than two at once. */
function ToastStack({
  children,
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `k-toasts ${className}`
  }, rest), children);
}
Object.assign(__ds_scope, { Toast, ToastStack });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Toast.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Tooltip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Hover explanation. Keel uses it to define state words and to spell out truncated identifiers. */
function Tooltip({
  label,
  shortcut,
  placement = 'top',
  wide = false,
  className = '',
  children,
  ...rest
}) {
  const [open, setOpen] = React.useState(false);
  return /*#__PURE__*/React.createElement("span", _extends({
    className: `k-tip ${className}`,
    onMouseEnter: () => setOpen(true),
    onMouseLeave: () => setOpen(false),
    onFocus: () => setOpen(true),
    onBlur: () => setOpen(false)
  }, rest), children, open && label && /*#__PURE__*/React.createElement("span", {
    className: `k-tip__bubble${placement === 'bottom' ? ' k-tip__bubble--bottom' : ''}${wide ? ' k-tip__bubble--wide' : ''}`,
    role: "tooltip"
  }, label, shortcut && /*#__PURE__*/React.createElement("span", {
    className: "k-tip__key"
  }, shortcut)));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Tooltip.jsx", error: String((e && e.message) || e) }); }

// ui_kits/console/BaselineScreen.jsx
try { (() => {
const KB = window.KeelDesignSystem_1c7cb8;
function BaselineScreen({
  onNavigate
}) {
  const {
    Card,
    DataTable,
    StatusPill,
    Badge,
    Toolbar,
    ToolbarDivider,
    Tabs,
    Input,
    Select,
    Button,
    IconButton,
    Drawer,
    DrawerSection,
    KeyValue,
    Tag,
    CoverageBar,
    EmptyState
  } = KB;
  const [tab, setTab] = React.useState('baselines');
  const [q, setQ] = React.useState('');
  const [open, setOpen] = React.useState(null);
  const baselines = window.KeelData.baselines.filter(b => !q || (b.name + b.id).toLowerCase().includes(q.toLowerCase()));
  const assertions = window.KeelData.assertions.filter(a => !q || (a.title + a.id).toLowerCase().includes(q.toLowerCase()));
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(window.PageHeader, {
    eyebrow: "Reusable knowledge",
    title: "Baseline library",
    meta: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", null, "5 baselines \xB7 14 programs instantiated"), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("span", null, "4 revisions published in the last 90 days")),
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      iconLeft: "upload"
    }, "Import baseline"), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "primary",
      iconLeft: "plus"
    }, "New baseline")),
    tabs: /*#__PURE__*/React.createElement(Tabs, {
      activeId: tab,
      onChange: setTab,
      items: [{
        id: 'baselines',
        label: 'Baselines',
        count: 5
      }, {
        id: 'assertions',
        label: 'Org assertions',
        count: 5
      }, {
        id: 'catalogs',
        label: 'Source catalogs',
        count: 3
      }]
    })
  }), /*#__PURE__*/React.createElement(window.PageBody, null, /*#__PURE__*/React.createElement(Card, {
    flush: true
  }, /*#__PURE__*/React.createElement(Toolbar, {
    count: tab === 'baselines' ? /*#__PURE__*/React.createElement(React.Fragment, null, "Showing ", /*#__PURE__*/React.createElement("b", null, baselines.length), " baselines") : /*#__PURE__*/React.createElement(React.Fragment, null, "Showing ", /*#__PURE__*/React.createElement("b", null, assertions.length), " assertions"),
    actions: /*#__PURE__*/React.createElement(IconButton, {
      icon: "columns-3",
      label: "Columns",
      size: "sm",
      variant: "secondary"
    })
  }, /*#__PURE__*/React.createElement(Input, {
    size: "sm",
    icon: "search",
    placeholder: tab === 'baselines' ? 'Filter baselines' : 'Filter assertions',
    value: q,
    onChange: e => setQ(e.target.value),
    onClear: q ? () => setQ('') : undefined,
    className: "k-toolbar__search"
  }), /*#__PURE__*/React.createElement(ToolbarDivider, null), /*#__PURE__*/React.createElement(Select, {
    size: "sm",
    placeholder: "All classes",
    options: ['Cloud service', 'Federal system', 'Commercial', 'Internal'],
    style: {
      width: 168
    }
  }), /*#__PURE__*/React.createElement(Tag, {
    label: "status",
    value: "published",
    onRemove: () => {}
  })), tab === 'baselines' && /*#__PURE__*/React.createElement(DataTable, {
    density: "relaxed",
    onRowClick: setOpen,
    selectedKeys: open ? [open.id] : [],
    getRowKey: r => r.id,
    columns: [{
      key: 'name',
      header: 'Baseline',
      render: r => /*#__PURE__*/React.createElement(window.RecordCell, {
        primary: r.name,
        secondary: r.class
      })
    }, {
      key: 'id',
      header: 'Identifier',
      width: 190,
      mono: true,
      render: r => /*#__PURE__*/React.createElement("span", null, r.id, /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--text-tertiary)'
        }
      }, "@", r.version))
    }, {
      key: 'controls',
      header: 'Controls',
      width: 88,
      align: 'num',
      sortable: true
    }, {
      key: 'assertions',
      header: 'Assertions',
      width: 96,
      align: 'num',
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--teal-600)'
        }
      }, r.assertions)
    }, {
      key: 'programs',
      header: 'Programs',
      width: 92,
      align: 'num',
      sortable: true
    }, {
      key: 'drift',
      header: 'Pinned behind',
      width: 128,
      render: r => r.drift ? /*#__PURE__*/React.createElement(Badge, {
        tone: "warning",
        dot: true
      }, r.drift, " programs") : /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--text-disabled)',
          fontSize: 'var(--text-xs)'
        }
      }, "None")
    }, {
      key: 'updated',
      header: 'Published',
      width: 112,
      muted: true,
      sortable: true
    }],
    rows: baselines
  }), tab === 'assertions' && /*#__PURE__*/React.createElement(DataTable, {
    density: "relaxed",
    getRowKey: r => r.id,
    rowVariant: r => r.state === 'inflight' ? null : null,
    columns: [{
      key: 'title',
      header: 'Assertion',
      render: r => /*#__PURE__*/React.createElement(window.RecordCell, {
        primary: r.title,
        secondary: `Owned by ${r.owner}`
      })
    }, {
      key: 'id',
      header: 'ID',
      width: 96,
      mono: true
    }, {
      key: 'state',
      header: 'State',
      tight: true,
      render: r => /*#__PURE__*/React.createElement(StatusPill, {
        state: r.state,
        size: "sm"
      })
    }, {
      key: 'validated',
      header: 'Last validated',
      width: 132,
      render: r => r.validated === '—' ? /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--text-disabled)',
          fontStyle: 'italic'
        }
      }, "Not recorded") : r.validated
    }, {
      key: 'cadence',
      header: 'Cadence',
      width: 92,
      mono: true,
      muted: true
    }, {
      key: 'controls',
      header: 'Covers',
      width: 88,
      align: 'num',
      render: r => /*#__PURE__*/React.createElement("span", null, r.controls, " controls")
    }, {
      key: 'programs',
      header: 'Inherited by',
      width: 116,
      align: 'num',
      render: r => /*#__PURE__*/React.createElement("span", null, r.programs, " programs")
    }],
    rows: assertions
  }), tab === 'catalogs' && /*#__PURE__*/React.createElement(EmptyState, {
    icon: "library",
    title: "Source catalogs are managed by Governance",
    description: "Catalogs are the upstream framework text Keel maps baselines against. They are read-only here.",
    actions: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      iconLeft: "external-link"
    }, "Open catalog service")
  }))), open && /*#__PURE__*/React.createElement(Drawer, {
    open: true,
    onClose: () => setOpen(null),
    width: "wide",
    eyebrow: /*#__PURE__*/React.createElement(React.Fragment, null, "Baseline ", /*#__PURE__*/React.createElement("span", {
      className: "k-mono"
    }, open.id, "@", open.version)),
    title: open.name,
    subtitle: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(StatusPill, {
      state: "validated",
      label: "Published",
      size: "sm"
    }), /*#__PURE__*/React.createElement("span", null, open.class), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("span", null, open.programs, " programs instantiated")),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "sm",
      iconLeft: "plus"
    }, "Instantiate for a system"), open.drift > 0 && /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      iconLeft: "git-compare",
      onClick: () => {
        setOpen(null);
        onNavigate('rebase');
      }
    }, "Review rebase (", open.drift, ")"), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "ghost",
      iconLeft: "download"
    }, "Export"))
  }, /*#__PURE__*/React.createElement(DrawerSection, {
    title: "Record"
  }, /*#__PURE__*/React.createElement(KeyValue, {
    layout: "rows",
    items: [{
      key: 'Identifier',
      value: `${open.id}@${open.version}`,
      mono: true
    }, {
      key: 'Class',
      value: open.class
    }, {
      key: 'Controls in scope',
      value: `${open.controls} controls`
    }, {
      key: 'Assertions composed',
      value: `${open.assertions} organizational assertions`
    }, {
      key: 'Published',
      value: `${open.updated} by Governance`
    }, {
      key: 'Programs pinned behind',
      value: open.drift ? `${open.drift} programs on an earlier revision` : undefined,
      empty: !open.drift
    }]
  })), /*#__PURE__*/React.createElement(DrawerSection, {
    title: "Composition"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)',
      textWrap: 'pretty'
    }
  }, "Of ", open.controls, " controls, ", open.assertions, " organizational assertions cover 96 of them \u2014 every program instantiated from this baseline inherits those without re-proving."), /*#__PURE__*/React.createElement(CoverageBar, {
    legend: true,
    segments: {
      inherited: 96,
      validated: 218,
      unknown: open.controls - 314 > 0 ? open.controls - 314 : 12
    }
  }))), /*#__PURE__*/React.createElement(DrawerSection, {
    title: "Revisions"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, [{
    v: open.version,
    when: open.updated,
    note: '18 controls changed · 2 added · 1 withdrawn',
    current: true
  }, {
    v: '4.2.0',
    when: '14 May 2026',
    note: '6 controls changed · evidence rules tightened'
  }, {
    v: '4.1.6',
    when: '02 Feb 2026',
    note: 'Editorial only'
  }].map(r => /*#__PURE__*/React.createElement("div", {
    key: r.v,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '10px 0',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "k-mono",
    style: {
      width: 62,
      fontSize: 'var(--text-xs)',
      color: r.current ? 'var(--text-primary)' : 'var(--text-tertiary)'
    }
  }, "@", r.v), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-sm)'
    }
  }, r.note), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-2xs)',
      color: 'var(--text-tertiary)'
    }
  }, "Published ", r.when)), r.current && /*#__PURE__*/React.createElement(Badge, {
    tone: "info",
    size: "sm"
  }, "Current")))))));
}
Object.assign(window, {
  BaselineScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/console/BaselineScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/console/DiscoveryScreen.jsx
try { (() => {
const KD = window.KeelDesignSystem_1c7cb8;
function DiscoveryScreen({
  onToast
}) {
  const {
    Card,
    DataTable,
    StatusPill,
    Toolbar,
    ToolbarDivider,
    Tabs,
    Input,
    Button,
    IconButton,
    Badge,
    Tag,
    Drawer,
    DrawerSection,
    KeyValue,
    ProvenanceTrail,
    Dialog,
    Field,
    Textarea,
    Select,
    Checkbox,
    Radio
  } = KD;
  const list = window.KeelData.discoveries;
  const [sel, setSel] = React.useState(list[0]);
  const [q, setQ] = React.useState('');
  const [promote, setPromote] = React.useState(false);
  const rows = list.filter(d => !q || (d.title + d.id + d.program).toLowerCase().includes(q.toLowerCase()));
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(window.PageHeader, {
    eyebrow: "Knowledge promotion",
    title: "Discoveries",
    meta: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", null, "4 open \xB7 found inside programs, true more broadly"), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("span", null, "Promoting one writes it back to the organization")),
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      iconLeft: "binoculars"
    }, "Scan for candidates"), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "primary",
      iconLeft: "plus"
    }, "Record discovery")),
    tabs: /*#__PURE__*/React.createElement(Tabs, {
      activeId: "open",
      items: [{
        id: 'open',
        label: 'Open',
        count: 4
      }, {
        id: 'promoted',
        label: 'Promoted',
        count: 27
      }, {
        id: 'declined',
        label: 'Declined',
        count: 6
      }]
    })
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      flexDirection: 'column',
      padding: '16px 0 16px 24px'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    flush: true,
    style: {
      flex: 1,
      minHeight: 0,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement(Toolbar, {
    count: /*#__PURE__*/React.createElement(React.Fragment, null, "Showing ", /*#__PURE__*/React.createElement("b", null, rows.length), " discoveries"),
    actions: /*#__PURE__*/React.createElement(IconButton, {
      icon: "funnel",
      label: "Filter",
      size: "sm",
      variant: "secondary"
    })
  }, /*#__PURE__*/React.createElement(Input, {
    size: "sm",
    icon: "search",
    placeholder: "Filter discoveries",
    value: q,
    onChange: e => setQ(e.target.value),
    onClear: q ? () => setQ('') : undefined,
    className: "k-toolbar__search"
  }), /*#__PURE__*/React.createElement(ToolbarDivider, null), /*#__PURE__*/React.createElement(Tag, {
    label: "reviewer",
    value: "me",
    onRemove: () => {}
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      overflowY: 'auto'
    }
  }, /*#__PURE__*/React.createElement(DataTable, {
    density: "relaxed",
    getRowKey: d => d.id,
    onRowClick: setSel,
    selectedKeys: sel ? [sel.id] : [],
    rowVariant: d => d.state === 'unknown' ? 'unknown' : null,
    columns: [{
      key: 'id',
      header: 'ID',
      width: 92,
      mono: true
    }, {
      key: 'title',
      header: 'Discovery',
      render: d => /*#__PURE__*/React.createElement(window.RecordCell, {
        primary: d.title,
        secondary: `Found in ${d.program} · ${d.found}`
      })
    }, {
      key: 'scope',
      header: 'Proposed scope',
      width: 210,
      render: d => /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 'var(--text-xs)',
          color: 'var(--text-secondary)'
        }
      }, d.scope)
    }, {
      key: 'controls',
      header: 'Covers',
      width: 84,
      align: 'num',
      render: d => /*#__PURE__*/React.createElement("span", null, d.controls)
    }, {
      key: 'evidence',
      header: 'Evidence',
      width: 88,
      align: 'num'
    }, {
      key: 'state',
      header: 'Review',
      tight: true,
      render: d => /*#__PURE__*/React.createElement(StatusPill, {
        state: d.state,
        size: "sm",
        label: d.state === 'inflight' ? 'In review' : d.state === 'validated' ? 'Ready' : 'Unowned'
      })
    }],
    rows: rows
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 440,
      flex: 'none',
      padding: '16px 24px 16px 16px'
    }
  }, sel ? /*#__PURE__*/React.createElement(Card, {
    flush: true,
    style: {
      height: '100%',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement(Drawer, {
    inline: true,
    width: "100%",
    eyebrow: /*#__PURE__*/React.createElement(React.Fragment, null, "Discovery ", /*#__PURE__*/React.createElement("span", {
      className: "k-mono"
    }, sel.id)),
    title: sel.title,
    subtitle: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(StatusPill, {
      state: sel.state,
      size: "sm",
      label: sel.state === 'inflight' ? 'In review' : sel.state === 'validated' ? 'Ready to promote' : 'Unowned'
    }), /*#__PURE__*/React.createElement("span", null, "Reviewer: ", sel.reviewer)),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "sm",
      iconLeft: "git-merge",
      onClick: () => setPromote(true)
    }, "Promote to assertion"), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      iconLeft: "x"
    }, "Decline"))
  }, /*#__PURE__*/React.createElement(DrawerSection, {
    title: "Record"
  }, /*#__PURE__*/React.createElement(KeyValue, {
    layout: "rows",
    items: [{
      key: 'Found in',
      value: sel.program
    }, {
      key: 'Found on',
      value: sel.found
    }, {
      key: 'Proposed scope',
      value: sel.scope
    }, {
      key: 'Would cover',
      value: `${sel.controls} controls across the catalog`
    }, {
      key: 'Evidence',
      value: `${sel.evidence} items carried over from the program`
    }, {
      key: 'Reviewer',
      value: sel.reviewer === 'Unassigned' ? undefined : sel.reviewer,
      empty: sel.reviewer === 'Unassigned'
    }]
  })), /*#__PURE__*/React.createElement(DrawerSection, {
    title: "What promotion would do"
  }, /*#__PURE__*/React.createElement(ProvenanceTrail, {
    nodes: [{
      title: `Program — ${sel.program}`,
      icon: 'target',
      meta: `Established here on ${sel.found}`,
      badge: /*#__PURE__*/React.createElement(StatusPill, {
        state: "validated",
        size: "sm"
      })
    }, {
      title: 'Promote → organizational assertion',
      icon: 'git-merge',
      variant: 'active',
      meta: 'Owned, dated, and re-verified on a cadence'
    }, {
      title: `6 programs inherit instead of re-proving`,
      icon: 'building-2',
      variant: 'inherited',
      meta: `${sel.controls} controls each stop being asked twice`,
      badge: /*#__PURE__*/React.createElement(StatusPill, {
        state: "inherited",
        size: "sm"
      })
    }]
  })), /*#__PURE__*/React.createElement(DrawerSection, {
    title: "Evidence carried over"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, Array.from({
    length: Math.min(sel.evidence, 3)
  }).map((_, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '8px 10px',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-md)',
      background: 'var(--surface-inset)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "k-icon k-icon--sm k-icon--file-check",
    style: {
      color: 'var(--green-500)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "k-mono k-truncate",
    style: {
      fontSize: 'var(--text-xs)'
    }
  }, "s3://keel-evidence/", sel.id.toLowerCase(), "/artifact-", i + 1, ".json"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-2xs)',
      color: 'var(--text-tertiary)'
    }
  }, "Reviewed by ", sel.reviewer)), /*#__PURE__*/React.createElement(Badge, {
    tone: "success",
    variant: "outline",
    size: "sm"
  }, "Accepted"))))))) : null)), promote && /*#__PURE__*/React.createElement(Dialog, {
    open: true,
    onClose: () => setPromote(false),
    icon: "git-merge",
    title: "Promote to organizational assertion",
    size: "wide",
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      onClick: () => setPromote(false)
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "sm",
      onClick: () => {
        setPromote(false);
        onToast({
          tone: 'success',
          title: 'Discovery promoted',
          description: `${sel.title} is now an organizational assertion. 6 programs re-evaluated; ${sel.controls * 6} control claims stopped being asked twice.`,
          actionLabel: 'View assertion'
        });
      }
    }, "Promote assertion"))
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-primary)'
    }
  }, sel.title), " becomes a fact the organization owns. Programs in scope inherit it instead of proving it again \u2014 and are re-evaluated the moment it changes or expires."), /*#__PURE__*/React.createElement(Field, {
    label: "Assertion statement",
    required: true
  }, /*#__PURE__*/React.createElement(Textarea, {
    rows: 2,
    defaultValue: sel.title
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Owning team",
    required: true
  }, /*#__PURE__*/React.createElement(Select, {
    options: ['Platform Security', 'Data Platform', 'Detection & Response', 'Governance']
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Re-verification cadence",
    hint: "How often the fact must be re-proven."
  }, /*#__PURE__*/React.createElement(Select, {
    options: ['90 days', '180 days', '365 days'],
    defaultValue: "180 days"
  }))), /*#__PURE__*/React.createElement(Field, {
    label: "Scope"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Radio, {
    name: "scope",
    defaultChecked: true,
    label: sel.scope,
    description: `Applies to ${sel.controls} controls across 6 programs`
  }), /*#__PURE__*/React.createElement(Radio, {
    name: "scope",
    label: "All systems in the organization",
    description: "Broadest scope \u2014 every program inherits"
  }))), /*#__PURE__*/React.createElement(Checkbox, {
    defaultChecked: true,
    label: "Re-evaluate affected programs immediately",
    description: "Inherited claims are recalculated and owners are notified."
  })));
}
Object.assign(window, {
  DiscoveryScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/console/DiscoveryScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/console/ProgramScreen.jsx
try { (() => {
const KP = window.KeelDesignSystem_1c7cb8;
function ProgramScreen({
  onNavigate
}) {
  const {
    Card,
    DataTable,
    StatusPill,
    CoverageBar,
    MetricTile,
    Toolbar,
    ToolbarDivider,
    Tabs,
    Input,
    Select,
    Button,
    IconButton,
    Tag,
    Badge,
    Drawer,
    DrawerSection,
    KeyValue,
    ProvenanceTrail,
    Pagination,
    Tooltip
  } = KP;
  const program = window.KeelData.programs[0];
  const [tab, setTab] = React.useState('controls');
  const [q, setQ] = React.useState('');
  const [sort, setSort] = React.useState({
    key: 'control',
    dir: 'asc'
  });
  const [open, setOpen] = React.useState(null);
  const base = window.KeelData.controls;
  const rows = base.filter(r => tab === 'controls' || tab === 'inherited' && r.state === 'inherited' || tab === 'deviations' && (r.state === 'deviation' || r.state === 'waived') || tab === 'unknowns' && r.state === 'unknown').filter(r => !q || (r.control + r.title).toLowerCase().includes(q.toLowerCase()));
  const total = Object.values(program.coverage).reduce((a, b) => a + b, 0);
  const assured = Math.round((program.coverage.validated + program.coverage.inherited) / total * 100);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(window.PageHeader, {
    eyebrow: /*#__PURE__*/React.createElement(React.Fragment, null, "Program \xB7 ", /*#__PURE__*/React.createElement("span", {
      className: "k-mono"
    }, program.system)),
    title: program.name,
    meta: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(StatusPill, {
      state: "inflight",
      label: "Authorization in progress",
      size: "sm"
    }), /*#__PURE__*/React.createElement("span", null, "Baseline ", /*#__PURE__*/React.createElement("span", {
      className: "k-mono"
    }, program.baseline, "@", program.version)), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("span", null, "AO: ", program.ao), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("span", null, "Package due ", program.due)),
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      iconLeft: "git-compare",
      onClick: () => onNavigate('rebase')
    }, "Rebase available"), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      iconLeft: "download"
    }, "Export package"), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "primary",
      iconLeft: "send"
    }, "Submit for authorization")),
    tabs: /*#__PURE__*/React.createElement(Tabs, {
      activeId: tab,
      onChange: setTab,
      items: [{
        id: 'controls',
        label: 'Controls',
        count: total
      }, {
        id: 'inherited',
        label: 'Inherited',
        count: program.coverage.inherited
      }, {
        id: 'unknowns',
        label: 'Unknowns',
        count: program.coverage.unknown
      }, {
        id: 'deviations',
        label: 'Deviations & waivers',
        count: program.coverage.deviation,
        alert: true
      }]
    })
  }), /*#__PURE__*/React.createElement(window.PageBody, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.55fr 1fr',
      gap: 16,
      alignItems: 'stretch'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: "Assurance coverage",
    subtitle: `${total} controls in scope · snapshot 11 Aug 2026`,
    actions: /*#__PURE__*/React.createElement(Tooltip, {
      label: "How the mix is counted",
      wide: true
    }, /*#__PURE__*/React.createElement(IconButton, {
      icon: "info",
      label: "About coverage",
      size: "xs"
    }))
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(CoverageBar, {
    size: "lg",
    legend: true,
    segments: program.coverage
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      borderTop: '1px solid var(--border-subtle)',
      marginTop: 2
    }
  }, /*#__PURE__*/React.createElement(MetricTile, {
    bordered: true,
    label: "Assured",
    value: assured,
    unit: "%",
    delta: "+4 pts since 01 Aug",
    deltaDirection: "up",
    style: {
      paddingLeft: 0
    }
  }), /*#__PURE__*/React.createElement(MetricTile, {
    bordered: true,
    label: "Unknown",
    value: program.coverage.unknown,
    tone: "unknown",
    footnote: "Never established"
  }), /*#__PURE__*/React.createElement(MetricTile, {
    label: "Open deviations",
    value: program.coverage.deviation,
    tone: "alert",
    delta: "2 past due",
    deltaDirection: "down"
  })))), /*#__PURE__*/React.createElement(Card, {
    title: "Inheritance",
    subtitle: "What this program does not have to prove again",
    flush: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 16px',
      display: 'flex',
      flexDirection: 'column',
      gap: 0
    }
  }, window.KeelData.assertions.slice(0, 4).map(a => /*#__PURE__*/React.createElement("div", {
    key: a.id,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '8px 0',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "k-icon k-icon--sm k-icon--building-2",
    style: {
      color: 'var(--teal-500)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "k-truncate",
    style: {
      fontSize: 'var(--text-sm)',
      fontWeight: 500
    }
  }, a.title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-2xs)',
      color: 'var(--text-tertiary)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "k-mono"
  }, a.id), " \xB7 ", a.owner, " \xB7 covers ", a.controls, " controls")), /*#__PURE__*/React.createElement(StatusPill, {
    state: a.state === 'validated' ? 'inherited' : a.state,
    size: "sm"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: 10
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "link",
    size: "sm",
    iconRight: "arrow-right",
    onClick: () => onNavigate('baselines')
  }, "View all 14 inherited assertions"))))), /*#__PURE__*/React.createElement(Card, {
    flush: true
  }, /*#__PURE__*/React.createElement(Toolbar, {
    count: /*#__PURE__*/React.createElement(React.Fragment, null, "Showing ", /*#__PURE__*/React.createElement("b", null, rows.length), " of ", /*#__PURE__*/React.createElement("b", null, base.length), " controls"),
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      iconLeft: "upload"
    }, "Attach evidence"), /*#__PURE__*/React.createElement(IconButton, {
      icon: "columns-3",
      label: "Columns",
      size: "sm",
      variant: "secondary"
    }))
  }, /*#__PURE__*/React.createElement(Input, {
    size: "sm",
    icon: "search",
    placeholder: "Filter controls",
    value: q,
    onChange: e => setQ(e.target.value),
    onClear: q ? () => setQ('') : undefined,
    className: "k-toolbar__search"
  }), /*#__PURE__*/React.createElement(ToolbarDivider, null), /*#__PURE__*/React.createElement(Tag, {
    label: "baseline",
    value: "4.2.1"
  }), /*#__PURE__*/React.createElement(Select, {
    size: "sm",
    placeholder: "All families",
    options: ['AC — Access control', 'AU — Audit', 'CM — Configuration', 'SC — System comms'],
    style: {
      width: 190
    }
  }), /*#__PURE__*/React.createElement(Select, {
    size: "sm",
    placeholder: "All owners",
    options: ['Platform Security', 'Data Platform', 'Infrastructure', 'Facilities'],
    style: {
      width: 168
    }
  })), /*#__PURE__*/React.createElement(DataTable, {
    density: "compact",
    sort: sort,
    onSortChange: key => setSort(s => ({
      key,
      dir: s.key === key && s.dir === 'asc' ? 'desc' : 'asc'
    })),
    onRowClick: setOpen,
    selectedKeys: open ? [open.control] : [],
    getRowKey: r => r.control,
    rowVariant: r => r.state === 'unknown' ? 'unknown' : r.state === 'deviation' ? 'deviation' : null,
    columns: [{
      key: 'control',
      header: 'Control',
      width: 104,
      mono: true,
      sortable: true
    }, {
      key: 'title',
      header: 'Statement',
      render: r => /*#__PURE__*/React.createElement("span", {
        className: "k-table__primary"
      }, r.title)
    }, {
      key: 'state',
      header: 'Assurance',
      tight: true,
      render: r => /*#__PURE__*/React.createElement(StatusPill, {
        state: r.state,
        size: "sm"
      })
    }, {
      key: 'provenance',
      header: 'Proven at',
      width: 132,
      render: r => r.provenance === '—' ? /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--text-disabled)'
        }
      }, "\u2014") : /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 'var(--text-xs)',
          color: r.provenance === 'Org assertion' ? 'var(--teal-600)' : 'var(--text-secondary)'
        }
      }, r.provenance)
    }, {
      key: 'owner',
      header: 'Owner',
      width: 148,
      muted: true
    }, {
      key: 'evidence',
      header: 'Evidence',
      width: 84,
      align: 'num',
      render: r => r.evidence === 0 ? /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--text-disabled)'
        }
      }, "0") : r.evidence
    }, {
      key: 'age',
      header: 'Age',
      width: 72,
      align: 'num',
      muted: true,
      sortable: true
    }],
    rows: rows
  }), /*#__PURE__*/React.createElement(Pagination, {
    page: 1,
    pageSize: 25,
    total: 370,
    onPageChange: () => {},
    onPageSizeChange: () => {}
  }))), open && /*#__PURE__*/React.createElement(Drawer, {
    open: true,
    onClose: () => setOpen(null),
    eyebrow: /*#__PURE__*/React.createElement(React.Fragment, null, "Control ", /*#__PURE__*/React.createElement("span", {
      className: "k-mono"
    }, open.control)),
    title: open.title,
    subtitle: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(StatusPill, {
      state: open.state,
      size: "sm"
    }), /*#__PURE__*/React.createElement("span", null, "Owner: ", open.owner), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("span", null, open.evidence, " evidence items")),
    footer: open.state === 'unknown' ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "sm",
      iconLeft: "route"
    }, "Route for assurance"), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      iconLeft: "upload"
    }, "Attach evidence")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "sm",
      iconLeft: "badge-check"
    }, "Re-verify claim"), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      iconLeft: "git-merge"
    }, "Promote to assertion"))
  }, /*#__PURE__*/React.createElement(DrawerSection, {
    title: "Record"
  }, /*#__PURE__*/React.createElement(KeyValue, {
    layout: "rows",
    items: [{
      key: 'Baseline',
      value: `${program.baseline}@${program.version}`,
      mono: true
    }, {
      key: 'Proven at',
      value: open.provenance === '—' ? undefined : open.provenance,
      empty: open.provenance === '—'
    }, {
      key: 'Owner',
      value: open.owner
    }, {
      key: 'Last validated',
      value: open.age === '—' ? undefined : `${open.age} ago`,
      empty: open.age === '—'
    }, {
      key: 'Evidence',
      value: open.evidence === 0 ? undefined : `${open.evidence} items on record`,
      empty: open.evidence === 0
    }]
  })), /*#__PURE__*/React.createElement(DrawerSection, {
    title: "Provenance"
  }, /*#__PURE__*/React.createElement(ProvenanceTrail, {
    nodes: open.provenance === 'Org assertion' ? [{
      title: 'Org assertion ORG-014 — Production boundary is segmented',
      icon: 'building-2',
      variant: 'inherited',
      meta: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", null, "Validated 04 Feb 2026"), /*#__PURE__*/React.createElement("span", null, "Cadence 180d"), /*#__PURE__*/React.createElement("span", null, "6 programs inherit")),
      badge: /*#__PURE__*/React.createElement(StatusPill, {
        state: "validated",
        size: "sm"
      })
    }, {
      title: `Baseline ${program.baseline}@${program.version}`,
      icon: 'layers',
      meta: 'Pinned at instantiation · 12 Mar 2026'
    }, {
      title: program.name,
      icon: 'target',
      variant: 'active',
      badge: /*#__PURE__*/React.createElement(StatusPill, {
        state: "inherited",
        size: "sm"
      })
    }] : open.state === 'unknown' ? [{
      title: 'No organizational assertion covers this control',
      icon: 'circle-dashed',
      variant: 'unknown',
      dashed: true,
      meta: 'Nothing upstream to inherit'
    }, {
      title: `Baseline ${program.baseline}@${program.version}`,
      icon: 'layers',
      meta: 'Pinned at instantiation',
      dashed: true
    }, {
      title: program.name,
      icon: 'target',
      variant: 'active',
      badge: /*#__PURE__*/React.createElement(StatusPill, {
        state: "unknown",
        size: "sm"
      })
    }] : [{
      title: `Baseline ${program.baseline}@${program.version}`,
      icon: 'layers',
      meta: 'Requirement as written in this revision'
    }, {
      title: `${program.name} — proven in program`,
      icon: 'target',
      variant: 'active',
      meta: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", null, open.owner), /*#__PURE__*/React.createElement("span", null, open.age, " ago")),
      badge: /*#__PURE__*/React.createElement(StatusPill, {
        state: open.state,
        size: "sm"
      })
    }]
  })), /*#__PURE__*/React.createElement(DrawerSection, {
    title: "Evidence",
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "link",
      size: "sm"
    }, "Open evidence store")
  }, open.evidence === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "k-empty k-empty--unknown k-empty--inline",
    style: {
      border: '1px dashed var(--border-strong)',
      borderRadius: 'var(--radius-md)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "k-empty__icon"
  }, /*#__PURE__*/React.createElement("span", {
    className: "k-icon k-icon--lg k-icon--circle-dashed"
  })), /*#__PURE__*/React.createElement("div", {
    className: "k-empty__title"
  }, "No evidence on record"), /*#__PURE__*/React.createElement("div", {
    className: "k-empty__desc"
  }, "Nothing has been attached for this control.")) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, Array.from({
    length: Math.min(open.evidence, 3)
  }).map((_, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '8px 10px',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-md)',
      background: 'var(--surface-inset)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "k-icon k-icon--sm k-icon--file-check",
    style: {
      color: 'var(--green-500)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "k-mono k-truncate",
    style: {
      fontSize: 'var(--text-xs)'
    }
  }, "s3://keel-evidence/atlas/", open.control.toLowerCase().replace(/[()]/g, ''), "/scan-", i + 1, ".json"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-2xs)',
      color: 'var(--text-tertiary)'
    }
  }, "Automated scan \xB7 collected 04 Aug 2026 \xB7 reviewed by ", open.owner)), /*#__PURE__*/React.createElement(Badge, {
    tone: "success",
    variant: "outline",
    size: "sm"
  }, "Accepted")))))));
}
Object.assign(window, {
  ProgramScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/console/ProgramScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/console/QueueScreen.jsx
try { (() => {
const KQ = window.KeelDesignSystem_1c7cb8;
function QueueScreen() {
  const {
    Card,
    DataTable,
    StatusPill,
    Toolbar,
    ToolbarDivider,
    Tabs,
    Input,
    Select,
    Button,
    IconButton,
    Tag,
    Pagination,
    MetricTile,
    Drawer,
    DrawerSection,
    KeyValue,
    ProvenanceTrail,
    EmptyState,
    Banner,
    MenuAnchor
  } = KQ;
  const all = window.KeelData.queue;
  const [tab, setTab] = React.useState('all');
  const [q, setQ] = React.useState('');
  const [sort, setSort] = React.useState({
    key: 'due',
    dir: 'asc'
  });
  const [open, setOpen] = React.useState(null);
  const [drawerTab, setDrawerTab] = React.useState('detail');
  const rows = all.filter(r => tab === 'all' || tab === 'unknown' && r.state === 'unknown' || tab === 'expiring' && r.state === 'expiring' || tab === 'deviation' && r.state === 'deviation').filter(r => !q || (r.control + r.title + r.program + r.id).toLowerCase().includes(q.toLowerCase()));
  const counts = {
    all: all.length,
    unknown: all.filter(r => r.state === 'unknown').length,
    expiring: all.filter(r => r.state === 'expiring').length,
    deviation: all.filter(r => r.state === 'deviation').length
  };
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(window.PageHeader, {
    eyebrow: "Assurance queue",
    title: "Routed to you",
    meta: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", null, "10 open items across 3 programs"), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("span", null, "2 past due"), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("span", null, "Refreshed 09:14 today")),
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      iconLeft: "download"
    }, "Export queue"), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "primary",
      iconLeft: "plus"
    }, "New assurance request")),
    tabs: /*#__PURE__*/React.createElement(Tabs, {
      activeId: tab,
      onChange: setTab,
      items: [{
        id: 'all',
        label: 'All routed work',
        count: counts.all
      }, {
        id: 'unknown',
        label: 'Unknowns',
        count: counts.unknown
      }, {
        id: 'expiring',
        label: 'Expiring',
        count: counts.expiring
      }, {
        id: 'deviation',
        label: 'Deviations',
        count: counts.deviation,
        alert: true
      }]
    })
  }), /*#__PURE__*/React.createElement(window.PageBody, null, /*#__PURE__*/React.createElement(Banner, {
    tone: "warning",
    title: "fedramp-mod@4.2.1 was published on 02 Aug",
    actions: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "secondary",
      iconLeft: "git-compare"
    }, "Open rebase review")
  }, "Six programs are pinned to an earlier revision. 18 controls change; 3 programs inherit a claim this revision tightens."), /*#__PURE__*/React.createElement(Card, {
    flush: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)'
    }
  }, /*#__PURE__*/React.createElement(MetricTile, {
    bordered: true,
    label: "Open items",
    value: "10",
    footnote: "Assigned to you"
  }), /*#__PURE__*/React.createElement(MetricTile, {
    bordered: true,
    label: "Past due",
    value: "2",
    tone: "alert",
    delta: "Both are deviations",
    deltaDirection: "down"
  }), /*#__PURE__*/React.createElement(MetricTile, {
    bordered: true,
    label: "Unknowns",
    value: "4",
    tone: "unknown",
    footnote: "Never established"
  }), /*#__PURE__*/React.createElement(MetricTile, {
    label: "Median age",
    value: "9",
    unit: "days",
    delta: "\u22123 days vs. July",
    deltaDirection: "up"
  }))), /*#__PURE__*/React.createElement(Card, {
    flush: true
  }, /*#__PURE__*/React.createElement(Toolbar, {
    count: /*#__PURE__*/React.createElement(React.Fragment, null, "Showing ", /*#__PURE__*/React.createElement("b", null, rows.length), " of ", /*#__PURE__*/React.createElement("b", null, all.length), " items"),
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(IconButton, {
      icon: "columns-3",
      label: "Columns",
      size: "sm",
      variant: "secondary"
    }), /*#__PURE__*/React.createElement(IconButton, {
      icon: "sliders-horizontal",
      label: "Density",
      size: "sm",
      variant: "secondary"
    }))
  }, /*#__PURE__*/React.createElement(Input, {
    size: "sm",
    icon: "search",
    placeholder: "Filter by control, program or ID",
    value: q,
    onChange: e => setQ(e.target.value),
    onClear: q ? () => setQ('') : undefined,
    className: "k-toolbar__search"
  }), /*#__PURE__*/React.createElement(ToolbarDivider, null), /*#__PURE__*/React.createElement(Tag, {
    label: "assigned",
    value: "me",
    onRemove: () => {}
  }), /*#__PURE__*/React.createElement(Select, {
    size: "sm",
    placeholder: "All owners",
    options: ['Platform Security', 'Data Platform', 'Detection & Response', 'Infrastructure'],
    style: {
      width: 168
    }
  }), /*#__PURE__*/React.createElement(Select, {
    size: "sm",
    placeholder: "All programs",
    options: ['Atlas Payments ATO', 'Meridian Data Lake', 'Harbor Identity'],
    style: {
      width: 176
    }
  })), rows.length === 0 ? /*#__PURE__*/React.createElement(EmptyState, {
    icon: "inbox",
    title: "Queue clear",
    description: "No assurance work of this kind is routed to you right now."
  }) : /*#__PURE__*/React.createElement(DataTable, {
    density: "standard",
    sort: sort,
    onSortChange: key => setSort(s => ({
      key,
      dir: s.key === key && s.dir === 'asc' ? 'desc' : 'asc'
    })),
    onRowClick: r => {
      setOpen(r);
      setDrawerTab('detail');
    },
    selectedKeys: open ? [open.id] : [],
    getRowKey: r => r.id,
    rowVariant: r => r.state === 'unknown' ? 'unknown' : r.state === 'deviation' ? 'deviation' : null,
    columns: [{
      key: 'id',
      header: 'Item',
      width: 96,
      mono: true,
      sortable: true
    }, {
      key: 'control',
      header: 'Control',
      width: 104,
      mono: true,
      sortable: true
    }, {
      key: 'title',
      header: 'Statement',
      render: r => /*#__PURE__*/React.createElement(window.RecordCell, {
        primary: r.title,
        secondary: r.reason
      })
    }, {
      key: 'program',
      header: 'Program',
      width: 168,
      sortable: true,
      render: r => /*#__PURE__*/React.createElement("span", {
        className: "k-truncate",
        style: {
          display: 'block'
        }
      }, r.program)
    }, {
      key: 'owner',
      header: 'Owner',
      width: 152,
      muted: true
    }, {
      key: 'state',
      header: 'Assurance',
      tight: true,
      render: r => /*#__PURE__*/React.createElement(StatusPill, {
        state: r.state,
        size: "sm"
      })
    }, {
      key: 'due',
      header: 'Due',
      width: 104,
      sortable: true,
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          color: r.overdue ? 'var(--red-600)' : 'var(--text-secondary)',
          fontWeight: r.overdue ? 500 : 400
        }
      }, r.due)
    }, {
      key: 'actions',
      header: '',
      tight: true,
      render: () => /*#__PURE__*/React.createElement(MenuAnchor, {
        trigger: ({
          toggle
        }) => /*#__PURE__*/React.createElement(IconButton, {
          icon: "ellipsis",
          label: "Item actions",
          size: "xs",
          onClick: e => {
            e.stopPropagation();
            toggle();
          }
        }),
        items: [{
          group: 'Disposition'
        }, {
          id: 'route',
          label: 'Route for assurance',
          icon: 'route'
        }, {
          id: 'waive',
          label: 'Request waiver',
          icon: 'scale'
        }, {
          id: 'dev',
          label: 'Record deviation',
          icon: 'triangle-alert'
        }, {
          separator: true
        }, {
          id: 'watch',
          label: 'Watch item',
          icon: 'eye',
          shortcut: 'W'
        }, {
          id: 'copy',
          label: 'Copy link',
          icon: 'link'
        }]
      })
    }],
    rows: rows
  }), /*#__PURE__*/React.createElement(Pagination, {
    page: 1,
    pageSize: 25,
    total: all.length,
    onPageChange: () => {},
    onPageSizeChange: () => {}
  }))), open && /*#__PURE__*/React.createElement(Drawer, {
    open: true,
    onClose: () => setOpen(null),
    eyebrow: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
      className: "k-mono"
    }, open.id), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("span", null, "Control ", open.control)),
    title: open.title,
    subtitle: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(StatusPill, {
      state: open.state,
      size: "sm"
    }), /*#__PURE__*/React.createElement("span", null, open.program), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("span", null, "Owner: ", open.owner)),
    tabs: /*#__PURE__*/React.createElement(Tabs, {
      activeId: drawerTab,
      onChange: setDrawerTab,
      items: [{
        id: 'detail',
        label: 'Detail'
      }, {
        id: 'evidence',
        label: 'Evidence',
        count: 0
      }, {
        id: 'history',
        label: 'History',
        count: 4
      }]
    }),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "sm",
      iconLeft: "route"
    }, "Route for assurance"), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      iconLeft: "triangle-alert"
    }, "Record deviation"), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "ghost",
      iconLeft: "scale"
    }, "Request waiver"))
  }, drawerTab === 'detail' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(DrawerSection, {
    title: "Record"
  }, /*#__PURE__*/React.createElement(KeyValue, {
    layout: "rows",
    items: [{
      key: 'Baseline',
      value: 'fedramp-mod@4.2.1',
      mono: true
    }, {
      key: 'Requirement',
      value: 'Deny network traffic by default and allow by exception at managed interfaces.'
    }, {
      key: 'Routed',
      value: '11 Aug 2026 · R. Okafor'
    }, {
      key: 'Due',
      value: open.due
    }, {
      key: 'Last validated',
      empty: open.state === 'unknown',
      value: '04 Feb 2026'
    }]
  })), /*#__PURE__*/React.createElement(DrawerSection, {
    title: "Provenance"
  }, /*#__PURE__*/React.createElement(ProvenanceTrail, {
    nodes: open.state === 'unknown' ? [{
      title: 'No organizational assertion covers this control',
      icon: 'circle-dashed',
      variant: 'unknown',
      dashed: true,
      meta: 'Nothing upstream to inherit — the program has to establish it'
    }, {
      title: 'Baseline fedramp-mod@4.2.1',
      icon: 'layers',
      meta: 'Pinned at instantiation · 12 Mar 2026',
      dashed: true
    }, {
      title: open.program,
      icon: 'target',
      variant: 'active',
      badge: /*#__PURE__*/React.createElement(StatusPill, {
        state: "unknown",
        size: "sm"
      })
    }] : [{
      title: 'Org assertion ORG-008 — Central audit log correlation',
      icon: 'building-2',
      variant: 'inherited',
      meta: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", null, "Validated 24 Aug 2025"), /*#__PURE__*/React.createElement("span", null, "Owner: Detection & Response")),
      badge: /*#__PURE__*/React.createElement(StatusPill, {
        state: "expiring",
        size: "sm"
      })
    }, {
      title: 'Baseline fedramp-mod@4.2.1',
      icon: 'layers',
      meta: 'Pinned at instantiation · 12 Mar 2026'
    }, {
      title: open.program,
      icon: 'target',
      variant: 'active',
      badge: /*#__PURE__*/React.createElement(StatusPill, {
        state: open.state,
        size: "sm"
      })
    }]
  })), /*#__PURE__*/React.createElement(DrawerSection, {
    title: "Why this is here"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)',
      lineHeight: 'var(--leading-md)',
      textWrap: 'pretty'
    }
  }, open.reason, ". ", open.state === 'unknown' ? 'This control has never been established for this system, and no upstream assertion covers it.' : 'The upstream claim this program inherits is moving out of date; re-verification keeps the program from dropping to unknown.'))), drawerTab === 'evidence' && /*#__PURE__*/React.createElement(EmptyState, {
    variant: "unknown",
    icon: "circle-dashed",
    title: "No evidence on record",
    description: "Nothing has been attached to this control for this program. Attaching evidence does not by itself validate the claim \u2014 it has to be reviewed by the owner.",
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "sm",
      iconLeft: "upload"
    }, "Attach evidence")
  }), drawerTab === 'history' && /*#__PURE__*/React.createElement(DrawerSection, {
    title: "Activity"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, window.KeelData.activity.map((a, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 12,
      padding: '10px 0',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 130,
      flex: 'none',
      fontSize: 'var(--text-2xs)',
      color: 'var(--text-tertiary)'
    }
  }, a.when), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)'
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      fontWeight: 500
    }
  }, a.who), " \u2014 ", a.what)))))));
}
Object.assign(window, {
  QueueScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/console/QueueScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/console/RebaseScreen.jsx
try { (() => {
const KR = window.KeelDesignSystem_1c7cb8;
function RebaseScreen({
  onToast
}) {
  const {
    Card,
    DataTable,
    StatusPill,
    DiffRow,
    Toolbar,
    ToolbarDivider,
    Tabs,
    Button,
    IconButton,
    Badge,
    Dialog,
    Field,
    Textarea,
    Checkbox,
    Banner,
    MetricTile,
    Select
  } = KR;
  const [mode, setMode] = React.useState('diff');
  const [confirm, setConfirm] = React.useState(false);
  const [selected, setSelected] = React.useState(window.KeelData.impact.map(r => r.program));
  const toggle = name => setSelected(s => s.includes(name) ? s.filter(x => x !== name) : s.concat(name));
  const diff = window.KeelData.diff;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(window.PageHeader, {
    eyebrow: /*#__PURE__*/React.createElement(React.Fragment, null, "Rebase review \xB7 ", /*#__PURE__*/React.createElement("span", {
      className: "k-mono"
    }, "fedramp-mod")),
    title: "4.2.0 \u2192 4.2.1",
    meta: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(StatusPill, {
      state: "inflight",
      label: "Review open",
      size: "sm"
    }), /*#__PURE__*/React.createElement("span", null, "Published 02 Aug 2026 by Governance"), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("span", null, "6 programs pinned behind")),
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      iconLeft: "download"
    }, "Export diff"), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "primary",
      iconLeft: "git-merge",
      onClick: () => setConfirm(true)
    }, "Rebase ", selected.length, " programs")),
    tabs: /*#__PURE__*/React.createElement(Tabs, {
      activeId: mode,
      onChange: setMode,
      items: [{
        id: 'diff',
        label: 'Requirement diff',
        count: diff.filter(d => d.kind !== 'context').length
      }, {
        id: 'impact',
        label: 'Program impact',
        count: 6,
        alert: true
      }]
    })
  }), /*#__PURE__*/React.createElement(window.PageBody, null, /*#__PURE__*/React.createElement(Banner, {
    tone: "info",
    title: "Nothing changes until you rebase"
  }, "Programs stay pinned to the revision they were instantiated against. Rebasing re-evaluates every inherited claim against the new text; claims the revision tightens drop to ", /*#__PURE__*/React.createElement("b", null, "unknown"), " until they are re-verified."), /*#__PURE__*/React.createElement(Card, {
    flush: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)'
    }
  }, /*#__PURE__*/React.createElement(MetricTile, {
    bordered: true,
    label: "Controls changed",
    value: "18",
    footnote: "Of 370 in scope"
  }), /*#__PURE__*/React.createElement(MetricTile, {
    bordered: true,
    label: "Added",
    value: "2",
    delta: "No evidence on record",
    deltaDirection: "flat"
  }), /*#__PURE__*/React.createElement(MetricTile, {
    bordered: true,
    label: "Withdrawn",
    value: "1",
    footnote: "Claims retired, not revoked"
  }), /*#__PURE__*/React.createElement(MetricTile, {
    label: "Claims dropping to unknown",
    value: "36",
    tone: "unknown",
    delta: "Across 6 programs",
    deltaDirection: "down"
  }))), mode === 'diff' && /*#__PURE__*/React.createElement(Card, {
    flush: true
  }, /*#__PURE__*/React.createElement(Toolbar, {
    variant: "sunken",
    count: /*#__PURE__*/React.createElement(React.Fragment, null, "Comparing ", /*#__PURE__*/React.createElement("b", {
      className: "k-mono"
    }, "@4.2.0"), " against ", /*#__PURE__*/React.createElement("b", {
      className: "k-mono"
    }, "@4.2.1")),
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(IconButton, {
      icon: "split",
      label: "Side by side",
      size: "sm",
      variant: "secondary"
    }), /*#__PURE__*/React.createElement(IconButton, {
      icon: "copy",
      label: "Copy diff",
      size: "sm",
      variant: "secondary"
    }))
  }, /*#__PURE__*/React.createElement(Select, {
    size: "sm",
    placeholder: "All change types",
    options: ['Changed', 'Added', 'Withdrawn'],
    style: {
      width: 168
    }
  }), /*#__PURE__*/React.createElement(ToolbarDivider, null), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--text-tertiary)'
    }
  }, "4 changed \xB7 2 added \xB7 1 withdrawn")), /*#__PURE__*/React.createElement("div", null, diff.map((d, i) => /*#__PURE__*/React.createElement(DiffRow, {
    key: i,
    kind: d.kind,
    text: d.text,
    was: d.was,
    meta: d.meta
  })))), mode === 'impact' && /*#__PURE__*/React.createElement(Card, {
    flush: true
  }, /*#__PURE__*/React.createElement(Toolbar, {
    variant: "sunken",
    count: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("b", null, selected.length), " of 6 programs selected"),
    actions: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      onClick: () => setSelected(selected.length ? [] : window.KeelData.impact.map(r => r.program))
    }, selected.length ? 'Clear selection' : 'Select all')
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--text-tertiary)'
    }
  }, "Rebasing is per program \u2014 an owner can stay pinned and record the reason.")), /*#__PURE__*/React.createElement(DataTable, {
    density: "relaxed",
    getRowKey: r => r.program,
    selectedKeys: selected,
    onRowClick: r => toggle(r.program),
    columns: [{
      key: 'sel',
      header: '',
      tight: true,
      render: r => /*#__PURE__*/React.createElement(Checkbox, {
        checked: selected.includes(r.program),
        onChange: () => toggle(r.program),
        "aria-label": `Select ${r.program}`
      })
    }, {
      key: 'program',
      header: 'Program',
      render: r => /*#__PURE__*/React.createElement(window.RecordCell, {
        primary: r.program,
        secondary: `AO: ${r.ao}`
      })
    }, {
      key: 'from',
      header: 'Pinned at',
      width: 104,
      mono: true,
      render: r => /*#__PURE__*/React.createElement("span", null, "@", r.from)
    }, {
      key: 'state',
      header: 'Current state',
      tight: true,
      render: r => /*#__PURE__*/React.createElement(StatusPill, {
        state: r.state,
        size: "sm"
      })
    }, {
      key: 'drops',
      header: 'Claims → unknown',
      width: 152,
      align: 'num',
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          color: r.drops > 6 ? 'var(--red-600)' : 'var(--text-primary)',
          fontWeight: 500
        }
      }, r.drops)
    }, {
      key: 'adds',
      header: 'New controls',
      width: 116,
      align: 'num'
    }, {
      key: 'after',
      header: 'After rebase',
      width: 132,
      render: () => /*#__PURE__*/React.createElement(Badge, {
        tone: "neutral",
        variant: "outline",
        mono: true,
        size: "sm"
      }, "@4.2.1")
    }],
    rows: window.KeelData.impact
  }))), confirm && /*#__PURE__*/React.createElement(Dialog, {
    open: true,
    onClose: () => setConfirm(false),
    icon: "triangle-alert",
    tone: "warning",
    size: "wide",
    title: `Rebase ${selected.length} programs onto fedramp-mod@4.2.1?`,
    footerLeft: /*#__PURE__*/React.createElement(Button, {
      variant: "link",
      size: "sm",
      onClick: () => {
        setConfirm(false);
        setMode('diff');
      }
    }, "View full diff"),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      onClick: () => setConfirm(false)
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "sm",
      onClick: () => {
        setConfirm(false);
        onToast({
          tone: 'success',
          title: `${selected.length} programs rebased onto @4.2.1`,
          description: '36 inherited claims dropped to unknown and were routed to their owners.',
          actionLabel: 'Open queue'
        });
      }
    }, "Rebase programs"))
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0
    }
  }, "18 controls change. 36 inherited claims across these programs no longer match the requirement as written; they drop to ", /*#__PURE__*/React.createElement("b", null, "unknown"), " and are routed to their owners for re-verification. Nothing is deleted \u2014 the previous claims stay on the record, attached to ", /*#__PURE__*/React.createElement("span", {
    className: "k-mono"
  }, "@4.2.0"), "."), /*#__PURE__*/React.createElement(Field, {
    label: "Rationale",
    hint: "Written to the audit record for every affected program.",
    required: true
  }, /*#__PURE__*/React.createElement(Textarea, {
    rows: 3,
    defaultValue: "Governance published 4.2.1 on 02 Aug; scan cadence and boundary requirements tightened."
  })), /*#__PURE__*/React.createElement(Checkbox, {
    defaultChecked: true,
    label: "Route the resulting unknowns immediately",
    description: "Owners are notified as soon as the rebase completes."
  })));
}
Object.assign(window, {
  RebaseScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/console/RebaseScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/console/Shell.jsx
try { (() => {
const K = window.KeelDesignSystem_1c7cb8;
const {
  SideNav,
  TopBar,
  Breadcrumb,
  IconButton,
  StatusPill,
  Tabs
} = K;
const NAV_SECTIONS = [{
  label: 'Assurance',
  items: [{
    id: 'queue',
    label: 'My queue',
    icon: 'inbox',
    count: 10,
    alert: true
  }, {
    id: 'discoveries',
    label: 'Discoveries',
    icon: 'microscope',
    count: 4
  }, {
    id: 'rebase',
    label: 'Rebase review',
    icon: 'git-compare',
    count: 6
  }]
}, {
  label: 'Programs',
  items: [{
    id: 'program',
    label: 'Atlas Payments ATO',
    icon: 'target'
  }, {
    id: 'programs',
    label: 'All programs',
    icon: 'list-checks'
  }]
}, {
  label: 'Knowledge',
  items: [{
    id: 'baselines',
    label: 'Baselines',
    icon: 'layers'
  }, {
    id: 'assertions',
    label: 'Org assertions',
    icon: 'building-2'
  }, {
    id: 'evidence',
    label: 'Evidence store',
    icon: 'database'
  }]
}, {
  label: 'Governance',
  items: [{
    id: 'authorizations',
    label: 'Authorizations',
    icon: 'gavel'
  }, {
    id: 'settings',
    label: 'Settings',
    icon: 'settings'
  }]
}];
function AppShell({
  view,
  onNavigate,
  crumbs,
  children
}) {
  const [q, setQ] = React.useState('');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      height: '100%',
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement(SideNav, {
    sections: NAV_SECTIONS,
    activeId: view,
    onNavigate: onNavigate,
    scope: {
      label: 'Organization',
      value: window.KeelData.org
    },
    user: window.KeelData.user
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      minWidth: 0,
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement(TopBar, {
    breadcrumb: /*#__PURE__*/React.createElement(Breadcrumb, {
      variant: "inverse",
      items: crumbs
    }),
    search: q,
    onSearchChange: e => setQ(e.target.value),
    env: "us-gov-west \xB7 prod",
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(IconButton, {
      icon: "bell",
      label: "Notifications",
      variant: "inverse",
      size: "sm"
    }), /*#__PURE__*/React.createElement(IconButton, {
      icon: "circle-question-mark",
      label: "Help",
      variant: "inverse",
      size: "sm"
    }), /*#__PURE__*/React.createElement(IconButton, {
      icon: "log-out",
      label: "Sign out",
      variant: "inverse",
      size: "sm"
    }))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--surface-page)',
      overflow: 'hidden'
    }
  }, children)));
}

/** White page header: title, meta row, right-hand actions, optional tabs pinned to the bottom edge. */
function PageHeader({
  eyebrow,
  title,
  meta,
  actions,
  tabs
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      flex: 'none',
      background: 'var(--surface-card)',
      borderBottom: '1px solid var(--border-default)',
      padding: '16px 24px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 16,
      paddingBottom: tabs ? 12 : 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      flex: 1
    }
  }, eyebrow && /*#__PURE__*/React.createElement("div", {
    className: "k-eyebrow",
    style: {
      marginBottom: 4
    }
  }, eyebrow), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 'var(--text-2xl)',
      lineHeight: 'var(--leading-2xl)',
      fontWeight: 600,
      letterSpacing: '-0.011em'
    }
  }, title), meta && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      marginTop: 6,
      fontSize: 'var(--text-xs)',
      color: 'var(--text-tertiary)',
      flexWrap: 'wrap'
    }
  }, meta)), actions && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flex: 'none',
      paddingTop: 4
    }
  }, actions)), tabs);
}

/** Scrolling canvas under the page header. */
function PageBody({
  children,
  pad = true,
  gap = 16
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: 'auto',
      padding: pad ? '16px 24px 24px' : 0,
      display: 'flex',
      flexDirection: 'column',
      gap
    }
  }, children);
}

/** Program / assertion identity line used in tables. */
function RecordCell({
  primary,
  secondary
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "k-table__primary k-truncate"
  }, primary), secondary && /*#__PURE__*/React.createElement("div", {
    className: "k-table__sub k-truncate"
  }, secondary));
}
Object.assign(window, {
  AppShell,
  PageHeader,
  PageBody,
  RecordCell,
  NAV_SECTIONS
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/console/Shell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/console/data.js
try { (() => {
window.KeelData = {
  org: 'Northbeam Federal',
  user: {
    initials: 'RO',
    name: 'R. Okafor',
    role: 'Assurance lead'
  },
  queue: [{
    id: 'ASR-2291',
    control: 'SC-7(4)',
    title: 'External telecommunications services',
    program: 'Atlas Payments ATO',
    reason: 'Never established',
    state: 'unknown',
    owner: 'Platform Security',
    due: '18 Aug 2026',
    overdue: false
  }, {
    id: 'ASR-2288',
    control: 'IR-4(1)',
    title: 'Automated incident handling',
    program: 'Atlas Payments ATO',
    reason: 'Inherited claim expires in 14 days',
    state: 'expiring',
    owner: 'Detection & Response',
    due: '24 Aug 2026',
    overdue: false
  }, {
    id: 'DEV-118',
    control: 'CM-6(1)',
    title: 'Automated configuration management',
    program: 'Meridian Data Lake',
    reason: 'Deviation open since 06 Aug',
    state: 'deviation',
    owner: 'Data Platform',
    due: '11 Aug 2026',
    overdue: true
  }, {
    id: 'ASR-2274',
    control: 'AC-6(9)',
    title: 'Log use of privileged functions',
    program: 'Meridian Data Lake',
    reason: 'Never established',
    state: 'unknown',
    owner: 'Data Platform',
    due: '21 Aug 2026',
    overdue: false
  }, {
    id: 'ASR-2270',
    control: 'SI-4(2)',
    title: 'Automated system-wide intrusion detection',
    program: 'Harbor Identity',
    reason: 'Routed for re-verification',
    state: 'inflight',
    owner: 'Detection & Response',
    due: '02 Sep 2026',
    overdue: false
  }, {
    id: 'ASR-2264',
    control: 'CP-9(1)',
    title: 'Testing for reliability and integrity',
    program: 'Harbor Identity',
    reason: 'Never established',
    state: 'unknown',
    owner: 'Platform Security',
    due: '09 Sep 2026',
    overdue: false
  }, {
    id: 'DEV-115',
    control: 'AU-9(3)',
    title: 'Cryptographic protection of audit information',
    program: 'Atlas Payments ATO',
    reason: 'Deviation awaiting AO decision',
    state: 'deviation',
    owner: 'Platform Security',
    due: '13 Aug 2026',
    overdue: true
  }, {
    id: 'ASR-2259',
    control: 'RA-5(5)',
    title: 'Privileged access for vulnerability scanning',
    program: 'Meridian Data Lake',
    reason: 'Inherited claim expires in 26 days',
    state: 'expiring',
    owner: 'Platform Security',
    due: '05 Sep 2026',
    overdue: false
  }, {
    id: 'ASR-2251',
    control: 'MA-4(6)',
    title: 'Cryptographic protection of maintenance',
    program: 'Harbor Identity',
    reason: 'Never established',
    state: 'unknown',
    owner: 'Infrastructure',
    due: '12 Sep 2026',
    overdue: false
  }, {
    id: 'ASR-2248',
    control: 'PE-3(1)',
    title: 'Physical access to information systems',
    program: 'Atlas Payments ATO',
    reason: 'Routed to facilities for evidence',
    state: 'inflight',
    owner: 'Facilities',
    due: '16 Sep 2026',
    overdue: false
  }],
  programs: [{
    id: 'atlas',
    name: 'Atlas Payments ATO',
    system: 'atlas-payments',
    baseline: 'fedramp-mod',
    version: '4.2.1',
    ao: 'D. Whitfield',
    due: '30 Nov 2026',
    state: 'inflight',
    coverage: {
      validated: 218,
      inherited: 96,
      inflight: 12,
      expiring: 9,
      deviation: 4,
      unknown: 31
    }
  }, {
    id: 'meridian',
    name: 'Meridian Data Lake',
    system: 'meridian-dl',
    baseline: 'fedramp-mod',
    version: '4.2.0',
    ao: 'D. Whitfield',
    due: '14 Jan 2027',
    state: 'deviation',
    coverage: {
      validated: 164,
      inherited: 121,
      inflight: 6,
      expiring: 4,
      deviation: 7,
      unknown: 68
    }
  }, {
    id: 'harbor',
    name: 'Harbor Identity',
    system: 'harbor-idp',
    baseline: 'nist-800-53r5',
    version: '2.0.0',
    ao: 'K. Adeyemi',
    due: '28 Feb 2027',
    state: 'unknown',
    coverage: {
      validated: 96,
      inherited: 74,
      inflight: 9,
      expiring: 2,
      deviation: 1,
      unknown: 142
    }
  }, {
    id: 'ledger',
    name: 'Ledger Reporting SOC 2',
    system: 'ledger-rpt',
    baseline: 'soc2-cc',
    version: '1.7.3',
    ao: 'A. Brandt',
    due: '19 Oct 2026',
    state: 'validated',
    coverage: {
      validated: 61,
      inherited: 38,
      inflight: 1,
      expiring: 0,
      deviation: 0,
      unknown: 3
    }
  }],
  controls: [{
    control: 'AC-2(1)',
    title: 'Automated account management',
    state: 'validated',
    provenance: 'Program',
    owner: 'Platform Security',
    age: '12d',
    evidence: 3
  }, {
    control: 'AC-6(9)',
    title: 'Log use of privileged functions',
    state: 'validated',
    provenance: 'Program',
    owner: 'Platform Security',
    age: '31d',
    evidence: 2
  }, {
    control: 'AU-6(3)',
    title: 'Correlate audit record repositories',
    state: 'inherited',
    provenance: 'Org assertion',
    owner: 'Detection & Response',
    age: '61d',
    evidence: 4
  }, {
    control: 'AU-9(3)',
    title: 'Cryptographic protection of audit information',
    state: 'deviation',
    provenance: 'Program',
    owner: 'Platform Security',
    age: '4d',
    evidence: 1
  }, {
    control: 'CM-6(1)',
    title: 'Automated configuration management',
    state: 'validated',
    provenance: 'Program',
    owner: 'Infrastructure',
    age: '9d',
    evidence: 6
  }, {
    control: 'CP-9(1)',
    title: 'Testing for reliability and integrity',
    state: 'unknown',
    provenance: '—',
    owner: 'Unassigned',
    age: '—',
    evidence: 0
  }, {
    control: 'IA-2(1)',
    title: 'Multifactor authentication to privileged accounts',
    state: 'inherited',
    provenance: 'Org assertion',
    owner: 'Harbor Identity',
    age: '22d',
    evidence: 5
  }, {
    control: 'IR-4(1)',
    title: 'Automated incident handling',
    state: 'expiring',
    provenance: 'Org assertion',
    owner: 'Detection & Response',
    age: '351d',
    evidence: 2
  }, {
    control: 'RA-5(5)',
    title: 'Privileged access for vulnerability scanning',
    state: 'inherited',
    provenance: 'Org assertion',
    owner: 'Platform Security',
    age: '44d',
    evidence: 3
  }, {
    control: 'SC-7(4)',
    title: 'External telecommunications services',
    state: 'unknown',
    provenance: '—',
    owner: 'Unassigned',
    age: '—',
    evidence: 0
  }, {
    control: 'SC-13',
    title: 'Cryptographic protection',
    state: 'inherited',
    provenance: 'Org assertion',
    owner: 'Platform Security',
    age: '78d',
    evidence: 2
  }, {
    control: 'SI-4(2)',
    title: 'Automated system-wide intrusion detection',
    state: 'inflight',
    provenance: 'Program',
    owner: 'Detection & Response',
    age: '2d',
    evidence: 1
  }, {
    control: 'SI-7(1)',
    title: 'Integrity checks of software and firmware',
    state: 'waived',
    provenance: 'Waiver WVR-31',
    owner: 'Infrastructure',
    age: '120d',
    evidence: 1
  }, {
    control: 'PE-3(1)',
    title: 'Physical access to information systems',
    state: 'inflight',
    provenance: 'Program',
    owner: 'Facilities',
    age: '6d',
    evidence: 0
  }],
  assertions: [{
    id: 'ORG-014',
    title: 'Production boundary is segmented',
    owner: 'Platform Security',
    state: 'validated',
    validated: '04 Feb 2026',
    cadence: '180d',
    programs: 6,
    controls: 11
  }, {
    id: 'ORG-021',
    title: 'FIPS-validated cryptography in transit and at rest',
    owner: 'Platform Security',
    state: 'validated',
    validated: '19 Jan 2026',
    cadence: '365d',
    programs: 8,
    controls: 7
  }, {
    id: 'ORG-008',
    title: 'Central audit log correlation across production',
    owner: 'Detection & Response',
    state: 'expiring',
    validated: '24 Aug 2025',
    cadence: '365d',
    programs: 5,
    controls: 9
  }, {
    id: 'ORG-030',
    title: 'Workforce MFA on all privileged access',
    owner: 'Harbor Identity',
    state: 'validated',
    validated: '11 Mar 2026',
    cadence: '180d',
    programs: 9,
    controls: 5
  }, {
    id: 'ORG-033',
    title: 'Quarterly access recertification',
    owner: 'Governance',
    state: 'inflight',
    validated: '—',
    cadence: '90d',
    programs: 4,
    controls: 3
  }],
  baselines: [{
    id: 'fedramp-mod',
    name: 'FedRAMP Moderate',
    version: '4.2.1',
    class: 'Cloud service · moderate',
    controls: 370,
    assertions: 14,
    programs: 6,
    updated: '02 Aug 2026',
    drift: 3
  }, {
    id: 'nist-800-53r5',
    name: 'NIST 800-53 rev 5',
    version: '2.0.0',
    class: 'Federal system · high',
    controls: 412,
    assertions: 18,
    programs: 3,
    updated: '11 Jun 2026',
    drift: 0
  }, {
    id: 'soc2-cc',
    name: 'SOC 2 Common Criteria',
    version: '1.7.3',
    class: 'Commercial · trust services',
    controls: 103,
    assertions: 9,
    programs: 4,
    updated: '28 May 2026',
    drift: 0
  }, {
    id: 'cmmc-l2',
    name: 'CMMC Level 2',
    version: '0.9.4',
    class: 'Defense supplier',
    controls: 110,
    assertions: 6,
    programs: 1,
    updated: '17 Jul 2026',
    drift: 1
  }, {
    id: 'internal-sec',
    name: 'Northbeam Internal Security',
    version: '3.1.0',
    class: 'Internal · all systems',
    controls: 64,
    assertions: 12,
    programs: 11,
    updated: '30 Jul 2026',
    drift: 0
  }],
  diff: [{
    kind: 'changed',
    was: 'scan cadence every 365 days',
    text: 'scan cadence every 180 days',
    meta: 'RA-5(5) · 3 programs inherit a claim this tightens'
  }, {
    kind: 'added',
    text: 'AU-6(3) Correlate audit record repositories',
    meta: 'New in 4.2.1 · 6 programs affected · no evidence on record'
  }, {
    kind: 'added',
    text: 'SC-7(4) External telecommunications services — deny by default',
    meta: 'New in 4.2.1 · 6 programs affected'
  }, {
    kind: 'changed',
    was: 'evidence: attestation accepted',
    text: 'evidence: automated scan required',
    meta: 'CM-6(1) · 2 programs must replace their evidence'
  }, {
    kind: 'removed',
    text: 'PE-18 Location of information system components',
    meta: 'Withdrawn in 4.2.1 · 6 programs · claims retired, not revoked'
  }, {
    kind: 'context',
    text: 'AC-2(1) Automated account management'
  }, {
    kind: 'context',
    text: 'IA-2(1) Multifactor authentication to privileged accounts'
  }],
  impact: [{
    program: 'Atlas Payments ATO',
    from: '4.2.0',
    drops: 4,
    adds: 2,
    state: 'inflight',
    ao: 'D. Whitfield'
  }, {
    program: 'Meridian Data Lake',
    from: '4.2.0',
    drops: 7,
    adds: 2,
    state: 'deviation',
    ao: 'D. Whitfield'
  }, {
    program: 'Cove Analytics',
    from: '4.1.6',
    drops: 11,
    adds: 2,
    state: 'unknown',
    ao: 'A. Brandt'
  }, {
    program: 'Beacon Notifications',
    from: '4.2.0',
    drops: 2,
    adds: 2,
    state: 'validated',
    ao: 'K. Adeyemi'
  }, {
    program: 'Tidewater Storage',
    from: '4.2.0',
    drops: 3,
    adds: 2,
    state: 'validated',
    ao: 'D. Whitfield'
  }, {
    program: 'Quay Message Bus',
    from: '4.1.6',
    drops: 9,
    adds: 2,
    state: 'expiring',
    ao: 'A. Brandt'
  }],
  discoveries: [{
    id: 'DSC-441',
    title: 'Egress from prod runs through a single inspected gateway',
    program: 'Atlas Payments ATO',
    found: '06 Aug 2026',
    evidence: 4,
    scope: 'All systems in the production boundary',
    controls: 6,
    state: 'inflight',
    reviewer: 'Platform Security'
  }, {
    id: 'DSC-438',
    title: 'All prod databases enforce customer-managed keys',
    program: 'Meridian Data Lake',
    found: '31 Jul 2026',
    evidence: 3,
    scope: 'All data-tier systems',
    controls: 4,
    state: 'inflight',
    reviewer: 'Data Platform'
  }, {
    id: 'DSC-433',
    title: 'Break-glass accounts are time-boxed and recorded',
    program: 'Harbor Identity',
    found: '24 Jul 2026',
    evidence: 5,
    scope: 'All systems',
    controls: 3,
    state: 'validated',
    reviewer: 'Governance'
  }, {
    id: 'DSC-427',
    title: 'Build provenance attested for every deployed artifact',
    program: 'Atlas Payments ATO',
    found: '12 Jul 2026',
    evidence: 2,
    scope: 'Systems built on the shared pipeline',
    controls: 5,
    state: 'unknown',
    reviewer: 'Unassigned'
  }],
  activity: [{
    when: '11 Aug 2026 · 09:14',
    who: 'R. Okafor',
    what: 'Routed SC-7(4) to Platform Security for assurance.'
  }, {
    when: '10 Aug 2026 · 16:02',
    who: 'System',
    what: 'fedramp-mod@4.2.1 published. 6 programs flagged for rebase review.'
  }, {
    when: '08 Aug 2026 · 11:47',
    who: 'L. Marchetti',
    what: 'Recorded deviation DEV-118 on CM-6(1) — Meridian Data Lake.'
  }, {
    when: '06 Aug 2026 · 08:30',
    who: 'S. Nakamura',
    what: 'Opened discovery DSC-441 from Atlas Payments evidence.'
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/console/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Banner = __ds_scope.Banner;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.CoverageBar = __ds_scope.CoverageBar;

__ds_ns.DataTable = __ds_scope.DataTable;

__ds_ns.DiffRow = __ds_scope.DiffRow;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.KeyValue = __ds_scope.KeyValue;

__ds_ns.MetricTile = __ds_scope.MetricTile;

__ds_ns.ProvenanceTrail = __ds_scope.ProvenanceTrail;

__ds_ns.StatusPill = __ds_scope.StatusPill;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Field = __ds_scope.Field;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.Breadcrumb = __ds_scope.Breadcrumb;

__ds_ns.Pagination = __ds_scope.Pagination;

__ds_ns.SideNav = __ds_scope.SideNav;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Toolbar = __ds_scope.Toolbar;

__ds_ns.ToolbarDivider = __ds_scope.ToolbarDivider;

__ds_ns.TopBar = __ds_scope.TopBar;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Drawer = __ds_scope.Drawer;

__ds_ns.DrawerSection = __ds_scope.DrawerSection;

__ds_ns.Menu = __ds_scope.Menu;

__ds_ns.MenuAnchor = __ds_scope.MenuAnchor;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.ToastStack = __ds_scope.ToastStack;

__ds_ns.Tooltip = __ds_scope.Tooltip;

})();
