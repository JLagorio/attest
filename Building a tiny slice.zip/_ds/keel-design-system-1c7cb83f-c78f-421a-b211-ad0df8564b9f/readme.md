# Keel — Design System

Keel is the working name for a **data-dense GRC platform** in the class of Drata, Vanta and eMASS —
built for organizations that carry many systems through many frameworks at once, and that are tired of
proving the same fact over and over.

> A program should not have to prove something the organization already knows unless something relevant changed.

The platform turns reusable **organizational assurance** into versioned **product/system baselines**,
instantiates those baselines into **programs**, makes **deviations and unknowns explicit**, routes
unresolved assurance work to the right people, and **promotes validated discoveries** back into the
reusable knowledge base.

## Sources used to build this system

**None were supplied.** No codebase, Figma file, repository, slide deck, screenshot or brand asset was
attached to this brief — only the product description above. Everything here was authored from that
description and is therefore a *proposal*, not a recreation:

| Thing | Status |
| --- | --- |
| Brand name "Keel" | **Invented here.** Rename freely — it appears in the wordmark, `readme`, `SKILL.md` and the UI kit only. |
| Logo / brand mark | **None exists.** The wordmark is plain type (IBM Plex Sans Condensed Bold, uppercase). Nothing was drawn or reconstructed. Supply real artwork and drop it in `assets/`. |
| Typefaces | IBM Plex Sans / Condensed / Mono, pulled from Google Fonts. **Substitution flagged** — no font binaries were provided. |
| Icons | Lucide (ISC licence), copied in full to `assets/icons/` — 91 glyphs. Not redrawn. |
| Product screens | Modelled on the described domain object model, not on real screens. |

If a real codebase, Figma library or brand kit exists, re-attach it and this system should be rebuilt
against it — the tokens, components and kit here are a defensible starting point, not ground truth.

## The domain, in the words the UI uses

Keel's vocabulary is the product. Every screen, label and status uses these terms and no synonyms.

- **Organizational assertion** — a fact the organization has established once, centrally, and can lend
  out: "our production boundary is segmented", "we run FIPS-validated crypto". Owned by a team, dated,
  and re-verified on a cadence.
- **Baseline** — a versioned, reusable requirement set for a class of product or system
  (`fedramp-mod@4.2.1`). Baselines compose from assertions and controls; they are *pinned*, never
  floating.
- **Program** — a baseline instantiated against a real system, with a real deadline and a real
  authorizing official (Atlas Payments ATO). A program inherits everything it legitimately can.
- **Inheritance** — the mechanism by which a program stops re-proving. Shown as provenance, never as a
  bare green tick: the user can always see *whose* claim they are standing on.
- **Deviation** — the program cannot satisfy the baseline as written. Explicit, owned, justified.
- **Waiver** — accepted risk with an approver and an expiry date. Never permanent.
- **Unknown** — the fact was never established. Keel's most important state: it is drawn, hatched, and
  counted, so that "we never asked" can never hide inside "nothing to report".
- **Discovery** — something learned inside one program that is true more broadly. Discoveries get
  reviewed and **promoted** into organizational assertions, which is how the knowledge base grows.
- **Assurance queue** — the routed work: every unresolved unknown, expiring claim and open deviation,
  assigned to the person who can actually resolve it.

## Content fundamentals

**Voice: a competent colleague reading you the record.** Keel is not enthusiastic, not apologetic, and
never congratulatory. It states what is known, what is not, and what happens next.

- **Person.** Second person for the user's own work ("Your queue", "You approved this on 4 Feb").
  First-person plural is never used — the system does not speak as "we". Records speak in third person
  and name the actor: "Platform Security validated this claim", never "This claim was validated".
- **Tense.** Past tense for facts on the record, present for state, future only with a date attached.
  "Expires 12 Aug 2026", not "will expire soon".
- **Casing.** Sentence case everywhere — buttons, headings, table headers (which are then set in
  small-caps by CSS, not by typing capitals), menu items. The only literal uppercase in the product is
  the wordmark and control identifiers (`SC-7(4)`, `AU-6(3)`).
- **Length.** Buttons are one to three words and start with a verb: "Route for assurance", "Record
  deviation", "Promote to assertion", "Rebase programs". Table cells never wrap to a second line;
  truncate and put the full string in a tooltip.
- **Numbers.** Always with their scope and their denominator: "218 of 370 controls", "87% assured
  · 31 unknown". Never a bare percentage. Dates are `12 Mar 2026` — day, abbreviated month, full year,
  no ordinals, no relative-only times. Relative time may follow an absolute one, never replace it.
- **Emoji: never.** Not in UI, not in empty states, not in toasts. This product is read by auditors.
- **Exclamation marks: never.** Not even in success messages.
- **Empty states say which kind of empty.** "Queue clear — no assurance work is routed to you right
  now" is a different sentence, and a different graphic treatment, from "No assertion on record —
  nothing upstream covers this control, so the program has to establish it".
- **Errors name the constraint, not the user's mistake.** "Cannot exceed the baseline cadence of 180
  days", not "Invalid value".
- **Destructive and consequential actions state the blast radius before the verb.** "Rebase 6 programs
  onto fedramp-mod@4.2.1?" with the body copy quantifying the change: "18 controls change. 3 programs
  inherit a claim this revision tightens; their assurance drops to unknown until re-verified."
- **Never claim certainty the record does not support.** If a field was never filled in, the UI prints
  "Not recorded" in italic disabled text. A blank cell is a bug.

Sample copy, verbatim from the kit:

> Nothing upstream covers this control, so the program has to establish it.
> Inherited from Northbeam Federal · Boundary segmentation · validated 04 Feb 2026.
> 3 programs inherit a claim this revision tightens.
> Discovery promoted. 6 programs re-evaluated.

## Visual foundations

**The idea:** a light, quiet, extremely dense data canvas held inside dark navigation chrome. The
chrome tells you where you are; the canvas is the brightest thing on screen and holds the record.
Colour is spent almost entirely on *state*, never on decoration.

**Colour.** One cool neutral ramp (`--ink-*`, blue-grey, not warm) carries every surface, border and
text colour. One interaction hue: signal blue `#2563C9` — links, focus, selection, primary buttons, and
nothing else. Five outcome hues, each with exactly one job: green = validated, red = deviation, amber =
expiring, teal = inherited, violet = waived. Grey means unknown. There are no other hues, no tints for
"brand personality", and no gradient anywhere in the system. Backgrounds are flat colour: no imagery,
no illustration, no texture, no full-bleed photography — a GRC console has nothing to illustrate.

**Type.** IBM Plex Sans at 13px base (a reading-dense console, not a marketing page), 450 weight for
body, 500 for emphasis, 600 for headings. IBM Plex Sans **Condensed**, uppercase, 0.06em, for the small
structural labels — table headers, drawer section titles, metric labels, nav groups. IBM Plex **Mono**
for anything an operator copies: control IDs, baseline versions, evidence URIs, hashes. Tabular figures
are on globally so numbers line up in every column. Type scale bottoms out at 10px and nothing smaller
ships.

**Spacing.** 2px base step, with 6px and 10px half-steps because dense tables need them. Cell padding
12px, control gap 8px, card padding 16px, section gap 20px, page gutter 24px. Four control heights
(22/26/30/36) and three row densities (28/34/42) — pick one per surface and hold it.

**Corners.** 2–8px, tight. Controls and badges 3–4px, cards and dialogs 6px, nothing above 8px. Pill
radius exists only for status dots and the switch knob. Nothing in Keel is a rounded "capsule card".

**Borders.** Hairlines do the structural work: `--border-subtle` between rows, `--border-default` on
cards and controls, `--border-strong` on hover. A dashed border always means *unknown or assumed* —
it is never a decorative style.

**Elevation.** Rationed. Cards sit flat on the canvas with a hairline and at most `--shadow-xs`. Real
shadows are reserved for things that genuinely float: menus (`md`), dialogs and drawers (`lg`), sticky
table headers under scroll (`sticky`). Every shadow includes a 1px ring in the same colour family so an
elevated surface still has a hard edge against dense data. There are no inner shadows, no glows.

**The unknown hatch — the one graphic motif.** A 45° 2px repeating hatch (`--pattern-unknown`) marks
any place where a fact was never established: the unknown segment of a coverage bar, an empty evidence
frame, the marker of a broken provenance hop. Absence of knowledge is drawn so it is as visible as a
failure. This is the only pattern in the system; do not invent others.

**Transparency and blur.** Almost none. The only translucent surface is the modal scrim
(`rgba(14,20,28,.48)`), and there is no backdrop blur anywhere — blur costs legibility against small
type. Focus rings are the one other alpha use: a 3px blue ring at 30%.

**Motion.** Confirmation, never decoration. 80ms hover/press, 120ms menus and toggles, 180ms drawer and
dialog entrance, 280ms ceiling. Easing is `cubic-bezier(.2,0,0,1)` — decelerate only. Nothing bounces,
nothing springs, nothing travels more than 8px, nothing loops. Coverage bars animate their width on
data change so a number moving is visible; that is the extent of the theatre. `prefers-reduced-motion`
kills all of it.

**Interaction states.** Hover on a surface = one step up the ink ramp (rows go to `--ink-50`); hover on
a bordered control = border darkens to `--border-strong`. Press = one further step down the ramp, never
a scale transform — nothing in Keel shrinks or lifts under the cursor. Selection is `--blue-50` with a
`--blue-100` hover. Disabled = `--ink-100` fill with `--ink-400` text and no border. Row state stripes
(a 2px inset shadow on the leading cell) appear only for `unknown` and `deviation` rows.

**Layout rules.** The frame is fixed and never moves: 220px nav rail (52px collapsed), 48px top bar,
40px toolbar, 520px record drawer (720px wide variant), 1600px max canvas width, 24px page gutter.
Records open in the right drawer over the list — the operator never loses their place in the queue.
Tables are the default page content; a page that is not a table is a detail view of a row in one.

**Imagery.** There is none, by design. No photography, no illustration, no avatars beyond initials
monograms, no empty-state artwork. If imagery is ever introduced it should be diagrammatic (system
boundaries, inheritance graphs) and drawn in the ink ramp plus at most one outcome hue.

## Iconography

- **Set:** [Lucide](https://lucide.dev) (ISC licence), 24×24 viewBox, 1.5px stroke, round caps and
  joins. **Substitution flagged:** no icon set was supplied with the brief, so Lucide was chosen for
  its stroke weight and neutral, non-illustrative tone. Swap wholesale if the real product uses another
  set.
- **Delivery:** the SVGs are copied into `assets/icons/` (91 glyphs, not linked from a CDN, so the
  system works offline). They are rendered as CSS masks (`tokens/icons.css`), which means every glyph
  inherits `currentColor` — an icon never carries colour of its own. State colour comes from the pill
  or the row around it.
- **Sizes:** 12 / 14 / 16 / 20 / 24px via `.k-icon--xs|sm|md|lg|xl`; 16px is the default and 14px the
  in-table size.
- **Usage:** icons clarify a repeated object type or an icon-only action — they never decorate a
  heading, and they never appear inside prose. Every icon-only button carries a `Tooltip` and an
  `aria-label`.
- **Domain glyphs:** the vocabulary maps to specific glyphs and should stay consistent —
  `building-2` organizational assertion, `layers` baseline, `target` program, `git-merge` promotion,
  `git-compare` rebase diff, `microscope` discovery, `route` routing, `scale` waiver, `gavel`
  authorization, `circle-dashed` unknown, `triangle-alert` deviation, `hourglass` expiring,
  `shield-check` validated.
- **No emoji, ever.** No unicode symbols used as icons either, with two deliberate exceptions inside
  the mono diff gutter: `+`, `−`, `~`.
- **`index.json`** in `assets/icons/` lists every available glyph name.

## What is in this project

```
styles.css              the single entry point consumers link — @import lines only
base.css                reset + the handful of global utilities (.k-mono, .k-eyebrow, .k-unknown-fill)
tokens/                 colors · typography · spacing · elevation · motion · fonts · icons
components/             React primitives, grouped by concern (see below)
guidelines/             21 foundation specimen cards (the Design System tab)
ui_kits/console/        the product recreation — 5 screens, click-through
templates/              starting folders consuming projects can copy
assets/icons/           91 Lucide SVGs + index.json
thumbnail.html          project tile
SKILL.md                Agent Skills entry point
```

### Components

Import from the compiled namespace (`window.<Namespace>.<Name>`); every component has a sibling
`.d.ts` for its props and a `.prompt.md` for when to use it.

**Core** (`components/core/`) — `Button`, `IconButton`, `Icon`, `Badge`, `Tag`, `Card`, `Banner`

**Forms** (`components/forms/`) — `Field`, `Input`, `Textarea`, `Select`, `Checkbox`, `Radio`, `Switch`

**Data** (`components/data/`) — `StatusPill`, `DataTable`, `CoverageBar`, `MetricTile`, `KeyValue`,
`DiffRow`, `ProvenanceTrail`, `EmptyState`

**Navigation** (`components/navigation/`) — `SideNav`, `TopBar`, `Tabs`, `Breadcrumb`, `Toolbar`
(+ `ToolbarDivider`), `Pagination`

**Overlay** (`components/overlay/`) — `Drawer` (+ `DrawerSection`), `Dialog`, `Menu` (+ `MenuAnchor`),
`Tooltip`, `Toast` (+ `ToastStack`)

**Intentional additions.** No source defined a component inventory, so this is an authored set sized to
the described product. Two entries exist for domain reasons rather than convention: `StatusPill` (the
seven-state assurance vocabulary, which a generic Badge cannot enforce) and `ProvenanceTrail` (the
inheritance chain, which is the product's core explanation surface). `DiffRow` and `CoverageBar` are
likewise domain-specific rather than standard library components.

### UI kit

`ui_kits/console/` — the Keel console: **Assurance queue**, **Program detail**, **Baseline library**,
**Rebase review**, **Discovery promotion**. `index.html` is click-through: navigate the rail, filter
and sort tables, open records in the drawer, run a rebase, promote a discovery.

### Templates

`templates/console-screen/` — **Console screen**: the full Keel app frame (dark rail, top bar, page
header, filter toolbar, dense record table) wired to the real components, ready to have its data and
columns swapped out.

## Known gaps — please fix these with real material

1. **Brand.** Name, wordmark and colour choices are proposals. No logo file exists; nothing was drawn.
2. **Fonts.** IBM Plex is loaded from Google Fonts. Supply licensed `woff2` binaries and replace the
   `@import` in `tokens/fonts.css` with local `@font-face` rules.
3. **Icons.** Lucide substituted for an unknown real set.
4. **Screens.** The console is modelled from the product description, not from real screens or code.
