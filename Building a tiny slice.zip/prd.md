PROGRAM ASSURANCEPLATFORM
Product Requirements Document
Product thesis
A program should not have to prove something the organization already knows unless something relevant changed. The platform turns reusable organizational assurance into versioned product/system baselines, instantiates those baselines into programs, makes deviations and unknowns explicit, routes unresolved assurance work to the right people, and promotes validated discoveries back into the reusable knowledge base.
Field
Value
Status
Draft for product/engineering review
Version
0.1
Date
August 10, 2026
Audience
Product, Systems Security Engineering, Security/GRC, System Engineering, HW/FW/SW Engineering, Assessment, Program Leadership
Working title
Program Assurance Platform
This document defines the product operating model, primary user experience, data ownership model, domain architecture, workflows, MVP boundaries, and phased roadmap for an internal governance, risk, compliance, and assurance platform supporting physical products composed of hardware, firmware, software, services, policies, and processes.
# Contents
1. Executive Summary
2. Product Context and Problem
3. Product Vision, Principles, and Boundaries
4. Users, Roles, and Governance
5. Core Domain Model
6. Information Architecture and Navigation
7. Organizational Knowledge Library
8. Control Profiles, Tailoring, and Customer Requirements
9. Product and System Baselines
10. Program Creation Experience
11. System Onboarding and Discovery
12. Program Delta and Impact Analysis
13. Assurance Workspace and Work Assignment
14. Evidence, Verification, and Assessment
15. Change Management, Versioning, and Invalidation
16. Bottom-Up Learning and Promotion
17. End-to-End UX Example
18. Functional Requirements
19. Non-Functional Requirements
20. MVP and Delivery Sequence
21. Metrics and Instrumentation
22. Migration and Adoption
23. Risks and Design Decisions
24. Open Questions
Appendix A. Status Models
Appendix B. Object Ownership / RACI
Appendix C. Standards Alignment Notes
# 1. Executive Summary
The problem is not a lack of compliance artifacts. It is that assurance knowledge is repeatedly recreated inside program-specific workbooks, making every program act as though the organization has never built, evaluated, or proven anything before.
The proposed platform establishes a reusable, versioned body of organizational assurance knowledge and uses it as the starting point for product/system baselines and program execution. A program receives two distinct starting points: (1) an effective control/requirements profile describing what must be satisfied, and (2) one or more system/product baselines describing what the delivered systems are believed to contain and how those systems normally satisfy obligations. The program workflow reconciles those two sides, exposes deltas and unknowns, and converts every unresolved gap into owned work.
Primary value loop
Establish reusable truth
Build system/product baseline
Create program
Declare deltas + unknowns
Route assurance work
Assess + learn
Promote reusable knowledge
## 1.1 North-star outcome
North-star
Given a program deadline, applicable control obligations, system architecture, organization knowledge, and customer-specific requirements, the platform should tell the team what is already known, what changed, what is unknown, what remains to be proven, who owns each unresolved item, and whether the program is on a credible path to assurance readiness.
## 1.2 Key product decisions
Unknown is a valid state. Missing architecture, components, mappings, or evidence must never be silently interpreted as compliant, not applicable, or absent.
Inheritance is reference-based and versioned. Programs consume pinned versions of organizational and product knowledge; they do not fork copies merely to use them.
Control profile and system baseline are separate. “What must be satisfied?” and “What is the system?” evolve independently and meet inside the program.
Programs are delta-driven. Existing systems are reviewed for variation and applicability rather than rebuilt from a blank control matrix.
New systems are allowed to be incomplete. A program can create a system with unknown architecture and progressively resolve it through assigned discovery work.
Organizational knowledge can grow bottom-up. Program-created components, capabilities, implementation patterns, requirements, and evidence can be submitted for governed promotion.
OSCAL is an interoperability/schema alignment layer, not the user experience. The UI uses product/program/security language familiar to the organization while preserving mappings to standards models where useful.
## 1.3 Initial product surface
Space
Purpose
Primary users
Programs
Plan and execute program assurance against deadlines; manage systems, deltas, unresolved work, and readiness.
Program SSEs, program leadership, engineers, assessors
Products & Systems
Maintain reusable standard product/system baselines and architecture definitions.
Product security, system engineering, product owners
Library
Maintain approved reusable controls, profiles, requirements, components, capabilities, implementation patterns, and evidence.
GRC/security, capability owners, library stewards
Work
Role-based queue of unresolved discovery, implementation, evidence, review, assessment, and decision tasks.
Everyone contributing to assurance
Assurance
Cross-program reporting, assessment status, evidence health, recurring gaps, and organizational learning.
Security/GRC leadership, program leadership
# 2. Product Context and Problem
## 2.1 Current-state pattern
Programs use workbooks and program-specific analysis to determine applicable controls, document system implementations, collect evidence, and meet customer or authorization deadlines. Physical products are frequently variants of established products, but the assurance analysis is often recreated at the program level. Reusable organizational knowledge is fragmented across workbooks, documents, SMEs, engineering systems, and historical program artifacts.
Programs repeatedly map controls to implementations that are substantially the same across product variants.
Program workbooks become local sources of truth and drift from product/system architecture and from each other.
Customer-specific requirements are mixed with baseline requirements without clear provenance or override semantics.
An inherited product may be only partially documented, causing false confidence when “baseline” is treated as complete.
Brand-new systems cannot benefit from inheritance and often begin with a blank spreadsheet rather than a guided discovery workflow.
GRC/security teams must ask engineers for information ad hoc because unresolved architecture and assurance work is not represented as assignable product work.
Evidence is frequently attached to a program or control without explicit applicability conditions, making reuse risky.
Program discoveries rarely improve the canonical organizational baseline, so the same gap is rediscovered later.
## 2.2 Primary product problem
Problem statement
The organization lacks a system that can separate reusable assurance knowledge from program-specific truth, instantiate that knowledge safely into program-specific system models, expose uncertainty and change, and orchestrate the remaining work required to reach an assurance decision by a deadline.
## 2.3 Jobs to be done
Actor
Job to be done
Program SSE
When a new program starts, rapidly determine what applies, what systems exist, what can be inherited, what is different, and what work must be completed before the program milestone.
System Security / Product Security
Establish reusable security architecture and implementation knowledge once, with clear conditions and evidence, so programs can safely leverage it.
HW/FW/SW Engineer
Answer targeted technical questions or provide implementation/evidence without becoming a compliance-framework expert.
GRC / Governance
Maintain approved control sources, tailoring policy, organizational profiles, and reusable requirements while retaining provenance and approvals.
Assessor
Understand the effective program baseline, implementation source, evidence lineage, deviations, and unresolved items without reconstructing history.
Program Leader
Know whether assurance work is on the critical path, who owns blockers, and what risks threaten the target date.
# 3. Product Vision, Principles, and Boundaries
## 3.1 Vision
Create an internal assurance operating system for physical products and programs: a structured graph of obligations, systems, components, capabilities, implementations, evidence, decisions, and work that compounds organizational knowledge instead of resetting it at the start of each program.
## 3.2 Product principles
Principle
Meaning
Establish once, reuse safely
Reusable truth should be authored and reviewed at the highest valid scope, then referenced by products/systems/programs with explicit applicability and versioning.
Delta over repetition
A variant program should focus human attention on differences, assumptions, unknowns, invalidated inheritance, and newly applicable obligations.
Provenance over convenience
Every effective requirement, parameter, implementation, evidence item, and decision must explain where it came from and why it applies.
Unknown over invented certainty
Incomplete information is represented explicitly and converted into discovery work; absence is never interpreted as satisfaction.
Human authority for assurance decisions
Automation may propose mappings, impact, or routing, but acceptance, applicability, tailoring, implementation claims, and assessment determinations remain attributable to authorized humans or authoritative imported sources.
Program urgency without program lock-in
Programs can create local objects quickly; reusable promotion happens later through governance without blocking execution.
Source systems remain authoritative where appropriate
The platform orchestrates assurance; it should integrate with PLM/ALM/SCM/test/document systems over time rather than becoming the master for every engineering datum.
Standards-compatible, workflow-native
OSCAL and NIST-aligned semantics inform the data model and interchange, but users work in organization-specific product/program language.
## 3.3 Product boundaries
In scope
Out of scope / not initially the system of record
Program security/assurance planning, system modeling, control/requirement applicability, reusable component/capability knowledge, implementation assertions, evidence lineage, assignment/work, assessment state, change impact, and readiness reporting.
Detailed hardware design, source code, CI/CD execution, PLM configuration control, enterprise document storage, general-purpose issue tracking, full contract lifecycle management, and replacing engineering ALM/requirements tools.
Program-specific customer requirement capture and mapping.
Interpreting legal/contract language without human review or asserting contractual authority automatically.
System/product baselines sufficient for assurance reuse.
Creating a complete digital twin of every product.
OSCAL-aligned import/export where valuable.
Exposing OSCAL structures as the primary UI or requiring users to hand-author OSCAL.
# 4. Users, Roles, and Governance
## 4.1 Product roles
Role
Primary responsibility
Governance / Control Steward
Owns control catalogs, organization profiles, tailoring policy, canonical requirement sources, and approval of baseline changes.
Library Steward
Curates reusable organizational components, capabilities, implementation patterns, evidence, and promotion requests.
Capability Owner / SME
Owns reusable capability/component knowledge and attests implementation conditions and evidence.
Product Security Lead
Owns the security baseline for a product/product family and publication of product/system baseline versions.
System Architect / System Owner
Defines system boundary, architecture, component inventory, interfaces, and technical ownership.
Program SSE / Program Security Lead
Creates program assurance context, validates inheritance, owns program-level tailoring/allocations, routes unresolved work, and drives readiness.
Engineering Contributor
Resolves targeted architecture, implementation, configuration, verification, or evidence work.
Assessor / Reviewer
Performs or approves assessments, validates evidence, records findings, and makes effectiveness determinations within delegated authority.
Program Manager / Leadership
Consumes readiness, deadline risk, blockers, and critical-path views; generally not an editor of technical assurance truth.
## 4.2 Object ownership model
Permissions should follow object ownership and delegated authority rather than job title alone. A team or named role owns each canonical object. Program-local objects may be authored quickly, while promotion into a broader scope requires the owner of the destination scope.
Scope
Can create
Can approve/publish
Organization profile / policy
Governance/control steward
Governance authority
Organization component/capability
Capability owner, library steward, submitted from program
Capability owner + library steward as configured
Reusable evidence
Evidence producer/owner
Evidence owner/reviewer
Product/system baseline
Product security + system engineering
Product baseline owner / security authority
Program requirement/override
Program SSE, customer requirement intake
Program security/governance per policy
Program system/component
Program SSE, system owner, engineering contributors
Program/system owner for program scope
Assessment result
Assessor
Assessment authority / configured reviewer
# 5. Core Domain Model
## 5.1 Scope hierarchy
Scope hierarchy
Organization
Product Family
Product Baseline Version
Program
System Instance
Component / Capability
Implementation / Evidence / Work
The hierarchy is intentionally not purely nested. Programs reference organizational knowledge and pinned product/system baseline versions; program-local objects can later be promoted to organizational or product scope.
## 5.2 Canonical objects
Object
Definition
Typical scope
Control Catalog
Authoritative collection of controls from NIST or another control source.
Organization / imported
Control
A control or control enhancement from an authoritative source.
Catalog
Profile / Baseline
Selected and tailored controls, including parameters and organizational/customer modifications.
Organization, product, or program
Requirement
An internal, customer, contractual, engineering, or security requirement that may map to one or more controls.
Organization/product/program
Product Family
A reusable physical-product family or standard deliverable architecture.
Organization
Product Baseline Version
Published, immutable definition of a product configuration sufficient for assurance inheritance.
Product
System Template / Baseline
Reusable definition of a system boundary and expected architecture within a product.
Product/organization
Program
A delivery/contract/mission effort with deadlines, customer requirements, security context, and one or more systems.
Program
System Instance
The actual program-scoped system being delivered/analyzed. May be inherited, variant, or new.
Program
Component
Hardware, firmware/software, service, policy, process, procedure, or other implementation element.
Organization/product/program
Capability
A reusable grouping of components/capabilities that collectively delivers a security/assurance function.
Organization/product/program
Implementation Assertion
A statement describing how a system/component/capability supports or satisfies a requirement/control under stated conditions.
Organization/product/program
Evidence
Artifact or structured result supporting an implementation or assessment assertion, with provenance and applicability conditions.
Organization/product/program
Assessment
A review/test/examination and resulting effectiveness determination against an obligation/implementation.
Program or reusable validation
Finding
Observed deficiency, risk, gap, or required remediation from an assessment.
Program/system
Work Item
Assignable unit of discovery, implementation, evidence, review, assessment, or decision work.
Program/organization
Promotion Request
Governed proposal to move program/product-local knowledge into a reusable higher scope.
Cross-scope
## 5.3 Critical semantic separations
Do not collapse these concepts
Control != requirement != implementation != component != capability != evidence != assessment. Likewise, a product baseline != a program system instance, and an inherited assertion != an assessed-effective assertion.
## 5.4 Effective assurance graph
At runtime, the platform computes an effective assurance graph for each program. The graph combines: applicable controls and requirements; system instances; inherited and program-local components/capabilities; implementation assertions; evidence; assessments; and unresolved work. The graph is the source for the program workbook, dashboard, impact analysis, and exports.
# 6. Information Architecture and Navigation
## 6.1 Global navigation
Navigation
What lives here
Home
Personal work, recent programs, overdue decisions, evidence expirations, and cross-program alerts.
Programs
Program portfolio, setup, systems, effective requirements/control profile, work, evidence, assessments, readiness.
Products & Systems
Product families, baseline versions, standard systems, architecture, reusable implementation mappings.
Library
Control catalogs/profiles, requirements, components, capabilities, implementation patterns, evidence, assessment procedures.
Work
My work, team work, unassigned items, blocked items, due soon, submitted for review.
Assurance
Cross-program posture, recurring gaps, baseline health, evidence health, promotion candidates, change blast radius.
Admin
Roles, routing rules, source integrations, approval policy, object schemas, import/export configuration.
## 6.2 Program information architecture
Program page / tab
Primary content
Overview
Target milestone, readiness dimensions, systems, critical path, top blockers, changes, decisions required.
Setup
Security context, categorization inputs, source profiles, overlays, customer requirements, effective parameters, roles.
Systems
All system instances; source baseline; completeness; delta state; owner; assurance readiness.
Requirements & Controls
Effective obligations, source/provenance, parameter values, scope/allocation, implementation/evidence state.
Work
All unresolved program work grouped by system, owner, type, due date, criticality.
Evidence
Inherited and program evidence; applicability, freshness, validation, gaps, expirations.
Assessments
Planned/completed assessments, results, findings, remediation, approval state.
Changes
Architecture/configuration/customer/baseline changes and calculated impact/invalidation.
Decisions
Tailoring, applicability, overrides, risk acceptances, baseline exceptions, with rationale and approval.
Export / Workbook
Program-specific structured workbook/report generated from the live graph.
## 6.3 Program dashboard wireframe
Area
Example content
Header
Nightwing | Customer X | Target: 15 Mar 2028 | Program SSE: Jane | Current assurance milestone
Readiness dimensions
System definition: 82% | Obligation disposition: 71% | Evidence current: 64% | Assessment complete: 42%
Critical path
14 assurance items currently threaten the target date; 3 unassigned; 2 blocked by architecture decisions.
Systems
Falcon Variant - Delta review; Tactical Controller - Definition incomplete; Ground Support - Assessment in progress.
Needs your decision
Customer password parameter override; system boundary question; N/A request; inheritance invalidated by FPGA change.
Recent changes
Bootloader 4.2 -> 4.4; customer requirement CR-118 added; evidence E-441 expires in 30 days.
# 7. Organizational Knowledge Library
## 7.1 Purpose
The Organizational Knowledge Library is the highest reusable scope for approved assurance knowledge. It should not be a prerequisite inventory of everything the company has ever built. It is a governed catalog that starts with the highest-value known knowledge and grows through deliberate authoring, migration of existing artifacts, and promotion from real program work.
## 7.2 Library domains
Library domain
Examples
Primary owner
Control sources
NIST SP 800-53 control catalog, approved internal control catalog.
Governance
Profiles / baselines
Organization security baseline, NSS-oriented profile, overlays, product-specific profile templates.
Governance / security
Requirements
Reusable internal product security requirements and standard parameter defaults.
Security architecture / governance
Components
Approved reusable HW/FW/SW/service/process/policy components with versions/models.
Engineering/capability owners
Capabilities
Secure boot, secure update, key management, vulnerability management, provisioning.
Capability owners
Implementation patterns
Reusable control/requirement satisfaction statements with conditions.
Security SMEs / capability owners
Evidence
Reusable test results, validations, architecture artifacts, procedures, policies, certifications.
Evidence owners
Assessment procedures
Reusable test/examine/interview procedures and expected evidence.
Assessment/security
## 7.3 How the library gets populated over time
Library population loop
Import authoritative sources
Migrate high-value known baselines
Create reusable capabilities/components
Onboard real program
Create missing local knowledge
Submit reusable candidates
Review + promote
Future programs inherit
Bootstrap, not boil-the-ocean. Seed the library with authoritative control sources, organization profiles, the most reused product families, and a small number of high-reuse security capabilities.
Program-local creation is always allowed. If Program Nightwing uses a component not in the library, the program can create it immediately as a program-scoped component.
Promotion is explicit. A program object only becomes organizational truth after submission, deduplication, ownership assignment, review, and publication.
Canonicalization preserves lineage. When a program-local object is promoted or matched to an approved library object, the program reference is re-linked without rewriting historical authorship or dates.
## 7.4 Component/capability authoring experience
Library authors should not start from OSCAL fields. The editor should ask product-native questions: what is this thing, who owns it, what versions/configurations are covered, what capabilities does it participate in, what requirements/controls can it support, under what conditions, what evidence supports those claims, and how should programs validate applicability?
Section
Fields / UX
Identity
Name, type, owner, model/version range, lifecycle state, source system link.
Scope
Organization/product/program scope; classification/marking metadata as required.
Applicability
Required hardware/software/configuration/environment assumptions; excluded contexts.
Relationships
Part of capabilities; depends on components/services; used by product baselines.
Assurance mappings
Requirements/controls supported; implementation assertions; confidence/review status.
Evidence
Reusable evidence, validation dates, expiration/refresh rules, evidence owner.
Assessment
Recommended verification procedure or imported test definition.
History
Versions, supersession, change log, impacted products/programs.
# 8. Control Profiles, Tailoring, and Customer Requirements
## 8.1 Control source vs. effective program profile
The user experience must distinguish a control catalog from a selected/tailored baseline. NIST SP 800-53 is treated as a control source/catalog; an organization or program selects and tailors the applicable set using the organization’s approved security process. For NSS contexts, the product must support the organization’s CNSSI 1253-derived categorization and control-selection workflow and retain the authoritative inputs and decisions used to establish the applicable program profile.
## 8.2 Profile layering model
Effective program obligation layering
Authoritative catalog(s)
Organization profile
Product profile / overlay
Program security context
Customer requirements
Program tailoring decisions
Effective program profile
Layering must preserve provenance. The system does not flatten away the reason a requirement exists. Users can always inspect the source stack and the decision that produced the effective value.
## 8.3 Organization-defined parameters and customer overrides
Parameter values should be modeled as scoped assertions, not overwritten strings. A program may inherit an organizational default and then receive a customer-specific value. The platform computes a proposed effective value but requires review when sources conflict or when “stricter” cannot be determined mechanically.
Source
Example value
State
Organization baseline
Password minimum length = 15
Inherited default
Product baseline
No modification
Inherited
Customer requirement CR-118
Password minimum length = 24
Program-specific source
Program decision
Effective value = 24
Approved with rationale
Precedence rule
Do not hard-code “customer always wins” or “largest number wins.” The system may propose a likely resolution, but effective values require policy-aware adjudication when sources conflict, weaken a requirement, use different scope, or are not semantically comparable.
## 8.4 Customer requirement intake
Classification
System behavior
Parameter modification
Map to an existing control/requirement parameter; retain customer source; require approval of effective value.
Strengthening requirement
Map to existing control/requirement and add program-specific requirement text/acceptance criteria.
New requirement
Create a program-specific requirement and map to controls/capabilities where appropriate.
Conflicting requirement
Flag for decision; do not auto-resolve; show impacted controls/systems.
Unmapped / ambiguous
Create triage item assigned to Program SSE or security SME.
Not security-related
Retain outside assurance scope or link to external requirements system as configured.
## 8.5 Tailoring UX
The default experience should show the resolved program profile and exceptions, not hundreds of raw profile operations. Advanced users can inspect source selection, inclusions/exclusions, parameter modifications, overlays, and decision history. Proposed N/A or exclusion actions require rationale, scope, approver, and affected requirement/system information.
# 9. Product and System Baselines
## 9.1 Why a second baseline is required
A program’s control profile answers what must be satisfied. A product/system baseline answers what the organization believes the standard product contains and how it normally satisfies those obligations. Keeping these separate prevents a “baseline” from ambiguously meaning both security requirements and product architecture.
## 9.2 Product model
Object
Purpose
Product Family
Stable identity for a product line or reusable physical-product architecture.
Product Baseline Version
Immutable published configuration such as Falcon v6.
System Template
One or more assurance boundaries that normally exist inside the product baseline.
Baseline Component Set
Expected HW/FW/SW/services/processes used by the system template.
Baseline Capabilities
Reusable security/assurance capabilities consumed by the system.
Baseline Implementation Assertions
Known mappings from obligations to implementations, including conditions.
Baseline Evidence References
Evidence potentially reusable when program applicability conditions hold.
## 9.3 Who builds and publishes a baseline
Stage
Owner
Workflow
Create draft product/system model
Product Security + System Engineering
Start from existing product architecture, prior program, imported inventory, or blank template.
Populate components/capabilities
System engineering + capability owners
Select from library; add product-local components where required.
Map implementations
Security architecture / SMEs
Attach reusable implementation assertions and applicability conditions.
Attach reusable evidence
Evidence owners / security
Reference evidence; define validity conditions and refresh rules.
Resolve unknowns
Assigned engineering/system owners
Close required architecture/documentation gaps before publication threshold.
Publish baseline version
Configured product baseline owner
Freeze the version; future changes create a new version or revision according to policy.
## 9.4 Baseline completeness
A baseline may exist before it is complete. The product must expose baseline maturity so programs understand what they are inheriting. Recommended dimensions are architecture completeness, component identification, capability mapping, implementation coverage, evidence coverage, and review freshness. Publication policy may require thresholds for “approved reusable baseline,” while draft baselines remain usable with explicit warnings.
# 10. Program Creation Experience
## 10.1 Design goal
Creating a program should produce a usable assurance plan, not an empty container. The setup flow gathers enough context to establish effective obligations, systems, inherited knowledge, responsible roles, and the first set of unresolved work. The flow is resumable; incomplete setup is allowed and visibly represented.
## 10.2 Program setup wizard
Step
Experience
1. Program basics
Name, customer/mission, target milestone, key dates, program manager, Program SSE/security lead.
2. Security context
NSS/non-NSS context as configured; categorization inputs; environment/mission attributes; applicable organization policy.
3. Control sources & overlays
Organization profile, product overlay, CNSSI-derived selection inputs as applicable, additional framework/customer overlays.
4. Customer requirements
Import/upload/enter customer requirements; classify, map, parameterize, or send to triage.
5. Systems
Select known product/system baselines, create variants, or create new/incomplete systems.
6. Ownership
Assign system owners, engineering leads, capability owners, reviewers, assessors; apply routing defaults.
7. Review effective plan
Show obligation count, inheritance sources, unknowns, conflicts, unassigned items, and planned work.
8. Launch
Instantiate program graph, pin baseline versions, create work items, notify owners, generate initial workbook/workspace.
## 10.3 System selection during setup
Choice
When used
System behavior
Use existing baseline
Program delivers a known standard product/system with no expected structural change.
Instantiate system from pinned baseline; require confirmation of key applicability assumptions.
Create variant
Program is a known product with customer/program modifications.
Instantiate baseline plus explicit delta workspace; impact analysis starts from declared differences.
Create new system
No trusted reusable baseline exists.
Create incomplete system with Unknown states and guided discovery tasks.
Import legacy program system
Existing workbook/data describes the program.
Create program-scoped objects, map known fields, mark unmapped/ambiguous content for triage.
## 10.4 Launch gating
A program should not be blocked from launch because every system is fully modeled. The minimum launch gate is: program identity, security lead, target milestone, at least one control-selection source or explicit “pending,” at least one system placeholder, and ownership for unresolved setup decisions. The platform then creates work to finish definition.
# 11. System Onboarding and Discovery
## 11.1 System is a first-class assurance boundary
A system instance is the unit against which architecture, control allocation, implementation, evidence, and assessment are reconciled. A program may contain multiple systems, including systems instantiated from different product baselines and systems that do not exist yet.
## 11.2 New/incomplete system UX
System page area
Behavior
Overview
Definition completeness, assurance readiness, owner, boundary status, key unknowns, blocked decisions.
Architecture
Boundary, interfaces, trust relationships, environment, major subsystems, external dependencies.
Components
HW/FW/SW/service/process inventory with source, version, scope, owner, confidence, and unknown placeholders.
Capabilities
Reusable capabilities consumed or program-local capabilities under development.
Requirements & Controls
Allocated obligations and current implementation/evidence status.
Evidence
Evidence by implementation/assessment; inherited vs local; stale/invalidated/missing.
Changes
Declared architecture/configuration changes and impact results.
## 11.3 Unknown model
Unknown type
Example
Generated work
Unknown component
Processor/SoC has not been selected.
Discovery task to hardware lead: identify production component and target decision date.
Unknown version/config
Bootloader known, production version unknown.
Confirm configuration/version with firmware lead.
Unknown boundary
External key service may be in or out of system boundary.
Boundary decision assigned to SSE/system architect.
Unknown implementation
Applicable authentication requirement has no implementation mapping.
Implementation analysis assigned to system security + SW owner.
Unknown evidence
Implementation believed present but no current proof identified.
Evidence request to implementation/evidence owner.
Unknown applicability
Control scope unclear for system.
Applicability decision assigned to Program SSE/reviewer.
## 11.4 Progressive system construction
New system maturation
Create system placeholder
Define boundary + owners
Identify major components
Select/create capabilities
Allocate requirements
Map implementations
Collect/validate evidence
Assess
Publish reusable candidate baseline
## 11.5 Program-created components
When an engineer identifies a component that does not exist in the Organizational Library, they create a program-scoped component with the minimum known fields. Matching suggests possible canonical duplicates. The program can proceed immediately. A library steward or capability owner later decides whether to promote, merge, or retain the component as program-specific.
# 12. Program Delta and Impact Analysis
## 12.1 Variant workflow
For a system instantiated from an existing baseline, the primary onboarding experience is not a blank architecture editor. It is a confirmation and delta review. The UI shows inherited architecture and asks the program to confirm unchanged areas, declare modifications/additions/removals, and identify unknowns.
Delta state
Meaning
Confirmed unchanged
Program has affirmed that a baseline element and its relevant applicability assumptions remain true.
Changed
Baseline element differs; new value/component/configuration is recorded.
Added
Program introduces a new component/capability/interface/requirement.
Removed
Baseline element is not present in the program system.
Unknown
Program cannot yet confirm whether the inherited assertion holds.
Not reviewed
No human confirmation yet; inheritance remains provisional according to policy.
## 12.2 Impact engine
Impact analysis traverses the assurance graph from a changed node to dependent requirements, controls, implementation assertions, evidence, assessment results, and program milestones. The engine does not automatically declare noncompliance; it changes the confidence/validity state and creates review work.
Example blast radius
TPM Y -> TPM Z
Secure Boot capability condition violated
Inherited implementation becomes Impacted
Evidence applicability questioned
Affected controls/requirements flagged
Revalidation work assigned
## 12.3 Impact classifications
Classification
Meaning
Default action
No known impact
Change does not intersect documented assurance dependencies.
Record change; no new work.
Review required
Dependency exists but impact cannot be determined automatically.
Create review work.
Implementation invalidated
An inherited implementation’s applicability condition is false.
Require new/updated implementation.
Evidence invalidated
Evidence no longer supports the program configuration.
Require replacement/revalidation.
New obligation
Change causes additional requirement/control applicability.
Add effective obligation and route work.
Assessment stale
Change occurred after relevant assessment.
Require assessor/reviewer determination.
# 13. Assurance Workspace and Work Assignment
## 13.1 Product concept
The workbook becomes a work queue
The program assurance workspace is a live, structured view of effective obligations and their implementation/evidence/assessment state. Rows are not merely documentation. Every unresolved row can generate actionable work with an owner, due date, blocking relationship, and “why this matters” trace.
## 13.2 Program assurance row
Field
Example
Obligation
REQ-IAM-014 / mapped control
Source
Organization profile + Customer CR-118
Effective parameter
Password minimum = 24
Scope
Tactical Management Controller
Implementation
Unknown
Evidence
None
Assessment
Not ready
State
Action required
Owner
System Software Lead
Due
Program milestone-derived date
Why
Customer requirement + applicable control; blocks security design review
## 13.3 Work item types
Work type
Purpose
Discovery
Find missing system/component/configuration/boundary information.
Applicability decision
Determine whether an obligation or inherited implementation applies.
Implementation
Design/build/change system behavior or document the implementation.
Evidence request
Produce, link, or refresh evidence.
Review / attestation
Confirm inherited configuration, implementation assertion, or evidence applicability.
Assessment
Execute test/examine/interview and record result.
Decision
Resolve customer conflict, tailoring, N/A, exception, risk acceptance, or baseline choice.
Promotion review
Decide whether program-local knowledge becomes reusable organization/product knowledge.
## 13.4 Assignment and routing
The platform should create work automatically where deterministic gaps exist, then route it using configurable rules. Program SSEs can override routing. Auto-assignment should prefer object ownership (component/capability/system owner) before generic role routing.
Trigger
Default route
Unknown hardware component
System hardware lead / configured HW owner
Unknown firmware version
Firmware owner
Missing control implementation
Program SSE + system security owner
Reusable capability applicability confirmation
Capability owner or delegated reviewer
Missing/expired reusable evidence
Evidence/capability owner
Customer requirement conflict
Program SSE + governance/security reviewer
Proposed N/A/tailoring exception
Program SSE -> configured approver
Assessment required
Assigned assessor/reviewer
Promotion candidate
Destination library/product owner
## 13.5 Engineering contributor experience
Engineering contributors should receive narrow tasks that explain the technical question, system context, due date, and downstream impact without requiring them to understand the full compliance framework. A task may ask “Identify production SoC for Tactical Controller” or “Provide evidence that firmware signature verification fails closed” and show which program milestone is blocked.
## 13.6 Work states
Work lifecycle
New
Assigned
In progress
Blocked
Submitted
Under review
Accepted / Closed
Rejected/submitted-back work returns to In Progress with reviewer rationale. All assignment, due-date, and state changes are auditable.
# 14. Evidence, Verification, and Assessment
## 14.1 Evidence is not a file attachment
Evidence is a structured assurance object with provenance, owner, source, creation time, supported assertion(s), system/component/capability context, applicability conditions, validity/expiration semantics, and review status. The binary/document may remain in an external document/test system.
## 14.2 Evidence scopes
Scope
Example
Reuse rule
Organization reusable
FIPS validation, corporate signing procedure, reusable secure-boot verification suite.
Reusable only when stated applicability conditions hold.
Product/system baseline
Falcon v6 architecture review or standard configuration test.
Available to programs inheriting that baseline, subject to program delta validation.
Program-specific
Customer FPGA test, Nightwing architecture review, deployment-specific configuration output.
Applies only to declared program scope unless promoted.
Machine-generated
Build/test/scanner/configuration result from integrated source.
Validity based on source integrity, version/config match, and configured freshness.
## 14.3 Evidence applicability conditions
Covered component/capability identity and version or version range.
Required configuration state or feature flag.
Required dependent components/services.
Environment or deployment assumptions.
Test target/build/release identifier where applicable.
Validity period / refresh cadence when evidence is time-sensitive.
Assessment/reviewer who accepted the evidence for reuse, when policy requires.
## 14.4 Evidence states
Evidence lifecycle
Draft / unreviewed
Current
Expiring
Expired
Impacted
Invalidated
Superseded
## 14.5 Assessment
Assessment is separate from implementation and evidence. The presence of an implementation assertion or evidence does not automatically mean a control is effective. Assessments reference the effective program profile, target systems/components, procedures, evidence, assessor, date, findings, and resulting determination. Assessment work can leverage reusable validation but must preserve the program-specific conclusion.
## 14.6 Readiness dimensions
Avoid one fake compliance percentage
The product should display separate readiness dimensions: system-definition completeness, obligation disposition/implementation coverage, evidence coverage/freshness, assessment completion/effectiveness, and unresolved critical-path work. A single percentage can be shown only as a secondary summary if its calculation and limitations are transparent.
# 15. Change Management, Versioning, and Invalidation
## 15.1 Version pinning
Programs must pin the versions of organization profiles, product/system baselines, components/capabilities, and reusable evidence they relied on at a point in time. Changes to canonical objects after program instantiation do not silently rewrite historical program truth.
## 15.2 Upstream change notifications
When a new canonical version is published, affected programs receive an impact notification. The program can remain pinned, explicitly adopt the new version, or selectively reconcile changes according to policy. Adoption generates a delta review before inherited assurance is updated.
## 15.3 Invalidation rules
Change
Potential result
Component version change
Implementation/evidence conditions re-evaluated; impacted assertions require review.
Capability implementation change
Programs using the capability are identified; evidence and assessment freshness may be impacted.
Organization profile revision
Programs are notified of control/parameter changes; adoption policy determines whether active programs must update.
Customer requirement change
Effective program obligations recomputed; conflicts and impacted systems/work surfaced.
Evidence expiry/revocation
All consuming programs show evidence health degradation and create refresh/review work.
System boundary/interface change
Control allocation and inherited implementation applicability require review.
# 16. Bottom-Up Learning and Promotion
## 16.1 Goal
Programs are where the organization encounters real variations, missing components, customer demands, and implementation gaps. The product should convert validated program discoveries into candidate reusable knowledge without allowing unreviewed program data to become organizational truth automatically.
## 16.2 Promotion candidates
Program object
Possible destination
New reusable component
Organizational Component Library
New capability / implementation pattern
Organizational capability library
Repeated program requirement
Product baseline or organization requirement set
Program-specific evidence with broader applicability
Product or organization evidence library
Improved assessment procedure
Organization assessment procedure library
Repeated product delta
New product baseline revision or product variant template
## 16.3 Promotion workflow
Promotion
Program creates local object
System detects reuse candidate / user submits
Deduplicate / compare
Assign destination owner
Review applicability + scope
Approve + publish version
Relink eligible consumers
Promotion does not rewrite prior program facts. It creates a canonical reusable object and establishes lineage to the program artifact that motivated it.
# 17. End-to-End UX Example
## 17.1 Scenario
Program Nightwing will deliver a Falcon-based physical product plus a new Tactical Management Controller to Customer X. The customer imposes a 24-character password requirement where the organization baseline uses 15. The Falcon portion is mostly standard but uses a customer FPGA and a newer bootloader. The Tactical Management Controller has no existing baseline.
## 17.2 Step-by-step experience
Step
User/system behavior
Create program
Program SSE creates Nightwing, assigns target date and security lead.
Establish security context
Selects approved organization profile and completes required NSS/CNSSI-derived context workflow.
Ingest customer requirements
CR-118 is classified as a password parameter modification; effective value 24 is proposed and approved with provenance.
Add Falcon system
User chooses “Create variant from Falcon v6.” Baseline components, capabilities, implementations, and evidence references are pinned.
Declare deltas
Customer FPGA added; bootloader 4.2 -> 4.4; production signing configuration marked Unknown.
Calculate impact
Secure-boot implementation/evidence affected by FPGA and bootloader changes; review tasks generated.
Add new system
User creates Tactical Management Controller with no baseline. System definition starts incomplete.
Assign discovery
Unknown SoC -> HW lead; bootloader -> firmware lead; key-management boundary -> system architect/SSE.
Create local component
HW lead identifies new AMD SoC; it is created at Nightwing scope and immediately usable.
Map capability
SSE assembles program-local secure-boot capability from SoC, bootloader, signing service, and release process.
Collect evidence
Engineering provides verification results; evidence is attached to implementation assertions and reviewed.
Assess
Assessor records results against the effective program profile.
Promote
New reusable SoC component and improved secure-boot pattern are submitted to the Organizational Library; library owners approve selected items.
Next program
A later program can inherit the newly approved knowledge rather than rediscovering it.
## 17.3 Program overview after setup
Dimension
Nightwing example
Systems
Falcon Variant: 1 changed/1 unknown; Tactical Controller: 43% definition complete
Effective obligations
Organization profile + program/customer modifications; full source lineage retained
Inherited assurance
Falcon baseline implementations/evidence available where conditions still hold
Unresolved work
Architecture discovery, implementation review, evidence refresh, customer requirement decisions
Critical path
Items whose due dates or blockers threaten the target milestone
Learning candidates
Program-created objects that may be promoted after validation
# 18. Functional Requirements
Requirements below define the intended product behavior. “MVP” denotes required for the first end-to-end usable release; “P1” is next-priority capability; “P2” is later maturity/integration.
## 18.1 Organization Library
ID
Priority
Requirement
FR-001
MVP
The system shall support versioned control catalogs from authoritative sources without requiring manual control re-entry.
FR-002
MVP
The system shall support organization-authored profiles/baselines that select and tailor controls and parameters.
FR-003
MVP
The system shall allow creation and versioning of reusable components with type, owner, version/model, applicability, relationships, and lifecycle state.
FR-004
MVP
The system shall allow creation and versioning of capabilities composed of components and/or other capabilities.
FR-005
MVP
The system shall support reusable implementation assertions mapping requirements/controls to components/capabilities with applicability conditions.
FR-006
MVP
The system shall support reusable evidence objects linked to implementation assertions and applicability conditions.
FR-007
P1
The system shall detect possible duplicate components/capabilities during program-local creation and promotion.
FR-008
P1
The system shall support reusable assessment procedures and validation records.
## 18.2 Profiles, Requirements, and Tailoring
ID
Priority
Requirement
FR-009
MVP
The system shall distinguish control catalog, organization profile, product overlay/profile, and effective program profile.
FR-010
MVP
The system shall preserve source/provenance for each selected control, requirement, parameter value, inclusion/exclusion, and tailoring decision.
FR-011
MVP
The system shall support program-specific customer requirements as first-class objects.
FR-012
MVP
The system shall support mapping a customer requirement to an existing requirement/control, to a parameter modification, or to a new program-specific requirement.
FR-013
MVP
The system shall flag conflicting parameter/requirement sources for human adjudication rather than silently resolving them.
FR-014
MVP
The system shall record effective program parameter values with source stack, rationale, reviewer, and date.
FR-015
P1
The system shall support import of customer requirements from structured spreadsheet templates and retain original source references.
FR-016
P2
The system shall support assisted classification/mapping proposals while requiring human acceptance before mappings become authoritative.
## 18.3 Product/System Baselines
ID
Priority
Requirement
FR-017
MVP
The system shall support product families and immutable published product baseline versions.
FR-018
MVP
A product baseline shall support one or more reusable system templates/baselines.
FR-019
MVP
System baselines shall reference reusable and product-local components/capabilities, implementation assertions, and evidence.
FR-020
MVP
The system shall expose baseline completeness/maturity and unresolved unknowns.
FR-021
MVP
Publishing a baseline shall preserve its version and prevent silent mutation of programs pinned to that version.
FR-022
P1
The system shall compare product baseline versions and show assurance-relevant changes.
## 18.4 Program Creation
ID
Priority
Requirement
FR-023
MVP
The system shall provide a resumable guided program setup experience including identity, target milestone, security context, profiles/overlays, customer requirements, systems, and roles.
FR-024
MVP
The system shall allow program launch while some security/system information remains Unknown, subject to minimum configured launch gates.
FR-025
MVP
The system shall pin source profile and product/system baseline versions at program launch.
FR-026
MVP
The system shall allow adding systems by using an existing baseline, creating a variant, or creating a new system from scratch.
FR-027
MVP
The system shall generate initial unresolved work from missing setup information, unassigned ownership, conflicts, and system unknowns.
FR-028
P1
The system shall support migration/import from approved legacy workbook formats.
## 18.5 System Modeling and Discovery
ID
Priority
Requirement
FR-029
MVP
A system instance shall support boundary, owner, architecture, components, capabilities, interfaces/dependencies, and definition status.
FR-030
MVP
The system shall support explicit Unknown placeholders for required but unresolved architecture/component/configuration information.
FR-031
MVP
Each Unknown shall be convertible to an assignable discovery work item with owner and due date.
FR-032
MVP
The system shall allow program-scoped components and capabilities to be created without prior Organizational Library approval.
FR-033
MVP
Program-scoped objects shall retain source and scope and shall not automatically become organizational truth.
FR-034
P1
The system shall calculate and display system-definition completeness separately from assurance compliance/readiness.
## 18.6 Inheritance and Delta
ID
Priority
Requirement
FR-035
MVP
A program system instantiated from a baseline shall inherit references to baseline architecture, components, capabilities, implementation assertions, and available evidence.
FR-036
MVP
The system shall distinguish inherited-unreviewed, confirmed-unchanged, changed, added, removed, and Unknown baseline elements.
FR-037
MVP
The system shall provide a delta review UI optimized for confirming differences rather than rebuilding the system.
FR-038
MVP
Changes shall trigger impact traversal across dependent implementations, evidence, requirements/controls, assessments, and work.
FR-039
MVP
Impact shall create review/invalidation states, not automatic noncompliance determinations.
FR-040
P1
The system shall support bulk confirmation of low-risk inherited elements with policy-configured attestation.
## 18.7 Work and Assignment
ID
Priority
Requirement
FR-041
MVP
The system shall represent unresolved assurance activities as first-class work items.
FR-042
MVP
Work items shall include type, system/object context, rationale, owner, due date, status, dependencies/blockers, and reviewer where applicable.
FR-043
MVP
The system shall support configurable routing rules based on system ownership, component/capability ownership, work type, and program role.
FR-044
MVP
Program SSEs shall be able to reassign, prioritize, and sequence work.
FR-045
MVP
Engineering contributors shall have a simplified work experience focused on the requested technical action and its deadline/impact.
FR-046
P1
The system shall derive critical-path assurance work from due dates, blockers, and program milestones.
## 18.8 Evidence and Assessment
ID
Priority
Requirement
FR-047
MVP
Evidence shall include provenance, owner, supported assertion(s), scope, applicability, creation/validation date, freshness, and lifecycle state.
FR-048
MVP
The system shall distinguish inherited, product/system, program-specific, and machine-generated evidence.
FR-049
MVP
Evidence applicability shall be re-evaluated when relevant system/component/configuration conditions change.
FR-050
MVP
The system shall support assessment records separate from implementation and evidence.
FR-051
MVP
Assessment records shall capture target, procedure/method, assessor, date, evidence used, determination, and findings.
FR-052
P1
Evidence expiry or invalidation shall notify consuming programs and create refresh/review work according to policy.
## 18.9 Promotion and Learning
ID
Priority
Requirement
FR-053
MVP
Users shall be able to submit program-local components, capabilities, requirements, implementations, or evidence for promotion to a higher scope.
FR-054
MVP
Promotion shall require destination ownership, review, and approval and shall preserve origin lineage.
FR-055
P1
The system shall surface repeated program-local patterns as candidate baseline improvements.
FR-056
P1
Approved promoted objects shall be available to future products/programs without rewriting historical programs.
## 18.10 Reporting, Export, and Interoperability
ID
Priority
Requirement
FR-057
MVP
The system shall generate a program workbook/view from the live assurance graph including source, implementation, evidence, state, owner, and outstanding work.
FR-058
MVP
Users shall be able to filter/export program assurance data for existing review workflows.
FR-059
MVP
The underlying model shall retain stable identifiers and mappings sufficient for OSCAL-aligned catalog/profile/component/SSP interoperability.
FR-060
P1
The system shall support OSCAL profile import/export for supported program/profile workflows.
FR-061
P1
The system shall support OSCAL component-definition aligned import/export for reusable component/capability assurance knowledge.
FR-062
P2
The system shall support OSCAL SSP/assessment artifacts where they align with organizational authorization workflows.
## 18.11 Audit, Search, and Permissions
ID
Priority
Requirement
FR-063
MVP
Every material object/state change shall record actor, timestamp, old/new value, source, and rationale when required.
FR-064
MVP
The system shall support role/object-scope permissions and approval gates.
FR-065
MVP
Users shall be able to search controls, requirements, systems, components, capabilities, evidence, programs, and work with cross-object navigation.
FR-066
MVP
Every inherited or effective assertion shall provide a “Why is this here?” provenance view.
FR-067
P1
Users shall be able to view organizational blast radius: which products/programs depend on a component, capability, profile, or evidence item.
FR-068
P1
The system shall support markings/access restrictions required for sensitive program content without duplicating unrestricted metadata unnecessarily.
# 19. Non-Functional Requirements
ID
Category
Requirement
NFR-001
Auditability
All material assurance changes, approvals, imports, promotions, and assessments must be attributable and historically reconstructable.
NFR-002
Data integrity
References between profiles, systems, components, assertions, evidence, and assessments must preserve referential integrity across versions.
NFR-003
Security
Access control, encryption, secure authentication, authorization, logging, and data-handling controls must match the organization’s internal security policy and information sensitivity.
NFR-004
Performance
Program dashboards and primary work queues should load interactively at realistic program sizes; graph impact calculations may be asynchronous only if state and completion are explicit to the user.
NFR-005
Scalability
Data model must support hundreds of products/programs, thousands of systems/components, and large control/evidence graphs without requiring per-program copies of reusable objects.
NFR-006
Availability
The platform should support routine program execution without creating a single point of failure for source engineering artifacts; external links should degrade gracefully.
NFR-007
Interoperability
Stable identifiers and import/export boundaries must support standards-aligned data exchange and future integrations.
NFR-008
Usability
Non-GRC contributors must be able to resolve assigned work without understanding control-framework syntax.
NFR-009
Explainability
Automation-generated mappings, impact, routing, or suggestions must expose source reasoning/context sufficient for human review; automated proposals are distinguishable from approved truth.
NFR-010
Versioning
Published profiles/baselines/reusable objects must be immutable or versioned so historical program decisions remain reproducible.
# 20. MVP and Delivery Sequence
## 20.1 MVP hypothesis
MVP hypothesis
If the platform can establish a small amount of reusable organizational/product assurance knowledge, instantiate it into a real program, let the program declare differences and unknowns, route unresolved work, and generate a trustworthy program workbook, then it has proven the core value proposition. Everything else can compound on that spine.
## 20.2 Release sequence
Release
Scope
Exit outcome
R0 - Domain spine
Canonical IDs and versions; organization/program/system/component/capability/requirement/control/evidence/work objects; audit trail; permissions.
Foundation only; prove model with seeded data.
R1 - First usable vertical slice
Control catalog/profile, basic organization library, product/system baseline, program creation, new/existing system onboarding, inheritance, Unknown states, program workbook.
Program can start from reusable knowledge rather than blank sheet.
R2 - Delta-driven execution
Customer requirements/parameters, delta UI, impact traversal, work routing, evidence applicability, assessment basics, readiness dashboard.
Program SSE can drive remaining work to deadline.
R3 - Learning organization
Promotion workflows, baseline revisions, cross-program blast radius, evidence health, recurring gap analytics.
Program discoveries improve future programs.
R4 - Interoperability and automation
OSCAL expansion, engineering-source integrations, machine evidence, assisted mappings, advanced continuous assurance.
Reduce manual population and increase freshness.
## 20.3 R1 explicit non-goals
No requirement to inventory every organizational component before first program onboarding.
No automatic compliance determination based on component/evidence presence.
No full replacement for existing engineering systems, Jira, PLM, document repositories, or requirements-management tools.
No need for complete automated customer-requirement parsing/mapping.
No requirement to support every OSCAL assessment/POA&M workflow in the first release.
No single aggregate compliance score used as the primary readiness indicator.
## 20.4 Suggested first pilot
Choose one active program that contains both (a) a recognizable product/system baseline with meaningful reuse potential and (b) at least one program-specific variation or incomplete/new system. Seed only the organization knowledge needed to make that program useful. Use every missing reusable object encountered by the pilot to test the bottom-up promotion workflow.
# 21. Metrics and Instrumentation
Metric
Definition
Program startup time
Elapsed time from program creation to a credible effective obligation/system/work plan.
Reuse rate
Share of accepted implementations/evidence originating from approved reusable organization/product knowledge.
Delta focus
Share of human review effort spent on changed/unknown/impacted items vs. full baseline re-analysis.
Ownership coverage
Percent of unresolved assurance work with accountable owner and due date.
Unknown burn-down
Count/age of system-definition Unknowns by program milestone.
Evidence health
Share of evidence current, expiring, expired, impacted, or missing.
Assessment readiness
Applicable obligations with accepted implementation/evidence sufficient to enter assessment.
Promotion yield
Program-local objects promoted to reusable scope and subsequently reused by other programs.
Repeat-gap rate
Frequency the same missing implementation/evidence/requirement is rediscovered across programs.
Deadline risk
Assurance work on critical path or forecast to miss configured milestones.
Initial releases should instrument these measures before assigning aggressive targets. The pilot establishes baseline performance and validates which metrics correlate with actual program outcomes.
# 22. Migration and Adoption
## 22.1 Migration strategy
Import authoritative control sources and create the organization’s first approved profile(s).
Select one or two high-reuse product/system baselines and migrate only the assurance knowledge necessary to support a pilot program.
Import/migrate existing program workbook data into program-scoped objects where practical; flag ambiguous mappings instead of inventing certainty.
Use pilot gaps to create program-local components/capabilities/requirements/evidence and exercise promotion.
Publish the first reusable product/system baseline version after the pilot exposes missing fields and workflows.
Expand coverage by product family based on reuse value, not organizational completeness.
Integrate high-value source systems only after object ownership and workflows are stable.
## 22.2 Legacy workbook coexistence
The product should initially coexist with established program workbook/report expectations. The live structured graph is authoritative inside the platform, while an export produces the familiar program-specific workbook view. Over time, review workflows can move into the application without forcing a big-bang process change.
## 22.3 Adoption guardrails
Never require engineers to manually learn control IDs to answer a technical task.
Never require a complete Organizational Library before a program can create missing objects.
Never import legacy blank cells as “not applicable.”
Never auto-promote program-local facts without an owner and review.
Never silently apply upstream baseline changes to active programs.
Never hide the source and approval history of an effective requirement or assurance assertion.
# 23. Risks and Design Decisions
Risk
Failure mode
Mitigation
Ontology over-design
Too many object types can slow MVP and confuse users.
Keep UI workflow-centric; expose advanced distinctions only where they prevent real traceability/reuse errors.
False inheritance confidence
Programs may trust a baseline that is stale or incomplete.
Show baseline maturity, pin versions, require confirmation, model Unknown, and re-evaluate applicability conditions.
Library garbage growth
Bottom-up creation can produce duplicate/low-quality objects.
Program scope first; duplicate suggestions; promotion gates; owner assignment; lifecycle/retirement.
Workbook recreation
Product could become another spreadsheet UI without orchestration.
Make unresolved state generate work; prioritize deadline/blocker views; use workbook as a view/export.
Compliance-by-presence
Component/evidence existence may be mistaken for satisfaction.
Separate implementation, evidence, and assessment; no auto-effectiveness conclusion.
Automation authority creep
AI/mapping logic could silently create compliance truth.
Proposal states + human acceptance + provenance + audit.
Source drift
Engineering source systems and assurance model can diverge.
Add freshness/source links; later integrate high-value sources; create change review on detected mismatch.
Customer complexity
Customer requirements may conflict, duplicate, or fall outside control frameworks.
First-class customer requirement object + triage + explicit effective decision.
Over-broad system model
Attempting a full digital twin could overwhelm product.
Model only architecture/configuration detail needed for assurance applicability, impact, and evidence.
## 23.1 Key decisions locked by this PRD
The Organizational Library can grow from program-created knowledge; it does not need to be complete before program onboarding.
Programs use both an effective control/requirements profile and one or more system/product baselines.
Programs can create new systems with no baseline and progressively build them through assigned discovery.
Product/system baselines are versioned and pinned; program variations are overlays/deltas, not mutations of canonical baselines.
Customer-specific requirements remain first-class sources and may modify parameters or add requirements without rewriting organizational defaults.
Unknown, inherited-unreviewed, impacted, and assessment states are distinct.
The program workbook is generated from structured truth; it is not the underlying data model.
OSCAL informs interoperability/data mappings but does not dictate screen design.
# 24. Open Questions
Topic
Question to resolve
Authority model
Who is authorized to approve program tailoring, customer overrides, N/A decisions, reusable implementation claims, and promotion at each scope?
System boundary policy
How does the organization currently define “system” for program analysis, and can one physical product contain multiple assurance/authorization system boundaries?
CNSSI workflow implementation
Which exact organizational CNSSI 1253 categorization/control-selection procedure, worksheets, overlays, and approvals must the platform reproduce or support?
Product baseline granularity
What constitutes a baseline version change versus a minor revision or configuration parameter?
Evidence validity
Which evidence types expire by time, by component/version change, by assessment event, or only by explicit revocation?
Customer requirements
What are the current authoritative inputs: contract documents, customer workbooks, DOORS/Jama/Jira, spreadsheets, PDFs, or other systems?
Source integration priority
Which source systems can authoritatively provide component/configuration truth: PLM, SBOM, Git, CI, firmware build metadata, asset inventory, document systems?
Assessment workflow
Is the product expected to support formal authorization package production or primarily pre-assessment program readiness in the first releases?
Data sensitivity
What classification/marking/access-control requirements apply to program content, evidence, and cross-program reuse?
Program deadline model
Which milestones should drive work due dates and critical path: SRR/PDR/CDR, authorization gates, customer deliveries, internal readiness reviews, other?
Legacy workbook contract
Which workbook columns/views must remain export-compatible during adoption?
External issue tracking
Should engineering implementation tasks be mirrored to Jira/other tools while assurance tasks remain in-platform?
# Appendix A. Status Models
## A.1 System definition states
State
Meaning
Placeholder
System exists in program planning but boundary/architecture is largely unknown.
Defining
Owners are actively populating boundary, architecture, components, and capabilities.
Sufficiently defined
Configured minimum definition threshold met for current assurance milestone.
Baseline candidate
System has enough validated reusable knowledge to submit as a product/system baseline.
Published baseline
Reusable version is approved and immutable.
Superseded
Newer baseline exists; historical consumers remain pinned.
## A.2 Assurance assertion states
State
Meaning
Unknown
No reliable determination exists.
Inherited - unreviewed
Assertion came from baseline but program applicability has not been confirmed as required.
Inherited - confirmed
Program confirms relevant assumptions remain valid.
Implemented / documented
Implementation assertion exists; not equivalent to assessed effectiveness.
Partially implemented
Some required behavior exists; gap remains.
Planned
Implementation is committed but not complete.
Impacted
Change may invalidate the assertion; review required.
Not implemented
Applicable obligation lacks implementation.
N/A proposed
Program proposes non-applicability; awaiting approval.
N/A approved
Authorized decision recorded with rationale.
Assessed effective
Assessment supports effectiveness within the assessed scope/time.
Assessed ineffective
Assessment found implementation ineffective or deficient.
## A.3 Promotion states
Promotion lifecycle
Program-local
Candidate
Submitted
In review
Approved / merged
Published reusable
Superseded / retired
# Appendix B. Object Ownership / RACI
Object
Responsible
Accountable
Consulted
Informed
Control Catalog
Governance
Governance
SSE / assessors
All
Organization Profile
Governance
Security authority
Program SSE / Product Security
All
Reusable Component
Component/Capability Owner
Library Steward / owner
Engineering / Product Security
Programs
Reusable Capability
Capability Owner
Security/Library owner
Component owners / SSE
Programs
Product/System Baseline
Product Security + System Engineering
Product baseline owner
Capability owners / assessors
Programs
Program Profile
Program SSE
Configured program security approver
Governance / customer stakeholders
Program
Program System
System Owner / Program SSE
Program authority as configured
Engineering / Security
Program
Reusable Evidence
Evidence Owner
Reviewer as configured
Capability owner / assessor
Programs
Program Assessment
Assessor
Assessment authority
Program SSE / system owner
Program leadership
Promotion Request
Submitter + destination owner
Destination owner
Library/Governance/SME
Origin program
# Appendix C. Standards Alignment Notes
This PRD deliberately separates the user-facing workflow from standards representations. The implementation should maintain enough structure and identifiers to support standards-aligned interoperability without requiring the organization to expose standards-native objects directly to every user.
## C.1 NIST SP 800-53
Treat SP 800-53 as a control catalog/source. Organization-defined parameters and tailoring decisions are represented as scoped, versioned values with provenance rather than edits to the source catalog.
## C.2 OSCAL Profile
OSCAL Profile semantics align with the product’s profile/baseline layer: importing selected controls from catalogs/profiles and modifying/tailoring parameters and control content. The UI should present resolved effective program obligations while retaining the underlying source and modification lineage.
## C.3 OSCAL Component Definition
OSCAL Component Definition semantics align with reusable hardware/software/service/policy/process/procedure components, grouping related components into capabilities, and documenting how implementations can support controls. This is a strong interchange target for the Organizational Library and reusable capability knowledge.
## C.4 OSCAL System Security Plan
OSCAL SSP semantics align with program/system-specific descriptions of system characteristics, inventory, applicable profile, responsible roles, and control implementations. The product’s system/program model should be capable of generating or consuming aligned SSP content where the organization requires it.
## C.5 CNSSI 1253
For National Security System workflows, program setup must support the organization’s authoritative CNSSI 1253 categorization and control-selection process and preserve the inputs, selection basis, tailoring decisions, and resulting profile. The exact workflow and required artifacts should be validated with the organization’s security authorities before engineering encodes selection rules.
## C.6 Reference sources consulted for this draft
NIST SP 800-53 Rev. 5, Security and Privacy Controls for Information Systems and Organizations.
NIST OSCAL Control Layer: Profile Model.
NIST OSCAL Implementation Layer: Component Definition Model.
NIST OSCAL Implementation Layer: System Security Plan (SSP) Model.
NIST CSRC definition of organization-defined control parameter / control parameter.
Authoritative CNSS/CNSSI 1253 material to be incorporated according to organizational policy and current controlled references.
# PRD Review Checklist
Before committing the domain model to engineering, the product/security team should be able to walk through the following scenarios without inventing a new object type or bypassing ownership/versioning rules:
Create a program with a known product baseline and no customer changes.
Create a variant where one firmware component changes and inherited evidence may no longer apply.
Create a program with a 24-character customer password requirement overriding a 15-character organizational default.
Create a new system that does not exist yet, assign discovery of its HW/FW/SW architecture, and progress without false compliance states.
Create a component inside a program that is missing from the organization catalog; later promote it safely.
Use a reusable organization capability that spans hardware, firmware/software, and process components.
Show why a specific requirement/control exists, how it is implemented, which evidence supports it, who approved it, and what changed since assessment.
Change a reusable component/capability and identify all programs whose assurance may be impacted without silently modifying their historical state.
Generate the program-specific workbook from structured data and reconcile it with the live work queue.
Close a program and promote validated learning so the next program starts with more organizational knowledge than the previous one.
Definition of a successful foundation
The platform succeeds when a program can begin with incomplete information, safely inherit what is known, make every deviation and unknown explicit, route the remaining work to accountable owners, and leave the organization with more reusable assurance knowledge than it had when the program started.
